// 'use strict';

// //const async = require('async');
// const mongodb = require('../mongodb');
// const ObjectId = require('mongodb').ObjectId;
// const moment = require('moment');
// var sample_user_details_table = "sample_user_details";

// exports.saveUserDetails = function (responseObj, callback) {
//     var db = mongodb.getDB();
//     //console.log("Collection in mongodb************",db);
//     var userscollection = db.collection(sample_user_details_table);
//    // console.log("@@@@@@************",userscollection);
//     responseObj._id = new ObjectId();
//     responseObj.userId = responseObj._id.toHexString();
// 	responseObj.createdAt = moment().toDate();	
// 	userscollection.insertOne(responseObj, function (err, response) {
// 		callback(err, response);
// 	});

// };

// // exports.findUserDetailsById = (userId,callback) =>
// // {
// // 	var db = mongodb.getDB();
// // 	var userscollection = db.collection(sample_user_details_table);
// // 	var query = {_id:new ObjectId(userId)};
// // 	console.log("userDetailsById Query ->", query);
// // 	userscollection.findOne(query,{sort:{_id:-1}},function (err, result) {
// // 		callback(err, result);
// // 	})
// // };

// exports.findUserDetailsById1 = (email,callback) =>
// {
// 	var db = mongodb.getDB();
// 	var userscollection = db.collection(sample_user_details_table);
// 	var query = {email:email};
// 	//console.log("userDetailsById Query ->", email);
// 	userscollection.findOne(query,{sort:{_id:-1}},function (err, result) {
// 		callback(err, result);
// 	})
// };

