(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
  /*!**************************************************!*\
    !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
    \**************************************************/

  /*! no static exports found */

  /***/
  function node_modulesMomentLocaleSyncRecursive$(module, exports, __webpack_require__) {
    var map = {
      "./af": "./node_modules/moment/locale/af.js",
      "./af.js": "./node_modules/moment/locale/af.js",
      "./ar": "./node_modules/moment/locale/ar.js",
      "./ar-dz": "./node_modules/moment/locale/ar-dz.js",
      "./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
      "./ar-kw": "./node_modules/moment/locale/ar-kw.js",
      "./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
      "./ar-ly": "./node_modules/moment/locale/ar-ly.js",
      "./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
      "./ar-ma": "./node_modules/moment/locale/ar-ma.js",
      "./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
      "./ar-sa": "./node_modules/moment/locale/ar-sa.js",
      "./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
      "./ar-tn": "./node_modules/moment/locale/ar-tn.js",
      "./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
      "./ar.js": "./node_modules/moment/locale/ar.js",
      "./az": "./node_modules/moment/locale/az.js",
      "./az.js": "./node_modules/moment/locale/az.js",
      "./be": "./node_modules/moment/locale/be.js",
      "./be.js": "./node_modules/moment/locale/be.js",
      "./bg": "./node_modules/moment/locale/bg.js",
      "./bg.js": "./node_modules/moment/locale/bg.js",
      "./bm": "./node_modules/moment/locale/bm.js",
      "./bm.js": "./node_modules/moment/locale/bm.js",
      "./bn": "./node_modules/moment/locale/bn.js",
      "./bn.js": "./node_modules/moment/locale/bn.js",
      "./bo": "./node_modules/moment/locale/bo.js",
      "./bo.js": "./node_modules/moment/locale/bo.js",
      "./br": "./node_modules/moment/locale/br.js",
      "./br.js": "./node_modules/moment/locale/br.js",
      "./bs": "./node_modules/moment/locale/bs.js",
      "./bs.js": "./node_modules/moment/locale/bs.js",
      "./ca": "./node_modules/moment/locale/ca.js",
      "./ca.js": "./node_modules/moment/locale/ca.js",
      "./cs": "./node_modules/moment/locale/cs.js",
      "./cs.js": "./node_modules/moment/locale/cs.js",
      "./cv": "./node_modules/moment/locale/cv.js",
      "./cv.js": "./node_modules/moment/locale/cv.js",
      "./cy": "./node_modules/moment/locale/cy.js",
      "./cy.js": "./node_modules/moment/locale/cy.js",
      "./da": "./node_modules/moment/locale/da.js",
      "./da.js": "./node_modules/moment/locale/da.js",
      "./de": "./node_modules/moment/locale/de.js",
      "./de-at": "./node_modules/moment/locale/de-at.js",
      "./de-at.js": "./node_modules/moment/locale/de-at.js",
      "./de-ch": "./node_modules/moment/locale/de-ch.js",
      "./de-ch.js": "./node_modules/moment/locale/de-ch.js",
      "./de.js": "./node_modules/moment/locale/de.js",
      "./dv": "./node_modules/moment/locale/dv.js",
      "./dv.js": "./node_modules/moment/locale/dv.js",
      "./el": "./node_modules/moment/locale/el.js",
      "./el.js": "./node_modules/moment/locale/el.js",
      "./en-SG": "./node_modules/moment/locale/en-SG.js",
      "./en-SG.js": "./node_modules/moment/locale/en-SG.js",
      "./en-au": "./node_modules/moment/locale/en-au.js",
      "./en-au.js": "./node_modules/moment/locale/en-au.js",
      "./en-ca": "./node_modules/moment/locale/en-ca.js",
      "./en-ca.js": "./node_modules/moment/locale/en-ca.js",
      "./en-gb": "./node_modules/moment/locale/en-gb.js",
      "./en-gb.js": "./node_modules/moment/locale/en-gb.js",
      "./en-ie": "./node_modules/moment/locale/en-ie.js",
      "./en-ie.js": "./node_modules/moment/locale/en-ie.js",
      "./en-il": "./node_modules/moment/locale/en-il.js",
      "./en-il.js": "./node_modules/moment/locale/en-il.js",
      "./en-nz": "./node_modules/moment/locale/en-nz.js",
      "./en-nz.js": "./node_modules/moment/locale/en-nz.js",
      "./eo": "./node_modules/moment/locale/eo.js",
      "./eo.js": "./node_modules/moment/locale/eo.js",
      "./es": "./node_modules/moment/locale/es.js",
      "./es-do": "./node_modules/moment/locale/es-do.js",
      "./es-do.js": "./node_modules/moment/locale/es-do.js",
      "./es-us": "./node_modules/moment/locale/es-us.js",
      "./es-us.js": "./node_modules/moment/locale/es-us.js",
      "./es.js": "./node_modules/moment/locale/es.js",
      "./et": "./node_modules/moment/locale/et.js",
      "./et.js": "./node_modules/moment/locale/et.js",
      "./eu": "./node_modules/moment/locale/eu.js",
      "./eu.js": "./node_modules/moment/locale/eu.js",
      "./fa": "./node_modules/moment/locale/fa.js",
      "./fa.js": "./node_modules/moment/locale/fa.js",
      "./fi": "./node_modules/moment/locale/fi.js",
      "./fi.js": "./node_modules/moment/locale/fi.js",
      "./fo": "./node_modules/moment/locale/fo.js",
      "./fo.js": "./node_modules/moment/locale/fo.js",
      "./fr": "./node_modules/moment/locale/fr.js",
      "./fr-ca": "./node_modules/moment/locale/fr-ca.js",
      "./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
      "./fr-ch": "./node_modules/moment/locale/fr-ch.js",
      "./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
      "./fr.js": "./node_modules/moment/locale/fr.js",
      "./fy": "./node_modules/moment/locale/fy.js",
      "./fy.js": "./node_modules/moment/locale/fy.js",
      "./ga": "./node_modules/moment/locale/ga.js",
      "./ga.js": "./node_modules/moment/locale/ga.js",
      "./gd": "./node_modules/moment/locale/gd.js",
      "./gd.js": "./node_modules/moment/locale/gd.js",
      "./gl": "./node_modules/moment/locale/gl.js",
      "./gl.js": "./node_modules/moment/locale/gl.js",
      "./gom-latn": "./node_modules/moment/locale/gom-latn.js",
      "./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
      "./gu": "./node_modules/moment/locale/gu.js",
      "./gu.js": "./node_modules/moment/locale/gu.js",
      "./he": "./node_modules/moment/locale/he.js",
      "./he.js": "./node_modules/moment/locale/he.js",
      "./hi": "./node_modules/moment/locale/hi.js",
      "./hi.js": "./node_modules/moment/locale/hi.js",
      "./hr": "./node_modules/moment/locale/hr.js",
      "./hr.js": "./node_modules/moment/locale/hr.js",
      "./hu": "./node_modules/moment/locale/hu.js",
      "./hu.js": "./node_modules/moment/locale/hu.js",
      "./hy-am": "./node_modules/moment/locale/hy-am.js",
      "./hy-am.js": "./node_modules/moment/locale/hy-am.js",
      "./id": "./node_modules/moment/locale/id.js",
      "./id.js": "./node_modules/moment/locale/id.js",
      "./is": "./node_modules/moment/locale/is.js",
      "./is.js": "./node_modules/moment/locale/is.js",
      "./it": "./node_modules/moment/locale/it.js",
      "./it-ch": "./node_modules/moment/locale/it-ch.js",
      "./it-ch.js": "./node_modules/moment/locale/it-ch.js",
      "./it.js": "./node_modules/moment/locale/it.js",
      "./ja": "./node_modules/moment/locale/ja.js",
      "./ja.js": "./node_modules/moment/locale/ja.js",
      "./jv": "./node_modules/moment/locale/jv.js",
      "./jv.js": "./node_modules/moment/locale/jv.js",
      "./ka": "./node_modules/moment/locale/ka.js",
      "./ka.js": "./node_modules/moment/locale/ka.js",
      "./kk": "./node_modules/moment/locale/kk.js",
      "./kk.js": "./node_modules/moment/locale/kk.js",
      "./km": "./node_modules/moment/locale/km.js",
      "./km.js": "./node_modules/moment/locale/km.js",
      "./kn": "./node_modules/moment/locale/kn.js",
      "./kn.js": "./node_modules/moment/locale/kn.js",
      "./ko": "./node_modules/moment/locale/ko.js",
      "./ko.js": "./node_modules/moment/locale/ko.js",
      "./ku": "./node_modules/moment/locale/ku.js",
      "./ku.js": "./node_modules/moment/locale/ku.js",
      "./ky": "./node_modules/moment/locale/ky.js",
      "./ky.js": "./node_modules/moment/locale/ky.js",
      "./lb": "./node_modules/moment/locale/lb.js",
      "./lb.js": "./node_modules/moment/locale/lb.js",
      "./lo": "./node_modules/moment/locale/lo.js",
      "./lo.js": "./node_modules/moment/locale/lo.js",
      "./lt": "./node_modules/moment/locale/lt.js",
      "./lt.js": "./node_modules/moment/locale/lt.js",
      "./lv": "./node_modules/moment/locale/lv.js",
      "./lv.js": "./node_modules/moment/locale/lv.js",
      "./me": "./node_modules/moment/locale/me.js",
      "./me.js": "./node_modules/moment/locale/me.js",
      "./mi": "./node_modules/moment/locale/mi.js",
      "./mi.js": "./node_modules/moment/locale/mi.js",
      "./mk": "./node_modules/moment/locale/mk.js",
      "./mk.js": "./node_modules/moment/locale/mk.js",
      "./ml": "./node_modules/moment/locale/ml.js",
      "./ml.js": "./node_modules/moment/locale/ml.js",
      "./mn": "./node_modules/moment/locale/mn.js",
      "./mn.js": "./node_modules/moment/locale/mn.js",
      "./mr": "./node_modules/moment/locale/mr.js",
      "./mr.js": "./node_modules/moment/locale/mr.js",
      "./ms": "./node_modules/moment/locale/ms.js",
      "./ms-my": "./node_modules/moment/locale/ms-my.js",
      "./ms-my.js": "./node_modules/moment/locale/ms-my.js",
      "./ms.js": "./node_modules/moment/locale/ms.js",
      "./mt": "./node_modules/moment/locale/mt.js",
      "./mt.js": "./node_modules/moment/locale/mt.js",
      "./my": "./node_modules/moment/locale/my.js",
      "./my.js": "./node_modules/moment/locale/my.js",
      "./nb": "./node_modules/moment/locale/nb.js",
      "./nb.js": "./node_modules/moment/locale/nb.js",
      "./ne": "./node_modules/moment/locale/ne.js",
      "./ne.js": "./node_modules/moment/locale/ne.js",
      "./nl": "./node_modules/moment/locale/nl.js",
      "./nl-be": "./node_modules/moment/locale/nl-be.js",
      "./nl-be.js": "./node_modules/moment/locale/nl-be.js",
      "./nl.js": "./node_modules/moment/locale/nl.js",
      "./nn": "./node_modules/moment/locale/nn.js",
      "./nn.js": "./node_modules/moment/locale/nn.js",
      "./pa-in": "./node_modules/moment/locale/pa-in.js",
      "./pa-in.js": "./node_modules/moment/locale/pa-in.js",
      "./pl": "./node_modules/moment/locale/pl.js",
      "./pl.js": "./node_modules/moment/locale/pl.js",
      "./pt": "./node_modules/moment/locale/pt.js",
      "./pt-br": "./node_modules/moment/locale/pt-br.js",
      "./pt-br.js": "./node_modules/moment/locale/pt-br.js",
      "./pt.js": "./node_modules/moment/locale/pt.js",
      "./ro": "./node_modules/moment/locale/ro.js",
      "./ro.js": "./node_modules/moment/locale/ro.js",
      "./ru": "./node_modules/moment/locale/ru.js",
      "./ru.js": "./node_modules/moment/locale/ru.js",
      "./sd": "./node_modules/moment/locale/sd.js",
      "./sd.js": "./node_modules/moment/locale/sd.js",
      "./se": "./node_modules/moment/locale/se.js",
      "./se.js": "./node_modules/moment/locale/se.js",
      "./si": "./node_modules/moment/locale/si.js",
      "./si.js": "./node_modules/moment/locale/si.js",
      "./sk": "./node_modules/moment/locale/sk.js",
      "./sk.js": "./node_modules/moment/locale/sk.js",
      "./sl": "./node_modules/moment/locale/sl.js",
      "./sl.js": "./node_modules/moment/locale/sl.js",
      "./sq": "./node_modules/moment/locale/sq.js",
      "./sq.js": "./node_modules/moment/locale/sq.js",
      "./sr": "./node_modules/moment/locale/sr.js",
      "./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
      "./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
      "./sr.js": "./node_modules/moment/locale/sr.js",
      "./ss": "./node_modules/moment/locale/ss.js",
      "./ss.js": "./node_modules/moment/locale/ss.js",
      "./sv": "./node_modules/moment/locale/sv.js",
      "./sv.js": "./node_modules/moment/locale/sv.js",
      "./sw": "./node_modules/moment/locale/sw.js",
      "./sw.js": "./node_modules/moment/locale/sw.js",
      "./ta": "./node_modules/moment/locale/ta.js",
      "./ta.js": "./node_modules/moment/locale/ta.js",
      "./te": "./node_modules/moment/locale/te.js",
      "./te.js": "./node_modules/moment/locale/te.js",
      "./tet": "./node_modules/moment/locale/tet.js",
      "./tet.js": "./node_modules/moment/locale/tet.js",
      "./tg": "./node_modules/moment/locale/tg.js",
      "./tg.js": "./node_modules/moment/locale/tg.js",
      "./th": "./node_modules/moment/locale/th.js",
      "./th.js": "./node_modules/moment/locale/th.js",
      "./tl-ph": "./node_modules/moment/locale/tl-ph.js",
      "./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
      "./tlh": "./node_modules/moment/locale/tlh.js",
      "./tlh.js": "./node_modules/moment/locale/tlh.js",
      "./tr": "./node_modules/moment/locale/tr.js",
      "./tr.js": "./node_modules/moment/locale/tr.js",
      "./tzl": "./node_modules/moment/locale/tzl.js",
      "./tzl.js": "./node_modules/moment/locale/tzl.js",
      "./tzm": "./node_modules/moment/locale/tzm.js",
      "./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
      "./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
      "./tzm.js": "./node_modules/moment/locale/tzm.js",
      "./ug-cn": "./node_modules/moment/locale/ug-cn.js",
      "./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
      "./uk": "./node_modules/moment/locale/uk.js",
      "./uk.js": "./node_modules/moment/locale/uk.js",
      "./ur": "./node_modules/moment/locale/ur.js",
      "./ur.js": "./node_modules/moment/locale/ur.js",
      "./uz": "./node_modules/moment/locale/uz.js",
      "./uz-latn": "./node_modules/moment/locale/uz-latn.js",
      "./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
      "./uz.js": "./node_modules/moment/locale/uz.js",
      "./vi": "./node_modules/moment/locale/vi.js",
      "./vi.js": "./node_modules/moment/locale/vi.js",
      "./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
      "./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
      "./yo": "./node_modules/moment/locale/yo.js",
      "./yo.js": "./node_modules/moment/locale/yo.js",
      "./zh-cn": "./node_modules/moment/locale/zh-cn.js",
      "./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
      "./zh-hk": "./node_modules/moment/locale/zh-hk.js",
      "./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
      "./zh-tw": "./node_modules/moment/locale/zh-tw.js",
      "./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
    };

    function webpackContext(req) {
      var id = webpackContextResolve(req);
      return __webpack_require__(id);
    }

    function webpackContextResolve(req) {
      if (!__webpack_require__.o(map, req)) {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      }

      return map[req];
    }

    webpackContext.keys = function webpackContextKeys() {
      return Object.keys(map);
    };

    webpackContext.resolve = webpackContextResolve;
    module.exports = webpackContext;
    webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/_components/alert.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/_components/alert.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcApp_componentsAlertComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div *ngIf=\"message\" [ngClass]=\"{ 'alert': message, 'alert-success': message.type === 'success', 'alert-danger': message.type === 'error' }\">{{message.text}}</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<router-outlet></router-outlet>\r\n<app-footer *ngIf=\"router.url != '/login'\"></app-footer>\r\n<div *ngIf=\"aggreymessage\" class=\"col-sm-12 no-margin agree-sec\">\r\n<p>This Website uses cookies to provide you with a personalized browsing experience. By using this Website you agree to our use of cookies as explained in our Privacy Policy. Please read our Privacy Policy for more information on how we use cookies and how you can manage them.</p>\r\n<a (click)=\"createCookie()\">I Agree</a>\t\t\t\t\t\t\t</div>\r\n<div class=\"col-sm-12 no-margin footer-sec\">\r\n<p>© {{year}}&nbsp;| Aragen Life Sciences Private Limited, All Rights Reserved | <a target=\"_blank\" href=\"https://eculelogitracker.gvkbio.com/terms-conditions/\">Terms &amp; Conditions</a> | <a target=\"_blank\" href=\"https://eculelogitracker.gvkbio.com/privacy-policy/\">Privacy Policy</a> </p></div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-add/carriers-add.component.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-add/carriers-add.component.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCarriersAddCarriersAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"carrierForm\" (ngSubmit)=\"onFormSubmit(carrierForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"carrier Name\" formControlName=\"carrier\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!carrierForm.get('carrier').valid && carrierForm.get('carrier').touched\">Please Carrier Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!carrierForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div>{{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-edit/carriers-edit.component.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-edit/carriers-edit.component.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCarriersEditCarriersEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"carrierForm\" (ngSubmit)=\"onFormSubmit(carrierForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"carrier Name\" formControlName=\"carrier\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!carrierForm.get('carrier').valid && carrierForm.get('carrier').touched\">Please Carrier Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!carrierForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-list/carriers-list.component.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-list/carriers-list.component.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCarriersListCarriersListComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->\r\n\r\n<div class=\"container mat-elevation-z8\">\r\n\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Filter Carrier\">\r\n    </mat-form-field>\r\n  </div>\r\n  <button class=\"btn-info btn full-right\" [routerLink]=\"['/carrier-add']\">Add Carrier</button>\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>  \r\n{{Message}}\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    ng update @angular/cli @angular/core\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"id\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Id</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"carrier\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Carrier</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.carrier}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"create_date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Created date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.create_date | date}}</mat-cell>\r\n    </ng-container>\r\n\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\" >Actions        </button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" [routerLink]=\"['/carrier-edit', row.id]\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n \r\n        <button mat-icon-button color=\"accent\" (click)=\"deleteCarrier(row.id)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n  </mat-table>\r\n\r\n<p *ngIf=\"dataSource.filteredData.length === 0\" class=\"no-records text-center\">No records found</p>\r\n  \r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/cha-add/cha-add.component.html":
  /*!**************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cha-add/cha-add.component.html ***!
    \**************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppChaAddChaAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"chaForm\" (ngSubmit)=\"onFormSubmit(chaForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"CHA Name\" formControlName=\"cha_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!chaForm.get('cha_name').valid && chaForm.get('cha_name').touched\">Please CHA Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!chaForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/cha-edit/cha-edit.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cha-edit/cha-edit.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppChaEditChaEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"chaForm\" (ngSubmit)=\"onFormSubmit(chaForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"CHA Name\" formControlName=\"cha_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!chaForm.get('cha_name').valid && chaForm.get('cha_name').touched\">Please CHA Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!chaForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/cha/cha.component.html":
  /*!******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cha/cha.component.html ***!
    \******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppChaChaComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->\r\n\r\n<div class=\"container mat-elevation-z8\">\r\n\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Search By CHA\">\r\n    </mat-form-field>\r\n  </div>\r\n  <button class=\"btn-info btn full-right\" [routerLink]=\"['/cha-add']\">Add country</button>\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>  \r\n{{Message}}\r\n<div class=\"table-responsive\">\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    ng update @angular/cli @angular/core\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"id\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Id</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"cha_name\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>CHA Name</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.cha_name}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"create_date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Created Date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.create_date | date}}</mat-cell>\r\n    </ng-container>\r\n\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\" >Actions</button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" [routerLink]=\"['/cha-edit', row.id]\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n \r\n        <button mat-icon-button color=\"accent\" (click)=\"deletecha(row.id)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n\r\n  </mat-table>\r\n</div>\r\n<p *ngIf=\"dataSource.filteredData.length === 0\" class=\"no-records text-center\">No records found</p>\r\n\r\n\r\n\r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/countries-add/countries-add.component.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/countries-add/countries-add.component.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCountriesAddCountriesAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"countriesForm\" (ngSubmit)=\"onFormSubmit(countriesForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Country Name\" formControlName=\"country\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!countriesForm.get('country').valid && countriesForm.get('country').touched\">Please Country Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!countriesForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/countries-edit/countries-edit.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/countries-edit/countries-edit.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCountriesEditCountriesEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"countriesForm\" (ngSubmit)=\"onFormSubmit(countriesForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Country Name\" formControlName=\"country\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!countriesForm.get('country').valid && countriesForm.get('country').touched\">Please Country Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!countriesForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/countries/countries.component.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/countries/countries.component.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCountriesCountriesComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->\r\n\r\n<div class=\"container mat-elevation-z8\">\r\n\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Search Country\">\r\n    </mat-form-field>\r\n  </div>\r\n  <button class=\"btn-info btn full-right\" [routerLink]=\"['/countries-add']\">Add country</button>\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>  \r\n{{Message}}\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    ng update @angular/cli @angular/core\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"id\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Id</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"country\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Country Name</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.country}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"create_date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Created date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.create_date | date}}</mat-cell>\r\n    </ng-container>\r\n\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\" >\r\n          Actions\r\n        </button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" [routerLink]=\"['/countries-edit', row.id]\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n \r\n        <button mat-icon-button color=\"accent\" (click)=\"DeleteCountry(row.id)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n  </mat-table>\r\n\r\n<p *ngIf=\"dataSource.filteredData.length === 0\" class=\"no-records text-center\">No records found</p>\r\n  \r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/currencies-add/currencies-add.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/currencies-add/currencies-add.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCurrenciesAddCurrenciesAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"currenciesForm\" (ngSubmit)=\"onFormSubmit(currenciesForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Currency Name\" formControlName=\"currency_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!currenciesForm.get('currency_name').valid && currenciesForm.get('currency_name').touched\">Please currency name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Import value\" formControlName=\"import_value\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!currenciesForm.get('import_value').valid && currenciesForm.get('import_value').touched\">Please enter import value</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Import value\" formControlName=\"export_value\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!currenciesForm.get('export_value').valid && currenciesForm.get('export_value').touched\">Please enter export value</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!currenciesForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/currencies-edit/currencies-edit.component.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/currencies-edit/currencies-edit.component.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCurrenciesEditCurrenciesEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"currenciesForm\" (ngSubmit)=\"onFormSubmit(currenciesForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Currency Name\" formControlName=\"currency_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!currenciesForm.get('currency_name').valid && currenciesForm.get('currency_name').touched\">Please currency name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Import value\" formControlName=\"import_value\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!currenciesForm.get('import_value').valid && currenciesForm.get('import_value').touched\">Please enter import value</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Import value\" formControlName=\"export_value\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!currenciesForm.get('export_value').valid && currenciesForm.get('export_value').touched\">Please enter export value</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!currenciesForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/currencies/currencies.component.html":
  /*!********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/currencies/currencies.component.html ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCurrenciesCurrenciesComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->\r\n\r\n<div class=\"container mat-elevation-z8\">\r\n\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Filter Currency\">\r\n    </mat-form-field>\r\n  </div>\r\n  <button class=\"btn-info btn full-right\" [routerLink]=\"['/currencies-add']\">Add Currency</button>\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>  \r\n{{Message}}\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    ng update @angular/cli @angular/core\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"id\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Id</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"currency_name\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Country name</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.currency_name}}</mat-cell>\r\n    </ng-container>\r\n    <ng-container matColumnDef=\"import_value\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Import value</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.import_value}}</mat-cell>\r\n    </ng-container>\r\n    <ng-container matColumnDef=\"export_value\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Export value</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.export_value}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"create_date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Created date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.create_date | date}}</mat-cell>\r\n    </ng-container>\r\n\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\" >\r\n  Actions\r\n        </button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" [routerLink]=\"['/currencies-edit', row.id]\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n \r\n        <button mat-icon-button color=\"accent\" (click)=\"deleteCurrency(row.id)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n  </mat-table>\r\n\r\n<p *ngIf=\"dataSource.filteredData.length === 0\" class=\"no-records text-center\">No records found</p>\r\n  \r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/custom-holidays/custom-holidays.component.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/custom-holidays/custom-holidays.component.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCustomHolidaysCustomHolidaysComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n \r\n<div class=\"example-container mat-elevation-z8\">\r\n  \r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n      <h2 class=\"title-h2\">Customs Holidays </h2>\r\n    <form [formGroup]=\"settingForm\" (ngSubmit)=\"onFormSubmit(settingForm.value)\">\r\n          <mat-form-field class=\"example-full-width\">\r\n        <textarea rows=\"6\" matInput placeholder=\"Description\" formControlName=\"page_description\"\r\n               [errorStateMatcher]=\"matcher\"></textarea>\r\n        <mat-error>\r\n          <span *ngIf=\"!settingForm.get('page_description').valid && settingForm.get('page_description').touched\">Please enter description</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!settingForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/add/add.dialog.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/add/add.dialog.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDialogsAddAddDialogHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"container\">\r\n  <h3 mat-dialog-title>Add new Issue</h3>\r\n\r\n  <form class=\"mat-dialog-content\" (ngSubmit)=\"submit\" #formControl=\"ngForm\">\r\n\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput #input class=\"form-control\" placeholder=\"Compound_DM_Time\" [(ngModel)]=\"data.Compound_DM_Time\" name=\"Compound_DM_Time\" required >\r\n        <mat-error *ngIf=\"formControl.invalid\">{{getErrorMessage()}}</mat-error>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <!--Textarea for demo purposes-->\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput #input class=\"form-control\" placeholder=\"CR_DM_Date\" [(ngModel)]=\"data.CR_DM_Date\" name=\"CR_DM_Date\" required >\r\n        <mat-error *ngIf=\"formControl.invalid\">{{getErrorMessage()}}</mat-error>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <!--Contains mat-hint for characters count and has maxLengt set-->\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput #inputstate class=\"form-control\" placeholder=\"Clearance_BSO_NON_BSO\" [(ngModel)]=\"data.Clearance_BSO_NON_BSO\" name=\"Clearance_BSO_NON_BSO\" maxlength=\"10\" required >\r\n        <mat-error *ngIf=\"formControl.invalid\">{{getErrorMessage()}}</mat-error>\r\n        <mat-hint align=\"end\">{{inputstate.value?.length || 0}}/10</mat-hint>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput placeholder=\"Carrier\" [(ngModel)]=\"data.Carrier\" name=\"Carrier\">\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput placeholder=\"Contract\" [(ngModel)]=\"data.Contract\" name=\"Contract\">\r\n      </mat-form-field>\r\n    </div>\r\n\r\n\r\n    <div mat-dialog-actions>\r\n      <button mat-button [type]=\"submit\" [disabled]=\"!formControl.valid\" [mat-dialog-close]=\"1\" (click)=\"confirmAdd()\">Save</button>\r\n      <button mat-button (click)=\"onNoClick()\" tabindex=\"-1\">Cancel</button>\r\n    </div>\r\n  </form>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/delete/delete.dialog.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/delete/delete.dialog.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDialogsDeleteDeleteDialogHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"container\">\r\n  <h3 mat-dialog-title>Are you sure?</h3>\r\n  <div mat-dialog-content>\r\n    Id: {{data.id}}\r\n    <p></p>\r\n    Title: {{data.title}}\r\n    <p></p>\r\n    State: {{data.state}}\r\n    <p></p>\r\n    Url: {{data.url}}\r\n    <p></p>\r\n  </div>\r\n\r\n  <div mat-dialog-actions>\r\n    <button mat-button [mat-dialog-close]=\"1\" (click)=\"confirmDelete()\">Delete</button>\r\n    <button mat-button (click)=\"onNoClick()\" tabindex=\"-1\">Cancel</button>\r\n  </div>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/edit/edit.dialog.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/edit/edit.dialog.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDialogsEditEditDialogHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"container\">\r\n  <h3 mat-dialog-title>Issue id: {{data.id}}</h3>\r\n\r\n  <form class=\"mat-dialog-content\" (ngSubmit)=\"submit\" #formControl=\"ngForm\">\r\n\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput #input class=\"form-control\" placeholder=\"Compound_DM_Time\" [(ngModel)]=\"data.Compound_DM_Time\" name=\"Compound_DM_Time\" required >\r\n        <mat-error *ngIf=\"formControl.invalid\">{{getErrorMessage()}}</mat-error>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <!--Textarea for demo purposes-->\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput #input class=\"form-control\" placeholder=\"CR_DM_Date\" [(ngModel)]=\"data.CR_DM_Date\" name=\"CR_DM_Date\" required >\r\n        <mat-error *ngIf=\"formControl.invalid\">{{getErrorMessage()}}</mat-error>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <!--Contains mat-hint for characters count and has maxLengt set-->\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput #inputstate class=\"form-control\" placeholder=\"Clearance_BSO_NON_BSO\" [(ngModel)]=\"data.Clearance_BSO_NON_BSO\" name=\"Clearance_BSO_NON_BSO\" maxlength=\"10\" required >\r\n        <mat-error *ngIf=\"formControl.invalid\">{{getErrorMessage()}}</mat-error>\r\n        <mat-hint align=\"end\">{{inputstate.value?.length || 0}}/10</mat-hint>\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"form\">\r\n        <mat-form-field color=\"accent\">\r\n          <input matInput placeholder=\"Carrier\" [(ngModel)]=\"data.Carrier\" name=\"Carrier\">\r\n        </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput placeholder=\"Contract\" [(ngModel)]=\"data.Contract\" name=\"Contract\">\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <div class=\"form\">\r\n      <mat-form-field color=\"accent\">\r\n        <input matInput placeholder=\"Updated at\" [(ngModel)]=\"data.updated_at\" name=\"updated_at\">\r\n      </mat-form-field>\r\n    </div>\r\n\r\n    <div mat-dialog-actions>\r\n      <button mat-button [type]=\"submit\" [disabled]=\"!formControl.valid\" [mat-dialog-close]=\"1\" (click)=\"stopEdit()\">Save</button>\r\n      <button mat-button (click)=\"onNoClick()\" tabindex=\"-1\">Cancel</button>\r\n    </div>\r\n  </form>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/export-record-add/export-record-add.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/export-record-add/export-record-add.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppExportRecordAddExportRecordAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t\t   <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"exportForm\" (ngSubmit)=\"onFormSubmit(exportForm.value)\">\r\n\r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Compound DM Time\" formControlName=\"Compound_DM_Time\">\r\n       \r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\t <input matInput [matDatepicker]=\"picker\" placeholder=\"CR DM Date\" formControlName=\"CR_DM_Date\" disabled>\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n      <mat-form-field class=\"example-full-width\">\r\n\r\n\t  <mat-select formControlName=\"Clearance_BSO_NON_BSO\" placeholder=\"Select Clearance by - BSO/ NON-BSO\">\r\n\t\t<mat-option *ngFor=\"let bsononbso of bsononbsos\" [value]=\"bsononbso.value\">{{bsononbso.viewValue}}</mat-option>\r\n\t  </mat-select>\t\t\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n      <mat-select formControlName=\"Carrier\" placeholder=\"Select Carrier\">\r\n\t\t<mat-option *ngFor=\"let carrier of carriers\" [value]=\"carrier.value\">{{carrier.viewValue}}</mat-option>\r\n\t  </mat-select>\t\t\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n      <mat-select formControlName=\"Contract\" placeholder=\"Select Contract\">\r\n\t\t<mat-option *ngFor=\"let contract of contracts\" [value]=\"contract.value\">{{contract.viewValue}}</mat-option>\r\n\t  </mat-select>\t\t\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"SOLD TO\" formControlName=\"SOLD_TO\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"SHIP_TO\" formControlName=\"SHIP_TO\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Destination\" formControlName=\"Destination\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n      <mat-select formControlName=\"Zone_Sales_District\" placeholder=\"Select Zone Sales District\">\r\n\t\t<mat-option *ngFor=\"let ZoneSalesDistrict of ZoneSalesDistricts\" [value]=\"ZoneSalesDistrict.value\">{{ZoneSalesDistrict.viewValue}}</mat-option>\r\n\t  </mat-select>\t\t\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Description\" formControlName=\"Description\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"QTY\" formControlName=\"QTY\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"SAP Ref No\" formControlName=\"SAP_Ref_No\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Invoice No\" formControlName=\"Invoice_No\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\t <input matInput [matDatepicker]=\"Invoice_Datepicker\" placeholder=\"Invoice Date\" formControlName=\"Invoice_Date\" disabled>\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"Invoice_Datepicker\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #Invoice_Datepicker disabled=\"false\"></mat-datepicker>\r\n\t\t\t</mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Tracking No\" formControlName=\"Tracking_No\" [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!exportForm.get('Tracking_No').valid && exportForm.get('Tracking_No').touched\">Please enter Tracking_No</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\t <input matInput [matDatepicker]=\"Datepicker\" placeholder=\"Shipment Date of Pick up \" formControlName=\"Date\" disabled (dateChange)=\"onChangeDate($event.value)\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"Datepicker\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #Datepicker disabled=\"false\"></mat-datepicker>\r\n\t\t\t</mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n      <mat-form-field class=\"example-full-width\">\r\n\t <input matInput placeholder=\"Shipment Day of pickup\" formControlName=\"Shipment_Day_of_pick_up\" disabled>\r\n\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\t <input matInput [matDatepicker]=\"Departure_from_Indiapicker\" placeholder=\"Departure from India\" formControlName=\"Departure_from_India\" disabled>\r\n\t<mat-datepicker-toggle matSuffix [for]=\"Departure_from_Indiapicker\"></mat-datepicker-toggle>\r\n\t<mat-datepicker #Departure_from_Indiapicker disabled=\"false\"></mat-datepicker>\r\n\r\n\t</mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n\r\n\t <input matInput [matDatepicker]=\"Landing_Destination_Portpicker\" placeholder=\"Landing Destination Port\" formControlName=\"Landing_Destination_Port\" disabled (dateChange)=\"onChangeLandingD_port($event.value)\">\r\n\t<mat-datepicker-toggle matSuffix [for]=\"Landing_Destination_Portpicker\"></mat-datepicker-toggle>\r\n\t<mat-datepicker #Landing_Destination_Portpicker disabled=\"false\"></mat-datepicker>\r\n\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n      <input matInput [matDatepicker]=\"dcrpicker\" placeholder=\"Destination Customs release date\" formControlName=\"Destination_Customs_release_date\" disabled>\r\n\t<mat-datepicker-toggle matSuffix [for]=\"dcrpicker\"></mat-datepicker-toggle>\r\n\t<mat-datepicker #dcrpicker disabled=\"false\"></mat-datepicker>\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n\t<input matInput [matDatepicker]=\"dodpicker\" placeholder=\"Date of Delivery to client\" formControlName=\"Date_of_Delivery_to_client\" disabled (dateChange)=\"onChangeDD_to_client($event.value)\">\r\n\t<mat-datepicker-toggle matSuffix [for]=\"dodpicker\"></mat-datepicker-toggle>\r\n\t<mat-datepicker #dodpicker disabled=\"false\"></mat-datepicker>\r\n\t\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"No of days Door to Port\" formControlName=\"No_of_days_Door_to_Port\" [value]=\"NDPdays\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"No of days Door to Door\" formControlName=\"No_of_days_Door_to_Door\" [value]=\"NDDDdays\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Remarks\" formControlName=\"Remarks\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"HS Code No\" formControlName=\"HS_Code_No\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"No of Boxes\" formControlName=\"No_of_Boxes\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Gr Wt\" formControlName=\"Gr_Wt\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n      <mat-select formControlName=\"Unit_of_measure\" placeholder=\"Select Unit of measure\">\r\n\t\t<mat-option *ngFor=\"let Unitofmeasure of Unitofmeasures\" [value]=\"Unitofmeasure.value\">{{Unitofmeasure.viewValue}}</mat-option>\r\n\t  </mat-select>\t\t\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n\t     <mat-select formControlName=\"Package_Size\" placeholder=\"Select Package Size\">\r\n\t\t<mat-option *ngFor=\"let packagesize of packagesizes\" [value]=\"packagesize.value\">{{packagesize.viewValue}}</mat-option>\r\n\t  </mat-select>\t\t\t\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\t     <mat-select formControlName=\"Storage_Conditions\" placeholder=\"Select Storage Condition\">\r\n\t\t<mat-option *ngFor=\"let storagecondition of storageconditions\" [value]=\"storagecondition.value\">{{storagecondition.viewValue}}</mat-option>\r\n\t  </mat-select>\t\t\t\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Net Wt\" formControlName=\"Net_Wt\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n      <mat-select formControlName=\"UOM\" placeholder=\"Select Unit of measure\">\r\n\t\t<mat-option *ngFor=\"let Unitofmeasure of Unitofmeasures\" [value]=\"Unitofmeasure.value\">{{Unitofmeasure.viewValue}}</mat-option>\r\n\t  </mat-select>\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n\t\t<input (input)=\"suggest($event.target.value)\" placeholder=\"Select Currency\" aria-label=\"Number\" matInput formControlName=\"Currency\"  [matAutocomplete]=\"autov\">\r\n\t\t<mat-autocomplete #autov=\"matAutocomplete\" (optionSelected)='getPosts($event.option)'>\r\n\t\t  <mat-option *ngFor=\"let option of currency_Result\" [value]=\"option.currency_name\" [attr.data-somedata]=\"option.export_value\">\r\n\t\t\t{{option.currency_name}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t\t\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\t\t<input matInput (input)=\"applyFilter($event)\" placeholder=\"Invoice Value\" formControlName=\"Invoice_Value\" [(ngModel)]=\"searchValue\">\r\n        \r\n      </mat-form-field>\r\n\t</div>   \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Value in INR\" formControlName=\"Value_in_INR\" [value]=\"inrvalue\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"FOB Value\" formControlName=\"FOB_Value\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Shipping Bill Number\" formControlName=\"Shipping_Bill_Number\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\r\n\t<input matInput [matDatepicker]=\"shipblpicker\" placeholder=\"Shipping Bill Date\" formControlName=\"Shipping_Bill_Date\" disabled>\r\n\t<mat-datepicker-toggle matSuffix [for]=\"shipblpicker\"></mat-datepicker-toggle>\r\n\t<mat-datepicker #shipblpicker disabled=\"false\"></mat-datepicker>\r\n\r\n\t</mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"MAWB\" formControlName=\"MAWB\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"HAWB\" formControlName=\"HAWB\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"LEO No\" formControlName=\"LEO_No\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n    \r\n\t<input matInput [matDatepicker]=\"LEO_Datepicker\" placeholder=\"LEO Date\" formControlName=\"LEO_Date\" disabled>\r\n\t<mat-datepicker-toggle matSuffix [for]=\"LEO_Datepicker\"></mat-datepicker-toggle>\r\n\t<mat-datepicker #LEO_Datepicker disabled=\"false\"></mat-datepicker>\r\n\r\n\t</mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput [matDatepicker]=\"SB_Datepicker\" placeholder=\"SB original Date of receipt\" formControlName=\"SB_original_Date_of_receipt\" disabled>\r\n        <mat-datepicker-toggle matSuffix [for]=\"SB_Datepicker\"></mat-datepicker-toggle>\r\n        <mat-datepicker #SB_Datepicker disabled=\"false\"></mat-datepicker>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n\r\n\t  <mat-select formControlName=\"uploaded_finance_Share\" placeholder=\"Select Uploaded in finance Share\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Clearance charges\" formControlName=\"Clearance_charges\">\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Carrier Bill Freight charges\" formControlName=\"Carrier_Bill_Freight_charges\">\r\n      </mat-form-field>\r\n\t</div>\r\n\t<div class=\"form-row\">\r\n\r\n\t <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Location</mat-label>\r\n\t  <mat-select formControlName=\"SBU_location\" placeholder=\"Select SBU location\">\r\n\t\t<mat-option *ngFor=\"let sbulocation of sbulocations\" [value]=\"sbulocation.value\">{{sbulocation.viewValue}}</mat-option>\r\n\t  </mat-select>\r\n\t</mat-form-field>\r\n    <mat-form-field class=\"example-full-width\">\r\n      <input matInput placeholder=\"customer ID\" formControlName=\"customerID\" >\r\n    </mat-form-field>\r\n</div>\t\r\n<div class=\"form-row\">\r\n\r\n  <mat-form-field class=\"example-full-width\">\r\n   <mat-select formControlName=\"Status\" placeholder=\"Select Status\">\r\n    <mat-option *ngFor=\"let data of statusData\" [value]=\"data.value\">{{data.value}}</mat-option>\r\n    </mat-select>\r\n </mat-form-field>\r\n</div>\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!exportForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div>\r\n    </form>\r\n\t  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/export-record-edit/export-record-edit.component.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/export-record-edit/export-record-edit.component.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppExportRecordEditExportRecordEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n       <div class=\"layout-wrapper layout-2\">\r\n        <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n    <div class=\"layout-container\">\r\n              <!-- Layout navbar -->\r\n        <app-navbar></app-navbar>\r\n              <!-- / Layout navbar -->  \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n\r\n\r\n <mat-card class=\"example-card\">\r\n   <form [formGroup]=\"exportForm\" (ngSubmit)=\"onFormSubmit(exportForm.value)\">\r\n\r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Compound DM Time\" formControlName=\"Compound_DM_Time\">\r\n      \r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n  <input matInput [matDatepicker]=\"picker\" placeholder=\"CR DM Date\" formControlName=\"CR_DM_Date\" disabled>\r\n     <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n     <mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n   \r\n     <mat-form-field class=\"example-full-width\">\r\n\r\n   <mat-select formControlName=\"Clearance_BSO_NON_BSO\" placeholder=\"Select Clearance by - BSO/ NON-BSO\">\r\n   <mat-option *ngFor=\"let bsononbso of bsononbsos\" [value]=\"bsononbso.value\">{{bsononbso.viewValue}}</mat-option>\r\n   </mat-select>\t\t\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n     <mat-select formControlName=\"Carrier\" placeholder=\"Select Carrier\">\r\n   <mat-option *ngFor=\"let carrier of carriers\" [value]=\"carrier.value\">{{carrier.viewValue}}</mat-option>\r\n   </mat-select>\t\t\r\n\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n     <mat-select formControlName=\"Contract\" placeholder=\"Select Contract\">\r\n   <mat-option *ngFor=\"let contract of contracts\" [value]=\"contract.value\">{{contract.viewValue}}</mat-option>\r\n   </mat-select>\t\t\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"SOLD TO\" formControlName=\"SOLD_TO\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"SHIP_TO\" formControlName=\"SHIP_TO\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Destination\" formControlName=\"Destination\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n     <mat-select formControlName=\"Zone_Sales_District\" placeholder=\"Select Zone Sales District\">\r\n   <mat-option *ngFor=\"let ZoneSalesDistrict of ZoneSalesDistricts\" [value]=\"ZoneSalesDistrict.value\">{{ZoneSalesDistrict.viewValue}}</mat-option>\r\n   </mat-select>\t\t\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Description\" formControlName=\"Description\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"QTY\" formControlName=\"QTY\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"SAP Ref No\" formControlName=\"SAP_Ref_No\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Invoice No\" formControlName=\"Invoice_No\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n  <input matInput [matDatepicker]=\"Invoice_Datepicker\" placeholder=\"Invoice Date\" formControlName=\"Invoice_Date\" disabled>\r\n     <mat-datepicker-toggle matSuffix [for]=\"Invoice_Datepicker\"></mat-datepicker-toggle>\r\n     <mat-datepicker #Invoice_Datepicker disabled=\"false\"></mat-datepicker>\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Tracking No\" formControlName=\"Tracking_No\" [errorStateMatcher]=\"matcher\">\r\n       <mat-error>\r\n         <span *ngIf=\"!exportForm.get('Tracking_No').valid && exportForm.get('Tracking_No').touched\">Please enter Tracking_No</span>\r\n       </mat-error>\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n  <input matInput [matDatepicker]=\"Datepicker\" placeholder=\"Shipment Date of Pick up \" formControlName=\"Date\" disabled (dateChange)=\"onChangeDate($event.value)\">\r\n     <mat-datepicker-toggle matSuffix [for]=\"Datepicker\"></mat-datepicker-toggle>\r\n     <mat-datepicker #Datepicker disabled=\"false\"></mat-datepicker>\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n   \r\n     <mat-form-field class=\"example-full-width\">\r\n  <input matInput placeholder=\"Shipment Day of pickup\" formControlName=\"Shipment_Day_of_pick_up\" disabled>\r\n\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n  <input matInput [matDatepicker]=\"Departure_from_Indiapicker\" placeholder=\"Departure from India\" formControlName=\"Departure_from_India\" disabled>\r\n <mat-datepicker-toggle matSuffix [for]=\"Departure_from_Indiapicker\"></mat-datepicker-toggle>\r\n <mat-datepicker #Departure_from_Indiapicker disabled=\"false\"></mat-datepicker>\r\n\r\n </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n\r\n  <input matInput [matDatepicker]=\"Landing_Destination_Portpicker\" placeholder=\"Landing Destination Port\" formControlName=\"Landing_Destination_Port\" disabled (dateChange)=\"onChangeLandingD_port($event.value)\">\r\n <mat-datepicker-toggle matSuffix [for]=\"Landing_Destination_Portpicker\"></mat-datepicker-toggle>\r\n <mat-datepicker #Landing_Destination_Portpicker disabled=\"false\"></mat-datepicker>\r\n\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n     <input matInput [matDatepicker]=\"dcrpicker\" placeholder=\"Destination Customs release date\" formControlName=\"Destination_Customs_release_date\" disabled>\r\n <mat-datepicker-toggle matSuffix [for]=\"dcrpicker\"></mat-datepicker-toggle>\r\n <mat-datepicker #dcrpicker disabled=\"false\"></mat-datepicker>\r\n\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n <input matInput [matDatepicker]=\"dodpicker\" placeholder=\"Date of Delivery to client\" formControlName=\"Date_of_Delivery_to_client\" disabled (dateChange)=\"onChangeDD_to_client($event.value)\">\r\n <mat-datepicker-toggle matSuffix [for]=\"dodpicker\"></mat-datepicker-toggle>\r\n <mat-datepicker #dodpicker disabled=\"false\"></mat-datepicker>\r\n \r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"No of days Door to Port\" formControlName=\"No_of_days_Door_to_Port\" [value]=\"NDPdays\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"No of days Door to Door\" formControlName=\"No_of_days_Door_to_Door\" [value]=\"NDDDdays\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Remarks\" formControlName=\"Remarks\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"HS Code No\" formControlName=\"HS_Code_No\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"No of Boxes\" formControlName=\"No_of_Boxes\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Gr Wt\" formControlName=\"Gr_Wt\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n     <mat-select formControlName=\"Unit_of_measure\" placeholder=\"Select Unit of measure\">\r\n   <mat-option *ngFor=\"let Unitofmeasure of Unitofmeasures\" [value]=\"Unitofmeasure.value\">{{Unitofmeasure.viewValue}}</mat-option>\r\n   </mat-select>\t\t\r\n\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n      <mat-select formControlName=\"Package_Size\" placeholder=\"Select Package Size\">\r\n   <mat-option *ngFor=\"let packagesize of packagesizes\" [value]=\"packagesize.value\">{{packagesize.viewValue}}</mat-option>\r\n   </mat-select>\t\t\t\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n      <mat-select formControlName=\"Storage_Conditions\" placeholder=\"Select Storage Condition\">\r\n   <mat-option *ngFor=\"let storagecondition of storageconditions\" [value]=\"storagecondition.value\">{{storagecondition.viewValue}}</mat-option>\r\n   </mat-select>\t\t\t\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Net Wt\" formControlName=\"Net_Wt\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n     <mat-select formControlName=\"UOM\" placeholder=\"Select Unit of measure\">\r\n   <mat-option *ngFor=\"let Unitofmeasure of Unitofmeasures\" [value]=\"Unitofmeasure.value\">{{Unitofmeasure.viewValue}}</mat-option>\r\n   </mat-select>\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n   <input (input)=\"suggest($event.target.value)\" placeholder=\"Select Currency\" aria-label=\"Number\" matInput formControlName=\"Currency\"  [matAutocomplete]=\"autov\">\r\n   <mat-autocomplete #autov=\"matAutocomplete\" (optionSelected)='getPosts($event.option)'>\r\n     <mat-option *ngFor=\"let option of currency_Result\" [value]=\"option.currency_name\" [attr.data-somedata]=\"option.export_value\">\r\n     {{option.currency_name}}\r\n     </mat-option>\r\n   </mat-autocomplete>\r\n   \r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n   <input matInput (input)=\"applyFilter($event)\" placeholder=\"Invoice Value\" formControlName=\"Invoice_Value\" [(ngModel)]=\"searchValue\">\r\n       \r\n     </mat-form-field>\r\n </div>   \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Value in INR\" formControlName=\"Value_in_INR\" [value]=\"inrvalue\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"FOB Value\" formControlName=\"FOB_Value\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Shipping Bill Number\" formControlName=\"Shipping_Bill_Number\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n\r\n <input matInput [matDatepicker]=\"shipblpicker\" placeholder=\"Shipping Bill Date\" formControlName=\"Shipping_Bill_Date\" disabled>\r\n <mat-datepicker-toggle matSuffix [for]=\"shipblpicker\"></mat-datepicker-toggle>\r\n <mat-datepicker #shipblpicker disabled=\"false\"></mat-datepicker>\r\n\r\n </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"MAWB\" formControlName=\"MAWB\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"HAWB\" formControlName=\"HAWB\">\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"LEO No\" formControlName=\"LEO_No\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n   \r\n <input matInput [matDatepicker]=\"LEO_Datepicker\" placeholder=\"LEO Date\" formControlName=\"LEO_Date\" disabled>\r\n <mat-datepicker-toggle matSuffix [for]=\"LEO_Datepicker\"></mat-datepicker-toggle>\r\n <mat-datepicker #LEO_Datepicker disabled=\"false\"></mat-datepicker>\r\n\r\n </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput [matDatepicker]=\"SB_Datepicker\" placeholder=\"SB original Date of receipt\" formControlName=\"SB_original_Date_of_receipt\" disabled>\r\n       <mat-datepicker-toggle matSuffix [for]=\"SB_Datepicker\"></mat-datepicker-toggle>\r\n       <mat-datepicker #SB_Datepicker disabled=\"false\"></mat-datepicker>\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n\r\n   <mat-select formControlName=\"uploaded_finance_Share\" placeholder=\"Select Uploaded in finance Share\">\r\n   <mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n   </mat-select>\r\n\r\n     </mat-form-field>\r\n </div>  \r\n <div class=\"form-row\">\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Clearance charges\" formControlName=\"Clearance_charges\">\r\n     </mat-form-field>\r\n     <mat-form-field class=\"example-full-width\">\r\n       <input matInput placeholder=\"Carrier Bill Freight charges\" formControlName=\"Carrier_Bill_Freight_charges\">\r\n     </mat-form-field>\r\n </div>\r\n <div class=\"form-row\">\r\n\r\n  <mat-form-field class=\"example-full-width\">\r\n   <mat-label>Select Location</mat-label>\r\n   <mat-select formControlName=\"SBU_location\" placeholder=\"Select SBU location\">\r\n   <mat-option *ngFor=\"let sbulocation of sbulocations\" [value]=\"sbulocation.value\">{{sbulocation.viewValue}}</mat-option>\r\n   </mat-select>\r\n   \r\n </mat-form-field>\r\n <mat-form-field class=\"example-full-width\">\r\n  <input matInput placeholder=\"customerID\" formControlName=\"customerID\" >\r\n</mat-form-field>\r\n</div>\r\n<div class=\"form-row\">\r\n\r\n  <mat-form-field class=\"example-full-width\">\r\n    <mat-label>Select Status</mat-label>\r\n    <mat-select formControlName=\"Status\" placeholder=\"Select Status\">\r\n      <mat-option *ngFor=\"let data of statusData\" [value]=\"data.value\">{{data.value}}</mat-option>\r\n    </mat-select>\r\n  </mat-form-field>\r\n</div>\t\r\n     <div class=\"button-row\">\r\n       <button type=\"submit\" [disabled]=\"!exportForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n     </div>\r\n   </form>\r\n   <div class=\"example-loading-shade\"\r\n      *ngIf=\"isLoadingResults\">\r\n   <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n </div>\r\n </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/export-records-list/export-records-list.component.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/export-records-list/export-records-list.component.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppExportRecordsListExportRecordsListComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n  <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n    <div class=\"layout-container\">\r\n      <!-- Layout navbar -->\r\n      <app-navbar></app-navbar>\r\n      <!-- / Layout navbar -->\r\n\r\n      <div class=\"container mat-elevation-z8\">\r\n        <div class=\"example-loading-shade\"\r\n          *ngIf=\"isLoadingResults\">\r\n          <mat-spinner ></mat-spinner>\r\n        </div>\r\n        <div class=\"row align-items-center\">\r\n          <div class=\"col-md-3\">\r\n            <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n              <input (keyup.enter)=\"onSubmit()\" matInput #filter [(ngModel)]=\"searchField\" placeholder=\"Tracking No/ Ship To / Invoice No / Location\">\r\n            </mat-form-field>\r\n          </div>\r\n          <div class=\"col-md-3\">\r\n            <button type=\"submit\" (click)=\"onSubmit()\" class=\"btn btn-primary\">\r\n              Submit\r\n            </button>\r\n          </div>\r\n          <div class=\"col-md-6 text-right\" >\r\n            <div class=\"top-btns\">\r\n              <button class=\"btn btn-secondary\" aria-label=\"export type\" title=\"Export data\" type=\"button\"\r\n                aria-expanded=\"false\" (click)=\"exportAsXLSX()\">\r\n                <i class=\"opacity-75 ion ion-md-cloud-download icon-share\"></i>\r\n                <span class=\"caret\"> Excel <i *ngIf=\"excelLoader\" class=\"fa fa-spinner fa-spin\" ></i>                </span>\r\n              </button>\r\n              <button (click)=\"accordion = !accordion\" class=\"btn btn-info\" id=\"accordionid\">\r\n                Import\r\n              </button>\r\n              <button class=\"btn btn-success\" routerLink=\"/export-add\">\r\n                Add\r\n              </button>\r\n            </div>\r\n          </div>\r\n        </div>\r\n\r\n        {{ Message }}\r\n        <div *ngIf=\"accordion\" id=\"accordion-1\" class=\"upload-f\">\r\n          <div class=\"card-body\">\r\n            <form class=\"import-sec\">\r\n              <div class=\"form-group\">\r\n                <div class=\"form-control\">\r\n                  <input type=\"file\" style=\"display: inline-block\" (change)=\"incomingfile($event)\"\r\n                    placeholder=\"Upload file\" accept=\".xlsx\" />\r\n                </div>\r\n              </div>\r\n              <div class=\"upload-btn\">\r\n                <button type=\"button\" class=\"btn btn-info\" (click)=\"Upload()\">\r\n                  Upload\r\n                </button>\r\n              </div>\r\n            </form>\r\n          </div>\r\n        </div>\r\n        <div class=\"table-responsive\">\r\n          <div class=\"fa-3x\" *ngIf=\"loader; else show_result\" style=\"text-align: center\">\r\n            <i class=\"fa fa-spinner fa-spin\" style=\"font-size: 24px\"></i>\r\n          </div>\r\n          <ng-template #show_result>\r\n            <mat-table #table [dataSource]=\"exportData?.records\" matSort class=\"mat-cell\">\r\n              <ng-container matColumnDef=\"id\">\r\n                <mat-header-cell *matHeaderCellDef>Id</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">{{ row.id }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"SBU_location\">\r\n                <mat-header-cell *matHeaderCellDef >SBU location</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">{{\r\n                  row.SBU_location\r\n                  }}</mat-cell>\r\n              </ng-container>\r\n\r\n              <ng-container matColumnDef=\"Compound_DM_Time\">\r\n                <mat-header-cell *matHeaderCellDef >Compound DM Time</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Compound_DM_Time }}</mat-cell>\r\n              </ng-container>\r\n\r\n              <ng-container matColumnDef=\"CR_DM_Date\">\r\n                <mat-header-cell *matHeaderCellDef >CR DM Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.CR_DM_Date | date }}\r\n                </mat-cell>\r\n              </ng-container>\r\n\r\n              <ng-container matColumnDef=\"Clearance_BSO_NON_BSO\">\r\n                <mat-header-cell *matHeaderCellDef >Clearance BSO NON-BSO</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Clearance_BSO_NON_BSO }}</mat-cell>\r\n              </ng-container>\r\n\r\n              <ng-container matColumnDef=\"Carrier\">\r\n                <mat-header-cell *matHeaderCellDef >Carrier</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.Carrier }}</mat-cell>\r\n              </ng-container>\r\n\r\n              <ng-container matColumnDef=\"Contract\">\r\n                <mat-header-cell *matHeaderCellDef >Contract</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.Contract }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"SOLD_TO\">\r\n                <mat-header-cell *matHeaderCellDef >SOLD TO</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.SOLD_TO }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"SHIP_TO\">\r\n                <mat-header-cell *matHeaderCellDef >SHIP TO</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.SHIP_TO }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Destination\">\r\n                <mat-header-cell *matHeaderCellDef >Destination</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Destination }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"QTY\">\r\n                <mat-header-cell *matHeaderCellDef >QTY</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.QTY }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"SAP_Ref_No\">\r\n                <mat-header-cell *matHeaderCellDef >SAP Ref No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.SAP_Ref_No }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Invoice_No\">\r\n                <mat-header-cell *matHeaderCellDef >Invoice No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.Invoice_No }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Invoice_Date\">\r\n                <mat-header-cell *matHeaderCellDef >Invoice Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Invoice_Date | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Clearance_charges\">\r\n                <mat-header-cell *matHeaderCellDef >Clearance charges</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Clearance_charges }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Carrier_Bill_Freight_charges\">\r\n                <mat-header-cell *matHeaderCellDef >Carrier Bill Freight charges</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Carrier_Bill_Freight_charges }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Tracking_No\">\r\n                <mat-header-cell *matHeaderCellDef >Tracking No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Tracking_No }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Date\">\r\n                <mat-header-cell *matHeaderCellDef >Shipment Pick Up Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Date | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Shipment_Day_of_pick_up\">\r\n                <mat-header-cell *matHeaderCellDef >Shipment Day of pick up</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Shipment_Day_of_pick_up }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Departure_from_India\">\r\n                <mat-header-cell *matHeaderCellDef >Departure from India</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Departure_from_India | date }}</mat-cell>\r\n              </ng-container>\r\n\r\n              <ng-container matColumnDef=\"Landing_Destination_Port\">\r\n                <mat-header-cell *matHeaderCellDef >Landing Destination Port</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Landing_Destination_Port | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Destination_Customs_release_date\">\r\n                <mat-header-cell *matHeaderCellDef >Destination Customs release date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Destination_Customs_release_date | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Date_of_Delivery_to_client\">\r\n                <mat-header-cell *matHeaderCellDef >Delivery to client</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Date_of_Delivery_to_client | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"No_of_days_Door_to_Port\">\r\n                <mat-header-cell *matHeaderCellDef >No of days Door to Port</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.No_of_days_Door_to_Port }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"No_of_days_Door_to_Door\">\r\n                <mat-header-cell *matHeaderCellDef >No of days Door to Door</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.No_of_days_Door_to_Door }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Remarks\">\r\n                <mat-header-cell *matHeaderCellDef >Remarks</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.Remarks }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"HS_Code_No\">\r\n                <mat-header-cell *matHeaderCellDef >HS Code No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.HS_Code_No }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"No_of_Boxes\">\r\n                <mat-header-cell *matHeaderCellDef >No of Boxes</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.No_of_Boxes }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Gr_Wt\">\r\n                <mat-header-cell *matHeaderCellDef >Gr Wt</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.Gr_Wt }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Unit_of_measure\">\r\n                <mat-header-cell *matHeaderCellDef >Unit of measure</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Unit_of_measure }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Package_Size\">\r\n                <mat-header-cell *matHeaderCellDef >Package Size</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Package_Size }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Storage_Conditions\">\r\n                <mat-header-cell *matHeaderCellDef >Storage Conditions</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Storage_Conditions }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Net_Wt\">\r\n                <mat-header-cell *matHeaderCellDef >Net Wt</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.Net_Wt }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"UOM\">\r\n                <mat-header-cell *matHeaderCellDef >UOM</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.UOM }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Currency\">\r\n                <mat-header-cell *matHeaderCellDef >Currency</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.Currency }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Invoice_Value\">\r\n                <mat-header-cell *matHeaderCellDef >Invoice Value</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Invoice_Value }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Value_in_INR\">\r\n                <mat-header-cell *matHeaderCellDef >Value in INR</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Value_in_INR }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"FOB_Value\">\r\n                <mat-header-cell *matHeaderCellDef >FOB Value</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.FOB_Value }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Shipping_Bill_Number\">\r\n                <mat-header-cell *matHeaderCellDef >Shipping Bill Number</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.FOB_Value }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Shipping_Bill_Date\">\r\n                <mat-header-cell *matHeaderCellDef >Shipping Bill Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Shipping_Bill_Date | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"MAWB\">\r\n                <mat-header-cell *matHeaderCellDef >MAWB</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.MAWB }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"HAWB\">\r\n                <mat-header-cell *matHeaderCellDef >HAWB</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.HAWB }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"LEO_No\">\r\n                <mat-header-cell *matHeaderCellDef >LEO No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{ row.LEO_No }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"LEO_Date\">\r\n                <mat-header-cell *matHeaderCellDef >LEO Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.LEO_Date | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"SB_original_Date_of_receipt\">\r\n                <mat-header-cell *matHeaderCellDef >SB original Date of receipt</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.SB_original_Date_of_receipt | date }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"uploaded_finance_Share\">\r\n                <mat-header-cell *matHeaderCellDef >uploaded finance Share</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.uploaded_finance_Share }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"customerID\">\r\n                <mat-header-cell *matHeaderCellDef >customerID</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.customerID }}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Status\">\r\n                <mat-header-cell *matHeaderCellDef >Status</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\">\r\n                  {{ row.Status }}</mat-cell>\r\n              </ng-container>\r\n\r\n              <!-- actions -->\r\n              <ng-container matColumnDef=\"actions\">\r\n                <mat-header-cell *matHeaderCellDef>\r\n                  <button mat-icon-button color=\"primary\">\r\n                    <mat-icon aria-label=\"Example icon-button with a heart icon\">add</mat-icon>\r\n                  </button>\r\n                </mat-header-cell>\r\n\r\n                <mat-cell *matCellDef=\"let row; let i = index\">\r\n                  <button mat-flat-button color=\"primary\" [routerLink]=\"['/export-edit', row.id]\">\r\n                    <mat-icon>edit</mat-icon>\r\n                  </button>\r\n                  <button mat-icon-button color=\"accent\" (click)=\"deleteExportShipment(row.id)\">\r\n                    <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n                  </button>\r\n                </mat-cell>\r\n              </ng-container>\r\n\r\n              <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n              <mat-row *matRowDef=\"let row; columns: displayedColumns\"></mat-row>\r\n            </mat-table>\r\n          </ng-template>\r\n        </div>\r\n        <p *ngIf=\"exportData?.records.length === 0\" class=\"no-records text-center\">\r\n          No records found\r\n        </p>\r\n\r\n        <mat-paginator #paginator (page)=\"getPaginatorData($event)\" [length]=\"exportData?.count\"\r\n          [pageSize]=\"exportData?.pagePer\" [pageSizeOptions]=\"[5, 10, 25, 100]\" [pageIndex]=\"exportData?.pageNo - 1\">\r\n        </mat-paginator>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/export-reports/export-reports.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/export-reports/export-reports.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppExportReportsExportReportsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n  <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n    <div class=\"layout-container\">\r\n      <!-- Layout navbar -->\r\n      <app-navbar></app-navbar>\r\n      <!-- <div class=\"col-md-12 d-flex\">\r\n        <div class=\"spinner-border text-muted\"></div>\r\n      </div> -->\r\n      <div class=\"container exp\">\r\n        <div class=\"row\">\r\n          <form [formGroup]=\"searchForm\" (ngSubmit)=\"onSubmit()\" style=\"width: 100%;\">\r\n            <div class=\"row\">\r\n              <div class=\"col-md-3\">\r\n                <div class=\"inp-item\">\r\n                  <mat-form-field>\r\n                    <input matInput [matDatepicker]=\"picker\" placeholder=\"From Date\" formControlName=\"fromDate\"\r\n                      disabled>\r\n                    <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                    <mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n                  </mat-form-field>\r\n                  <div *ngIf=\"f.fromDate.errors && f.fromDate.errors.required && submitted\" class=\"text-danger\">\r\n                    This Field is required.\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"col-md-3\">\r\n                <div class=\"inp-item\">\r\n                  <mat-form-field>\r\n                    <input matInput [matDatepicker]=\"pickerToDate\" placeholder=\"To Date\" formControlName=\"toDate\"\r\n                      disabled>\r\n                    <mat-datepicker-toggle matSuffix [for]=\"pickerToDate\"></mat-datepicker-toggle>\r\n                    <mat-datepicker #pickerToDate disabled=\"false\"></mat-datepicker>\r\n                  </mat-form-field>\r\n\r\n\r\n\r\n                  <div *ngIf=\"f.toDate.errors && f.toDate.errors.required && submitted\" class=\"text-danger\">\r\n                    This Field is required.\r\n                  </div>\r\n                </div>\r\n              </div>\r\n              <div class=\"col-md-3\">\r\n                <ng-multiselect-dropdown [placeholder]=\"'Select Zone'\" [data]=\"zonesData\" formControlName=\"regions\"\r\n                  (onSelect)=\"onItemSelect($event)\" (onDeSelect)=\"onDeSelect($event)\"\r\n                  (onSelectAll)=\"onSelectAll($event)\" (onDeSelectAll)=\"onDeSelectAll($event)\" [settings]=\"settings\">\r\n                </ng-multiselect-dropdown>\r\n              </div>\r\n              <div class=\"col-md-3\">\r\n                <ng-multiselect-dropdown [placeholder]=\"'Select countries'\" [data]=\"countries\"\r\n                  formControlName=\"Destination\" [settings]=\"settings\">\r\n                </ng-multiselect-dropdown>\r\n              </div>\r\n              <div class=\"col-md-3\">\r\n                <ng-multiselect-dropdown [data]=\"dropDownData?.carriers\" [placeholder]=\"'Select Carriers'\"\r\n                  formControlName=\"carriers\" [settings]=\"settings\">\r\n                </ng-multiselect-dropdown>\r\n              </div>\r\n              <div class=\"col-md-3\">\r\n                <mat-form-field class=\"example-full-width\">\r\n\r\n                  <mat-select formControlName=\"Clearance_BSO_NON_BSO\" placeholder=\"Select Clearance\">\r\n                    <mat-option *ngFor=\"let bsononbso of bsononbsos\" [value]=\"bsononbso.value\">{{bsononbso.viewValue}}\r\n                    </mat-option>\r\n                  </mat-select>\r\n                </mat-form-field>\r\n                <div *ngIf=\"f.Clearance_BSO_NON_BSO.errors && f.Clearance_BSO_NON_BSO.errors.required && submitted\"\r\n                  class=\"text-danger\">\r\n                  This Field is required.\r\n                </div>\r\n              </div>\r\n              <div class=\"col-md-3\">\r\n                <input type=\"number\" placeholder=\"Door to Port\" min=\"0\" class=\"form-control\" formControlName=\"days\" />\r\n                <div *ngIf=\"f.days.errors && f.days.errors.required && submitted\" class=\"text-danger\">\r\n                  This Field is required.\r\n                </div>\r\n              </div>\r\n\r\n              <div class=\"col-md-3 text-right\">\r\n                <button class=\"btn btn-info\">Submit</button>\r\n              </div>\r\n            </div>\r\n\r\n          </form>\r\n        </div>\r\n        <div class=\"fa-3x\" *ngIf=\"loading; else show_result\" style=\"text-align: center;\">\r\n          <i class=\"fa fa-spinner fa-spin\" style=\"font-size:24px; \"></i>\r\n        </div>\r\n        <div class=\"row\" style=\"margin-top: 20px;\">\r\n          <ng-template #show_result>\r\n            <div class=\"row\" *ngFor=\"let data of exportData?.region | keyvalue\">\r\n              <div class=\"col-md-12\">\r\n                <div class=\"exp-sec\">\r\n                  <h4>{{data?.key}} [Percentage & No. of Shipments]</h4>\r\n                  <div class=\"table-responsive mb-2\">\r\n                    <table style=\"width: 100%\">\r\n                      <tbody>\r\n                        <tr>\r\n                          <td style=\"width: 25%; border: 1px solid #4e5155;\"\r\n                            *ngFor=\"let data of data.value | keyvalue \">\r\n                            <table class=\"table  table-bordered table-striped\">\r\n                              <tbody>\r\n                                <tr>\r\n                                  <th colspan=\"5\" class=\"text-center\">{{data?.key}}</th>\r\n                                </tr>\r\n                                <tr>\r\n                                  <th>Location</th>\r\n                                  <th>%</th>\r\n                                  <th>No.'s</th>\r\n                                  <th>On time</th>\r\n                                  <th>Delay</th>\r\n                                </tr>\r\n                                <tr *ngFor=\"let data of data?.value | keyvalue\">\r\n                                  <td><b>{{data?.key}}</b></td>\r\n                                  <td>{{data?.value.onTime / data?.value.no * 100 > 0 ? (data?.value.onTime /\r\n                                    data?.value.no * 100 | number: '1.0-2') : 0 }}% </td>\r\n                                  <td>{{data?.value.no}}</td>\r\n                                  <td>{{data?.value.onTime}}</td>\r\n                                  <td>{{data?.value.delay}}</td>\r\n                                </tr>\r\n                              </tbody>\r\n                            </table>\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"row\" *ngIf=\"exportData?.TotalsByCarrier\">\r\n              <div class=\"col-md-12\">\r\n                <div class=\"exp-sec\">\r\n                  <h4>Over All</h4>\r\n                  <div class=\"table-responsive\">\r\n                    <table style=\"width: 100%\">\r\n                      <tbody>\r\n                        <tr>\r\n                          <td>\r\n                            <table class=\"table table-bordered table-striped\">\r\n                              <tbody>\r\n                                <tr>\r\n                                  <th></th>\r\n                                  <th>On Time %</th>\r\n                                  <th>Total</th>\r\n                                  <th>On Time</th>\r\n                                  <th>Delay</th>\r\n                                </tr>\r\n                                <tr *ngFor=\"let data of exportData?.TotalsByCarrier | keyvalue\">\r\n                                  <td *ngIf=\"data?.key == 'ZTotal'; else show_ttab\"><b>Total</b></td>\r\n                                  <ng-template #show_ttab>\r\n                                    <td>{{data?.key}}</td>\r\n                                  </ng-template>\r\n                                  <td>{{data?.value.onTime / data.value.totalNo * 100 > 0 ? (data.value.onTime /\r\n                                    data.value.totalNo * 100 | number: '1.0-2') : 0 }} %</td>\r\n                                  <td>{{data.value.totalNo}}</td>\r\n                                  <td>{{data.value.onTime}}</td>\r\n                                  <td>{{data.value.delay}}</td>\r\n                                </tr>\r\n                              </tbody>\r\n                            </table>\r\n                          </td>\r\n                        </tr>\r\n                      </tbody>\r\n                    </table>\r\n                    <br><br>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </ng-template>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppFooterFooterComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "         \r\n                    \r\n                  <!-- / Layout footer -->\r\n               \r\n         <!-- Overlay -->\r\n         <div class=\"layout-overlay layout-sidenav-toggle\"></div>\r\n      \r\n      <!-- / Layout wrapper -->\r\n      <!-- Core scripts -->\r\n      <script src=\"assets/js/popper.js\"></script>\r\n      <script src=\"assets/js/bootstrap.js\"></script>\r\n      <script src=\"assets/js/sidenav.js\"></script>\r\n      <!-- Libs -->\r\n      <script src=\"assets/js/perfect-scrollbar.js\"></script>\r\n      <script src=\"assets/js/tableexport.js\"></script>\r\n      <script src=\"assets/js/moment.js\"></script>\r\n      <script src=\"assets/js/flatpickr.js\"></script>\r\n      <script src=\"assets/js/bootstrap-table.js\"></script>\r\n      <script src=\"assets/js/export.js\"></script>\r\n      <!-- Demo -->\r\n      <script src=\"assets/js/demo.js\"></script>\r\n      <script src=\"assets/js/tables_bootstrap-table.js\"></script>\r\n      <script src=\"assets/js/forms_pickers.js\"></script>\r\n<script>\r\n\r\n\r\n</script>\r\n<style>\r\n   .err_msg {\r\n    display:none;\r\n\tcolor:red;\r\n\t\r\n    }\r\n\t\r\n</style>\r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHeaderHeaderComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"app-brand demo m-v\">\r\n   <span class=\"open-icon\" style=\"font-size:30px;cursor:pointer;margin-left: 15px;\" onclick=\"openNav()\">&#9776; </span>                \r\n   <a routerLink=\"/import-records\" class=\"app-brand-text demo sidenav-text font-weight-normal ml-2\">\r\n       <img src=\"assets/images/gvk2.png\"></a>\r\n      \r\n</div>\r\n<div id=\"mySidenav\" class=\"sidenav sidenav-vertical\">\r\n   <a href=\"javascript:void(0)\" class=\"closebtn\" onclick=\"closeNav()\">&times;</a>\r\n   <div class=\"app-brand demo\">\r\n                   \r\n      <a routerLink=\"/import-records\" class=\"app-brand-text demo sidenav-text font-weight-normal ml-2\">\r\n          <img src=\"assets/images/gvk2.png\"></a>\r\n          <span class=\"open-icon\" style=\"font-size:30px;cursor:pointer\" onclick=\"openNav()\">&#9776; </span>\r\n   </div>\r\n   <div class=\"sidenav-divider mt-0\"></div>\r\n   <ul class=\"sidenav-inner py-1\">\r\n      <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/import-records\" >\r\n            <i class=\"sidenav-icon ion ion-md-code-download\"></i>\r\n            <div>Import Shipments</div>\r\n         </a>\r\n      </li>\r\n      <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/export-records\">\r\n            <i class=\"sidenav-icon ion ion-md-cloud-upload\"></i>\r\n            <div>Export Shipments</div>\r\n         </a>\r\n      </li>\r\n      <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/import-reports\" >\r\n            <i class=\"sidenav-icon ion ion-md-code-download\"></i>\r\n            <div>Import Reports</div>\r\n         </a>\r\n      </li>\r\n      <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/imports-overall-reports\">\r\n            <i class=\"sidenav-icon ion ion-md-download\"></i>\r\n            <div>Import Overall Reports</div>\r\n         </a>\r\n      </li>\r\n      <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/export-reports\">\r\n            <i class=\"sidenav-icon ion ion-md-cloud-upload\"></i>\r\n            <div>Export Reports</div>\r\n         </a>\r\n      </li>\r\n      <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/weekely-reports\">\r\n            <i class=\"sidenav-icon ion ion-md-people\"></i>\r\n            <div>Exports Weekly</div>\r\n         </a>\r\n      </li>\r\n      <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/vendors\">\r\n            <i class=\"sidenav-icon ion ion-md-people\"></i>\r\n            <div>Vendors</div>\r\n         </a>\r\n      </li>\r\n  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/carriers\">\r\n            <i class=\"sidenav-icon ion ion-md-cart\"></i>\r\n            <div>Carriers</div>\r\n         </a>\r\n      </li>\r\n  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/countries\">\r\n            <i class=\"sidenav-icon ion ion-md-globe\"></i>\r\n            <div>Countries</div>\r\n         </a>\r\n      </li>\r\n  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/cha\">\r\n            <i class=\"sidenav-icon ion ion-md-person-add\"></i>\r\n            <div>Custom Handling Agents</div>\r\n         </a>\r\n      </li>\r\n  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/currencies\">\r\n            <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n            <div>Currencies</div>\r\n         </a>\r\n      </li>\r\n  <li  class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/users\">\r\n            <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n            <div>Users</div>\r\n         </a>\r\n      </li>\r\n   <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n      <a class=\"sidenav-link \" routerLink=\"/users-logs\">\r\n         <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n         <div>Users Logs</div>\r\n      </a>\r\n   </li>\r\n  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n         <a class=\"sidenav-link \" routerLink=\"/custom-holidays\">\r\n            <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n            <div>Custom Holidays</div>\r\n         </a>\r\n      </li>\r\n  <li class=\"sidenav-item\">\r\n  <a style=\"cursor: pointer;\" class=\"sidenav-link \" (click)=\"logout()\">\r\n            <i class=\"sidenav-icon ion ion-md-log-out\"></i>\r\n            <div>Logout</div>\r\n         </a>\r\n         \r\n      </li>\r\n      \r\n   </ul>\r\n </div>\r\n \r\n\r\n\r\n           <!--\r\n            <div id=\"layout-sidenav\" class=\"layout-sidenav sidenav sidenav-vertical bg-dark\">\r\n               <div class=\"app-brand demo\">\r\n                   \r\n                  <a routerLink=\"/import-records\" class=\"app-brand-text demo sidenav-text font-weight-normal ml-2\">\r\n                      <img src=\"assets/images/gvk2.png\"></a>\r\n                 \r\n               </div>\r\n               <div class=\"sidenav-divider mt-0\"></div>\r\n\r\n\r\n               \r\n\r\n               \r\n               <ul class=\"sidenav-inner py-1\">\r\n                  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/import-records\" >\r\n                        <i class=\"sidenav-icon ion ion-md-code-download\"></i>\r\n                        <div>Import Shipments</div>\r\n                     </a>\r\n                  </li>\r\n                  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/export-records\">\r\n                        <i class=\"sidenav-icon ion ion-md-cloud-upload\"></i>\r\n                        <div>Export Shipments</div>\r\n                     </a>\r\n                  </li>\r\n                  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/import-reports\" >\r\n                        <i class=\"sidenav-icon ion ion-md-code-download\"></i>\r\n                        <div>Import Reports</div>\r\n                     </a>\r\n                  </li>\r\n                  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/imports-overall-reports\">\r\n                        <i class=\"sidenav-icon ion ion-md-download\"></i>\r\n                        <div>Import Overall Reports</div>\r\n                     </a>\r\n                  </li>\r\n                  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/export-reports\">\r\n                        <i class=\"sidenav-icon ion ion-md-cloud-upload\"></i>\r\n                        <div>Export Reports</div>\r\n                     </a>\r\n                  </li>\r\n                  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/weekely-reports\">\r\n                        <i class=\"sidenav-icon ion ion-md-people\"></i>\r\n                        <div>Exports Weekly</div>\r\n                     </a>\r\n                  </li>\r\n\t\t\t\t\t   <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/vendors\">\r\n                        <i class=\"sidenav-icon ion ion-md-people\"></i>\r\n                        <div>Vendors</div>\r\n                     </a>\r\n                  </li>\r\n\t\t\t\t  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/carriers\">\r\n                        <i class=\"sidenav-icon ion ion-md-cart\"></i>\r\n                        <div>Carriers</div>\r\n                     </a>\r\n                  </li>\r\n\t\t\t\t  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/countries\">\r\n                        <i class=\"sidenav-icon ion ion-md-globe\"></i>\r\n                        <div>Countries</div>\r\n                     </a>\r\n                  </li>\r\n\t\t\t\t  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/cha\">\r\n                        <i class=\"sidenav-icon ion ion-md-person-add\"></i>\r\n                        <div>Custom Handling Agents</div>\r\n                     </a>\r\n                  </li>\r\n\t\t\t\t  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/currencies\">\r\n                        <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n                        <div>Currencies</div>\r\n                     </a>\r\n                  </li>\r\n\t\t\t\t  <li  class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/users\">\r\n                        <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n                        <div>Users</div>\r\n                     </a>\r\n                  </li>\r\n               <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                  <a class=\"sidenav-link \" routerLink=\"/users-logs\">\r\n                     <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n                     <div>Users Logs</div>\r\n                  </a>\r\n               </li>\r\n\t\t\t\t  <li class=\"sidenav-item\" routerLinkActive=\"is-active\">\r\n                     <a class=\"sidenav-link \" routerLink=\"/custom-holidays\">\r\n                        <i class=\"sidenav-icon ion ion-md-cash\"></i>\r\n                        <div>Custom Holidays</div>\r\n                     </a>\r\n                  </li>\r\n\t\t\t\t  <li class=\"sidenav-item\">\r\n\t\t\t\t  <a style=\"cursor: pointer;\" class=\"sidenav-link \" (click)=\"logout()\">\r\n                        <i class=\"sidenav-icon ion ion-md-log-out\"></i>\r\n                        <div>Logout</div>\r\n                     </a>\r\n                     \r\n                  </li>\r\n                  \r\n               </ul>\r\n            </div>\r\n         -->\r\n\r\n\r\n\r\n            <!-- / Layout sidenav -->\r\n            <!-- Layout container -->\r\n       ";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html":
  /*!********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html ***!
    \********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomeHomeComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\r\n\r\n\r\n<mat-toolbar color=\"primary\">\r\n  <span>Import Records</span>\r\n  <span class=\"spacer\"></span>\r\n  Reload data:\r\n  <button mat-icon-button (click)=\"refresh()\">\r\n    <mat-icon>refresh</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<div class=\"container mat-elevation-z8\">\r\n<div class=\"csv-file-chooser-section\">\r\n  <input type=\"file\" #fileImportInput name=\"File Upload\" id=\"txtFileUpload\" (change)=\"fileChangeListener($event)\"\r\n         accept=\".csv\"/>\r\n</div>\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Filter issues\">\r\n    </mat-form-field>\r\n  </div>\r\n\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    ng update @angular/cli @angular/core\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"id\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Id</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"Compound_DM_Time\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Compound_DM_Time</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.Compound_DM_Time}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"CR_DM_Date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>CR_DM_Date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.CR_DM_Date}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"Clearance_BSO_NON_BSO\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Clearance_BSO_NON_BSO</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.Clearance_BSO_NON_BSO}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"Carrier\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Carrier</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.Carrier}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"Contract\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Contract</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.Contract}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\" (click)=\"addNew()\">\r\n          <mat-icon aria-label=\"Example icon-button with a heart icon\">add</mat-icon>\r\n        </button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" (click)=\"startEdit(i, row.id, row.Compound_DM_Time, row.CR_DM_Date, row.Clearance_BSO_NON_BSO, row.Carrier, row.Contract)\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n\r\n        <button mat-icon-button color=\"accent\" (click)=\"deleteItem(i, row.id, row.Compound_DM_Time, row.CR_DM_Date, row.Clearance_BSO_NON_BSO)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n  </mat-table>\r\n\r\n\r\n  \r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/import-record-add/import-record-add.component.html":
  /*!**********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/import-record-add/import-record-add.component.html ***!
    \**********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppImportRecordAddImportRecordAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n     \t\t <app-navbar></app-navbar>\r\n          <!-- / Layout navbar -->  \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"importForm\" (ngSubmit)=\"onFormSubmit(importForm.value)\">\r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n\t\t\t <input matInput [matDatepicker]=\"picker\" placeholder=\"Date\" formControlName=\"Date\" disabled>\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n \t </mat-form-field>  \r\n\t  \r\n\t  \r\n\t  \r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput [matDatepicker]=\"pickerw\" placeholder=\"Revised Information\" formControlName=\"Rev_info\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"pickerw\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #pickerw></mat-datepicker>\r\n      </mat-form-field>\r\n\t  \r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n\t <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Location</mat-label>\r\n\t  <mat-select formControlName=\"SBU_location\" placeholder=\"Select SBU locaction\">\r\n\t\t<mat-option *ngFor=\"let sbulocation of sbulocations\" [value]=\"sbulocation.value\">{{sbulocation.viewValue}}</mat-option>\r\n\t  </mat-select>\r\n\t</mat-form-field>\r\n\t  \r\n\t  \t\r\n\t\t\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Request Sent By\" formControlName=\"Req_sent_by\">\r\n      </mat-form-field>\r\n\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input (input)=\"suggest($event.target.value)\" placeholder=\"Select Vendor\" aria-label=\"Number\" matInput formControlName=\"Vendor_name\" [matAutocomplete]=\"autov\">\r\n\t\t<mat-autocomplete #autov=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let option of Vendor_Result\" [value]=\"option.vendor_name\">\r\n\t\t\t{{option.vendor_name}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\r\n\t <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Category</mat-label>\r\n\t  <mat-select formControlName=\"Category\" placeholder=\"Select SBU Category\">\r\n\t\t<mat-option *ngFor=\"let category of categories\" [value]=\"category.value\">{{category.viewValue}}</mat-option>\r\n\t  </mat-select>\t\r\n\t  </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Nacharam Unit-Purchage Order\" formControlName=\"NRM\">\r\n      </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Mallapur Unit-Purchase Order\" formControlName=\"MPR\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Bangalore Unit-Purchase Order\" formControlName=\"BLR\">\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Visakhapatnam Unit-Purchase Order\" formControlName=\"VPO\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input type=\"text\" (input)=\"suggest_country($event.target.value)\" placeholder=\"Select Country\" aria-label=\"Number\" matInput formControlName=\"Country\" [matAutocomplete]=\"autoc\">\r\n\t\t<mat-autocomplete #autoc=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let c of country_Result\" [value]=\"c.country\">\r\n\t\t\t{{c.country}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Number of Chemicals\" formControlName=\"No_of_chem\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Air Way Bill/Bill of Lading Number\" formControlName=\"AWB_no\" [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!importForm.get('AWB_no').valid && importForm.get('AWB_no').touched\">Please enter AWB No</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Remarks\" formControlName=\"Remarks\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Reasons\" formControlName=\"Reasons\">\r\n      </mat-form-field>\r\n\r\n\t<mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Status</mat-label>\r\n\t  <mat-select formControlName=\"Status\" placeholder=\"Select Status\">\r\n\t\t<mat-option *ngFor=\"let importstatu of importstatus\" [value]=\"importstatu.value\">{{importstatu.viewValue}}</mat-option>\r\n\t  </mat-select>\t\r\n\t</mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n    <mat-form-field class=\"example-full-width\">\r\n\t\t <input matInput [matDatepicker]=\"pickerdel\" placeholder=\"Delivery Date\" formControlName=\"Delivery_Date\" (dateChange)=\"onChangeDelivery_Date($event.value)\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"pickerdel\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #pickerdel></mat-datepicker>\r\n    </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t <input matInput [matDatepicker]=\"pickeredel\" placeholder=\"Expected Delivery Date\" formControlName=\"Expected_Date_Delivery\" >\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"pickeredel\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #pickeredel></mat-datepicker>\r\n \t  </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input type=\"text\" (input)=\"suggest_carrier($event.target.value)\" placeholder=\"Select Carrier\" aria-label=\"Number\" matInput formControlName=\"Carrier\" [matAutocomplete]=\"auto\">\r\n\t\t<mat-autocomplete #auto=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let o of carrier_Result\" [value]=\"o.carrier\">\r\n\t\t\t{{o.carrier}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t <input matInput [matDatepicker]=\"Pick_up_date\" placeholder=\"Pick up date\" formControlName=\"Pick_up_date\" (dateChange)=\"onChangePickupdate($event.value)\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"Pick_up_date\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #Pick_up_date ></mat-datepicker>\r\n\t  </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n     \t\t <input matInput [matDatepicker]=\"shpt_land_dt\" placeholder=\"Shipment Landed Date\" formControlName=\"shpt_land_dt\" (dateChange)=\"onChangeshipment($event.value)\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"shpt_land_dt\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #shpt_land_dt></mat-datepicker>\r\n\t\t</mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n     \t\t <input matInput [matDatepicker]=\"Docs_shared_date\" placeholder=\"Documents Shared Date\" formControlName=\"Docs_shared_date\" >\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"Docs_shared_date\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #Docs_shared_date></mat-datepicker>\r\n\t\t\t\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\r\n\t  <mat-label>Select Port of clearance</mat-label>\r\n\t  <mat-select formControlName=\"Port_of_clearance\">\r\n\t\t<mat-option [value]=\"AIR-BLR\">AIR-BLR</mat-option>\r\n\t\t<mat-option [value]=\"ICD-BLR\">ICD-BLR</mat-option>\r\n\t\t<mat-option [value]=\"AIR-HYD\">AIR-HYD</mat-option>\r\n\t\t<mat-option [value]=\"ICD-HYD\">ICD-HYD</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input type=\"text\" (input)=\"suggest_cha($event.target.value)\" placeholder=\"Select Customs handling agent\" aria-label=\"Number\" matInput formControlName=\"CHA\" [matAutocomplete]=\"autocha\">\r\n\t\t<mat-autocomplete #autocha=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let ch of tempcha_Result\" [value]=\"ch.cha_name\">\r\n\t\t\t{{ch.cha_name}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Clearance Turn Around Time\" formControlName=\"Clearance_TAT\" [value]=\"Clearance_TATdays\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Transit Turn Around Time\" formControlName=\"Transit_TAT\" [value]=\"Transit_TATdays\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Total Turn Around Time\" formControlName=\"Total_TAT\" [value]=\"Total_TATdays\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"PC Meter\" formControlName=\"PC_Meter\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Bill Number\" formControlName=\"Bill_No\">\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Clearance Charges\" formControlName=\"Clearance_Charges\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Freight\" formControlName=\"Freight\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Bill of Entry Number\" formControlName=\"BE_No\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n   \t\t <input matInput [matDatepicker]=\"BE_Date\" placeholder=\"Bill of Entry Date\" formControlName=\"BE_Date\" >\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"BE_Date\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #BE_Date></mat-datepicker>\r\n\t\t\r\n\t\t\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Penalty Charges\" formControlName=\"Penalty_Charges\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Reason for penalty\" formControlName=\"Reason_for_penalty\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Approval status\" formControlName=\"Approval_status\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Dangerous Goods</mat-label>\r\n\t  <mat-select formControlName=\"DG\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t  \r\n\t  \t \r\n\t \r\n\t\t\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select High Value</mat-label>\r\n\t  <mat-select formControlName=\"High_Value\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<mat-label>Select Perishable</mat-label>\r\n\t\t<mat-select formControlName=\"Perishable\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<mat-label>Select Bank Release Order\r\n\t\t</mat-label>\r\n\t\t<mat-select formControlName=\"BRO\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<mat-label>Select Reasons For Reports\r\n\t\t</mat-label>\r\n\t\t<mat-select formControlName=\"Reasons_For_Reports\">\r\n\t\t<mat-option *ngFor=\"let Rfp of Rfps\" [value]=\"Rfp.value\">{{Rfp.viewValue}}</mat-option>\r\n\t  </mat-select>\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Zone\" formControlName=\"Zone\">\r\n      </mat-form-field>\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Remarks For Reports\" formControlName=\"RemarksForReports\">\r\n      </mat-form-field>\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"CMS shipts Balance Details\" formControlName=\"CMSshiptsBalanceDetails\">\r\n      </mat-form-field>\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input matInput [matDatepicker]=\"OriginalBoESubmittedDate\" placeholder=\"Original BoE Submitted Date\" formControlName=\"OriginalBoESubmittedDate\" >\r\n\t\t<mat-datepicker-toggle matSuffix [for]=\"OriginalBoESubmittedDate\"></mat-datepicker-toggle>\r\n\t\t<mat-datepicker #OriginalBoESubmittedDate></mat-datepicker>\r\n  \t  </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"CMS_CDS_Product_NameRrProjectCode\" formControlName=\"CMS_CDS_Product_NameRrProjectCode\">\r\n      </mat-form-field>\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Gross Weight_Kg\" formControlName=\"GrossWeight_Kg\">\r\n      </mat-form-field>\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Distance In Kms\" formControlName=\"DistanceInKms\">\r\n      </mat-form-field>\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Co2 Emiission_Kg\" formControlName=\"Co2Emiission_Kg\">\r\n      </mat-form-field>\r\n\r\n\t\r\n\t</div>  \r\n\r\n \r\n  <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!importForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon>Save</button>\r\n     <div class='alert-success'> {{Message}}\r\n\t </div>\r\n\t </div>\r\n    </form>\r\n\t  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/import-record-edit/import-record-edit.component.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/import-record-edit/import-record-edit.component.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppImportRecordEditImportRecordEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n     \t\t <app-navbar></app-navbar>\r\n          <!-- / Layout navbar -->  \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"importForm\" (ngSubmit)=\"onFormSubmit(importForm.value)\">\r\n\t<div class=\"form-row\">\r\n      <mat-form-field class=\"example-full-width\">\r\n\t\t\t <input matInput [matDatepicker]=\"picker\" placeholder=\"Date\" formControlName=\"Date\" disabled>\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n \t </mat-form-field>  \r\n\t  \r\n\t  \r\n\t  \r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput [matDatepicker]=\"pickerw\" placeholder=\"Revised Information\" formControlName=\"Rev_info\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"pickerw\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #pickerw></mat-datepicker>\r\n      </mat-form-field>\r\n\t  \r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n\t <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Location</mat-label>\r\n\t  <mat-select formControlName=\"SBU_location\" placeholder=\"Select SBU locaction\">\r\n\t\t<mat-option *ngFor=\"let sbulocation of sbulocations\" [value]=\"sbulocation.value\">{{sbulocation.viewValue}}</mat-option>\r\n\t  </mat-select>\r\n\t</mat-form-field>\r\n\t  \r\n\t  \t\r\n\t\t\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Request Sent By\" formControlName=\"Req_sent_by\">\r\n      </mat-form-field>\r\n\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input (input)=\"suggest($event.target.value)\" placeholder=\"Select Vendor\" aria-label=\"Number\" matInput formControlName=\"Vendor_name\" [matAutocomplete]=\"autov\">\r\n\t\t<mat-autocomplete #autov=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let option of Vendor_Result\" [value]=\"option.vendor_name\">\r\n\t\t\t{{option.vendor_name}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\r\n\t <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Category</mat-label>\r\n\t  <mat-select formControlName=\"Category\" placeholder=\"Select SBU Category\">\r\n\t\t<mat-option *ngFor=\"let category of categories\" [value]=\"category.value\">{{category.viewValue}}</mat-option>\r\n\t  </mat-select>\t\r\n\t  </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n      \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Nacharam Unit-Purchage Order\" formControlName=\"NRM\">\r\n      </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Mallapur Unit-Purchase Order\" formControlName=\"MPR\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Bangalore Unit-Purchase Order\" formControlName=\"BLR\">\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Visakhapatnam Unit-Purchase Order\" formControlName=\"VPO\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input type=\"text\" (input)=\"suggest_country($event.target.value)\" placeholder=\"Select Country\" aria-label=\"Number\" matInput formControlName=\"Country\" [matAutocomplete]=\"autoc\">\r\n\t\t<mat-autocomplete #autoc=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let c of country_Result\" [value]=\"c.country\">\r\n\t\t\t{{c.country}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Number of Chemicals\" formControlName=\"No_of_chem\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Air Way Bill/Bill of Lading Number\" formControlName=\"AWB_no\" [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!importForm.get('AWB_no').valid && importForm.get('AWB_no').touched\">Please enter AWB No</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Remarks\" formControlName=\"Remarks\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Reasons\" formControlName=\"Reasons\">\r\n      </mat-form-field>\r\n\r\n\t<mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Status</mat-label>\r\n\t  <mat-select formControlName=\"Status\" placeholder=\"Select Status\">\r\n\t\t<mat-option *ngFor=\"let importstatu of importstatus\" [value]=\"importstatu.value\">{{importstatu.viewValue}}</mat-option>\r\n\t  </mat-select>\t\r\n\t</mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\r\n    <mat-form-field class=\"example-full-width\">\r\n\t\t <input matInput [matDatepicker]=\"pickerdel\" placeholder=\"Delivery Date\" formControlName=\"Delivery_Date\" (dateChange)=\"onChangeDelivery_Date($event.value)\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"pickerdel\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #pickerdel></mat-datepicker>\r\n    </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t <input matInput [matDatepicker]=\"pickeredel\" placeholder=\"Expected Delivery Date\" formControlName=\"Expected_Date_Delivery\" >\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"pickeredel\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #pickeredel></mat-datepicker>\r\n \t  </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input type=\"text\" (input)=\"suggest_carrier($event.target.value)\" placeholder=\"Select Carrier\" aria-label=\"Number\" matInput formControlName=\"Carrier\" [matAutocomplete]=\"auto\">\r\n\t\t<mat-autocomplete #auto=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let o of carrier_Result\" [value]=\"o.carrier\">\r\n\t\t\t{{o.carrier}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t <input matInput [matDatepicker]=\"Pick_up_date\" placeholder=\"Pick up date\" formControlName=\"Pick_up_date\" (dateChange)=\"onChangePickupdate($event.value)\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"Pick_up_date\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #Pick_up_date ></mat-datepicker>\r\n\t  </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n     \t\t <input matInput [matDatepicker]=\"shpt_land_dt\" placeholder=\"Shipment Landed Date\" formControlName=\"shpt_land_dt\" (dateChange)=\"onChangeshipment($event.value)\">\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"shpt_land_dt\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #shpt_land_dt></mat-datepicker>\r\n\t\t</mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n     \t\t <input matInput [matDatepicker]=\"Docs_shared_date\" placeholder=\"Documents Shared Date\" formControlName=\"Docs_shared_date\" >\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"Docs_shared_date\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #Docs_shared_date></mat-datepicker>\r\n\t\t\t\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\r\n\t  <mat-label>Select Port of clearance</mat-label>\r\n\t  <mat-select formControlName=\"Port_of_clearance\">\r\n\t\t<mat-option [value]=\"AIR-BLR\">AIR-BLR</mat-option>\r\n\t\t<mat-option [value]=\"ICD-BLR\">ICD-BLR</mat-option>\r\n\t\t<mat-option [value]=\"AIR-HYD\">AIR-HYD</mat-option>\r\n\t\t<mat-option [value]=\"ICD-HYD\">ICD-HYD</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<input type=\"text\" (input)=\"suggest_cha($event.target.value)\" placeholder=\"Select Customs handling agent\" aria-label=\"Number\" matInput formControlName=\"CHA\" [matAutocomplete]=\"autocha\">\r\n\t\t<mat-autocomplete #autocha=\"matAutocomplete\">\r\n\t\t  <mat-option *ngFor=\"let ch of tempcha_Result\" [value]=\"ch.cha_name\">\r\n\t\t\t{{ch.cha_name}}\r\n\t\t  </mat-option>\r\n\t\t</mat-autocomplete>\r\n\t  </mat-form-field>\r\n\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Clearance Turn Around Time\" formControlName=\"Clearance_TAT\" [value]=\"Clearance_TATdays\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Transit Turn Around Time\" formControlName=\"Transit_TAT\" [value]=\"Transit_TATdays\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Total Turn Around Time\" formControlName=\"Total_TAT\" [value]=\"Total_TATdays\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"PC Meter\" formControlName=\"PC_Meter\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Bill Number\" formControlName=\"Bill_No\">\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Clearance Charges\" formControlName=\"Clearance_Charges\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Freight\" formControlName=\"Freight\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Bill of Entry Number\" formControlName=\"BE_No\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n   \t\t <input matInput [matDatepicker]=\"BE_Date\" placeholder=\"Bill of Entry Date\" formControlName=\"BE_Date\" >\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"BE_Date\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #BE_Date></mat-datepicker>\r\n\t\t\r\n\t\t\r\n      </mat-form-field>\r\n\r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Penalty Charges\" formControlName=\"Penalty_Charges\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Reason for penalty\" formControlName=\"Reason_for_penalty\">\r\n      </mat-form-field>\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Approval status\" formControlName=\"Approval_status\">\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select Dangerous Goods</mat-label>\r\n\t  <mat-select formControlName=\"DG\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t  \r\n\t  \t \r\n\t \r\n\t\t\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t  <mat-label>Select High Value</mat-label>\r\n\t  <mat-select formControlName=\"High_Value\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<mat-label>Select Perishable</mat-label>\r\n\t\t<mat-select formControlName=\"Perishable\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t  \r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<mat-label>Select Bank Release Order\r\n\t\t</mat-label>\r\n\t\t<mat-select formControlName=\"BRO\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n\r\n      </mat-form-field>\r\n\t</div>  \r\n\t<div class=\"form-row\">\r\n\t\r\n\t  <mat-form-field class=\"example-full-width\">\r\n\t\t<mat-label>Select Reasons For Reports\r\n\t\t</mat-label>\r\n\t\t<mat-select formControlName=\"Reasons_For_Reports\">\r\n\t\t<mat-option *ngFor=\"let Rfp of Rfps\" [value]=\"Rfp.value\">{{Rfp.viewValue}}</mat-option>\r\n\t  </mat-select>\r\n      </mat-form-field>\r\n\r\n\t<mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Zone\" formControlName=\"Zone\">\r\n      </mat-form-field>\r\n\t</div> \r\n\t<div class=\"form-row\">\r\n\t\t<mat-form-field class=\"example-full-width\">\r\n\t\t\t<input matInput placeholder=\"Remarks For Reports\" formControlName=\"RemarksForReports\">\r\n\t\t  </mat-form-field>\r\n\t\t  <mat-form-field class=\"example-full-width\">\r\n\t\t\t<input matInput placeholder=\"CMS shipts Balance Details\" formControlName=\"CMSshiptsBalanceDetails\">\r\n\t\t  </mat-form-field>\r\n\t</div>\r\n\t<div class=\"form-row\">\r\n\t\t<mat-form-field class=\"example-full-width\">\r\n\t\t\t<input matInput [matDatepicker]=\"OriginalBoESubmittedDate\" placeholder=\"Original BoE Submitted Date\" formControlName=\"OriginalBoESubmittedDate\" >\r\n\t\t\t<mat-datepicker-toggle matSuffix [for]=\"OriginalBoESubmittedDate\"></mat-datepicker-toggle>\r\n\t\t\t<mat-datepicker #OriginalBoESubmittedDate></mat-datepicker>\r\n\t\t\t</mat-form-field>\r\n\t\t  \r\n\t\t  <mat-form-field class=\"example-full-width\">\r\n\t\t\t<input matInput placeholder=\"CMS_CDS_Product_NameRrProjectCode\" formControlName=\"CMS_CDS_Product_NameRrProjectCode\">\r\n\t\t  </mat-form-field>\r\n\t</div>\r\n\t<div class=\"form-row\">\r\n\t\t<mat-form-field class=\"example-full-width\">\r\n\t\t\t<input matInput placeholder=\"Gross Weight_Kg\" formControlName=\"GrossWeight_Kg\">\r\n\t\t  </mat-form-field>\r\n\t\t  <mat-form-field class=\"example-full-width\">\r\n\t\t\t<input matInput placeholder=\"Distance In Kms\" formControlName=\"DistanceInKms\">\r\n\t\t  </mat-form-field>\r\n\t</div>\r\n\t<div class=\"form-row\">\r\n\t\t<mat-form-field class=\"example-full-width\">\r\n\t\t\t<input matInput placeholder=\"Co2 Emiission_Kg\" formControlName=\"Co2Emiission_Kg\">\r\n\t\t  </mat-form-field> \r\n\t</div>\r\n  <div class=\"button-row\">\r\n        <button type=\"submit\"  mat-flat-button color=\"primary\"><mat-icon>save</mat-icon>Save</button>\r\n     <div class='alert-success'> {{Message}}\r\n\t </div>\r\n\t </div>\r\n    </form>\r\n\t  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/import-records-list/import-records-list.component.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/import-records-list/import-records-list.component.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppImportRecordsListImportRecordsListComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n  <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n    <div class=\"layout-container\">\r\n      <!-- Layout navbar -->\r\n      <app-navbar></app-navbar>\r\n      <!-- / Layout navbar -->\r\n      <div class=\"container mat-elevation-z8\">\r\n        <div class=\"row align-items-center\">\r\n          <div class=\"col-md-3\">\r\n              <!-- <input type=\"text\" required [(ngModel)]=\"searchField\" class=\"form-control\" placeholder=\"AWB No. / Vendor Name\">  -->\r\n              <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n                <input (keyup.enter)=\"onSubmit()\" matInput #filter [(ngModel)]=\"searchField\" placeholder=\"AWB No. / Vendor Name\">\r\n              </mat-form-field>\r\n          </div>\r\n          <div class=\"col-md-3\">\r\n            <button type=\"submit\" (click)=\"onSubmit()\" class=\"btn btn-primary\" >Submit</button>\r\n          </div>\r\n          <div class=\"col-md-6 text-right\">\r\n            <div class=\"top-btns\">\r\n              <button [disabled]=\"totalShipments?.length==0\" class=\"btn btn-secondary\" aria-label=\"export type\" title=\"Export data\" type=\"button\"\r\n                aria-expanded=\"false\" (click)=\"exportAsXLSX()\">\r\n                <i class=\"opacity-75 ion ion-md-cloud-download icon-share\"></i>\r\n                <span class=\"caret\"> Excel <i class=\"fa fa-spinner fa-spin\" *ngIf=\"excelLoader\"></i></span>\r\n              </button>\r\n              <button (click)='accordion = !accordion' class=\"btn btn-info\" id=\"accordionid\">Import</button>\r\n              <button routerLink=\"/import-add\" class=\"btn btn-success\">Add</button>\r\n            </div>\r\n          </div>\r\n        </div>\r\n        {{Message}}\r\n        <div *ngIf=\"accordion\" id=\"accordion-1\" class=\"upload-f\">\r\n          <div class=\"card-body\">\r\n            <form class=\"import-sec\">\r\n              <div class=\"form-group\">\r\n                <div class=\"form-control\">\r\n                  <input type=\"file\" style=\"display:inline-block;\" (change)=\"incomingfile($event)\"\r\n                    placeholder=\"Upload file\" accept=\".xlsx\">\r\n                </div>\r\n              </div>\r\n              <div class=\"upload-btn\">\r\n                <button type=\"button\" class=\"btn btn-info\" (click)=\"Upload()\">Upload</button>\r\n              </div>\r\n            </form>\r\n          </div>\r\n        </div>\r\n        <div class=\"example-loading-shade\" *ngIf=\"isLoadingResults\">\r\n            <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n        </div> \r\n        <div class=\"table-responsive\">\r\n          <div class=\"fa-3x\" *ngIf=\"loader; else show_result\" style=\"text-align: center;\">\r\n            <i class=\"fa fa-spinner fa-spin\" style=\"font-size:24px\"></i>\r\n          </div>\r\n          <ng-template #show_result>\r\n            <mat-table #table [dataSource]=\"importedData?.records\" matSort class=\"mat-cell\">\r\n              <ng-container matColumnDef=\"id\">\r\n                <mat-header-cell *matHeaderCellDef >Id</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n              </ng-container>\r\n          \r\n              <ng-container matColumnDef=\"AWB No\">\r\n                <mat-header-cell *matHeaderCellDef >AWB No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.AWB_no}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Date\">\r\n                <mat-header-cell *matHeaderCellDef >Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Date | date}} \r\n          </mat-cell>\r\n              </ng-container>\r\n          \r\n              <ng-container matColumnDef=\"Rev_info\">\r\n                <mat-header-cell *matHeaderCellDef >Rev info</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Rev_info | date}}</mat-cell>\r\n              </ng-container>\r\n          \r\n              <ng-container matColumnDef=\"SBU_location\">\r\n                <mat-header-cell *matHeaderCellDef >SBU location</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.SBU_location}}</mat-cell>\r\n              </ng-container>\r\n          \r\n              <ng-container matColumnDef=\"Req_sent_by\">\r\n                <mat-header-cell *matHeaderCellDef >Req sent by</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Req_sent_by}}</mat-cell>\r\n              </ng-container>\r\n          \r\n              <ng-container matColumnDef=\"Vendor_name\">\r\n                <mat-header-cell *matHeaderCellDef >Vendor Name</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Vendor_name}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Category\">\r\n                <mat-header-cell *matHeaderCellDef >Category</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Category}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Contract\">\r\n                <mat-header-cell *matHeaderCellDef >Contract</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Contract}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"NRM\">\r\n                <mat-header-cell *matHeaderCellDef >NRM</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.NRM}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"MPR\">\r\n                <mat-header-cell *matHeaderCellDef >MPR</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.MPR}}</mat-cell>\r\n              </ng-container>  \r\n            <ng-container matColumnDef=\"BLR\">\r\n                <mat-header-cell *matHeaderCellDef >BLR</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.BLR}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"VPO\">\r\n                <mat-header-cell *matHeaderCellDef >VPO</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.VPO}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Country\">\r\n                <mat-header-cell *matHeaderCellDef >Country</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Country}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"No_of_chem\">\r\n                <mat-header-cell *matHeaderCellDef >No of chem</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.No_of_chem}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Remarks\">\r\n                <mat-header-cell *matHeaderCellDef >Remarks</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Remarks}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Reasons\">\r\n                <mat-header-cell *matHeaderCellDef >Reasons</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Reasons}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Status\">\r\n                <mat-header-cell *matHeaderCellDef >Status</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Status}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Delivery_Date\">\r\n                <mat-header-cell *matHeaderCellDef >Delivery Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Delivery_Date | date}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Expected_Date_Delivery\">\r\n                <mat-header-cell *matHeaderCellDef >Expected Date Delivery</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Expected_Date_Delivery | date}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Carrier\">\r\n                <mat-header-cell *matHeaderCellDef >Carrier</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Carrier}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Pick_up_date\">\r\n                <mat-header-cell *matHeaderCellDef >Pick up date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Pick_up_date | date}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"shpt_land_dt\">\r\n                <mat-header-cell *matHeaderCellDef >Shipment land date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.shpt_land_dt | date}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Docs_shared_date\">\r\n                <mat-header-cell *matHeaderCellDef >Document shared date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Docs_shared_date | date}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Port_of_clearance\">\r\n                <mat-header-cell *matHeaderCellDef >Port of clearance</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Port_of_clearance}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"CHA\">\r\n                <mat-header-cell *matHeaderCellDef >CHA</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.CHA}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Clearance_TAT\">\r\n                <mat-header-cell *matHeaderCellDef >Clearance TAT</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Clearance_TAT}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Transit_TAT\">\r\n                <mat-header-cell *matHeaderCellDef >Transit TAT</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Transit_TAT}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Total_TAT\">\r\n                <mat-header-cell *matHeaderCellDef >Total TAT</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Total_TAT}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"PC_Meter\">\r\n                <mat-header-cell *matHeaderCellDef >PC Meter</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.PC_Meter}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Bill_No\">\r\n                <mat-header-cell *matHeaderCellDef >Bill No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Bill_No}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Clearance_Charges\">\r\n                <mat-header-cell *matHeaderCellDef >Clearance Charges</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Clearance_Charges}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Freight\">\r\n                <mat-header-cell *matHeaderCellDef >Freight</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Freight}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"BE_No\">\r\n                <mat-header-cell *matHeaderCellDef >BE No</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.BE_No}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"BE_Date\">\r\n                <mat-header-cell *matHeaderCellDef >BE Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.BE_Date | date}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Penalty_Charges\">\r\n                <mat-header-cell *matHeaderCellDef >Penalty Charges</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Penalty_Charges}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Reason_for_penalty\">\r\n                <mat-header-cell *matHeaderCellDef >Reason for penalty</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Reason_for_penalty}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Approval_status\">\r\n                <mat-header-cell *matHeaderCellDef >Approval status</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Approval_status}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"DG\">\r\n                <mat-header-cell *matHeaderCellDef >DG</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.DG}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"High_Value\">\r\n                <mat-header-cell *matHeaderCellDef >High Value</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.High_Value}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Perishable\">\r\n                <mat-header-cell *matHeaderCellDef >Perishable</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Perishable}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"BRO\">\r\n                <mat-header-cell *matHeaderCellDef >BRO</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.BRO}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Reasons_For_Reports\">\r\n                <mat-header-cell *matHeaderCellDef >Reasons_For_Reports</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Reasons_For_Reports}}</mat-cell>\r\n              </ng-container>\r\n            <ng-container matColumnDef=\"Create_Date\">\r\n                <mat-header-cell *matHeaderCellDef >Create_Date</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Create_Date}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Zone\">\r\n                <mat-header-cell *matHeaderCellDef >Zone</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Zone}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"RemarksForReports\">\r\n                <mat-header-cell *matHeaderCellDef >RemarksForReports</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.RemarksForReports}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"CMSshiptsBalanceDetails\">\r\n                <mat-header-cell *matHeaderCellDef >CMSshiptsBalanceDetails</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.CMSshiptsBalanceDetails}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"OriginalBoESubmittedDate\">\r\n                <mat-header-cell *matHeaderCellDef >OriginalBoESubmittedDate</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.OriginalBoESubmittedDate | date}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"CMS_CDS_Product_NameRrProjectCode\">\r\n                <mat-header-cell *matHeaderCellDef >CMS_CDS_Product_NameRrProjectCode</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.CMS_CDS_Product_NameRrProjectCode}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"GrossWeight_Kg\">\r\n                <mat-header-cell *matHeaderCellDef >GrossWeight_Kg</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.GrossWeight_Kg}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"DistanceInKms\">\r\n                <mat-header-cell *matHeaderCellDef >DistanceInKms</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.DistanceInKms}}</mat-cell>\r\n              </ng-container>\r\n              <ng-container matColumnDef=\"Co2Emiission_Kg\">\r\n                <mat-header-cell *matHeaderCellDef >Co2Emiission_Kg</mat-header-cell>\r\n                <mat-cell *matCellDef=\"let row\"> {{row.Co2Emiission_Kg}}</mat-cell>\r\n              </ng-container>\r\n              <!-- actions -->\r\n              <ng-container matColumnDef=\"actions\">\r\n                <mat-header-cell *matHeaderCellDef>\r\n                  <button mat-icon-button color=\"primary\" >\r\n                    <mat-icon aria-label=\"Example icon-button with a heart icon\">Actions</mat-icon>\r\n                  </button>\r\n                </mat-header-cell>\r\n          \r\n                <mat-cell *matCellDef=\"let row; let i=index;\">\r\n                  \r\n              <button mat-icon-button color=\"accent\"  [routerLink]=\"['/import-edit', row.id]\"><mat-icon>edit</mat-icon></button>\r\n          \r\n                  <button mat-icon-button color=\"accent\" (click)=\"deleteimportshipment(row.id)\">\r\n                    <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n                  </button>\r\n                </mat-cell>\r\n              </ng-container>\r\n          \r\n              <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n              <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n            </mat-table>\r\n          \r\n          <p *ngIf=\"importedData?.records.length === 0\" class=\"no-records text-center\">No records found</p>\r\n            \r\n          </ng-template>\r\n            <mat-paginator \r\n                (page)=\"getPaginatorData($event)\"\r\n                [length]=\"importedData?.count\"\r\n                [pageSize]=\"importedData?.pagePer\"\r\n                [pageIndex]=\"importedData?.pageNo - 1\"\r\n                [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n            </mat-paginator>\r\n        </div>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/import-reports/import-reports.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/import-reports/import-reports.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppImportReportsImportReportsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n  <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n    <div class=\"layout-container\">\r\n      <!-- Layout navbar -->\r\n      <app-navbar></app-navbar>\r\n      <div *ngIf=\"zonesLoader; else show_zones\" class=\"container exp\">\r\n        <p>Loading...</p>\r\n      </div>\r\n      <ng-template #show_zones>\r\n        <div class=\"container exp\">\r\n          <form  [formGroup]=\"searchForm\" (ngSubmit)=\"onSubmit()\">\r\n            <div class=\"row align-items-center fil-sec\">\r\n              <div class=\"col-md-10 \">\r\n                <div class=\"row \">\r\n                  <div class=\"col-md-12 d-flex\">\r\n                    <div class=\"inp-item\">\r\n                    <mat-form-field >\r\n                      <input matInput [matDatepicker]=\"picker\" placeholder=\"From Date\" formControlName=\"fromDate\" disabled>\r\n                         <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                         <mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n                         </mat-form-field>\r\n                    <div *ngIf=\"f.fromDate.errors && f.fromDate.errors.required && submitted\" class=\"text-danger\">\r\n                      This Field is required.\r\n                  </div>\r\n                    </div>\r\n                    <div class=\"inp-item\">\r\n                    <mat-form-field >\r\n                      <input matInput [matDatepicker]=\"pickerToDate\" placeholder=\"To Date\" formControlName=\"toDate\" disabled>\r\n                         <mat-datepicker-toggle matSuffix [for]=\"pickerToDate\"></mat-datepicker-toggle>\r\n                         <mat-datepicker #pickerToDate disabled=\"false\"></mat-datepicker>\r\n                    </mat-form-field>\r\n                    <div *ngIf=\"f.toDate.errors && f.toDate.errors.required && submitted\" class=\"text-danger\">\r\n                      This Field is required.\r\n                  </div>\r\n                    </div>\r\n                 <div class=\"inp-item\">\r\n                  <input\r\n                  type=\"number\"\r\n                  placeholder=\"Days\"\r\n                  min=\"0\"\r\n                  class=\"form-control\"\r\n                  formControlName=\"days\"\r\n                />\r\n                <div *ngIf=\"f.days.errors && f.days.errors.required && submitted\" class=\"text-danger\">\r\n                  This Field is required.\r\n              </div>\r\n                 </div>        \r\n                  </div>\r\n                  <div class=\"col-md-12 mt-2 d-flex\">\r\n                    <ng-multiselect-dropdown\r\n                    [data]=\"zonesData\"\r\n                    [placeholder]=\"'Select Zones'\" \r\n                    [settings]=\"settings\"\r\n                    formControlName=\"zone\"\r\n                    >\r\n                    </ng-multiselect-dropdown>\r\n                    <ng-multiselect-dropdown\r\n                    [data]=\"cat\"\r\n                    [placeholder]=\"'Select Category'\" \r\n                    formControlName=\"category\"\r\n                    [settings]=\"settings\"\r\n                    (onSelect)=\"onItemSelect($event)\" \r\n                    (onDeSelect)=\"onDeSelect($event)\"\r\n                    (onSelectAll)=\"onSelectAll($event)\"\r\n                    (onDeSelectAll)=\"onDeSelectAll($event)\"\r\n                    >\r\n                    </ng-multiselect-dropdown>\r\n                    \r\n                  </div>\r\n                  <div class=\"col-md-12 mt-2 d-flex\">\r\n                    <ng-multiselect-dropdown *ngIf=\"carrierShow\"\r\n                    [data]=\"carriers\"\r\n                    [placeholder]=\"'Select Carrier'\" \r\n                    formControlName=\"carriers\"\r\n                    [settings]=\"settings\">\r\n                </ng-multiselect-dropdown>\r\n                <ng-multiselect-dropdown *ngIf=\"chaShow\"\r\n                  [data]=\"cha\"\r\n                  [placeholder]=\"'Select CHA'\" \r\n                  formControlName=\"cha\"\r\n                  [settings]=\"settings\">\r\n                </ng-multiselect-dropdown>\r\n                  </div>\r\n                </div>\r\n                \r\n             \r\n               \r\n              </div>\r\n              <div class=\"col-md-2\">\r\n                <button class=\"btn btn-info\">Submit</button>\r\n              </div>\r\n            </div>\r\n          </form><br><br>\r\n          <div class=\"fa-3x\" *ngIf=\"loading; else show_result\" style=\"text-align: center;\">\r\n            <i class=\"fa fa-spinner fa-spin\" style=\"font-size:24px; text-align: center;\"></i>\r\n          </div>\r\n          <ng-template #show_result>\r\n            <div *ngIf=\"importData\">\r\n              <button class=\"btn btn-secondary\" (click)=\"exportAsXLSX()\">Export <i class=\"opacity-75 ion ion-md-cloud-download icon-share\"></i></button><br><br>\r\n              <div class=\"row\" >\r\n                <div class=\"col-md-12\">\r\n                  <div class=\"exp-sec\">\r\n                    <div class=\"table-responsive\">\r\n                      <table style=\"width: 100%\" >\r\n                        <tbody>\r\n                          <tr>\r\n                            <td>\r\n                              <table  class=\"table table-bordered table-striped\" id=\"excel-table\">\r\n                                <tbody  >\r\n                                  <ng-container *ngIf=\"importData?.response['Clearance TAT']\">\r\n                                    <tr>\r\n                                      <th colspan=\"5\" style=\"background-color: #e9f8ff;\"> Clearance TAT</th>\r\n                                    </tr>\r\n                                    <tr >\r\n                                      <th style=\"width: 200px;\">CHA</th>\r\n                                      <th style=\"width: 200px;\">Percentage(%)</th>\r\n                                      <th style=\"width: 200px;\">Total</th>\r\n                                      <th style=\"width: 200px;\">On Time</th>\r\n                                      <th style=\"width: 200px;\">Delay</th>\r\n                                    </tr>\r\n                                    <tr *ngFor=\"let data2 of importData?.response['Clearance TAT'] | keyvalue\">\r\n                                      <td ><b>{{data2.key}}</b></td>\r\n                                      <td>{{data2?.value.onTime / data2?.value.totalNo * 100  >  0 ?  (data2?.value.onTime / data2?.value.totalNo * 100 | number: '1.0-0') : 0   }}  %</td>\r\n                                      <td >{{data2.value.totalNo}}</td>\r\n                                      <td >{{data2.value.onTime}}</td>\r\n                                      <td >{{data2.value.delay}}</td>\r\n                                  </tr>\r\n                                  </ng-container>\r\n                                  <ng-container *ngIf=\"importData?.response['Transit TAT']\">\r\n                                    <tr>\r\n                                      <th colspan=\"5\" style=\"background-color: #e9f8ff;\"> Transit TAT</th>\r\n                                    </tr>\r\n                                    <tr >\r\n                                      <th style=\"width: 200px;\">Carrier</th>\r\n                                      <th style=\"width: 200px;\">Percentage(%)</th>\r\n                                      <th style=\"width: 200px;\">Total</th>\r\n                                      <th style=\"width: 200px;\">On Time</th>\r\n                                      <th style=\"width: 200px;\">Delay</th>\r\n                                    </tr>\r\n                                    <tr *ngFor=\"let data2 of importData?.response['Transit TAT'] | keyvalue\">\r\n                                      <td ><b>{{data2.key}}</b></td>\r\n                                      <td>{{data2?.value.onTime / data2?.value.totalNo * 100  >  0 ?  (data2?.value.onTime / data2?.value.totalNo * 100 | number: '1.0-0') : 0   }}  %</td>\r\n                                      <td >{{data2.value.totalNo}}</td>\r\n                                      <td >{{data2.value.onTime}}</td>\r\n                                      <td >{{data2.value.delay}}</td>\r\n                                  </tr><br><br>\r\n                                  </ng-container>\r\n                                  \r\n                                  <tr>\r\n                                    <th colspan=\"5\" style=\"background-color: #e9f8ff;\"> Over All</th>\r\n                                  </tr>\r\n                                  <tr >\r\n                                    <th style=\"width: 200px;\"></th>\r\n                                    <th style=\"width: 200px;\">Percentage(%)</th>\r\n                                    <th style=\"width: 200px;\">Total</th>\r\n                                    <th style=\"width: 200px;\">On Time</th>\r\n                                    <th style=\"width: 200px;\">Delay</th>\r\n                                  </tr>\r\n                                  <tr *ngFor=\"let data of importData?.totalShipments | keyvalue\">\r\n                                      <td><b>{{data?.key}}</b></td>\r\n                                      <td>{{data?.value.onTime / data.value.totalNo * 100  >  0 ?  (data.value.onTime / data.value.totalNo * 100 | number: '1.0-0') : 0   }}  %</td>\r\n                                      <td >{{data.value.totalNo}}</td>\r\n                                      <td >{{data.value.onTime}}</td>\r\n                                      <td >{{data.value.delay}}</td>\r\n                                  </tr>\r\n                                </tbody>\r\n                              </table>\r\n                            </td>\r\n                          </tr>\r\n                        </tbody>\r\n                      </table>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </ng-template>\r\n        </div>\r\n      </ng-template>\r\n    </div>\r\n  </div>\r\n</div>\r\n<br><br><br><br><br>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html":
  /*!**********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLoginLoginComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"page-loader\">\r\n  <div class=\"bg-primary\"></div>\r\n</div>\r\n<div class=\"authentication-wrapper authentication-3\">\r\n  <div class=\"authentication-inner\">\r\n\r\n    <!-- Side container -->\r\n    <!-- Do not display the container on extra small, small and medium screens -->\r\n    <div class=\"d-none d-lg-flex col-lg-8 align-items-center ui-bg-cover ui-bg-overlay-container p-5\"\r\n      style=\"background-image: url('assets/images/21.jpg');height:100vh;\">\r\n      <div class=\"ui-bg-overlay bg-dark opacity-50\"></div>\r\n\r\n      <!-- Text -->\r\n      <div class=\"w-100 text-white px-5\">\r\n        <h2 class=\"font-weight-bolder text-center\"> eCule Logi Tracker</h2>\r\n        <!--<div class=\"text-large font-weight-light\">\r\n            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum vehicula ex eu gravida faucibus. Suspendisse viverra pharetra purus. Proin fringilla ac lorem at sagittis. Proin tincidunt dui et nunc ultricies dignissim.\r\n          </div>-->\r\n      </div>\r\n      <!-- /.Text -->\r\n    </div>\r\n    <!-- / Side container -->\r\n\r\n    <!-- Form container -->\r\n    <div class=\"d-flex col-lg-4 align-items-center bg-white p-5\">\r\n      <!-- Inner container -->\r\n      <!-- Have to add `.d-flex` to control width via `.col-*` classes -->\r\n      <div class=\"d-flex col-sm-7 col-md-5 col-lg-12 px-0 px-xl-4 mx-auto\">\r\n        <div class=\"w-100\">\r\n\r\n          <!-- Logo -->\r\n          <div class=\"d-flex justify-content-center align-items-center\">\r\n            <div>\r\n              <div class=\"text-center\"> <img src=\"../assets/images/Aragen_Logo.png\" height=\"60px\"><br></div>\r\n              <div>\r\n                <img src=\"assets/images/gvk2.png\" style=\"height: 100px;\">\r\n\r\n              </div>\r\n            </div>\r\n          </div>\r\n          <!-- / Logo -->\r\n\r\n          <h4 class=\"text-center text-lighter font-weight-normal mt-5 mb-0\">LOGIN</h4>\r\n\r\n          <!-- Form -->\r\n          <alert></alert>\r\n          <form [formGroup]=\"loginForm\" (ngSubmit)=\"onSubmit()\">\r\n            <div class=\"form-group\">\r\n              <label for=\"email\">Email</label>\r\n              <input type=\"text\" formControlName=\"email\" class=\"form-control\"\r\n                [ngClass]=\"{ 'is-invalid': submitted && f.email.errors }\" />\r\n              <div *ngIf=\"submitted && f.email.errors\" class=\"invalid-feedback\">\r\n                <div *ngIf=\"f.email.errors.required\">Email is required</div>\r\n              </div>\r\n            </div>\r\n            <div class=\"form-group\">\r\n              <label for=\"password\">Password</label>\r\n              <input type=\"password\" formControlName=\"password\" class=\"form-control\"\r\n                [ngClass]=\"{ 'is-invalid': submitted && f.password.errors }\" />\r\n              <div *ngIf=\"submitted && f.password.errors\" class=\"invalid-feedback\">\r\n                <div *ngIf=\"f.password.errors.required\">Password is required</div>\r\n              </div>\r\n            </div>\r\n            <div class=\"form-group\">\r\n              <button [disabled]=\"loading\" class=\"btn btn-primary\">Login</button>\r\n              <img *ngIf=\"loading\" class=\"pl-3\"\r\n                src=\"data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==\" />\r\n\r\n            </div>\r\n          </form> <!-- / Form -->\r\n\r\n\r\n\r\n        </div>\r\n      </div>\r\n    </div>\r\n    <!-- / Form container -->\r\n\r\n  </div>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/navbar/navbar.component.html":
  /*!************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/navbar/navbar.component.html ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppNavbarNavbarComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "               <nav class=\"layout-navbar navbar navbar-expand-lg align-items-lg-center bg-white container-p-x\" id=\"layout-navbar\">\r\n                \r\n                  <a  class=\"navbar-brand app-brand demo d-lg-none py-0 mr-4\">\r\n                  <span class=\"app-brand-text demo font-weight-normal ml-2\">ARAGEN</span>\r\n                  </a>\r\n                  <!-- Sidenav toggle (see assets/css/demo/demo.css) -->\r\n                  <div class=\"layout-sidenav-toggle navbar-nav d-lg-none align-items-lg-center mr-auto\">\r\n                     <a class=\"nav-item nav-link px-0 mr-lg-4\" >\r\n                     <i class=\"ion ion-md-menu text-large align-middle\"></i>\r\n                     </a>\r\n                  </div>\r\n                  <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#layout-navbar-collapse\">\r\n                  <span class=\"navbar-toggler-icon\"></span>\r\n                  </button>\r\n                  <div class=\"navbar-collapse collapse\" id=\"layout-navbar-collapse\">\r\n                     <!-- Divider -->\r\n                     <hr class=\"d-lg-none w-100 my-2\">\r\n                     <div class=\"navbar-nav align-items-lg-center\">\r\n                        \r\n                     </div>\r\n                     <div class=\"navbar-nav align-items-lg-center ml-auto\">\r\n                        <div class=\"demo-navbar-user nav-item dropdown\">\r\n                           \r\n                           <div class=\"dropdown-menu dropdown-menu-right\">\r\n                              \r\n                              <a  class=\"dropdown-item\"><i class=\"ion ion-ios-log-out text-danger\"></i> &nbsp; Log Out</a>\r\n                           </div>\r\n                        </div>\r\n                     </div>\r\n                  </div>\r\n               </nav>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/overall-reports/overall-reports.component.html":
  /*!******************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/overall-reports/overall-reports.component.html ***!
    \******************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOverallReportsOverallReportsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n  <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n    <div class=\"layout-container\">\r\n      <!-- Layout navbar -->\r\n      <app-navbar></app-navbar>\r\n      <div *ngIf=\"zonesLoader; else show_zones\" class=\"container exp\">\r\n        <p>Loading...</p>\r\n      </div>\r\n      <ng-template #show_zones>\r\n        <div class=\"container exp\">\r\n          <form [formGroup]=\"searchForm\" (ngSubmit)=\"onSubmit()\">\r\n            <div class=\"row align-items-center fil-sec\">\r\n              <div class=\"col-md-10 \">\r\n                <div class=\"row \">\r\n                  <div class=\"col-md-12 d-flex\">\r\n                    <div class=\"inp-item\">\r\n                      <mat-form-field>\r\n                        <input matInput [matDatepicker]=\"picker\" placeholder=\"From Date\" formControlName=\"fromDate\"\r\n                          disabled>\r\n                        <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                        <mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n                      </mat-form-field>\r\n                      <div *ngIf=\"f.fromDate.errors && f.fromDate.errors.required && submitted\" class=\"text-danger\">\r\n                        This Field is required.\r\n                      </div>\r\n                    </div>\r\n                    <div class=\"inp-item\">\r\n                      <mat-form-field>\r\n                        <input matInput [matDatepicker]=\"pickerToDate\" placeholder=\"To Date\" formControlName=\"toDate\"\r\n                          disabled>\r\n                        <mat-datepicker-toggle matSuffix [for]=\"pickerToDate\"></mat-datepicker-toggle>\r\n                        <mat-datepicker #pickerToDate disabled=\"false\"></mat-datepicker>\r\n                      </mat-form-field>\r\n                      <div *ngIf=\"f.toDate.errors && f.toDate.errors.required && submitted\" class=\"text-danger\">\r\n                        This Field is required.\r\n                      </div>\r\n                    </div>\r\n\r\n                    <ng-multiselect-dropdown [data]=\"zonesData\" [placeholder]=\"'Select Zones'\" [settings]=\"settings\"\r\n                      formControlName=\"zone\">\r\n                    </ng-multiselect-dropdown>\r\n                  </div>\r\n                  <div class=\"col-md-12 mt-2 d-flex\">\r\n                    <ng-multiselect-dropdown [data]=\"cat\" [placeholder]=\"'Select Category'\" formControlName=\"category\"\r\n                      [settings]=\"settings\" (onSelect)=\"onItemSelect($event)\" (onDeSelect)=\"onDeSelect($event)\"\r\n                      (onSelectAll)=\"onSelectAll($event)\" (onDeSelectAll)=\"onDeSelectAll($event)\">\r\n                    </ng-multiselect-dropdown>\r\n                    <ng-multiselect-dropdown *ngIf=\"carrierShow\" [data]=\"carriers\" [placeholder]=\"'Select Carrier'\"\r\n                      formControlName=\"carriers\" [settings]=\"settings\">\r\n                    </ng-multiselect-dropdown>\r\n\r\n                    <ng-multiselect-dropdown *ngIf=\"chaShow\" [data]=\"cha\" [placeholder]=\"'Select CHA'\"\r\n                      formControlName=\"cha\" [settings]=\"settings\">\r\n                    </ng-multiselect-dropdown>\r\n\r\n                  </div>\r\n                </div>\r\n\r\n\r\n\r\n              </div>\r\n              <div class=\"col-md-2\">\r\n                <button class=\"btn btn-info\">Submit</button>\r\n              </div>\r\n            </div>\r\n          </form><br><br>\r\n          <div class=\"fa-3x\" *ngIf=\"loading; else show_result\" style=\"text-align: center;\">\r\n            <i class=\"fa fa-spinner fa-spin\" style=\"font-size:24px\"></i>\r\n          </div>\r\n          <ng-template #show_result>\r\n            <div *ngIf=\"importData\">\r\n              <button class=\"btn btn-secondary\" (click)=\"exportAsXLSX()\">Export <i\r\n                  class=\"opacity-75 ion ion-md-cloud-download icon-share\"></i> </button><br><br>\r\n              <div class=\"row\">\r\n                <div class=\"col-md-12\">\r\n                  <div class=\"exp-sec\">\r\n                    <div class=\"table-responsive\">\r\n                      <table style=\"width: 100%\">\r\n                        <tbody>\r\n                          <tr>\r\n                            <td>\r\n                              <table class=\"table table-bordered table-striped\" id=\"excel-table\">\r\n                                <tbody>\r\n                                  <ng-container *ngIf=\"importData?.response['Clearance TAT']\">\r\n                                    <tr>\r\n                                      <th colspan=\"5\" style=\"background-color: #e9f8ff;\"> Clearance TAT</th>\r\n                                    </tr>\r\n                                    <tr>\r\n                                      <th style=\"width: 200px;\">CHA</th>\r\n                                      <th style=\"width: 200px;\">Percentage(%)</th>\r\n                                      <th style=\"width: 200px;\">Total</th>\r\n                                      <th style=\"width: 200px;\">On Time</th>\r\n                                      <th style=\"width: 200px;\">Delay</th>\r\n                                    </tr>\r\n                                    <tr *ngFor=\"let data2 of importData?.response['Clearance TAT'] | keyvalue\">\r\n                                      <td><b>{{data2.key}}</b></td>\r\n                                      <td>{{data2?.value.onTime / data2?.value.totalNo * 100 > 0 ? (data2?.value.onTime\r\n                                        / data2?.value.totalNo * 100 | number: '1.0-0') : 0 }}%</td>\r\n                                      <td>{{data2.value.totalNo}}</td>\r\n                                      <td>{{data2.value.onTime}}</td>\r\n                                      <td>{{data2.value.delay}}</td>\r\n                                    </tr>\r\n                                  </ng-container>\r\n                                  <ng-container *ngIf=\"importData?.response['Transit TAT']\">\r\n                                    <tr>\r\n                                      <th colspan=\"5\" style=\"background-color: #e9f8ff;\"> Transit TAT</th>\r\n                                    </tr>\r\n                                    <tr>\r\n                                      <th style=\"width: 200px;\">Carrier</th>\r\n                                      <th style=\"width: 200px;\">Percentage(%)</th>\r\n                                      <th style=\"width: 200px;\">Total</th>\r\n                                      <th style=\"width: 200px;\">On Time</th>\r\n                                      <th style=\"width: 200px;\">Delay</th>\r\n                                    </tr>\r\n                                    <tr *ngFor=\"let data2 of importData?.response['Transit TAT'] | keyvalue\">\r\n                                      <td><b>{{data2.key}}</b></td>\r\n                                      <td>{{data2?.value.onTime / data2?.value.totalNo * 100 > 0 ? (data2?.value.onTime\r\n                                        / data2?.value.totalNo * 100 | number: '1.0-0') : 0 }} %</td>\r\n                                      <td>{{data2.value.totalNo}}</td>\r\n                                      <td>{{data2.value.onTime}}</td>\r\n                                      <td>{{data2.value.delay}}</td>\r\n                                    </tr><br><br>\r\n                                  </ng-container>\r\n                                  <tr>\r\n                                    <th colspan=\"5\" style=\"background-color: #e9f8ff;\"> Over All</th>\r\n                                  </tr>\r\n                                  <tr>\r\n                                    <th style=\"width: 200px;\"></th>\r\n                                    <th style=\"width: 200px;\">Percentage(%)</th>\r\n                                    <th style=\"width: 200px;\">Total</th>\r\n                                    <th style=\"width: 200px;\">On Time</th>\r\n                                    <th style=\"width: 200px;\">Delay</th>\r\n                                  </tr>\r\n                                  <tr *ngFor=\"let data of importData?.totalShipments | keyvalue\">\r\n                                    <td><b>{{data?.key}}</b></td>\r\n                                    <td>{{data?.value.onTime / data.value.totalNo * 100 > 0 ? (data.value.onTime /\r\n                                      data.value.totalNo * 100 | number: '1.0-0') : 0 }} %</td>\r\n                                    <td>{{data.value.totalNo}}</td>\r\n                                    <td>{{data.value.onTime}}</td>\r\n                                    <td>{{data.value.delay}}</td>\r\n                                  </tr>\r\n                                </tbody>\r\n                              </table>\r\n                            </td>\r\n                          </tr>\r\n                        </tbody>\r\n                      </table>\r\n                    </div>\r\n                  </div>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </ng-template>\r\n        </div>\r\n      </ng-template>\r\n    </div>\r\n  </div>\r\n</div>\r\n<br><br><br><br><br>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/privacy-policy/privacy-policy.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/privacy-policy/privacy-policy.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPrivacyPolicyPrivacyPolicyComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"settingForm\" (ngSubmit)=\"onFormSubmit(settingForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <textarea matInput placeholder=\"Description\" formControlName=\"page_description\"\r\n               [errorStateMatcher]=\"matcher\"></textarea>\r\n        <mat-error>\r\n          <span *ngIf=\"!settingForm.get('page_description').valid && settingForm.get('page_description').touched\">Please enter description</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!settingForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRegisterRegisterComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<h2>Register</h2>\r\n<form [formGroup]=\"registerForm\" (ngSubmit)=\"onSubmit()\">\r\n    <div class=\"form-group\">\r\n        <label for=\"firstName\">First Name</label>\r\n        <input type=\"text\" formControlName=\"firstName\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': submitted && f.firstName.errors }\" />\r\n        <div *ngIf=\"submitted && f.firstName.errors\" class=\"invalid-feedback\">\r\n            <div *ngIf=\"f.firstName.errors.required\">First Name is required</div>\r\n        </div>\r\n    </div>\r\n    <div class=\"form-group\">\r\n        <label for=\"lastName\">Last Name</label>\r\n        <input type=\"text\" formControlName=\"lastName\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': submitted && f.lastName.errors }\" />\r\n        <div *ngIf=\"submitted && f.lastName.errors\" class=\"invalid-feedback\">\r\n            <div *ngIf=\"f.lastName.errors.required\">Last Name is required</div>\r\n        </div>\r\n    </div>\r\n    <div class=\"form-group\">\r\n        <label for=\"username\">Username</label>\r\n        <input type=\"text\" formControlName=\"username\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': submitted && f.username.errors }\" />\r\n        <div *ngIf=\"submitted && f.username.errors\" class=\"invalid-feedback\">\r\n            <div *ngIf=\"f.username.errors.required\">Username is required</div>\r\n        </div>\r\n    </div>\r\n    <div class=\"form-group\">\r\n        <label for=\"password\">Password</label>\r\n        <input type=\"password\" formControlName=\"password\" class=\"form-control\" [ngClass]=\"{ 'is-invalid': submitted && f.password.errors }\" />\r\n        <div *ngIf=\"submitted && f.password.errors\" class=\"invalid-feedback\">\r\n            <div *ngIf=\"f.password.errors.required\">Password is required</div>\r\n            <div *ngIf=\"f.password.errors.minlength\">Password must be at least 6 characters</div>\r\n        </div>\r\n    </div>\r\n    <div class=\"form-group\">\r\n        <button [disabled]=\"loading\" class=\"btn btn-primary\">Register</button>\r\n        <img *ngIf=\"loading\" class=\"pl-3\" src=\"data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==\" />\r\n        <a routerLink=\"/login\" class=\"btn btn-link\">Cancel</a>\r\n    </div>\r\n</form>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/settings-add/settings-add.component.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings-add/settings-add.component.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSettingsAddSettingsAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"settingForm\" (ngSubmit)=\"onFormSubmit(settingForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Name\" formControlName=\"page_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!settingForm.get('page_name').valid && settingForm.get('page_name').touched\">Please enter Page Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <textarea matInput placeholder=\"Description\" formControlName=\"page_description\"\r\n               [errorStateMatcher]=\"matcher\"></textarea>\r\n        <mat-error>\r\n          <span *ngIf=\"!settingForm.get('page_description').valid && settingForm.get('page_description').touched\">Please enter description</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!settingForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/settings-edit/settings-edit.component.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings-edit/settings-edit.component.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSettingsEditSettingsEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n \r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"settingForm\" (ngSubmit)=\"onFormSubmit(settingForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Name\" formControlName=\"page_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!settingForm.get('page_name').valid && settingForm.get('page_name').touched\">Please enter Page Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <textarea matInput placeholder=\"Description\" formControlName=\"page_description\"\r\n               [errorStateMatcher]=\"matcher\"></textarea>\r\n        <mat-error>\r\n          <span *ngIf=\"!settingForm.get('page_description').valid && settingForm.get('page_description').touched\">Please enter description</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!settingForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div> {{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSettingsSettingsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->\r\n\r\n<div class=\"container mat-elevation-z8\">\r\n\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Search By CHA\">\r\n    </mat-form-field>\r\n  </div>\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>  \r\n{{Message}}\r\n<div class=\"table-responsive\">\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    ng update @angular/cli @angular/core\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"id\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Id</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"cha_name\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>CHA Name</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.cha_name}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"create_date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Created Date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.create_date | date}}</mat-cell>\r\n    </ng-container>\r\n\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\" >\r\n          <mat-icon aria-label=\"Example icon-button with a heart icon\" [routerLink]=\"['/settings-add']\">add</mat-icon>\r\n        </button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" [routerLink]=\"['/settings-edit', row.id]\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n \r\n        <button mat-icon-button color=\"accent\" (click)=\"deletecha(row.id)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n\r\n  </mat-table>\r\n</div>\r\n<p *ngIf=\"dataSource.filteredData.length === 0\" class=\"no-records text-center\">No records found</p>\r\n\r\n\r\n\r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/user-logs/user-logs.component.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/user-logs/user-logs.component.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUserLogsUserLogsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n  <div class=\"layout-wrapper layout-2\">\r\n    <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n<div class=\"layout-container\">\r\n          <!-- Layout navbar -->\r\n    <app-navbar></app-navbar>\r\n          <!-- / Layout navbar -->\r\n<div class=\"container mat-elevation-z8\">\r\n    <form class=\"mb-4\" [formGroup]=\"blogForm\" (ngSubmit)=\"onFormSubmit()\">\r\n        <div class=\"row\">\r\n        <div class=\"col-md-4\"> \r\n          From: <input type=\"date\" class=\"form-control\" max=\"{{currentDate|date:'yyyy-MM-dd'}}\"    formControlName=\"fromDate\" (change) = \"setFromDate($event)\">\r\n          <div *ngIf=\"!blogForm.get('fromDate').valid && (blogForm.get('fromDate').touched)\">\r\n              <span class=\"badge-danger\"  *ngIf=\"blogForm.controls['fromDate'].errors.required\">\r\n                This field is required.\r\n              </span>\r\n            </div>\r\n        </div> \r\n        <div class=\"col-md-4\">  To:  <input class=\"form-control\" type=\"date\"  max=\"{{currentDate| date:'yyyy-MM-dd'}}\"    formControlName=\"toDate\" (change) = \"setToDate($event)\"></div>\r\n        <div  class=\"col-md-4\"><br><button class=\"btn btn-primary\" type=\"submit\">Search</button></div>\r\n      </div>\r\n      </form>\r\n   <table class=\"table table-bordered table-striped\">\r\n            <thead>\r\n              <tr>\r\n                <th>S.No</th>\r\n                <th>Name</th>\r\n                <th>Email</th>\r\n                <th>Designation</th>\r\n                <th>Date</th>\r\n   \r\n              </tr>\r\n            </thead>\r\n            <tbody>\r\n              <tr *ngFor=\"let user of dataSource; let i = index\">\r\n                <td>{{ i + 1 }}</td>\r\n                <td>{{ user.fullname }}</td>\r\n                <td>{{ user.email }}</td>\r\n                <td>{{ user.designation }}</td>\r\n                <td>{{ user.DateCreated | date :'dd MMM yyyy hh:mm:ss a' : '-0'}}</td>\r\n                </tr>\r\n                </tbody>\r\n\r\n            </table>\r\n\r\n</div>\r\n\r\n\r\n\r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/users-add/users-add.component.html":
  /*!******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/users-add/users-add.component.html ***!
    \******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUsersAddUsersAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n <div class=\"layout-inner\">\r\n <app-header></app-header>\r\n<div class=\"layout-container\">\r\n\t   <!-- Layout navbar -->\r\n <app-navbar></app-navbar>\r\n\t   <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n    \r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n     \r\n          <div class=\"col-md-12 text-center\">\r\n            <h4>Add User</h4>\r\n          </div>\r\n        \r\n    <form [formGroup]=\"userForm\" (ngSubmit)=\"onFormSubmit(userForm.value)\">\r\n      <div class=\"row\">\r\n        <div class=\"col-md-6\">\r\n            <mat-form-field class=\"example-full-width\">\r\n                <input matInput placeholder=\"User name\" formControlName=\"username\"\r\n                       [errorStateMatcher]=\"matcher\">\r\n                <mat-error>\r\n                  <span *ngIf=\"!userForm.get('username').valid && userForm.get('username').touched\">Enter user name</span>\r\n                </mat-error>\r\n             </mat-form-field>\r\n             <mat-form-field class=\"example-full-width\">\r\n                <input matInput placeholder=\"Full name\" formControlName=\"fullname\"\r\n                       [errorStateMatcher]=\"matcher\">\r\n                <mat-error>\r\n                  <span *ngIf=\"!userForm.get('fullname').valid && userForm.get('fullname').touched\">Enter full name</span>\r\n                </mat-error>\r\n              </mat-form-field>\r\n\r\n            <mat-form-field class=\"example-full-width\">\r\n                <input matInput placeholder=\"Email\" formControlName=\"email\"\r\n                       [errorStateMatcher]=\"matcher\">\r\n                <mat-error>\r\n                  <span *ngIf=\"!userForm.get('email').valid && userForm.get('email').touched\">Enter email</span>\r\n                </mat-error>\r\n            </mat-form-field>\r\n              <mat-form-field class=\"example-full-width\">\r\n                <div *ngIf=\"superadmin; then superadmins else admin\"></div>\r\n                <ng-template #superadmins>\r\n                  <mat-select formControlName=\"usertype\" placeholder=\"Select User Type\">\r\n                    <mat-option *ngFor=\"let adminsusertype of adminsusertypes\" [value]=\"adminsusertype.value\">{{adminsusertype.viewValue}}</mat-option>\r\n                \r\n                    </mat-select>\r\n                </ng-template>\r\n                <ng-template #admin>\r\n                  <mat-select formControlName=\"usertype\" placeholder=\"Select User Type\">\r\n                    <mat-option *ngFor=\"let usertype of usertypes\" [value]=\"usertype.value\">{{usertype.viewValue}}</mat-option>\r\n                \r\n                    </mat-select>\r\n                </ng-template>  \r\n                \r\n               \r\n\r\n               \r\n              </mat-form-field>\r\n              <mat-form-field class=\"example-full-width\">\r\n                <input matInput placeholder=\"customerID\" formControlName=\"customerID\">\r\n            </mat-form-field>\r\n                   <div class=\"button-row\">\r\n                      <button type=\"submit\" [disabled]=\"!userForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n                    </div>{{Message}}\r\n        </div>\r\n        <div class=\"col-md-6\">\r\n              <mat-form-field class=\"example-full-width\">\r\n                <input matInput placeholder=\"Designation\" formControlName=\"designation\"\r\n                       [errorStateMatcher]=\"matcher\">\r\n                <mat-error>\r\n                  <span *ngIf=\"!userForm.get('designation').valid && userForm.get('designation').touched\">Enter designation</span>\r\n                </mat-error>\r\n              </mat-form-field>\r\n              <mat-form-field class=\"example-full-width\">\r\n                <input matInput placeholder=\"Department\" formControlName=\"department\"\r\n                       [errorStateMatcher]=\"matcher\">\r\n                <mat-error>\r\n                  <span *ngIf=\"!userForm.get('department').valid && userForm.get('department').touched\">Enter department name</span>\r\n                </mat-error>\r\n              </mat-form-field>\r\n              <mat-form-field class=\"example-full-width\">\r\n                <input matInput placeholder=\"Password\" formControlName=\"password\"\r\n                       [errorStateMatcher]=\"matcher\">\r\n                <mat-error>\r\n                  <span *ngIf=\"!userForm.get('password').valid && userForm.get('password').touched\">Enter Password</span>\r\n                </mat-error>\r\n              </mat-form-field>\r\n\r\n              <mat-form-field class=\"example-full-width\">\r\n                  <mat-select formControlName=\"status\" placeholder=\"Select Status\">\r\n                 <mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n             \r\n                 </mat-select>\r\n                   </mat-form-field> \r\n        </div>\r\n      </div>\r\n     \r\n     \r\n     \r\n     \r\n\r\n      \r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/users-edit/users-edit.component.html":
  /*!********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/users-edit/users-edit.component.html ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUsersEditUsersEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n <div class=\"layout-inner\">\r\n <app-header></app-header>\r\n<div class=\"layout-container\">\r\n\t   <!-- Layout navbar -->\r\n <app-navbar></app-navbar>\r\n\t   <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n      <div class=\"col-md-12 text-center\">\r\n          <h4>Edit User</h4>\r\n        </div>\r\n    <form [formGroup]=\"userForm\" (ngSubmit)=\"onFormSubmit(userForm.value)\">\r\n        <mat-form-field class=\"example-full-width\">\r\n            <input matInput placeholder=\"User name\" formControlName=\"username\"\r\n                   [errorStateMatcher]=\"matcher\">\r\n            <mat-error>\r\n              <span *ngIf=\"!userForm.get('username').valid && userForm.get('username').touched\">Enter user name</span>\r\n            </mat-error>\r\n         </mat-form-field>\r\n         <mat-form-field class=\"example-full-width\">\r\n            <input matInput placeholder=\"Full name\" formControlName=\"fullname\"\r\n                   [errorStateMatcher]=\"matcher\">\r\n            <mat-error>\r\n              <span *ngIf=\"!userForm.get('fullname').valid && userForm.get('fullname').touched\">Enter full name</span>\r\n            </mat-error>\r\n          </mat-form-field>\r\n          <mat-form-field class=\"example-full-width\">\r\n              <input matInput placeholder=\"Designation\" formControlName=\"designation\"\r\n                     [errorStateMatcher]=\"matcher\">\r\n              <mat-error>\r\n                <span *ngIf=\"!userForm.get('designation').valid && userForm.get('designation').touched\">Enter designation</span>\r\n              </mat-error>\r\n            </mat-form-field>\r\n            <mat-form-field class=\"example-full-width\">\r\n              <input matInput placeholder=\"Department\" formControlName=\"department\"\r\n                     [errorStateMatcher]=\"matcher\">\r\n              <mat-error>\r\n                <span *ngIf=\"!userForm.get('department').valid && userForm.get('department').touched\">Enter department name</span>\r\n              </mat-error>\r\n            </mat-form-field>\r\n        <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Email\" formControlName=\"email\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!userForm.get('email').valid && userForm.get('email').touched\">Enter email</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Password\" formControlName=\"password\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!userForm.get('password').valid && userForm.get('password').touched\">Enter password</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n \t  <mat-select formControlName=\"status\" placeholder=\"Select Status\">\r\n\t\t<mat-option *ngFor=\"let yesno of yesnos\" [value]=\"yesno.value\">{{yesno.viewValue}}</mat-option>\r\n\r\n\t  </mat-select>\r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n          <div *ngIf=\"superadmin; then superadmins else admin\"></div>\r\n        <ng-template #superadmins>\r\n          <mat-select formControlName=\"usertype\" placeholder=\"Select User Typesss\">\r\n            <mat-option *ngFor=\"let adminsusertype of adminsusertypes\" [value]=\"adminsusertype.value\">{{adminsusertype.viewValue}}</mat-option>\r\n        \r\n            </mat-select>\r\n        </ng-template>\r\n        <ng-template #admin>\r\n          <mat-select formControlName=\"usertype\" placeholder=\"Select User Type\">\r\n            <mat-option *ngFor=\"let usertype of usertypes\" [value]=\"usertype.value\">{{usertype.viewValue}}</mat-option>\r\n        \r\n            </mat-select>\r\n        </ng-template>  \r\n      </mat-form-field>\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"customerID\" formControlName=\"customerID\">\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!userForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div>{{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/users/users.component.html":
  /*!**********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/users/users.component.html ***!
    \**********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppUsersUsersComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->\r\n<div class=\"container mat-elevation-z8\">\r\n\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Filter User\">\r\n    </mat-form-field>\r\n  </div>\r\n  <button class=\"btn-info form-control col-md-3\" [routerLink]=\"['/user-add']\"> Add User  </button>\r\n  <br>\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>  \r\n{{Message}}\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"username\">\r\n        <mat-header-cell *matHeaderCellDef mat-sort-header>User Name</mat-header-cell>\r\n        <mat-cell *matCellDef=\"let row\" >{{row.username}}</mat-cell>\r\n      </ng-container>\r\n      <ng-container matColumnDef=\"fullname\">\r\n          <mat-header-cell *matHeaderCellDef mat-sort-header>Full Name</mat-header-cell>\r\n          <mat-cell *matCellDef=\"let row\" >{{row.fullname}}</mat-cell>\r\n        </ng-container>\r\n     \r\n    <ng-container matColumnDef=\"email\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Email</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.email}}</mat-cell>\r\n    </ng-container>\r\n    <ng-container matColumnDef=\"designation\">\r\n        <mat-header-cell *matHeaderCellDef mat-sort-header>Designation</mat-header-cell>\r\n        <mat-cell *matCellDef=\"let row\" >{{row.designation}}</mat-cell>\r\n      </ng-container>\r\n     <ng-container matColumnDef=\"department\">\r\n          <mat-header-cell *matHeaderCellDef mat-sort-header>Department</mat-header-cell>\r\n          <mat-cell *matCellDef=\"let row\" >{{row.department}}</mat-cell>\r\n        </ng-container>\r\n        <ng-container matColumnDef=\"customerID\">\r\n          <mat-header-cell *matHeaderCellDef mat-sort-header>customer ID</mat-header-cell>\r\n          <mat-cell *matCellDef=\"let row\"> {{row.customerID}}</mat-cell>\r\n        </ng-container>\r\n\r\n    <ng-container matColumnDef=\"password\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Password</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.password}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"usertype\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>User type</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\">\r\n        <div [ngSwitch]=\"row.usertype\">\r\n          <p *ngSwitchCase=\"1\">Super Admin</p>\r\n          <p *ngSwitchCase=\"2\">Admin</p>\r\n          <p *ngSwitchCase=\"3\">Super User</p>\r\n          <p *ngSwitchCase=\"4\">Import User</p>\r\n          <p *ngSwitchCase=\"5\">Export User</p>\r\n        </div>\r\n        \r\n        </mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"status\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Status</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> \r\n            <div [ngSwitch]=\"row.status\">\r\n              <p *ngSwitchCase=\"1\">Active</p>\r\n              <p *ngSwitchCase=\"2\">Incactive</p>\r\n            </div>\r\n    \r\n      </mat-cell>\r\n    </ng-container>\r\n\t\r\n    <ng-container matColumnDef=\"create_date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Create Date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.create_date | date}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\" >\r\n          <mat-icon aria-label=\"Example icon-button with a heart icon\" [routerLink]=\"['/user-add']\">add</mat-icon>\r\n        </button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" [routerLink]=\"['/user-edit', row.id]\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n \r\n        <button mat-icon-button color=\"accent\" (click)=\"deleteUser(row.id)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n  </mat-table>\r\n\r\n<p *ngIf=\"dataSource.filteredData.length === 0\" class=\"no-records text-center\">No records found</p>\r\n  \r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/vendor-add/vendor-add.component.html":
  /*!********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/vendor-add/vendor-add.component.html ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppVendorAddVendorAddComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"vendorForm\" (ngSubmit)=\"onFormSubmit(vendorForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Vendor Name\" formControlName=\"vendor_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!vendorForm.get('vendor_name').valid && vendorForm.get('vendor_name').touched\">Please Vendor Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!vendorForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div>{{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/vendor-edit/vendor-edit.component.html":
  /*!**********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/vendor-edit/vendor-edit.component.html ***!
    \**********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppVendorEditVendorEditComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "       <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->  \r\n\r\n<div class=\"example-container mat-elevation-z8\">\r\n\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>\r\n \r\n  <mat-card class=\"example-card\">\r\n    <form [formGroup]=\"vendorForm\" (ngSubmit)=\"onFormSubmit(vendorForm.value)\">\r\n      <mat-form-field class=\"example-full-width\">\r\n        <input matInput placeholder=\"Vendor Name\" formControlName=\"vendor_name\"\r\n               [errorStateMatcher]=\"matcher\">\r\n        <mat-error>\r\n          <span *ngIf=\"!vendorForm.get('vendor_name').valid && vendorForm.get('vendor_name').touched\">Please Vendor Name</span>\r\n        </mat-error>\r\n      </mat-form-field>\r\n\r\n      <div class=\"button-row\">\r\n        <button type=\"submit\" [disabled]=\"!vendorForm.valid\" mat-flat-button color=\"primary\"><mat-icon>save</mat-icon></button>\r\n      </div>{{Message}}\r\n    </form>\r\n  </mat-card>\r\n</div>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/vendors/vendors.component.html":
  /*!**************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/vendors/vendors.component.html ***!
    \**************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppVendorsVendorsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  <!-- Layout wrapper -->\r\n      <div class=\"layout-wrapper layout-2\">\r\n         <div class=\"layout-inner\">\r\n\t\t <app-header></app-header>\r\n     <div class=\"layout-container\">\r\n               <!-- Layout navbar -->\r\n\t\t <app-navbar></app-navbar>\r\n               <!-- / Layout navbar -->\r\n\r\n<div class=\"container mat-elevation-z8\">\r\n\r\n  <div class=\"form\">\r\n    <mat-form-field floatPlaceholder=\"never\" color=\"accent\">\r\n      <input matInput #filter placeholder=\"Search By Vendor\">\r\n    </mat-form-field>\r\n  </div>\r\n<button class=\"btn-info btn full-right\" [routerLink]=\"['/vendor-add']\">Add Vendor</button>\r\n  <div class=\"example-loading-shade\"\r\n       *ngIf=\"isLoadingResults\">\r\n    <mat-spinner *ngIf=\"isLoadingResults\"></mat-spinner>\r\n  </div>  \r\n\t{{Message}}\r\n  <mat-table #table [dataSource]=\"dataSource\" matSort class=\"mat-cell\">\r\n    ng update @angular/cli @angular/core\r\n    <!--- Note that these columns can be defined in any order.\r\n          The actual rendered columns are set as a property on the row definition\" -->\r\n\r\n    <!-- ID Column -->\r\n    <ng-container matColumnDef=\"id\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>S.No</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\" >{{row.id}}</mat-cell>\r\n    </ng-container>\r\n\r\n    <ng-container matColumnDef=\"vendor_name\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Vendor Name</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.vendor_name}}</mat-cell>\r\n    </ng-container>\r\n\r\n   \r\n\r\n    <ng-container matColumnDef=\"create_date\">\r\n      <mat-header-cell *matHeaderCellDef mat-sort-header>Created Date</mat-header-cell>\r\n      <mat-cell *matCellDef=\"let row\"> {{row.create_date | date}}</mat-cell>\r\n    </ng-container>\r\n\r\n\r\n    <!-- actions -->\r\n    <ng-container matColumnDef=\"actions\">\r\n      <mat-header-cell *matHeaderCellDef>\r\n        <button mat-icon-button color=\"primary\">\r\n          Actions\r\n        </button>\r\n      </mat-header-cell>\r\n\r\n      <mat-cell *matCellDef=\"let row; let i=index;\">\r\n        <button mat-icon-button color=\"accent\" [routerLink]=\"['/vendor-edit', row.id]\">\r\n          <mat-icon aria-label=\"Edit\">edit</mat-icon>\r\n        </button>\r\n\r\n        <button mat-icon-button color=\"accent\" (click)=\"deleteVendor(row.id)\">\r\n          <mat-icon aria-label=\"Delete\">delete</mat-icon>\r\n        </button>\r\n      </mat-cell>\r\n    </ng-container>\r\n\r\n    <mat-header-row *matHeaderRowDef=\"displayedColumns\"></mat-header-row>\r\n    <mat-row *matRowDef=\"let row; columns: displayedColumns;\"></mat-row>\r\n  </mat-table>\r\n\r\n<p *ngIf=\"dataSource.filteredData.length === 0\" class=\"no-records text-center\">No records found</p>\r\n  \r\n\r\n <mat-paginator #paginator\r\n                 [length]=\"dataSource.filteredData.length\"\r\n                 [pageIndex]=\"0\"\r\n                 [pageSize]=\"10\"\r\n                 [pageSizeOptions]=\"[5, 10, 25, 100]\">\r\n  </mat-paginator>\r\n</div>\r\n\r\n\r\n  \r\n\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/weekly-reports/weekly-reports.component.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/weekly-reports/weekly-reports.component.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppWeeklyReportsWeeklyReportsComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<!-- Layout wrapper -->\r\n<div class=\"layout-wrapper layout-2\">\r\n  <div class=\"layout-inner\">\r\n    <app-header></app-header>\r\n    <div class=\"layout-container\">\r\n      <!-- Layout navbar -->\r\n      <app-navbar></app-navbar>\r\n      <!-- <div class=\"col-md-12 d-flex\">\r\n          <div class=\"spinner-border text-muted\"></div>\r\n        </div> -->\r\n      <div class=\"container exp\">\r\n        <div class=\"row fil-sec\">\r\n          <div class=\"col-md-8 \">\r\n            <form [formGroup]=\"searchForm\" class=\"d-flex\" (ngSubmit)=\"onSubmit()\">\r\n              <div class=\"inp-item\">\r\n\r\n                <mat-form-field>\r\n                  <input matInput [matDatepicker]=\"picker\" placeholder=\"From Date\" formControlName=\"fromDate\" disabled>\r\n                  <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                  <mat-datepicker #picker disabled=\"false\"></mat-datepicker>\r\n                </mat-form-field>\r\n                <div *ngIf=\"f.fromDate.errors && f.fromDate.errors.required && submitted\" class=\"text-danger\">\r\n                  This Field is required.\r\n                </div>\r\n              </div>\r\n              <div class=\"inp-item\">\r\n                <mat-form-field>\r\n                  <input matInput [matDatepicker]=\"pickerToDate\" placeholder=\"To Date\" formControlName=\"toDate\"\r\n                    disabled>\r\n                  <mat-datepicker-toggle matSuffix [for]=\"pickerToDate\"></mat-datepicker-toggle>\r\n                  <mat-datepicker #pickerToDate disabled=\"false\"></mat-datepicker>\r\n                </mat-form-field>\r\n                <div *ngIf=\"f.toDate.errors && f.toDate.errors.required && submitted\" class=\"text-danger\">\r\n                  This Field is required.\r\n                </div>\r\n              </div>\r\n              <button class=\"btn btn-info\">Submit</button>\r\n            </form>\r\n          </div>\r\n        </div>\r\n        <div class=\"fa-3x\" *ngIf=\"loading; else show_result\" style=\"text-align: center;\">\r\n          <i class=\"fa fa-spinner fa-spin\" style=\"font-size:24px; \"></i>\r\n        </div>\r\n        <ng-template #show_result>\r\n          <div class=\"row\" *ngIf=\"showTable\">\r\n            <div class=\"col-md-12\">\r\n              <div class=\"exp-sec\">\r\n                <h4>Week to date({{searchForm.value.fromDate | date: 'dd/MM/yyyy'}} to {{searchForm.value.toDate | date:\r\n                  'dd/MM/yyyy'}})</h4>\r\n                <div class=\"table-responsive mb-2\">\r\n                  <table style=\"width: 100%\">\r\n                    <tbody>\r\n                      <tr>\r\n                        <td style=\"width: 25%; border: 1px solid #4e5155;\">\r\n                          <table class=\"table  table-bordered table-striped\">\r\n                            <tbody>\r\n                              <tr>\r\n                                <th>S.No</th>\r\n                                <th>Region</th>\r\n                                <th>\r\n                                  <=5 days</th>\r\n                                <th>6-7 days</th>\r\n                                <th>8-9 days</th>\r\n                                <th>10-11 days</th>\r\n                                <th> >11 days</th>\r\n                                <th>No of shipments</th>\r\n                                <th>Gross Weight Handled in Kgs</th>\r\n                                <th>Net Weight Handled in Kgs</th>\r\n                                <th>Average Door to Port</th>\r\n                              </tr>\r\n                              <tr *ngFor=\"let data of recordsData?.count[0] | keyvalue  ; let i = index\">\r\n                                <td><b>{{i+1}}</b></td>\r\n                                <td>{{ recordsData?.count[0][i].region}}</td>\r\n                                <td>{{(recordsData?.count[0][i].belowFiveDays == null ? 0 :\r\n                                  (recordsData?.count[0][i].belowFiveDays | number : '1.0-2')) }}%</td>\r\n                                <td>{{(recordsData?.count[0][i].SixSeven==null ? 0 : (recordsData?.count[0][i].SixSeven\r\n                                  | number: '1.0-2'))}}%</td>\r\n                                <td>{{(recordsData?.count[0][i].EightNine==null ? 0 :\r\n                                  (recordsData?.count[0][i].EightNine | number: '1.0-2')) }}%</td>\r\n                                <td>{{(recordsData?.count[0][i].TenEleven==null ? 0 :\r\n                                  (recordsData?.count[0][i].TenEleven | number: '1.0-2'))}}%</td>\r\n                                <td>{{(recordsData?.count[0][i].AboveEleven==null ? 0 :\r\n                                  (recordsData?.count[0][i].AboveEleven | number: '1.0-2'))}}% </td>\r\n                                <td>{{recordsData?.count[0][i].noItems | number: '1.0-2'}}</td>\r\n                                <td>{{recordsData?.count[0][i].Gr_Wt | number: '1.0-2'}}</td>\r\n                                <td>{{recordsData?.count[0][i].Net_Wt | number: '1.0-2'}}</td>\r\n                                <td>{{recordsData?.count[0][i].avg_DTP | number: '1.0-2'}}</td>\r\n                              </tr>\r\n                              <tr>\r\n                                <td colspan=\"2\"><b>Grand Total</b></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td><b>{{table1.No_of_Shipments}}</b></td>\r\n                                <td><b>{{table1.Gross_Weight_Handled_in_Kgs | number: '1.0-2'}}</b></td>\r\n                                <td><b>{{table1.Net_Weight_Handled_in_Kgs | number: '1.0-2'}}</b></td>\r\n                                <td></td>\r\n                              </tr>\r\n                            </tbody>\r\n                          </table>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n            <div class=\"col-md-12\">\r\n              <div class=\"exp-sec\">\r\n                <h4>Year to date(01/04/2021 to {{today | date: 'dd/MM/yyyy'}})</h4>\r\n                <div class=\"table-responsive mb-2\">\r\n                  <table style=\"width: 100%\">\r\n                    <tbody>\r\n                      <tr>\r\n                        <td style=\"width: 25%; border: 1px solid #4e5155;\">\r\n                          <table class=\"table  table-bordered table-striped\">\r\n                            <tbody>\r\n                              <tr>\r\n                                <th>S.No</th>\r\n                                <th>Region</th>\r\n                                <th>\r\n                                  <=5 days</th>\r\n                                <th>6-7 days</th>\r\n                                <th>8-9 days</th>\r\n                                <th>10-11 days</th>\r\n                                <th> >11 days</th>\r\n                                <th>No of shipments</th>\r\n                                <th>Gross Weight Handled in Kgs</th>\r\n                                <th>Net Weight Handled in Kgs</th>\r\n                                <th>Average Door to Port</th>\r\n                              </tr>\r\n                              <tr *ngFor=\"let data of recordsData?.count[1] | keyvalue; let i = index\">\r\n                                <td><b>{{i+1}}</b></td>\r\n                                <td>{{ recordsData?.count[1][i].region}}</td>\r\n                                <td>{{( recordsData?.count[1][i].belowFiveDays == null ? 0 : (\r\n                                  recordsData?.count[1][i].belowFiveDays | number: '1.0-2')) }}%</td>\r\n                                <td>{{( recordsData?.count[1][i].SixSeven==null ? 0 : (\r\n                                  recordsData?.count[1][i].SixSeven | number: '1.0-2'))}}%</td>\r\n                                <td>{{( recordsData?.count[1][i].EightNine==null ? 0 : (\r\n                                  recordsData?.count[1][i].EightNine | number: '1.0-2')) }}%</td>\r\n                                <td>{{( recordsData?.count[1][i].TenEleven==null ? 0 : (\r\n                                  recordsData?.count[1][i].TenEleven | number: '1.0-2'))}}%</td>\r\n                                <td>{{( recordsData?.count[1][i].AboveEleven==null ? 0 : (\r\n                                  recordsData?.count[1][i].AboveEleven | number: '1.0-2'))}}% </td>\r\n                                <td>{{ recordsData?.count[1][i].noItems | number: '1.0-2'}}</td>\r\n                                <td>{{ recordsData?.count[1][i].Gr_Wt | number: '1.0-2'}}</td>\r\n                                <td>{{ recordsData?.count[1][i].Net_Wt | number: '1.0-2'}}</td>\r\n                                <td>{{ recordsData?.count[1][i].avg_DTP | number: '1.0-2'}}</td>\r\n                              </tr>\r\n                              <tr>\r\n                                <td colspan=\"2\"><b>Grand Total</b></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td></td>\r\n                                <td><b>{{table2.No_of_Shipments}}</b></td>\r\n                                <td><b>{{table2.Gross_Weight_Handled_in_Kgs | number: '1.0-2'}}</b></td>\r\n                                <td><b>{{table2.Net_Weight_Handled_in_Kgs | number: '1.0-2'}}</b></td>\r\n                                <td></td>\r\n                              </tr>\r\n                            </tbody>\r\n                          </table>\r\n                        </td>\r\n                      </tr>\r\n                    </tbody>\r\n                  </table>\r\n                </div>\r\n              </div>\r\n            </div>\r\n          </div>\r\n        </ng-template>\r\n      </div>\r\n    </div>\r\n  </div>\r\n</div>";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0
    
    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.
    
    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0) t[p[i]] = s[p[i]];
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : new P(function (resolve) {
            resolve(result.value);
          }).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];

          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;

            case 4:
              _.label++;
              return {
                value: op[1],
                done: false
              };

            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;

            case 7:
              op = _.ops.pop();

              _.trys.pop();

              continue;

            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }

              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }

              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }

              if (t && _.label < t[2]) {
                _.label = t[2];

                _.ops.push(op);

                break;
              }

              if (t[2]) _.ops.pop();

              _.trys.pop();

              continue;
          }

          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __exportStar(m, exports) {
      for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
      var m = typeof Symbol === "function" && o[Symbol.iterator],
          i = 0;
      if (m) return m.call(o);
      return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));

      return ar;
    }

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      result.default = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        default: mod
      };
    }
    /***/

  },

  /***/
  "./src/$$_lazy_route_resource lazy recursive":
  /*!**********************************************************!*\
    !*** ./src/$$_lazy_route_resource lazy namespace object ***!
    \**********************************************************/

  /*! no static exports found */

  /***/
  function src$$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./src/app/_components/alert.component.ts":
  /*!************************************************!*\
    !*** ./src/app/_components/alert.component.ts ***!
    \************************************************/

  /*! exports provided: AlertComponent */

  /***/
  function srcApp_componentsAlertComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertComponent", function () {
      return AlertComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");

    let AlertComponent = class AlertComponent {
      constructor(alertService) {
        this.alertService = alertService;
      }

      ngOnInit() {
        this.subscription = this.alertService.getMessage().subscribe(message => {
          this.message = message;
        });
      }

      ngOnDestroy() {
        this.subscription.unsubscribe();
      }

    };

    AlertComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AlertService"]
    }];

    AlertComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'alert',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./alert.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/_components/alert.component.html")).default
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AlertService"]])], AlertComponent);
    /***/
  },

  /***/
  "./src/app/_components/index.ts":
  /*!**************************************!*\
    !*** ./src/app/_components/index.ts ***!
    \**************************************/

  /*! exports provided: AlertComponent */

  /***/
  function srcApp_componentsIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _alert_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./alert.component */
    "./src/app/_components/alert.component.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "AlertComponent", function () {
      return _alert_component__WEBPACK_IMPORTED_MODULE_1__["AlertComponent"];
    });
    /***/

  },

  /***/
  "./src/app/_guards/auth.guard.ts":
  /*!***************************************!*\
    !*** ./src/app/_guards/auth.guard.ts ***!
    \***************************************/

  /*! exports provided: AuthGuard */

  /***/
  function srcApp_guardsAuthGuardTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthGuard", function () {
      return AuthGuard;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");

    let AuthGuard = class AuthGuard {
      constructor(router, authenticationService) {
        this.router = router;
        this.authenticationService = authenticationService;
      }

      canActivate(route, state) {
        const currentUser = this.authenticationService.currentUserValue;

        if (currentUser) {
          // authorised so return true
          return true;
        } // not logged in so redirect to login page with the return url


        this.router.navigate(['/login'], {
          queryParams: {
            returnUrl: state.url
          }
        });
        return false;
      }

    };

    AuthGuard.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]
    }];

    AuthGuard = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _app_services__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]])], AuthGuard);
    /***/
  },

  /***/
  "./src/app/_guards/index.ts":
  /*!**********************************!*\
    !*** ./src/app/_guards/index.ts ***!
    \**********************************/

  /*! exports provided: AuthGuard */

  /***/
  function srcApp_guardsIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _auth_guard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./auth.guard */
    "./src/app/_guards/auth.guard.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "AuthGuard", function () {
      return _auth_guard__WEBPACK_IMPORTED_MODULE_1__["AuthGuard"];
    });
    /***/

  },

  /***/
  "./src/app/_helpers/error.interceptor.ts":
  /*!***********************************************!*\
    !*** ./src/app/_helpers/error.interceptor.ts ***!
    \***********************************************/

  /*! exports provided: ErrorInterceptor */

  /***/
  function srcApp_helpersErrorInterceptorTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ErrorInterceptor", function () {
      return ErrorInterceptor;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");

    let ErrorInterceptor = class ErrorInterceptor {
      constructor(authenticationService) {
        this.authenticationService = authenticationService;
      }

      intercept(request, next) {
        return next.handle(request).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(err => {
          if (err.status === 401) {
            // auto logout if 401 response returned from api
            this.authenticationService.logout();
            location.reload(true);
          }

          const error = err.error.message || err.statusText;
          return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(error);
        }));
      }

    };

    ErrorInterceptor.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]
    }];

    ErrorInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]])], ErrorInterceptor);
    /***/
  },

  /***/
  "./src/app/_helpers/fake-backend.ts":
  /*!******************************************!*\
    !*** ./src/app/_helpers/fake-backend.ts ***!
    \******************************************/

  /*! exports provided: FakeBackendInterceptor, fakeBackendProvider */

  /***/
  function srcApp_helpersFakeBackendTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FakeBackendInterceptor", function () {
      return FakeBackendInterceptor;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "fakeBackendProvider", function () {
      return fakeBackendProvider;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    let FakeBackendInterceptor = class FakeBackendInterceptor {
      constructor() {}

      intercept(request, next) {
        // array in local storage for registered users
        let users = JSON.parse(localStorage.getItem('users')) || []; // wrap in delayed observable to simulate server api call

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(null).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["mergeMap"])(() => {
          // authenticate
          if (request.url.endsWith('/users/authenticate') && request.method === 'POST') {
            // find if any user matches login credentials
            let filteredUsers = users.filter(user => {
              return user.username === request.body.username && user.password === request.body.password;
            });

            if (filteredUsers.length) {
              // if login details are valid return 200 OK with user details and fake jwt token
              let user = filteredUsers[0];
              let body = {
                id: user.id,
                username: user.username,
                firstName: user.firstName,
                lastName: user.lastName,
                token: 'fake-jwt-token'
              };
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]({
                status: 200,
                body: body
              }));
            } else {
              // else return 400 bad request
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                error: {
                  message: 'Username or password is incorrect'
                }
              });
            }
          } // get users


          if (request.url.endsWith('/users') && request.method === 'GET') {
            // check for fake auth token in header and return users if valid, this security is implemented server side in a real application
            if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]({
                status: 200,
                body: users
              }));
            } else {
              // return 401 not authorised if token is null or invalid
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                status: 401,
                error: {
                  message: 'Unauthorised'
                }
              });
            }
          } // get user by id


          if (request.url.match(/\/users\/\d+$/) && request.method === 'GET') {
            // check for fake auth token in header and return user if valid, this security is implemented server side in a real application
            if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
              // find user by id in users array
              let urlParts = request.url.split('/');
              let id = parseInt(urlParts[urlParts.length - 1]);
              let matchedUsers = users.filter(user => {
                return user.id === id;
              });
              let user = matchedUsers.length ? matchedUsers[0] : null;
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]({
                status: 200,
                body: user
              }));
            } else {
              // return 401 not authorised if token is null or invalid
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                status: 401,
                error: {
                  message: 'Unauthorised'
                }
              });
            }
          } // register user


          if (request.url.endsWith('/users/register') && request.method === 'POST') {
            // get new user object from post body
            let newUser = request.body; // validation

            let duplicateUser = users.filter(user => {
              return user.username === newUser.username;
            }).length;

            if (duplicateUser) {
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                error: {
                  message: 'Username "' + newUser.username + '" is already taken'
                }
              });
            } // save new user


            newUser.id = users.length + 1;
            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users)); // respond 200 OK

            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]({
              status: 200
            }));
          } // delete user


          if (request.url.match(/\/users\/\d+$/) && request.method === 'DELETE') {
            // check for fake auth token in header and return user if valid, this security is implemented server side in a real application
            if (request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
              // find user by id in users array
              let urlParts = request.url.split('/');
              let id = parseInt(urlParts[urlParts.length - 1]);

              for (let i = 0; i < users.length; i++) {
                let user = users[i];

                if (user.id === id) {
                  // delete user
                  users.splice(i, 1);
                  localStorage.setItem('users', JSON.stringify(users));
                  break;
                }
              } // respond 200 OK


              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["of"])(new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]({
                status: 200
              }));
            } else {
              // return 401 not authorised if token is null or invalid
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])({
                status: 401,
                error: {
                  message: 'Unauthorised'
                }
              });
            }
          } // pass through any requests not handled above


          return next.handle(request);
        })) // call materialize and dematerialize to ensure delay even if an error is thrown (https://github.com/Reactive-Extensions/RxJS/issues/648)
        .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["materialize"])()).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["delay"])(500)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["dematerialize"])());
      }

    };
    FakeBackendInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], FakeBackendInterceptor);
    let fakeBackendProvider = {
      // use fake backend in place of Http service for backend-less development
      provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HTTP_INTERCEPTORS"],
      useClass: FakeBackendInterceptor,
      multi: true
    };
    /***/
  },

  /***/
  "./src/app/_helpers/index.ts":
  /*!***********************************!*\
    !*** ./src/app/_helpers/index.ts ***!
    \***********************************/

  /*! exports provided: ErrorInterceptor, JwtInterceptor, FakeBackendInterceptor, fakeBackendProvider */

  /***/
  function srcApp_helpersIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _error_interceptor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./error.interceptor */
    "./src/app/_helpers/error.interceptor.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ErrorInterceptor", function () {
      return _error_interceptor__WEBPACK_IMPORTED_MODULE_1__["ErrorInterceptor"];
    });
    /* harmony import */


    var _jwt_interceptor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./jwt.interceptor */
    "./src/app/_helpers/jwt.interceptor.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "JwtInterceptor", function () {
      return _jwt_interceptor__WEBPACK_IMPORTED_MODULE_2__["JwtInterceptor"];
    });
    /* harmony import */


    var _fake_backend__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./fake-backend */
    "./src/app/_helpers/fake-backend.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "FakeBackendInterceptor", function () {
      return _fake_backend__WEBPACK_IMPORTED_MODULE_3__["FakeBackendInterceptor"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "fakeBackendProvider", function () {
      return _fake_backend__WEBPACK_IMPORTED_MODULE_3__["fakeBackendProvider"];
    });
    /***/

  },

  /***/
  "./src/app/_helpers/jwt.interceptor.ts":
  /*!*********************************************!*\
    !*** ./src/app/_helpers/jwt.interceptor.ts ***!
    \*********************************************/

  /*! exports provided: JwtInterceptor */

  /***/
  function srcApp_helpersJwtInterceptorTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "JwtInterceptor", function () {
      return JwtInterceptor;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");

    let JwtInterceptor = class JwtInterceptor {
      constructor(authenticationService) {
        this.authenticationService = authenticationService;
      }

      intercept(request, next) {
        // add authorization header with jwt token if available
        let currentUser = this.authenticationService.currentUserValue;

        if (currentUser && currentUser.token) {
          request = request.clone({
            setHeaders: {
              Authorization: "Bearer ".concat(currentUser.token)
            }
          });
        }

        return next.handle(request);
      }

    };

    JwtInterceptor.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }];

    JwtInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])], JwtInterceptor);
    /***/
  },

  /***/
  "./src/app/_services/alert.service.ts":
  /*!********************************************!*\
    !*** ./src/app/_services/alert.service.ts ***!
    \********************************************/

  /*! exports provided: AlertService */

  /***/
  function srcApp_servicesAlertServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AlertService", function () {
      return AlertService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    let AlertService = class AlertService {
      constructor(router) {
        this.router = router;
        this.subject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this.keepAfterNavigationChange = false; // clear alert message on route change

        router.events.subscribe(event => {
          if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationStart"]) {
            if (this.keepAfterNavigationChange) {
              // only keep for a single location change
              this.keepAfterNavigationChange = false;
            } else {
              // clear alert
              this.subject.next();
            }
          }
        });
      }

      success(message, keepAfterNavigationChange = false) {
        this.keepAfterNavigationChange = keepAfterNavigationChange;
        this.subject.next({
          type: 'success',
          text: message
        });
      }

      error(message, keepAfterNavigationChange = false) {
        this.keepAfterNavigationChange = keepAfterNavigationChange;
        this.subject.next({
          type: 'error',
          text: message
        });
      }

      getMessage() {
        return this.subject.asObservable();
      }

    };

    AlertService.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }];

    AlertService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])], AlertService);
    /***/
  },

  /***/
  "./src/app/_services/api-services.service.ts":
  /*!***************************************************!*\
    !*** ./src/app/_services/api-services.service.ts ***!
    \***************************************************/

  /*! exports provided: ApiServicesService */

  /***/
  function srcApp_servicesApiServicesServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ApiServicesService", function () {
      return ApiServicesService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../environments/environment */
    "./src/environments/environment.ts");

    let ApiServicesService = class ApiServicesService {
      constructor() {
        this.GET_EXPORT_REPORTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/export-reports/");
        this.GET_IMPORT_REPORTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/import-reports");
        this.GET_EXPORT_DROPDOWNS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/export-reports-dropdowns");
        this.GET_OVERALL_REPORTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/import-reports-overAll");
        this.GET_IMPORT_ALL_SHIPMENTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/import/allshipments");
        this.GET_EXPORT_ALL_SHIPMENTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/export/allshipments");
        this.GET_TOTAL_IMPORT_SHIPMENTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/import/allshipments");
        this.GET_TOTAL_EXPORTS_SHIPMENTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/export/export_shipments");
        this.WEEKELY_REPORTS = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/export-reports-weekly");
        this.EXPORT_DROP_DOWN_LIST = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/export-reports-dropdown-list");
        this.COUNTRIES_DROP_DOWN = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/export-reports-dropdown-by-zone");
        this.ZONES_LIST = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].apiUrl_base, "/api/import-reports-zones-list");
      }

    };
    ApiServicesService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], ApiServicesService);
    /***/
  },

  /***/
  "./src/app/_services/authentication.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/_services/authentication.service.ts ***!
    \*****************************************************/

  /*! exports provided: AuthenticationService */

  /***/
  function srcApp_servicesAuthenticationServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AuthenticationService", function () {
      return AuthenticationService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let AuthenticationService = class AuthenticationService {
      constructor(http) {
        this.http = http;
        this.currentUserSubject = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"](JSON.parse(localStorage.getItem('currentUser')));
        this.currentUser = this.currentUserSubject.asObservable();
      }

      get currentUserValue() {
        return this.currentUserSubject.value;
      }

      login(email, password) {
        return this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].apiUrl, "/SignIn"), {
          email,
          password
        }).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(user => {
          if (user.data[0]) {
            if (user.data[0].usertype < '3') {
              localStorage.setItem('currentUser', JSON.stringify(user.data[0]));
              localStorage.setItem('currentUserType', user.data[0].usertype);
              this.currentUserSubject.next(user.data[0]);
            }
          }

          if (user.data[0]) {
            if (user.data[0].usertype < '3') {
              return user.data[0];
            } else {
              return false;
            }
          } else {
            return false;
          }
        }));
      }

      logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
      }

    };

    AuthenticationService.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
    }];

    AuthenticationService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], AuthenticationService);
    /***/
  },

  /***/
  "./src/app/_services/index.ts":
  /*!************************************!*\
    !*** ./src/app/_services/index.ts ***!
    \************************************/

  /*! exports provided: AuthenticationService, AlertService, UserService */

  /***/
  function srcApp_servicesIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _alert_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./alert.service */
    "./src/app/_services/alert.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "AlertService", function () {
      return _alert_service__WEBPACK_IMPORTED_MODULE_1__["AlertService"];
    });
    /* harmony import */


    var _authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./authentication.service */
    "./src/app/_services/authentication.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "AuthenticationService", function () {
      return _authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"];
    });
    /* harmony import */


    var _user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./user.service */
    "./src/app/_services/user.service.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "UserService", function () {
      return _user_service__WEBPACK_IMPORTED_MODULE_3__["UserService"];
    });
    /***/

  },

  /***/
  "./src/app/_services/user.service.ts":
  /*!*******************************************!*\
    !*** ./src/app/_services/user.service.ts ***!
    \*******************************************/

  /*! exports provided: UserService */

  /***/
  function srcApp_servicesUserServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserService", function () {
      return UserService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let UserService = class UserService {
      constructor(http) {
        this.http = http;
      }

      getAll() {
        return this.http.get('http://localhost:3000/api/products/').pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])(users => {
          return users.response;
        }));
      }

      getById(id) {
        return this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl, "/users/").concat(id));
      }

      register(user) {
        return this.http.post('http://localhost:3000/api/products/', user);
      }

      update(user) {
        return this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl, "/users/").concat(user.id), user);
      }

      delete(id) {
        return this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl, "/users/").concat(id));
      }

    };

    UserService.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
    }];

    UserService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], UserService);
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var ngx_cookie_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ngx-cookie-service */
    "./node_modules/ngx-cookie-service/ngx-cookie-service.js");
    /* harmony import */


    var _services__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./_services */
    "./src/app/_services/index.ts");

    let AppComponent = class AppComponent {
      constructor(router, cookieService, authenticationService) {
        this.router = router;
        this.cookieService = cookieService;
        this.authenticationService = authenticationService;
        this.year = new Date().getFullYear();
        this.title = 'GVKBio Logistics';
        this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
      }

      ngOnInit() {
        this.aggreymessage = true;
        var ssss = this.getCookie('gvkTrackCookie');

        if (ssss === 'savedCookie') {
          this.aggreymessage = false;
        }
      }

      createCookie() {
        this.cookieService.set('gvkTrackCookie', 'savedCookie');
        var sddsss = this.getCookie('gvkTrackCookie');

        if (sddsss === 'savedCookie') {
          this.aggreymessage = false;
        }
      }

      getCookie(key) {
        return this.cookieService.get(key);
      }

      deleteCookie(key) {
        return this.cookieService.delete(key);
      }

      logout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
      }

    };

    AppComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: ngx_cookie_service__WEBPACK_IMPORTED_MODULE_3__["CookieService"]
    }, {
      type: _services__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]
    }];

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], ngx_cookie_service__WEBPACK_IMPORTED_MODULE_3__["CookieService"], _services__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]])], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var ngx_cookie_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ngx-cookie-service */
    "./node_modules/ngx-cookie-service/ngx-cookie-service.js");
    /* harmony import */


    var _helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./_helpers */
    "./src/app/_helpers/index.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _angular_material__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material */
    "./node_modules/@angular/material/esm2015/material.js");
    /* harmony import */


    var _angular_material_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/material/button */
    "./node_modules/@angular/material/esm2015/button.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @angular/material/icon */
    "./node_modules/@angular/material/esm2015/icon.js");
    /* harmony import */


    var _angular_material_input__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @angular/material/input */
    "./node_modules/@angular/material/esm2015/input.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_material_table__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! @angular/material/table */
    "./node_modules/@angular/material/esm2015/table.js");
    /* harmony import */


    var _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! @angular/material/toolbar */
    "./node_modules/@angular/material/esm2015/toolbar.js");
    /* harmony import */


    var _services_excel_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./services/excel.service */
    "./src/app/services/excel.service.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ./services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _dialogs_add_add_dialog_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! ./dialogs/add/add.dialog.component */
    "./src/app/dialogs/add/add.dialog.component.ts");
    /* harmony import */


    var _dialogs_edit_edit_dialog_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! ./dialogs/edit/edit.dialog.component */
    "./src/app/dialogs/edit/edit.dialog.component.ts");
    /* harmony import */


    var _dialogs_delete_delete_dialog_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! ./dialogs/delete/delete.dialog.component */
    "./src/app/dialogs/delete/delete.dialog.component.ts");
    /* harmony import */


    var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! @angular/platform-browser/animations */
    "./node_modules/@angular/platform-browser/fesm2015/animations.js");
    /* harmony import */


    var _app_routing__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! ./app.routing */
    "./src/app/app.routing.ts");
    /* harmony import */


    var _components__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
    /*! ./_components */
    "./src/app/_components/index.ts");
    /* harmony import */


    var _home__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
    /*! ./home */
    "./src/app/home/index.ts");
    /* harmony import */


    var _login__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
    /*! ./login */
    "./src/app/login/index.ts");
    /* harmony import */


    var _register__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
    /*! ./register */
    "./src/app/register/index.ts");
    /* harmony import */


    var _vendors_vendors_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(
    /*! ./vendors/vendors.component */
    "./src/app/vendors/vendors.component.ts");
    /* harmony import */


    var _vendor_add_vendor_add_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(
    /*! ./vendor-add/vendor-add.component */
    "./src/app/vendor-add/vendor-add.component.ts");
    /* harmony import */


    var _import_record_add_import_record_add_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(
    /*! ./import-record-add/import-record-add.component */
    "./src/app/import-record-add/import-record-add.component.ts");
    /* harmony import */


    var _export_record_add_export_record_add_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(
    /*! ./export-record-add/export-record-add.component */
    "./src/app/export-record-add/export-record-add.component.ts");
    /* harmony import */


    var _import_records_list_import_records_list_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(
    /*! ./import-records-list/import-records-list.component */
    "./src/app/import-records-list/import-records-list.component.ts");
    /* harmony import */


    var _export_records_list_export_records_list_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(
    /*! ./export-records-list/export-records-list.component */
    "./src/app/export-records-list/export-records-list.component.ts");
    /* harmony import */


    var _export_record_edit_export_record_edit_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(
    /*! ./export-record-edit/export-record-edit.component */
    "./src/app/export-record-edit/export-record-edit.component.ts");
    /* harmony import */


    var _import_record_edit_import_record_edit_component__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(
    /*! ./import-record-edit/import-record-edit.component */
    "./src/app/import-record-edit/import-record-edit.component.ts");
    /* harmony import */


    var _header_header_component__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(
    /*! ./header/header.component */
    "./src/app/header/header.component.ts");
    /* harmony import */


    var _footer_footer_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(
    /*! ./footer/footer.component */
    "./src/app/footer/footer.component.ts");
    /* harmony import */


    var _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(
    /*! ./navbar/navbar.component */
    "./src/app/navbar/navbar.component.ts");
    /* harmony import */


    var _carriers_list_carriers_list_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(
    /*! ./carriers-list/carriers-list.component */
    "./src/app/carriers-list/carriers-list.component.ts");
    /* harmony import */


    var _carriers_add_carriers_add_component__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(
    /*! ./carriers-add/carriers-add.component */
    "./src/app/carriers-add/carriers-add.component.ts");
    /* harmony import */


    var _carriers_edit_carriers_edit_component__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(
    /*! ./carriers-edit/carriers-edit.component */
    "./src/app/carriers-edit/carriers-edit.component.ts");
    /* harmony import */


    var _countries_countries_component__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(
    /*! ./countries/countries.component */
    "./src/app/countries/countries.component.ts");
    /* harmony import */


    var _countries_add_countries_add_component__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(
    /*! ./countries-add/countries-add.component */
    "./src/app/countries-add/countries-add.component.ts");
    /* harmony import */


    var _countries_edit_countries_edit_component__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(
    /*! ./countries-edit/countries-edit.component */
    "./src/app/countries-edit/countries-edit.component.ts");
    /* harmony import */


    var _currencies_currencies_component__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(
    /*! ./currencies/currencies.component */
    "./src/app/currencies/currencies.component.ts");
    /* harmony import */


    var _currencies_add_currencies_add_component__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(
    /*! ./currencies-add/currencies-add.component */
    "./src/app/currencies-add/currencies-add.component.ts");
    /* harmony import */


    var _currencies_edit_currencies_edit_component__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(
    /*! ./currencies-edit/currencies-edit.component */
    "./src/app/currencies-edit/currencies-edit.component.ts");
    /* harmony import */


    var _cha_cha_component__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(
    /*! ./cha/cha.component */
    "./src/app/cha/cha.component.ts");
    /* harmony import */


    var _cha_add_cha_add_component__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(
    /*! ./cha-add/cha-add.component */
    "./src/app/cha-add/cha-add.component.ts");
    /* harmony import */


    var _cha_edit_cha_edit_component__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(
    /*! ./cha-edit/cha-edit.component */
    "./src/app/cha-edit/cha-edit.component.ts");
    /* harmony import */


    var _vendor_edit_vendor_edit_component__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(
    /*! ./vendor-edit/vendor-edit.component */
    "./src/app/vendor-edit/vendor-edit.component.ts");
    /* harmony import */


    var _users_users_component__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(
    /*! ./users/users.component */
    "./src/app/users/users.component.ts");
    /* harmony import */


    var _users_add_users_add_component__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(
    /*! ./users-add/users-add.component */
    "./src/app/users-add/users-add.component.ts");
    /* harmony import */


    var _users_edit_users_edit_component__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(
    /*! ./users-edit/users-edit.component */
    "./src/app/users-edit/users-edit.component.ts");
    /* harmony import */


    var _settings_settings_component__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(
    /*! ./settings/settings.component */
    "./src/app/settings/settings.component.ts");
    /* harmony import */


    var _settings_add_settings_add_component__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(
    /*! ./settings-add/settings-add.component */
    "./src/app/settings-add/settings-add.component.ts");
    /* harmony import */


    var _settings_edit_settings_edit_component__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(
    /*! ./settings-edit/settings-edit.component */
    "./src/app/settings-edit/settings-edit.component.ts");
    /* harmony import */


    var _custom_holidays_custom_holidays_component__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(
    /*! ./custom-holidays/custom-holidays.component */
    "./src/app/custom-holidays/custom-holidays.component.ts");
    /* harmony import */


    var _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(
    /*! ./privacy-policy/privacy-policy.component */
    "./src/app/privacy-policy/privacy-policy.component.ts");
    /* harmony import */


    var _user_logs_user_logs_component__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(
    /*! ./user-logs/user-logs.component */
    "./src/app/user-logs/user-logs.component.ts");
    /* harmony import */


    var _export_reports_export_reports_component__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(
    /*! ./export-reports/export-reports.component */
    "./src/app/export-reports/export-reports.component.ts");
    /* harmony import */


    var _import_reports_import_reports_component__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(
    /*! ./import-reports/import-reports.component */
    "./src/app/import-reports/import-reports.component.ts");
    /* harmony import */


    var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(
    /*! ng-multiselect-dropdown */
    "./node_modules/ng-multiselect-dropdown/fesm2015/ng-multiselect-dropdown.js");
    /* harmony import */


    var _overall_reports_overall_reports_component__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(
    /*! ./overall-reports/overall-reports.component */
    "./src/app/overall-reports/overall-reports.component.ts");
    /* harmony import */


    var _weekly_reports_weekly_reports_component__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(
    /*! ./weekly-reports/weekly-reports.component */
    "./src/app/weekly-reports/weekly-reports.component.ts"); // used to create fake backend


    ;
    ;
    ; // import { ExcelService } from '../app/_services/excelsheet.service';

    let AppModule = class AppModule {};
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _app_routing__WEBPACK_IMPORTED_MODULE_23__["routing"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_63__["NgMultiSelectDropDownModule"].forRoot(), _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_22__["BrowserAnimationsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_10__["MatDialogModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_9__["MatButtonModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_12__["MatInputModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_11__["MatIconModule"], _angular_material_sort__WEBPACK_IMPORTED_MODULE_14__["MatSortModule"], _angular_material_table__WEBPACK_IMPORTED_MODULE_15__["MatTableModule"], _angular_material_toolbar__WEBPACK_IMPORTED_MODULE_16__["MatToolbarModule"], _angular_material_paginator__WEBPACK_IMPORTED_MODULE_13__["MatPaginatorModule"], _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatProgressSpinnerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatCardModule"], _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatSelectModule"], _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatAutocompleteModule"], _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatDatepickerModule"], _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatNativeDateModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], _components__WEBPACK_IMPORTED_MODULE_24__["AlertComponent"], _home__WEBPACK_IMPORTED_MODULE_25__["HomeComponent"], _login__WEBPACK_IMPORTED_MODULE_26__["LoginComponent"], _register__WEBPACK_IMPORTED_MODULE_27__["RegisterComponent"], _dialogs_add_add_dialog_component__WEBPACK_IMPORTED_MODULE_19__["AddDialogComponent"], _dialogs_edit_edit_dialog_component__WEBPACK_IMPORTED_MODULE_20__["EditDialogComponent"], _dialogs_delete_delete_dialog_component__WEBPACK_IMPORTED_MODULE_21__["DeleteDialogComponent"], _vendors_vendors_component__WEBPACK_IMPORTED_MODULE_28__["VendorsComponent"], _vendor_add_vendor_add_component__WEBPACK_IMPORTED_MODULE_29__["VendorAddComponent"], _import_record_add_import_record_add_component__WEBPACK_IMPORTED_MODULE_30__["ImportRecordAddComponent"], _export_record_add_export_record_add_component__WEBPACK_IMPORTED_MODULE_31__["ExportRecordAddComponent"], _import_records_list_import_records_list_component__WEBPACK_IMPORTED_MODULE_32__["ImportRecordsListComponent"], _export_records_list_export_records_list_component__WEBPACK_IMPORTED_MODULE_33__["ExportRecordsListComponent"], _export_record_edit_export_record_edit_component__WEBPACK_IMPORTED_MODULE_34__["ExportRecordEditComponent"], _import_record_edit_import_record_edit_component__WEBPACK_IMPORTED_MODULE_35__["ImportRecordEditComponent"], _footer_footer_component__WEBPACK_IMPORTED_MODULE_37__["FooterComponent"], _header_header_component__WEBPACK_IMPORTED_MODULE_36__["HeaderComponent"], _navbar_navbar_component__WEBPACK_IMPORTED_MODULE_38__["NavbarComponent"], _carriers_edit_carriers_edit_component__WEBPACK_IMPORTED_MODULE_41__["CarriersEditComponent"], _carriers_add_carriers_add_component__WEBPACK_IMPORTED_MODULE_40__["CarriersAddComponent"], _carriers_list_carriers_list_component__WEBPACK_IMPORTED_MODULE_39__["CarriersListComponent"], _countries_edit_countries_edit_component__WEBPACK_IMPORTED_MODULE_44__["CountriesEditComponent"], _countries_add_countries_add_component__WEBPACK_IMPORTED_MODULE_43__["CountriesAddComponent"], _countries_countries_component__WEBPACK_IMPORTED_MODULE_42__["CountriesComponent"], _cha_add_cha_add_component__WEBPACK_IMPORTED_MODULE_49__["ChaAddComponent"], _cha_edit_cha_edit_component__WEBPACK_IMPORTED_MODULE_50__["ChaEditComponent"], _cha_cha_component__WEBPACK_IMPORTED_MODULE_48__["ChaComponent"], _currencies_edit_currencies_edit_component__WEBPACK_IMPORTED_MODULE_47__["CurrenciesEditComponent"], _currencies_add_currencies_add_component__WEBPACK_IMPORTED_MODULE_46__["CurrenciesAddComponent"], _currencies_currencies_component__WEBPACK_IMPORTED_MODULE_45__["CurrenciesComponent"], _vendor_edit_vendor_edit_component__WEBPACK_IMPORTED_MODULE_51__["VendorEditComponent"], _users_users_component__WEBPACK_IMPORTED_MODULE_52__["UsersComponent"], _users_add_users_add_component__WEBPACK_IMPORTED_MODULE_53__["UsersAddComponent"], _users_edit_users_edit_component__WEBPACK_IMPORTED_MODULE_54__["UsersEditComponent"], _settings_settings_component__WEBPACK_IMPORTED_MODULE_55__["SettingsComponent"], _settings_edit_settings_edit_component__WEBPACK_IMPORTED_MODULE_57__["SettingsEditComponent"], _settings_add_settings_add_component__WEBPACK_IMPORTED_MODULE_56__["SettingsAddComponent"], _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_59__["PrivacyPolicyComponent"], _custom_holidays_custom_holidays_component__WEBPACK_IMPORTED_MODULE_58__["CustomHolidaysComponent"], _user_logs_user_logs_component__WEBPACK_IMPORTED_MODULE_60__["UserLogsComponent"], _export_reports_export_reports_component__WEBPACK_IMPORTED_MODULE_61__["ExportReportsComponent"], _import_reports_import_reports_component__WEBPACK_IMPORTED_MODULE_62__["ImportReportsComponent"], _overall_reports_overall_reports_component__WEBPACK_IMPORTED_MODULE_64__["OverallReportsComponent"], _weekly_reports_weekly_reports_component__WEBPACK_IMPORTED_MODULE_65__["WeeklyReportsComponent"]],
      entryComponents: [_dialogs_add_add_dialog_component__WEBPACK_IMPORTED_MODULE_19__["AddDialogComponent"], _dialogs_edit_edit_dialog_component__WEBPACK_IMPORTED_MODULE_20__["EditDialogComponent"], _dialogs_delete_delete_dialog_component__WEBPACK_IMPORTED_MODULE_21__["DeleteDialogComponent"]],
      providers: [{
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
        useClass: _helpers__WEBPACK_IMPORTED_MODULE_6__["JwtInterceptor"],
        multi: true
      }, {
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HTTP_INTERCEPTORS"],
        useClass: _helpers__WEBPACK_IMPORTED_MODULE_6__["ErrorInterceptor"],
        multi: true
      }, {
        provide: _angular_material__WEBPACK_IMPORTED_MODULE_8__["MAT_DATE_LOCALE"],
        useValue: 'en-GB'
      }, // provider used to create fake backend
      _helpers__WEBPACK_IMPORTED_MODULE_6__["fakeBackendProvider"], _services_data_service__WEBPACK_IMPORTED_MODULE_18__["DataService"], ngx_cookie_service__WEBPACK_IMPORTED_MODULE_5__["CookieService"], _angular_material__WEBPACK_IMPORTED_MODULE_8__["MatDatepickerModule"], _services_excel_service__WEBPACK_IMPORTED_MODULE_17__["ExcelService"]],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/app.routing.ts":
  /*!********************************!*\
    !*** ./src/app/app.routing.ts ***!
    \********************************/

  /*! exports provided: routing */

  /***/
  function srcAppAppRoutingTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "routing", function () {
      return routing;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _vendors_vendors_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./vendors/vendors.component */
    "./src/app/vendors/vendors.component.ts");
    /* harmony import */


    var _vendor_add_vendor_add_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./vendor-add/vendor-add.component */
    "./src/app/vendor-add/vendor-add.component.ts");
    /* harmony import */


    var _vendor_edit_vendor_edit_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./vendor-edit/vendor-edit.component */
    "./src/app/vendor-edit/vendor-edit.component.ts");
    /* harmony import */


    var _import_record_add_import_record_add_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./import-record-add/import-record-add.component */
    "./src/app/import-record-add/import-record-add.component.ts");
    /* harmony import */


    var _import_records_list_import_records_list_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./import-records-list/import-records-list.component */
    "./src/app/import-records-list/import-records-list.component.ts");
    /* harmony import */


    var _import_record_edit_import_record_edit_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./import-record-edit/import-record-edit.component */
    "./src/app/import-record-edit/import-record-edit.component.ts");
    /* harmony import */


    var _export_record_add_export_record_add_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ./export-record-add/export-record-add.component */
    "./src/app/export-record-add/export-record-add.component.ts");
    /* harmony import */


    var _export_records_list_export_records_list_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./export-records-list/export-records-list.component */
    "./src/app/export-records-list/export-records-list.component.ts");
    /* harmony import */


    var _export_record_edit_export_record_edit_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./export-record-edit/export-record-edit.component */
    "./src/app/export-record-edit/export-record-edit.component.ts");
    /* harmony import */


    var _carriers_list_carriers_list_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./carriers-list/carriers-list.component */
    "./src/app/carriers-list/carriers-list.component.ts");
    /* harmony import */


    var _carriers_add_carriers_add_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./carriers-add/carriers-add.component */
    "./src/app/carriers-add/carriers-add.component.ts");
    /* harmony import */


    var _carriers_edit_carriers_edit_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./carriers-edit/carriers-edit.component */
    "./src/app/carriers-edit/carriers-edit.component.ts");
    /* harmony import */


    var _countries_countries_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./countries/countries.component */
    "./src/app/countries/countries.component.ts");
    /* harmony import */


    var _countries_add_countries_add_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ./countries-add/countries-add.component */
    "./src/app/countries-add/countries-add.component.ts");
    /* harmony import */


    var _countries_edit_countries_edit_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
    /*! ./countries-edit/countries-edit.component */
    "./src/app/countries-edit/countries-edit.component.ts");
    /* harmony import */


    var _currencies_currencies_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
    /*! ./currencies/currencies.component */
    "./src/app/currencies/currencies.component.ts");
    /* harmony import */


    var _currencies_add_currencies_add_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
    /*! ./currencies-add/currencies-add.component */
    "./src/app/currencies-add/currencies-add.component.ts");
    /* harmony import */


    var _currencies_edit_currencies_edit_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
    /*! ./currencies-edit/currencies-edit.component */
    "./src/app/currencies-edit/currencies-edit.component.ts");
    /* harmony import */


    var _cha_cha_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
    /*! ./cha/cha.component */
    "./src/app/cha/cha.component.ts");
    /* harmony import */


    var _cha_add_cha_add_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
    /*! ./cha-add/cha-add.component */
    "./src/app/cha-add/cha-add.component.ts");
    /* harmony import */


    var _cha_edit_cha_edit_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
    /*! ./cha-edit/cha-edit.component */
    "./src/app/cha-edit/cha-edit.component.ts");
    /* harmony import */


    var _users_users_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
    /*! ./users/users.component */
    "./src/app/users/users.component.ts");
    /* harmony import */


    var _users_add_users_add_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
    /*! ./users-add/users-add.component */
    "./src/app/users-add/users-add.component.ts");
    /* harmony import */


    var _users_edit_users_edit_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
    /*! ./users-edit/users-edit.component */
    "./src/app/users-edit/users-edit.component.ts");
    /* harmony import */


    var _settings_settings_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
    /*! ./settings/settings.component */
    "./src/app/settings/settings.component.ts");
    /* harmony import */


    var _settings_add_settings_add_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
    /*! ./settings-add/settings-add.component */
    "./src/app/settings-add/settings-add.component.ts");
    /* harmony import */


    var _settings_edit_settings_edit_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(
    /*! ./settings-edit/settings-edit.component */
    "./src/app/settings-edit/settings-edit.component.ts");
    /* harmony import */


    var _custom_holidays_custom_holidays_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(
    /*! ./custom-holidays/custom-holidays.component */
    "./src/app/custom-holidays/custom-holidays.component.ts");
    /* harmony import */


    var _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(
    /*! ./privacy-policy/privacy-policy.component */
    "./src/app/privacy-policy/privacy-policy.component.ts");
    /* harmony import */


    var _user_logs_user_logs_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(
    /*! ./user-logs/user-logs.component */
    "./src/app/user-logs/user-logs.component.ts");
    /* harmony import */


    var _export_reports_export_reports_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(
    /*! ./export-reports/export-reports.component */
    "./src/app/export-reports/export-reports.component.ts");
    /* harmony import */


    var _import_reports_import_reports_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(
    /*! ./import-reports/import-reports.component */
    "./src/app/import-reports/import-reports.component.ts");
    /* harmony import */


    var _login__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(
    /*! ./login */
    "./src/app/login/index.ts");
    /* harmony import */


    var _register__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(
    /*! ./register */
    "./src/app/register/index.ts");
    /* harmony import */


    var _guards__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(
    /*! ./_guards */
    "./src/app/_guards/index.ts");
    /* harmony import */


    var _overall_reports_overall_reports_component__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(
    /*! ./overall-reports/overall-reports.component */
    "./src/app/overall-reports/overall-reports.component.ts");
    /* harmony import */


    var _weekly_reports_weekly_reports_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(
    /*! ./weekly-reports/weekly-reports.component */
    "./src/app/weekly-reports/weekly-reports.component.ts");

    const appRoutes = [{
      path: '',
      component: _import_records_list_import_records_list_component__WEBPACK_IMPORTED_MODULE_6__["ImportRecordsListComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'login',
      component: _login__WEBPACK_IMPORTED_MODULE_34__["LoginComponent"]
    }, {
      path: 'vendors',
      component: _vendors_vendors_component__WEBPACK_IMPORTED_MODULE_2__["VendorsComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'vendor-add',
      component: _vendor_add_vendor_add_component__WEBPACK_IMPORTED_MODULE_3__["VendorAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'register',
      component: _register__WEBPACK_IMPORTED_MODULE_35__["RegisterComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'export-records',
      component: _export_records_list_export_records_list_component__WEBPACK_IMPORTED_MODULE_9__["ExportRecordsListComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'export-add',
      component: _export_record_add_export_record_add_component__WEBPACK_IMPORTED_MODULE_8__["ExportRecordAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'export-edit/:id',
      component: _export_record_edit_export_record_edit_component__WEBPACK_IMPORTED_MODULE_10__["ExportRecordEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'import-edit/:id',
      component: _import_record_edit_import_record_edit_component__WEBPACK_IMPORTED_MODULE_7__["ImportRecordEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'import-add',
      component: _import_record_add_import_record_add_component__WEBPACK_IMPORTED_MODULE_5__["ImportRecordAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'import-records',
      component: _import_records_list_import_records_list_component__WEBPACK_IMPORTED_MODULE_6__["ImportRecordsListComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'carriers',
      component: _carriers_list_carriers_list_component__WEBPACK_IMPORTED_MODULE_11__["CarriersListComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'carrier-add',
      component: _carriers_add_carriers_add_component__WEBPACK_IMPORTED_MODULE_12__["CarriersAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'carrier-edit/:id',
      component: _carriers_edit_carriers_edit_component__WEBPACK_IMPORTED_MODULE_13__["CarriersEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'countries',
      component: _countries_countries_component__WEBPACK_IMPORTED_MODULE_14__["CountriesComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'countries-add',
      component: _countries_add_countries_add_component__WEBPACK_IMPORTED_MODULE_15__["CountriesAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'countries-edit/:id',
      component: _countries_edit_countries_edit_component__WEBPACK_IMPORTED_MODULE_16__["CountriesEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'currencies',
      component: _currencies_currencies_component__WEBPACK_IMPORTED_MODULE_17__["CurrenciesComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'currencies-add',
      component: _currencies_add_currencies_add_component__WEBPACK_IMPORTED_MODULE_18__["CurrenciesAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'currencies-edit/:id',
      component: _currencies_edit_currencies_edit_component__WEBPACK_IMPORTED_MODULE_19__["CurrenciesEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'cha',
      component: _cha_cha_component__WEBPACK_IMPORTED_MODULE_20__["ChaComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'cha-add',
      component: _cha_add_cha_add_component__WEBPACK_IMPORTED_MODULE_21__["ChaAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'cha-edit/:id',
      component: _cha_edit_cha_edit_component__WEBPACK_IMPORTED_MODULE_22__["ChaEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'vendor-edit/:id',
      component: _vendor_edit_vendor_edit_component__WEBPACK_IMPORTED_MODULE_4__["VendorEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'users',
      component: _users_users_component__WEBPACK_IMPORTED_MODULE_23__["UsersComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'user-add',
      component: _users_add_users_add_component__WEBPACK_IMPORTED_MODULE_24__["UsersAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'user-edit/:id',
      component: _users_edit_users_edit_component__WEBPACK_IMPORTED_MODULE_25__["UsersEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'users-logs',
      component: _user_logs_user_logs_component__WEBPACK_IMPORTED_MODULE_31__["UserLogsComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'settings',
      component: _settings_settings_component__WEBPACK_IMPORTED_MODULE_26__["SettingsComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'settings-add',
      component: _settings_add_settings_add_component__WEBPACK_IMPORTED_MODULE_27__["SettingsAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'settings-edit/:id',
      component: _settings_edit_settings_edit_component__WEBPACK_IMPORTED_MODULE_28__["SettingsEditComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'custom-holidays',
      component: _custom_holidays_custom_holidays_component__WEBPACK_IMPORTED_MODULE_29__["CustomHolidaysComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'privacy-policy',
      component: _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_30__["PrivacyPolicyComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'export-reports',
      component: _export_reports_export_reports_component__WEBPACK_IMPORTED_MODULE_32__["ExportReportsComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'import-reports',
      component: _import_reports_import_reports_component__WEBPACK_IMPORTED_MODULE_33__["ImportReportsComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'imports-overall-reports',
      component: _overall_reports_overall_reports_component__WEBPACK_IMPORTED_MODULE_37__["OverallReportsComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'settings-add',
      component: _settings_add_settings_add_component__WEBPACK_IMPORTED_MODULE_27__["SettingsAddComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, {
      path: 'weekely-reports',
      component: _weekly_reports_weekly_reports_component__WEBPACK_IMPORTED_MODULE_38__["WeeklyReportsComponent"],
      canActivate: [_guards__WEBPACK_IMPORTED_MODULE_36__["AuthGuard"]]
    }, // otherwise redirect to home
    {
      path: '**',
      redirectTo: 'import-records'
    }];

    const routing = _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(appRoutes);
    /***/

  },

  /***/
  "./src/app/carriers-add/carriers-add.component.scss":
  /*!**********************************************************!*\
    !*** ./src/app/carriers-add/carriers-add.component.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCarriersAddCarriersAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NhcnJpZXJzLWFkZC9jYXJyaWVycy1hZGQuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/carriers-add/carriers-add.component.ts":
  /*!********************************************************!*\
    !*** ./src/app/carriers-add/carriers-add.component.ts ***!
    \********************************************************/

  /*! exports provided: CarriersAddComponent */

  /***/
  function srcAppCarriersAddCarriersAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CarriersAddComponent", function () {
      return CarriersAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CarriersAddComponent = class CarriersAddComponent {
      constructor(router, api, formBuilder, http) {
        this.router = router;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.carrier = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.carrierForm = this.formBuilder.group({
          'carrier': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/carrier/carrierAdd/', form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Carrier added Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/carriers']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

    };

    CarriersAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    CarriersAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-carriers-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./carriers-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-add/carriers-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./carriers-add.component.scss */
      "./src/app/carriers-add/carriers-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], CarriersAddComponent);
    /***/
  },

  /***/
  "./src/app/carriers-edit/carriers-edit.component.scss":
  /*!************************************************************!*\
    !*** ./src/app/carriers-edit/carriers-edit.component.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCarriersEditCarriersEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NhcnJpZXJzLWVkaXQvY2FycmllcnMtZWRpdC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/carriers-edit/carriers-edit.component.ts":
  /*!**********************************************************!*\
    !*** ./src/app/carriers-edit/carriers-edit.component.ts ***!
    \**********************************************************/

  /*! exports provided: CarriersEditComponent */

  /***/
  function srcAppCarriersEditCarriersEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CarriersEditComponent", function () {
      return CarriersEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CarriersEditComponent = class CarriersEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.carrier = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getCarrierDetails(this.route.snapshot.params['id']);
        this.carrierForm = this.formBuilder.group({
          'carrier': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        let cid = this.route.snapshot.params['id'];
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/carrier/carrierUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/carriers']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      getCarrierDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/carrier/carriers/' + cNo).subscribe(dataaa => {
          this.carrierForm.setValue({
            carrier: dataaa[0].carrier
          });
        });
      }

    };

    CarriersEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    CarriersEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-carriers-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./carriers-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-edit/carriers-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./carriers-edit.component.scss */
      "./src/app/carriers-edit/carriers-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], CarriersEditComponent);
    /***/
  },

  /***/
  "./src/app/carriers-list/carriers-list.component.scss":
  /*!************************************************************!*\
    !*** ./src/app/carriers-list/carriers-list.component.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCarriersListCarriersListComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  float: left;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2FycmllcnMtbGlzdC9EOlxcUHJvamVjdHNcXGd2a2FkbWluLWZyb250ZW5kL3NyY1xcYXBwXFxjYXJyaWVycy1saXN0XFxjYXJyaWVycy1saXN0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jYXJyaWVycy1saXN0L2NhcnJpZXJzLWxpc3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURBQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7QUNHSjs7QUREQztFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7QUNJRDs7QURGRTtFQUNFLCtCQUFBO0VBQ0gsbUJBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7QUNLRDs7QURIQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtBQ01BOztBREpBO0VBQ0UscUJBQUE7RUFDRSxXQUFBO0VBQ0gsZ0JBQUE7QUNPRDs7QURMQTtFQUNBLFVBQUE7QUNRQTs7QUROQTtFQUNBLFVBQUE7QUNTQTs7QURQQTtFQUNBLHlCQUFBO0FDVUE7O0FEUkE7RUFDQSxpQkFBQTtBQ1dBOztBRFRBO0VBQ0Esb0JBQUE7QUNZQTs7QURWQTtFQUNBLFdBQUE7QUNhQSIsImZpbGUiOiJzcmMvYXBwL2NhcnJpZXJzLWxpc3QvY2FycmllcnMtbGlzdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtaGVhZGVyLWNlbGwge1xyXG4gICAgbWluLXdpZHRoOiAxMDBweDtcclxufVxyXG4ubWF0LWNlbGwubmctc3Rhci1pbnNlcnRlZCB7XHJcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG59XHJcbi5tYXQtdGFibGUge1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBvdmVyZmxvdy14OiBhdXRvO1xyXG59XHJcbiBtYXQtaGVhZGVyLWNlbGx7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2U5ZjhmZjtcclxuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcclxufVxyXG4gIG1hdC1jZWxsICwgbWF0LWhlYWRlci1jZWxse1xyXG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlOTtcclxuXHRhbGlnbi1zZWxmOiBzdHJldGNoO1x0XHJcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XHJcblx0cGFkZGluZzowIDhweDtcclxufVxyXG4udXBsb2FkLWYubmctc3Rhci1pbnNlcnRlZHtcclxuZGlzcGxheTpmbGV4O1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwICwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcblx0bWFyZ2luLWJvdHRvbTowO1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3Vwe1xyXG53aWR0aDo3NSU7XHJcbn1cclxuLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbndpZHRoOjI1JTtcclxufVxyXG4ubWF0LXRhYmxle1xyXG5ib3JkZXI6IDFweCBzb2xpZCAjZThlOGU5O1xyXG59XHJcbi51cGxvYWQtYnRue1xyXG50ZXh0LWFsaWduOnJpZ2h0O1xyXG59XHJcbi50b3AtYnRucyAuYnRue1xyXG5tYXJnaW46MCA1cHggMTBweCAwO1xyXG59XHJcbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvd3tcclxuYm9yZGVyOjBweFxyXG59IiwiLm1hdC1oZWFkZXItY2VsbCB7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG5cbi5tYXQtY2VsbC5uZy1zdGFyLWluc2VydGVkIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBvdmVyZmxvdy14OiBhdXRvO1xufVxuXG5tYXQtaGVhZGVyLWNlbGwge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxubWF0LWNlbGwsIG1hdC1oZWFkZXItY2VsbCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XG4gIGFsaWduLXNlbGY6IHN0cmV0Y2g7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xuICBwYWRkaW5nOiAwIDhweDtcbn1cblxuLnVwbG9hZC1mLm5nLXN0YXItaW5zZXJ0ZWQge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tYm90dG9tOiAwO1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCB7XG4gIHdpZHRoOiA3NSU7XG59XG5cbi5pbXBvcnQtc2VjIC51cGxvYWQtYnRuIHtcbiAgd2lkdGg6IDI1JTtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XG59XG5cbi51cGxvYWQtYnRuIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbi50b3AtYnRucyAuYnRuIHtcbiAgbWFyZ2luOiAwIDVweCAxMHB4IDA7XG59XG5cbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvdyB7XG4gIGJvcmRlcjogMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/carriers-list/carriers-list.component.ts":
  /*!**********************************************************!*\
    !*** ./src/app/carriers-list/carriers-list.component.ts ***!
    \**********************************************************/

  /*! exports provided: CarriersListComponent, ExampleDataSource */

  /***/
  function srcAppCarriersListCarriersListComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CarriersListComponent", function () {
      return CarriersListComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CarriersListComponent = class CarriersListComponent {
      constructor(authenticationService, userService, httpClient, dialog, http, dataService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.http = http;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['id', 'carrier', 'create_date', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        this.loadData(); //       this.loadAllUsers();
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      deleteCarrier(cid) {
        this.isLoadingResults = true;
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].apiUrl_base) + '/carrier/DeleteCarrier/' + cid).subscribe(datar => {
          this.isLoadingResults = false;
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
            this.refresh();
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      refresh() {
        this.loadData();
      }

      refreshTable() {
        // Refreshing table using paginator
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    CarriersListComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"])], CarriersListComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"])], CarriersListComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], CarriersListComponent.prototype, "filter", void 0);
    CarriersListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-carriers-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./carriers-list.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/carriers-list/carriers-list.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./carriers-list.component.scss */
      "./src/app/carriers-list/carriers-list.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], CarriersListComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_9__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.carrierDataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getCarriers();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.carrierData.slice().filter(carrier => {
            const searchStr = (carrier.id + carrier.carrier + carrier.create_date).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'id':
              [propertyA, propertyB] = [a.id, b.id];
              break;

            case 'carrier':
              [propertyA, propertyB] = [a.carrier, b.carrier];
              break;

            case 'create_date':
              [propertyA, propertyB] = [a.create_date, b.create_date];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'desc' ? 1 : -1);
        });
      }

    }
    /***/

  },

  /***/
  "./src/app/cha-add/cha-add.component.scss":
  /*!************************************************!*\
    !*** ./src/app/cha-add/cha-add.component.scss ***!
    \************************************************/

  /*! exports provided: default */

  /***/
  function srcAppChaAddChaAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NoYS1hZGQvY2hhLWFkZC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/cha-add/cha-add.component.ts":
  /*!**********************************************!*\
    !*** ./src/app/cha-add/cha-add.component.ts ***!
    \**********************************************/

  /*! exports provided: ChaAddComponent */

  /***/
  function srcAppChaAddChaAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChaAddComponent", function () {
      return ChaAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let ChaAddComponent = class ChaAddComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.cha_name = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.chaForm = this.formBuilder.group({
          'cha_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/cha/chaadd/', form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record  Successfully inserted";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/cha']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

    };

    ChaAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    ChaAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cha-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./cha-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/cha-add/cha-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./cha-add.component.scss */
      "./src/app/cha-add/cha-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], ChaAddComponent);
    /***/
  },

  /***/
  "./src/app/cha-edit/cha-edit.component.scss":
  /*!**************************************************!*\
    !*** ./src/app/cha-edit/cha-edit.component.scss ***!
    \**************************************************/

  /*! exports provided: default */

  /***/
  function srcAppChaEditChaEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NoYS1lZGl0L2NoYS1lZGl0LmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/cha-edit/cha-edit.component.ts":
  /*!************************************************!*\
    !*** ./src/app/cha-edit/cha-edit.component.ts ***!
    \************************************************/

  /*! exports provided: ChaEditComponent */

  /***/
  function srcAppChaEditChaEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChaEditComponent", function () {
      return ChaEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let ChaEditComponent = class ChaEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.cha_name = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getchaDetails(this.route.snapshot.params['id']);
        this.chaForm = this.formBuilder.group({
          'cha_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        let cid = this.route.snapshot.params['id'];
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/cha/chaUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/cha']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      } // get CHA details


      getchaDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/cha/getcha/' + cNo).subscribe(dataaa => {
          this.chaForm.setValue({
            cha_name: dataaa[0].cha_name
          });
        });
      }

    };

    ChaEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    ChaEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cha-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./cha-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/cha-edit/cha-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./cha-edit.component.scss */
      "./src/app/cha-edit/cha-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], ChaEditComponent);
    /***/
  },

  /***/
  "./src/app/cha/cha.component.scss":
  /*!****************************************!*\
    !*** ./src/app/cha/cha.component.scss ***!
    \****************************************/

  /*! exports provided: default */

  /***/
  function srcAppChaChaComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  float: left;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhL0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXGNoYVxcY2hhLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jaGEvY2hhLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7QUNDSjs7QURDQTtFQUNJLGdCQUFBO0FDRUo7O0FEQUE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0FDR0o7O0FEREM7RUFDQSx5QkFBQTtFQUNBLGdDQUFBO0FDSUQ7O0FERkU7RUFDRSwrQkFBQTtFQUNILG1CQUFBO0VBQ0EsZ0NBQUE7RUFDQSxjQUFBO0FDS0Q7O0FESEE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7QUNNQTs7QURKQTtFQUNFLHFCQUFBO0VBQ0UsV0FBQTtFQUNILGdCQUFBO0FDT0Q7O0FETEE7RUFDQSxVQUFBO0FDUUE7O0FETkE7RUFDQSxVQUFBO0FDU0E7O0FEUEE7RUFDQSx5QkFBQTtBQ1VBOztBRFJBO0VBQ0EsaUJBQUE7QUNXQTs7QURUQTtFQUNBLG9CQUFBO0FDWUE7O0FEVkE7RUFDQSxXQUFBO0FDYUEiLCJmaWxlIjoic3JjL2FwcC9jaGEvY2hhLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hdC1oZWFkZXItY2VsbCB7XHJcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG59XHJcbi5tYXQtY2VsbC5uZy1zdGFyLWluc2VydGVkIHtcclxuICAgIG1pbi13aWR0aDogMTAwcHg7XHJcbn1cclxuLm1hdC10YWJsZSB7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIG92ZXJmbG93LXg6IGF1dG87XHJcbn1cclxuIG1hdC1oZWFkZXItY2VsbHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmO1xyXG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xyXG59XHJcbiAgbWF0LWNlbGwgLCBtYXQtaGVhZGVyLWNlbGx7XHJcbiAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU5O1xyXG5cdGFsaWduLXNlbGY6IHN0cmV0Y2g7XHRcclxuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcclxuXHRwYWRkaW5nOjAgOHB4O1xyXG59XHJcbi51cGxvYWQtZi5uZy1zdGFyLWluc2VydGVke1xyXG5kaXNwbGF5OmZsZXg7XHJcbn1cclxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXAgLCAuaW1wb3J0LXNlYyAudXBsb2FkLWJ0bntcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuXHRtYXJnaW4tYm90dG9tOjA7XHJcbn1cclxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXB7XHJcbndpZHRoOjc1JTtcclxufVxyXG4uaW1wb3J0LXNlYyAudXBsb2FkLWJ0bntcclxud2lkdGg6MjUlO1xyXG59XHJcbi5tYXQtdGFibGV7XHJcbmJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbn1cclxuLnVwbG9hZC1idG57XHJcbnRleHQtYWxpZ246cmlnaHQ7XHJcbn1cclxuLnRvcC1idG5zIC5idG57XHJcbm1hcmdpbjowIDVweCAxMHB4IDA7XHJcbn1cclxubWF0LWZvb3Rlci1yb3csIG1hdC1oZWFkZXItcm93LCBtYXQtcm93e1xyXG5ib3JkZXI6MHB4XHJcbn0iLCIubWF0LWhlYWRlci1jZWxsIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbn1cblxuLm1hdC1jZWxsLm5nLXN0YXItaW5zZXJ0ZWQge1xuICBtaW4td2lkdGg6IDEwMHB4O1xufVxuXG4ubWF0LXRhYmxlIHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIG92ZXJmbG93LXg6IGF1dG87XG59XG5cbm1hdC1oZWFkZXItY2VsbCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlOWY4ZmY7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xufVxuXG5tYXQtY2VsbCwgbWF0LWhlYWRlci1jZWxsIHtcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlOTtcbiAgYWxpZ24tc2VsZjogc3RyZXRjaDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XG4gIHBhZGRpbmc6IDAgOHB4O1xufVxuXG4udXBsb2FkLWYubmctc3Rhci1pbnNlcnRlZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG5cbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwLCAuaW1wb3J0LXNlYyAudXBsb2FkLWJ0biB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG5cbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwIHtcbiAgd2lkdGg6IDc1JTtcbn1cblxuLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICB3aWR0aDogMjUlO1xufVxuXG4ubWF0LXRhYmxlIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxuLnVwbG9hZC1idG4ge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLnRvcC1idG5zIC5idG4ge1xuICBtYXJnaW46IDAgNXB4IDEwcHggMDtcbn1cblxubWF0LWZvb3Rlci1yb3csIG1hdC1oZWFkZXItcm93LCBtYXQtcm93IHtcbiAgYm9yZGVyOiAwcHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/cha/cha.component.ts":
  /*!**************************************!*\
    !*** ./src/app/cha/cha.component.ts ***!
    \**************************************/

  /*! exports provided: ChaComponent, ExampleDataSource */

  /***/
  function srcAppChaChaComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ChaComponent", function () {
      return ChaComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let ChaComponent = class ChaComponent {
      constructor(authenticationService, userService, httpClient, dialog, http, dataService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.http = http;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['id', 'cha_name', 'create_date', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        this.loadData(); //       this.loadAllUsers();
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      deletecha(cid) {
        this.isLoadingResults = true;
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].apiUrl_base) + '/cha/deleteCha/' + cid).subscribe(datar => {
          this.isLoadingResults = false;
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
            this.refresh();
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      refresh() {
        this.loadData();
      }

      refreshTable() {
        // Refreshing table using paginator
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    ChaComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"])], ChaComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"])], ChaComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], ChaComponent.prototype, "filter", void 0);
    ChaComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cha',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./cha.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/cha/cha.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./cha.component.scss */
      "./src/app/cha/cha.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], ChaComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_9__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.chaDataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getCha();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.chaData.slice().filter(cha => {
            const searchStr = (cha.id + cha.cha_name + cha.create_date).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'id':
              [propertyA, propertyB] = [a.id, b.id];
              break;

            case 'cha_name':
              [propertyA, propertyB] = [a.cha_name, b.cha_name];
              break;

            case 'create_date':
              [propertyA, propertyB] = [a.create_date, b.create_date];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'desc' ? 1 : -1);
        });
      }

    }
    /***/

  },

  /***/
  "./src/app/countries-add/countries-add.component.scss":
  /*!************************************************************!*\
    !*** ./src/app/countries-add/countries-add.component.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCountriesAddCountriesAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvdW50cmllcy1hZGQvY291bnRyaWVzLWFkZC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/countries-add/countries-add.component.ts":
  /*!**********************************************************!*\
    !*** ./src/app/countries-add/countries-add.component.ts ***!
    \**********************************************************/

  /*! exports provided: CountriesAddComponent */

  /***/
  function srcAppCountriesAddCountriesAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CountriesAddComponent", function () {
      return CountriesAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CountriesAddComponent = class CountriesAddComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.country = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.countriesForm = this.formBuilder.group({
          'country': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/country/countryadd/', form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record  Successfully inserted";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/countries']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

    };

    CountriesAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    CountriesAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-countries-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./countries-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/countries-add/countries-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./countries-add.component.scss */
      "./src/app/countries-add/countries-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], CountriesAddComponent);
    /***/
  },

  /***/
  "./src/app/countries-edit/countries-edit.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/countries-edit/countries-edit.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCountriesEditCountriesEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvdW50cmllcy1lZGl0L2NvdW50cmllcy1lZGl0LmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/countries-edit/countries-edit.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/countries-edit/countries-edit.component.ts ***!
    \************************************************************/

  /*! exports provided: CountriesEditComponent */

  /***/
  function srcAppCountriesEditCountriesEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CountriesEditComponent", function () {
      return CountriesEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CountriesEditComponent = class CountriesEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.country = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getcountryDetails(this.route.snapshot.params['id']);
        this.countriesForm = this.formBuilder.group({
          'country': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        let cid = this.route.snapshot.params['id'];
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/country/countryUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/countries']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      } // get Country details


      getcountryDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/country/countries/' + cNo).subscribe(dataaa => {
          this.countriesForm.setValue({
            country: dataaa[0].country
          });
        });
      }

    };

    CountriesEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    CountriesEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-countries-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./countries-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/countries-edit/countries-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./countries-edit.component.scss */
      "./src/app/countries-edit/countries-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], CountriesEditComponent);
    /***/
  },

  /***/
  "./src/app/countries/countries.component.scss":
  /*!****************************************************!*\
    !*** ./src/app/countries/countries.component.scss ***!
    \****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCountriesCountriesComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  float: left;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY291bnRyaWVzL0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXGNvdW50cmllc1xcY291bnRyaWVzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb3VudHJpZXMvY291bnRyaWVzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7QUNDSjs7QURDQTtFQUNJLGdCQUFBO0FDRUo7O0FEQUE7RUFDSSxpQkFBQTtFQUNBLGdCQUFBO0FDR0o7O0FEREM7RUFDQSx5QkFBQTtFQUNBLGdDQUFBO0FDSUQ7O0FERkU7RUFDRSwrQkFBQTtFQUNILG1CQUFBO0VBQ0EsZ0NBQUE7RUFDQSxjQUFBO0FDS0Q7O0FESEE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7QUNNQTs7QURKQTtFQUNFLHFCQUFBO0VBQ0UsV0FBQTtFQUNILGdCQUFBO0FDT0Q7O0FETEE7RUFDQSxVQUFBO0FDUUE7O0FETkE7RUFDQSxVQUFBO0FDU0E7O0FEUEE7RUFDQSx5QkFBQTtBQ1VBOztBRFJBO0VBQ0EsaUJBQUE7QUNXQTs7QURUQTtFQUNBLG9CQUFBO0FDWUE7O0FEVkE7RUFDQSxXQUFBO0FDYUEiLCJmaWxlIjoic3JjL2FwcC9jb3VudHJpZXMvY291bnRyaWVzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hdC1oZWFkZXItY2VsbCB7XHJcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG59XHJcbi5tYXQtY2VsbC5uZy1zdGFyLWluc2VydGVkIHtcclxuICAgIG1pbi13aWR0aDogMTAwcHg7XHJcbn1cclxuLm1hdC10YWJsZSB7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIG92ZXJmbG93LXg6IGF1dG87XHJcbn1cclxuIG1hdC1oZWFkZXItY2VsbHtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmO1xyXG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xyXG59XHJcbiAgbWF0LWNlbGwgLCBtYXQtaGVhZGVyLWNlbGx7XHJcbiAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU5O1xyXG5cdGFsaWduLXNlbGY6IHN0cmV0Y2g7XHRcclxuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcclxuXHRwYWRkaW5nOjAgOHB4O1xyXG59XHJcbi51cGxvYWQtZi5uZy1zdGFyLWluc2VydGVke1xyXG5kaXNwbGF5OmZsZXg7XHJcbn1cclxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXAgLCAuaW1wb3J0LXNlYyAudXBsb2FkLWJ0bntcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBmbG9hdDogbGVmdDtcclxuXHRtYXJnaW4tYm90dG9tOjA7XHJcbn1cclxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXB7XHJcbndpZHRoOjc1JTtcclxufVxyXG4uaW1wb3J0LXNlYyAudXBsb2FkLWJ0bntcclxud2lkdGg6MjUlO1xyXG59XHJcbi5tYXQtdGFibGV7XHJcbmJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbn1cclxuLnVwbG9hZC1idG57XHJcbnRleHQtYWxpZ246cmlnaHQ7XHJcbn1cclxuLnRvcC1idG5zIC5idG57XHJcbm1hcmdpbjowIDVweCAxMHB4IDA7XHJcbn1cclxubWF0LWZvb3Rlci1yb3csIG1hdC1oZWFkZXItcm93LCBtYXQtcm93e1xyXG5ib3JkZXI6MHB4XHJcbn0iLCIubWF0LWhlYWRlci1jZWxsIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbn1cblxuLm1hdC1jZWxsLm5nLXN0YXItaW5zZXJ0ZWQge1xuICBtaW4td2lkdGg6IDEwMHB4O1xufVxuXG4ubWF0LXRhYmxlIHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIG92ZXJmbG93LXg6IGF1dG87XG59XG5cbm1hdC1oZWFkZXItY2VsbCB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlOWY4ZmY7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xufVxuXG5tYXQtY2VsbCwgbWF0LWhlYWRlci1jZWxsIHtcbiAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlOTtcbiAgYWxpZ24tc2VsZjogc3RyZXRjaDtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XG4gIHBhZGRpbmc6IDAgOHB4O1xufVxuXG4udXBsb2FkLWYubmctc3Rhci1pbnNlcnRlZCB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG5cbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwLCAuaW1wb3J0LXNlYyAudXBsb2FkLWJ0biB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG5cbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwIHtcbiAgd2lkdGg6IDc1JTtcbn1cblxuLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICB3aWR0aDogMjUlO1xufVxuXG4ubWF0LXRhYmxlIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxuLnVwbG9hZC1idG4ge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLnRvcC1idG5zIC5idG4ge1xuICBtYXJnaW46IDAgNXB4IDEwcHggMDtcbn1cblxubWF0LWZvb3Rlci1yb3csIG1hdC1oZWFkZXItcm93LCBtYXQtcm93IHtcbiAgYm9yZGVyOiAwcHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/countries/countries.component.ts":
  /*!**************************************************!*\
    !*** ./src/app/countries/countries.component.ts ***!
    \**************************************************/

  /*! exports provided: CountriesComponent, ExampleDataSource */

  /***/
  function srcAppCountriesCountriesComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CountriesComponent", function () {
      return CountriesComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CountriesComponent = class CountriesComponent {
      constructor(authenticationService, userService, httpClient, dialog, http, dataService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.http = http;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['id', 'country', 'create_date', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        this.loadData(); //       this.loadAllUsers();
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      DeleteCountry(cid) {
        this.isLoadingResults = true;
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].apiUrl_base) + '/country/DeleteCountry/' + cid).subscribe(datar => {
          this.isLoadingResults = false;
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
            this.refresh();
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      refresh() {
        this.loadData();
      }

      refreshTable() {
        // Refreshing table using paginator
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    CountriesComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"])], CountriesComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"])], CountriesComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], CountriesComponent.prototype, "filter", void 0);
    CountriesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-countries',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./countries.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/countries/countries.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./countries.component.scss */
      "./src/app/countries/countries.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], CountriesComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_9__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.countriesDataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getCountries();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.countriesData.slice().filter(countries => {
            const searchStr = (countries.id + countries.country + countries.create_date).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'id':
              [propertyA, propertyB] = [a.id, b.id];
              break;

            case 'country':
              [propertyA, propertyB] = [a.country, b.country];
              break;

            case 'create_date':
              [propertyA, propertyB] = [a.create_date, b.create_date];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'desc' ? 1 : -1);
        });
      }

    }
    /***/

  },

  /***/
  "./src/app/currencies-add/currencies-add.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/currencies-add/currencies-add.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCurrenciesAddCurrenciesAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1cnJlbmNpZXMtYWRkL2N1cnJlbmNpZXMtYWRkLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/currencies-add/currencies-add.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/currencies-add/currencies-add.component.ts ***!
    \************************************************************/

  /*! exports provided: CurrenciesAddComponent */

  /***/
  function srcAppCurrenciesAddCurrenciesAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CurrenciesAddComponent", function () {
      return CurrenciesAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CurrenciesAddComponent = class CurrenciesAddComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.currency_name = '';
        this.import_value = '';
        this.export_value = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.currenciesForm = this.formBuilder.group({
          'currency_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'import_value': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'export_value': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/currency/currenciesadd/', form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record  Successfully inserted";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/currencies']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

    };

    CurrenciesAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    CurrenciesAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-currencies-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./currencies-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/currencies-add/currencies-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./currencies-add.component.scss */
      "./src/app/currencies-add/currencies-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], CurrenciesAddComponent);
    /***/
  },

  /***/
  "./src/app/currencies-edit/currencies-edit.component.scss":
  /*!****************************************************************!*\
    !*** ./src/app/currencies-edit/currencies-edit.component.scss ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCurrenciesEditCurrenciesEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1cnJlbmNpZXMtZWRpdC9jdXJyZW5jaWVzLWVkaXQuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/currencies-edit/currencies-edit.component.ts":
  /*!**************************************************************!*\
    !*** ./src/app/currencies-edit/currencies-edit.component.ts ***!
    \**************************************************************/

  /*! exports provided: CurrenciesEditComponent */

  /***/
  function srcAppCurrenciesEditCurrenciesEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CurrenciesEditComponent", function () {
      return CurrenciesEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CurrenciesEditComponent = class CurrenciesEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.currency_name = '';
        this.import_value = '';
        this.export_value = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getcurrenciesDetails(this.route.snapshot.params['id']);
        this.currenciesForm = this.formBuilder.group({
          'currency_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'import_value': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'export_value': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        let cid = this.route.snapshot.params['id'];
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/currency/currenciesUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record  Successfully Updated";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/currencies']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      } // get currencies details


      getcurrenciesDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/currency/getcurrency/' + cNo).subscribe(dataaa => {
          this.currenciesForm.setValue({
            currency_name: dataaa[0].currency_name,
            import_value: dataaa[0].import_value,
            export_value: dataaa[0].export_value
          });
        });
      }

    };

    CurrenciesEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    CurrenciesEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-currencies-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./currencies-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/currencies-edit/currencies-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./currencies-edit.component.scss */
      "./src/app/currencies-edit/currencies-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], CurrenciesEditComponent);
    /***/
  },

  /***/
  "./src/app/currencies/currencies.component.scss":
  /*!******************************************************!*\
    !*** ./src/app/currencies/currencies.component.scss ***!
    \******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCurrenciesCurrenciesComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  float: left;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VycmVuY2llcy9EOlxcUHJvamVjdHNcXGd2a2FkbWluLWZyb250ZW5kL3NyY1xcYXBwXFxjdXJyZW5jaWVzXFxjdXJyZW5jaWVzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jdXJyZW5jaWVzL2N1cnJlbmNpZXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURBQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7QUNHSjs7QUREQztFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7QUNJRDs7QURGRTtFQUNFLCtCQUFBO0VBQ0gsbUJBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7QUNLRDs7QURIQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtBQ01BOztBREpBO0VBQ0UscUJBQUE7RUFDRSxXQUFBO0VBQ0gsZ0JBQUE7QUNPRDs7QURMQTtFQUNBLFVBQUE7QUNRQTs7QUROQTtFQUNBLFVBQUE7QUNTQTs7QURQQTtFQUNBLHlCQUFBO0FDVUE7O0FEUkE7RUFDQSxpQkFBQTtBQ1dBOztBRFRBO0VBQ0Esb0JBQUE7QUNZQTs7QURWQTtFQUNBLFdBQUE7QUNhQSIsImZpbGUiOiJzcmMvYXBwL2N1cnJlbmNpZXMvY3VycmVuY2llcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtaGVhZGVyLWNlbGwge1xyXG4gICAgbWluLXdpZHRoOiAxMDBweDtcclxufVxyXG4ubWF0LWNlbGwubmctc3Rhci1pbnNlcnRlZCB7XHJcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG59XHJcbi5tYXQtdGFibGUge1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBvdmVyZmxvdy14OiBhdXRvO1xyXG59XHJcbiBtYXQtaGVhZGVyLWNlbGx7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2U5ZjhmZjtcclxuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcclxufVxyXG4gIG1hdC1jZWxsICwgbWF0LWhlYWRlci1jZWxse1xyXG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlOTtcclxuXHRhbGlnbi1zZWxmOiBzdHJldGNoO1x0XHJcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XHJcblx0cGFkZGluZzowIDhweDtcclxufVxyXG4udXBsb2FkLWYubmctc3Rhci1pbnNlcnRlZHtcclxuZGlzcGxheTpmbGV4O1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwICwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcblx0bWFyZ2luLWJvdHRvbTowO1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3Vwe1xyXG53aWR0aDo3NSU7XHJcbn1cclxuLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbndpZHRoOjI1JTtcclxufVxyXG4ubWF0LXRhYmxle1xyXG5ib3JkZXI6IDFweCBzb2xpZCAjZThlOGU5O1xyXG59XHJcbi51cGxvYWQtYnRue1xyXG50ZXh0LWFsaWduOnJpZ2h0O1xyXG59XHJcbi50b3AtYnRucyAuYnRue1xyXG5tYXJnaW46MCA1cHggMTBweCAwO1xyXG59XHJcbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvd3tcclxuYm9yZGVyOjBweFxyXG59IiwiLm1hdC1oZWFkZXItY2VsbCB7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG5cbi5tYXQtY2VsbC5uZy1zdGFyLWluc2VydGVkIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBvdmVyZmxvdy14OiBhdXRvO1xufVxuXG5tYXQtaGVhZGVyLWNlbGwge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxubWF0LWNlbGwsIG1hdC1oZWFkZXItY2VsbCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XG4gIGFsaWduLXNlbGY6IHN0cmV0Y2g7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xuICBwYWRkaW5nOiAwIDhweDtcbn1cblxuLnVwbG9hZC1mLm5nLXN0YXItaW5zZXJ0ZWQge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tYm90dG9tOiAwO1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCB7XG4gIHdpZHRoOiA3NSU7XG59XG5cbi5pbXBvcnQtc2VjIC51cGxvYWQtYnRuIHtcbiAgd2lkdGg6IDI1JTtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XG59XG5cbi51cGxvYWQtYnRuIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbi50b3AtYnRucyAuYnRuIHtcbiAgbWFyZ2luOiAwIDVweCAxMHB4IDA7XG59XG5cbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvdyB7XG4gIGJvcmRlcjogMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/currencies/currencies.component.ts":
  /*!****************************************************!*\
    !*** ./src/app/currencies/currencies.component.ts ***!
    \****************************************************/

  /*! exports provided: CurrenciesComponent, ExampleDataSource */

  /***/
  function srcAppCurrenciesCurrenciesComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CurrenciesComponent", function () {
      return CurrenciesComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    let CurrenciesComponent = class CurrenciesComponent {
      constructor(authenticationService, userService, httpClient, dialog, http, dataService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.http = http;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['id', 'currency_name', 'import_value', 'export_value', 'create_date', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        this.loadData(); //       this.loadAllUsers();
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      deleteCurrency(cid) {
        this.isLoadingResults = true;
        this.http.delete('http://localhost:3000/api/deletecurrencies/' + cid).subscribe(datar => {
          this.isLoadingResults = false;
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
            this.refresh();
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      refresh() {
        this.loadData();
      }

      refreshTable() {
        // Refreshing table using paginator
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    CurrenciesComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"])], CurrenciesComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"])], CurrenciesComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], CurrenciesComponent.prototype, "filter", void 0);
    CurrenciesComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-currencies',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./currencies.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/currencies/currencies.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./currencies.component.scss */
      "./src/app/currencies/currencies.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], CurrenciesComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_9__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.currencyDataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getCurrency();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.currencyData.slice().filter(currency => {
            const searchStr = (currency.id + currency.currency_name + currency.create_date).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'id':
              [propertyA, propertyB] = [a.id, b.id];
              break;

            case 'currency_name':
              [propertyA, propertyB] = [a.currency_name, b.currency_name];
              break;

            case 'import_value':
              [propertyA, propertyB] = [a.import_value, b.import_value];
              break;

            case 'create_date':
              [propertyA, propertyB] = [a.create_date, b.create_date];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'desc' ? 1 : -1);
        });
      }

    }
    /***/

  },

  /***/
  "./src/app/custom-holidays/custom-holidays.component.scss":
  /*!****************************************************************!*\
    !*** ./src/app/custom-holidays/custom-holidays.component.scss ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCustomHolidaysCustomHolidaysComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-form-field {\n  display: block;\n  position: relative;\n  text-align: left;\n  margin-left: 5%;\n  width: 90%;\n}\n\n.button-row {\n  margin-left: 5%;\n}\n\nh2.title-h2 {\n  margin: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VzdG9tLWhvbGlkYXlzL0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXGN1c3RvbS1ob2xpZGF5c1xcY3VzdG9tLWhvbGlkYXlzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jdXN0b20taG9saWRheXMvY3VzdG9tLWhvbGlkYXlzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQ0NKOztBRENBO0VBQ0ksZUFBQTtBQ0VKOztBREFBO0VBQ0ksWUFBQTtBQ0dKIiwiZmlsZSI6InNyYy9hcHAvY3VzdG9tLWhvbGlkYXlzL2N1c3RvbS1ob2xpZGF5cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICB3aWR0aDogOTAlO1xyXG59XHJcbi5idXR0b24tcm93IHtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxufVxyXG5oMi50aXRsZS1oMiB7XHJcbiAgICBtYXJnaW46IDUwcHg7XHJcbn0iLCIubWF0LWZvcm0tZmllbGQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIHdpZHRoOiA5MCU7XG59XG5cbi5idXR0b24tcm93IHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xufVxuXG5oMi50aXRsZS1oMiB7XG4gIG1hcmdpbjogNTBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/custom-holidays/custom-holidays.component.ts":
  /*!**************************************************************!*\
    !*** ./src/app/custom-holidays/custom-holidays.component.ts ***!
    \**************************************************************/

  /*! exports provided: CustomHolidaysComponent */

  /***/
  function srcAppCustomHolidaysCustomHolidaysComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomHolidaysComponent", function () {
      return CustomHolidaysComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let CustomHolidaysComponent = class CustomHolidaysComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.page_name = '';
        this.page_description = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getpageDetails(1);
        this.settingForm = this.formBuilder.group({
          'page_description': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        let cid = 1;
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/settings/pageUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/custom-holidays']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      getpageDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/settings/pagedetails/' + cNo).subscribe(dataaa => {
          this.settingForm.setValue({
            page_description: dataaa[0].page_description
          });
        });
      }

    };

    CustomHolidaysComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    CustomHolidaysComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-custom-holidays',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./custom-holidays.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/custom-holidays/custom-holidays.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./custom-holidays.component.scss */
      "./src/app/custom-holidays/custom-holidays.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], CustomHolidaysComponent);
    /***/
  },

  /***/
  "./src/app/dialogs/add/add.dialog.component.ts":
  /*!*****************************************************!*\
    !*** ./src/app/dialogs/add/add.dialog.component.ts ***!
    \*****************************************************/

  /*! exports provided: AddDialogComponent */

  /***/
  function srcAppDialogsAddAddDialogComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddDialogComponent", function () {
      return AddDialogComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _models_issue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../models/issue */
    "./src/app/models/issue.ts");

    let AddDialogComponent = class AddDialogComponent {
      constructor(dialogRef, data, dataService) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.dataService = dataService;
        this.formControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required // Validators.email,
        ]);
      }

      getErrorMessage() {
        return this.formControl.hasError('required') ? 'Required field' : this.formControl.hasError('email') ? 'Not a valid email' : '';
      }

      submit() {// emppty stuff
      }

      onNoClick() {
        this.dialogRef.close();
      }

      confirmAdd() {
        this.dataService.addIssue(this.data);
      }

    };

    AddDialogComponent.ctorParameters = () => [{
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]
    }, {
      type: _models_issue__WEBPACK_IMPORTED_MODULE_5__["Issue"],
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"],
        args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"]]
      }]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    AddDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-add.dialog',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!../../dialogs/add/add.dialog.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/add/add.dialog.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ../../dialogs/add/add.dialog.css */
      "./src/app/dialogs/add/add.dialog.css")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], _models_issue__WEBPACK_IMPORTED_MODULE_5__["Issue"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], AddDialogComponent);
    /***/
  },

  /***/
  "./src/app/dialogs/add/add.dialog.css":
  /*!********************************************!*\
    !*** ./src/app/dialogs/add/add.dialog.css ***!
    \********************************************/

  /*! exports provided: default */

  /***/
  function srcAppDialogsAddAddDialogCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".container {\r\n  display: -webkit-box;\r\n  display: flex;\r\n  -webkit-box-orient: vertical;\r\n  -webkit-box-direction: normal;\r\n          flex-direction: column;\r\n  min-width: 450px;\r\n}\r\n\r\n.container > * {\r\n  width: 100%;\r\n}\r\n\r\n.form {\r\n  display: -webkit-box;\r\n  display: flex;\r\n  padding-top: 6px;\r\n}\r\n\r\n.mat-form-field {\r\n  font-size: 16px;\r\n  -webkit-box-flex: 1;\r\n          flex-grow: 1;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGlhbG9ncy9hZGQvYWRkLmRpYWxvZy5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBYTtFQUFiLGFBQWE7RUFDYiw0QkFBc0I7RUFBdEIsNkJBQXNCO1VBQXRCLHNCQUFzQjtFQUN0QixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxXQUFXO0FBQ2I7O0FBRUE7RUFDRSxvQkFBYTtFQUFiLGFBQWE7RUFDYixnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsbUJBQVk7VUFBWixZQUFZO0FBQ2QiLCJmaWxlIjoic3JjL2FwcC9kaWFsb2dzL2FkZC9hZGQuZGlhbG9nLmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBtaW4td2lkdGg6IDQ1MHB4O1xyXG59XHJcblxyXG4uY29udGFpbmVyID4gKiB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5mb3JtIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIHBhZGRpbmctdG9wOiA2cHg7XHJcbn1cclxuXHJcbi5tYXQtZm9ybS1maWVsZCB7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGZsZXgtZ3JvdzogMTtcclxufVxyXG4iXX0= */";
    /***/
  },

  /***/
  "./src/app/dialogs/delete/delete.dialog.component.ts":
  /*!***********************************************************!*\
    !*** ./src/app/dialogs/delete/delete.dialog.component.ts ***!
    \***********************************************************/

  /*! exports provided: DeleteDialogComponent */

  /***/
  function srcAppDialogsDeleteDeleteDialogComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DeleteDialogComponent", function () {
      return DeleteDialogComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../services/data.service */
    "./src/app/services/data.service.ts");

    let DeleteDialogComponent = class DeleteDialogComponent {
      constructor(dialogRef, data, dataService) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.dataService = dataService;
      }

      onNoClick() {
        this.dialogRef.close();
      }

    };

    DeleteDialogComponent.ctorParameters = () => [{
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"],
        args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"]]
      }]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    DeleteDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-delete.dialog',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!../../dialogs/delete/delete.dialog.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/delete/delete.dialog.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ../../dialogs/delete/delete.dialog.css */
      "./src/app/dialogs/delete/delete.dialog.css")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object, _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], DeleteDialogComponent);
    /***/
  },

  /***/
  "./src/app/dialogs/delete/delete.dialog.css":
  /*!**************************************************!*\
    !*** ./src/app/dialogs/delete/delete.dialog.css ***!
    \**************************************************/

  /*! exports provided: default */

  /***/
  function srcAppDialogsDeleteDeleteDialogCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".container {\r\n  display: -webkit-box;\r\n  display: flex;\r\n  -webkit-box-orient: vertical;\r\n  -webkit-box-direction: normal;\r\n          flex-direction: column;\r\n}\r\n\r\n.container > * {\r\n  width: 100%;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGlhbG9ncy9kZWxldGUvZGVsZXRlLmRpYWxvZy5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxvQkFBYTtFQUFiLGFBQWE7RUFDYiw0QkFBc0I7RUFBdEIsNkJBQXNCO1VBQXRCLHNCQUFzQjtBQUN4Qjs7QUFFQTtFQUNFLFdBQVc7QUFDYiIsImZpbGUiOiJzcmMvYXBwL2RpYWxvZ3MvZGVsZXRlL2RlbGV0ZS5kaWFsb2cuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG4uY29udGFpbmVyID4gKiB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbn1cclxuIl19 */";
    /***/
  },

  /***/
  "./src/app/dialogs/edit/edit.dialog.component.ts":
  /*!*******************************************************!*\
    !*** ./src/app/dialogs/edit/edit.dialog.component.ts ***!
    \*******************************************************/

  /*! exports provided: EditDialogComponent */

  /***/
  function srcAppDialogsEditEditDialogComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "EditDialogComponent", function () {
      return EditDialogComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");

    let EditDialogComponent = class EditDialogComponent {
      constructor(dialogRef, data, dataService) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.dataService = dataService;
        this.formControl = new _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required // Validators.email,
        ]);
      }

      getErrorMessage() {
        return this.formControl.hasError('required') ? 'Required field' : this.formControl.hasError('email') ? 'Not a valid email' : '';
      }

      submit() {// emppty stuff
      }

      onNoClick() {
        this.dialogRef.close();
      }

      stopEdit() {
        this.dataService.updateIssue(this.data);
      }

    };

    EditDialogComponent.ctorParameters = () => [{
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"]
    }, {
      type: undefined,
      decorators: [{
        type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"],
        args: [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"]]
      }]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    EditDialogComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-baza.dialog',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!../../dialogs/edit/edit.dialog.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/dialogs/edit/edit.dialog.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ../../dialogs/edit/edit.dialog.css */
      "./src/app/dialogs/edit/edit.dialog.css")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__param"](1, Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Inject"])(_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MAT_DIALOG_DATA"])), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_material_dialog__WEBPACK_IMPORTED_MODULE_1__["MatDialogRef"], Object, _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], EditDialogComponent);
    /***/
  },

  /***/
  "./src/app/dialogs/edit/edit.dialog.css":
  /*!**********************************************!*\
    !*** ./src/app/dialogs/edit/edit.dialog.css ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppDialogsEditEditDialogCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".container {\r\n  display: -webkit-box;\r\n  display: flex;\r\n  -webkit-box-orient: vertical;\r\n  -webkit-box-direction: normal;\r\n          flex-direction: column;\r\n  min-width: 450px;\r\n}\r\n\r\n.container > * {\r\n  width: 100%;\r\n}\r\n\r\n.form {\r\n  display: -webkit-box;\r\n  display: flex;\r\n  padding-top: 6px;\r\n}\r\n\r\n.mat-form-field {\r\n  font-size: 16px;\r\n  -webkit-box-flex: 1;\r\n          flex-grow: 1;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGlhbG9ncy9lZGl0L2VkaXQuZGlhbG9nLmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLG9CQUFhO0VBQWIsYUFBYTtFQUNiLDRCQUFzQjtFQUF0Qiw2QkFBc0I7VUFBdEIsc0JBQXNCO0VBQ3RCLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLFdBQVc7QUFDYjs7QUFFQTtFQUNFLG9CQUFhO0VBQWIsYUFBYTtFQUNiLGdCQUFnQjtBQUNsQjs7QUFFQTtFQUNFLGVBQWU7RUFDZixtQkFBWTtVQUFaLFlBQVk7QUFDZCIsImZpbGUiOiJzcmMvYXBwL2RpYWxvZ3MvZWRpdC9lZGl0LmRpYWxvZy5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgbWluLXdpZHRoOiA0NTBweDtcclxufVxyXG5cclxuLmNvbnRhaW5lciA+ICoge1xyXG4gIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uZm9ybSB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBwYWRkaW5nLXRvcDogNnB4O1xyXG59XHJcblxyXG4ubWF0LWZvcm0tZmllbGQge1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBmbGV4LWdyb3c6IDE7XHJcbn1cclxuIl19 */";
    /***/
  },

  /***/
  "./src/app/export-record-add/export-record-add.component.scss":
  /*!********************************************************************!*\
    !*** ./src/app/export-record-add/export-record-add.component.scss ***!
    \********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppExportRecordAddExportRecordAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-form-field {\n  display: block;\n  position: relative;\n  text-align: left;\n  margin-left: 5%;\n  width: 40%;\n}\n\n.button-row {\n  margin-left: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXhwb3J0LXJlY29yZC1hZGQvRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcZXhwb3J0LXJlY29yZC1hZGRcXGV4cG9ydC1yZWNvcmQtYWRkLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9leHBvcnQtcmVjb3JkLWFkZC9leHBvcnQtcmVjb3JkLWFkZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7QUNDSjs7QURDQTtFQUNJLGVBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL2V4cG9ydC1yZWNvcmQtYWRkL2V4cG9ydC1yZWNvcmQtYWRkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hdC1mb3JtLWZpZWxkIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIHdpZHRoOiA0MCU7XHJcbn1cclxuLmJ1dHRvbi1yb3cge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG59XHJcbiIsIi5tYXQtZm9ybS1maWVsZCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgd2lkdGg6IDQwJTtcbn1cblxuLmJ1dHRvbi1yb3cge1xuICBtYXJnaW4tbGVmdDogNSU7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/export-record-add/export-record-add.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/export-record-add/export-record-add.component.ts ***!
    \******************************************************************/

  /*! exports provided: ExportRecordAddComponent */

  /***/
  function srcAppExportRecordAddExportRecordAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExportRecordAddComponent", function () {
      return ExportRecordAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! moment/moment.js */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment_moment_js__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let ExportRecordAddComponent = class ExportRecordAddComponent {
      constructor(router, api, formBuilder, http) {
        this.router = router;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.yesnos = [{
          value: 'YES',
          viewValue: 'YES'
        }, {
          value: 'NO',
          viewValue: 'NO'
        }];
        this.bsononbsos = [{
          value: 'BSO',
          viewValue: 'BSO'
        }, {
          value: 'NON-BSO',
          viewValue: 'NON-BSO'
        }];
        this.carriers = [{
          value: 'FedEx',
          viewValue: 'FedEx'
        }, {
          value: 'DHL',
          viewValue: 'DHL'
        }, {
          value: 'UPS',
          viewValue: 'UPS'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }];
        this.contracts = [{
          value: 'FTE',
          viewValue: 'FTE'
        }, {
          value: 'FFS',
          viewValue: 'FFS'
        }, {
          value: 'MFG',
          viewValue: 'MFG'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }];
        this.ZoneSalesDistricts = [{
          value: 'US',
          viewValue: 'US'
        }, {
          value: 'APAC',
          viewValue: 'APAC'
        }, {
          value: 'EUR',
          viewValue: 'EUR'
        }, {
          value: 'ME',
          viewValue: 'ME'
        }];
        this.Unitofmeasures = [{
          value: 'mg',
          viewValue: 'mg'
        }, {
          value: 'ml',
          viewValue: 'ml'
        }, {
          value: 'g',
          viewValue: 'g'
        }, {
          value: 'kg',
          viewValue: 'kg'
        }, {
          value: 'L',
          viewValue: 'L'
        }];
        this.sbulocations = [{
          value: 'BLR',
          viewValue: 'BLR'
        }, {
          value: 'NRM',
          viewValue: 'NRM'
        }, {
          value: 'MPR',
          viewValue: 'MPR'
        }];
        this.packagesizes = [{
          value: 'Small - 25x20x22 cm',
          viewValue: 'Small - 25x20x22 cm'
        }, {
          value: 'Medium - 27x28x33 cm',
          viewValue: 'Medium - 27x28x33 cm'
        }, {
          value: 'Large - 32x33x41 cms',
          viewValue: 'Large - 32x33x41 cms'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }];
        this.storageconditions = [{
          value: '-20 to -80 Degrees Celsius',
          viewValue: '-20 to -80 Degrees Celsius'
        }, {
          value: '1.5 Kg Dry Ice',
          viewValue: '1.5 Kg Dry Ice'
        }, {
          value: '2 to 8 Degrees Celsius',
          viewValue: '2 to 8 Degrees Celsius'
        }, {
          value: 'Ambient',
          viewValue: 'Ambient'
        }, {
          value: 'Gel Packs',
          viewValue: 'Gel Packs'
        }, {
          value: 'Liquid Nitrogen',
          viewValue: 'Liquid Nitrogen'
        }];
        this.statusData = [{
          value: 'Pickup',
          viewValue: 'Pickup'
        }, {
          value: 'Departure',
          viewValue: 'Departure'
        }, {
          value: 'Arrival',
          viewValue: 'Arrival'
        }, {
          value: 'Delivery',
          viewValue: 'Delivery'
        }];
        this.SBU_location = '';
        this.Compound_DM_Time = '';
        this.CR_DM_Date = '';
        this.Clearance_BSO_NON_BSO = '';
        this.Carrier = '';
        this.Contract = '';
        this.SOLD_TO = '';
        this.SHIP_TO = '';
        this.Destination = '';
        this.Zone_Sales_District = '';
        this.Description = '';
        this.QTY = '';
        this.SAP_Ref_No = '';
        this.Invoice_No = '';
        this.Invoice_Date = '';
        this.Clearance_charges = '';
        this.Carrier_Bill_Freight_charges = '';
        this.Tracking_No = '';
        this.Date = '';
        this.Shipment_Day_of_pick_up = '';
        this.Departure_from_India = '';
        this.Landing_Destination_Port = '';
        this.Destination_Customs_release_date = '';
        this.Date_of_Delivery_to_client = '';
        this.No_of_days_Door_to_Port = '';
        this.No_of_days_Door_to_Door = '';
        this.Remarks = '';
        this.HS_Code_No = '';
        this.No_of_Boxes = '';
        this.Gr_Wt = '';
        this.Unit_of_measure = '';
        this.Package_Size = '';
        this.Storage_Conditions = '';
        this.Net_Wt = '';
        this.UOM = '';
        this.Currency = '';
        this.Invoice_Value = '';
        this.Value_in_INR = '';
        this.FOB_Value = '';
        this.Shipping_Bill_Number = '';
        this.Shipping_Bill_Date = '';
        this.MAWB = '';
        this.HAWB = '';
        this.LEO_No = '';
        this.LEO_Date = '';
        this.SB_original_Date_of_receipt = '';
        this.uploaded_finance_Share = '';
        this.customerID = '';
        this.Status = '';
        this.isLoadingResults = false;
        this.Message = '';
      }

      ngOnInit() {
        this.currencyButton();
        this.NDDDdays = 0;
        this.NDPdays = 0;
        this.inrvalue = 0;
        this.exportForm = this.formBuilder.group({
          'SBU_location': [null],
          'Compound_DM_Time': [null],
          'CR_DM_Date': [null],
          'Clearance_BSO_NON_BSO': [null],
          'Carrier': [null],
          'Contract': [null],
          'SOLD_TO': [null],
          'SHIP_TO': [null],
          'Destination': [null],
          'Zone_Sales_District': [null],
          'Description': [null],
          'QTY': [null],
          'SAP_Ref_No': [null],
          'Invoice_No': [null],
          'Invoice_Date': [null],
          'Clearance_charges': [null],
          'Carrier_Bill_Freight_charges': [null],
          'Tracking_No': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'Date': [null],
          'Shipment_Day_of_pick_up': [null],
          'Departure_from_India': [null],
          'Landing_Destination_Port': [null],
          'Destination_Customs_release_date': [null],
          'Date_of_Delivery_to_client': [null],
          'No_of_days_Door_to_Port': [null],
          'No_of_days_Door_to_Door': [null],
          'Remarks': [null],
          'HS_Code_No': [null],
          'No_of_Boxes': [null],
          'Gr_Wt': [null],
          'Unit_of_measure': [null],
          'Package_Size': [null],
          'Storage_Conditions': [null],
          'Net_Wt': [null],
          'UOM': [null],
          'Currency': [null],
          'Invoice_Value': [null],
          'Value_in_INR': [null],
          'FOB_Value': [null],
          'Shipping_Bill_Number': [null],
          'Shipping_Bill_Date': [null],
          'MAWB': [null],
          'HAWB': [null],
          'LEO_No': [null],
          'LEO_Date': [null],
          'SB_original_Date_of_receipt': [null],
          'uploaded_finance_Share': [null],
          'customerID': [null],
          'Status': [null]
        });
      }

      onFormSubmit(form) {
        this.save({
          SBU_location: form.SBU_location ? form.SBU_location : '',
          Compound_DM_Time: form.Compound_DM_Time ? form.Compound_DM_Time : '',
          CR_DM_Date: form.CR_DM_Date ? form.CR_DM_Date : '',
          Clearance_BSO_NON_BSO: form.Clearance_BSO_NON_BSO ? form.Clearance_BSO_NON_BSO : '',
          Carrier: form.Carrier ? form.Carrier : '',
          Contract: form.Contract ? form.Contract : '',
          SOLD_TO: form.SOLD_TO ? form.SOLD_TO : '',
          SHIP_TO: form.SHIP_TO ? form.SHIP_TO : '',
          Destination: form.Destination ? form.Destination : '',
          Zone_Sales_District: form.Zone_Sales_District ? form.Zone_Sales_District : '',
          Description: form.Description ? form.Description : '',
          QTY: form.QTY ? form.QTY : '',
          SAP_Ref_No: form.SAP_Ref_No ? form.SAP_Ref_No : '',
          Invoice_No: form.Invoice_No ? form.Invoice_No : '',
          Invoice_Date: form.Invoice_Date ? form.Invoice_Date : '',
          Clearance_charges: form.Clearance_charges ? form.Clearance_charges : '',
          Carrier_Bill_Freight_charges: form.Carrier_Bill_Freight_charges ? form.Carrier_Bill_Freight_charges : '',
          Tracking_No: form.Tracking_No ? form.Tracking_No : '',
          Date: form.Date ? form.Date : '',
          Shipment_Day_of_pick_up: form.Shipment_Day_of_pick_up ? form.Shipment_Day_of_pick_up : '',
          Departure_from_India: form.Departure_from_India ? form.Departure_from_India : '',
          Landing_Destination_Port: form.Landing_Destination_Port ? form.Landing_Destination_Port : '',
          Destination_Customs_release_date: form.Destination_Customs_release_date ? form.Destination_Customs_release_date : '',
          Date_of_Delivery_to_client: form.Date_of_Delivery_to_client ? form.Date_of_Delivery_to_client : '',
          No_of_days_Door_to_Port: this.NDPdays ? this.NDPdays : '',
          No_of_days_Door_to_Door: this.NDDDdays ? this.NDDDdays : '',
          Remarks: form.Remarks ? form.Remarks : '',
          HS_Code_No: form.HS_Code_No ? form.HS_Code_No : '',
          No_of_Boxes: form.No_of_Boxes ? form.No_of_Boxes : '',
          Gr_Wt: form.Gr_Wt ? form.Gr_Wt : '',
          Unit_of_measure: form.Unit_of_measure ? form.Unit_of_measure : '',
          Package_Size: form.Package_Size ? form.Package_Size : '',
          Storage_Conditions: form.Storage_Conditions ? form.Storage_Conditions : '',
          Net_Wt: form.Net_Wt ? form.Net_Wt : '',
          UOM: form.UOM ? form.UOM : '',
          Currency: form.Currency ? form.Currency : '',
          Invoice_Value: form.Invoice_Value ? form.Invoice_Value : '',
          Value_in_INR: this.inrvalue ? this.inrvalue : '',
          FOB_Value: form.FOB_Value ? form.FOB_Value : '',
          Shipping_Bill_Number: form.Shipping_Bill_Number ? form.Shipping_Bill_Number : '',
          Shipping_Bill_Date: form.Shipping_Bill_Date ? form.Shipping_Bill_Date : '',
          MAWB: form.MAWB ? form.MAWB : '',
          HAWB: form.HAWB ? form.HAWB : '',
          LEO_No: form.LEO_No ? form.LEO_No : '',
          LEO_Date: form.LEO_Date ? form.LEO_Date : '',
          SB_original_Date_of_receipt: form.SB_original_Date_of_receipt ? form.SB_original_Date_of_receipt : '',
          uploaded_finance_Share: form.uploaded_finance_Share ? form.uploaded_finance_Share : '',
          customerID: form.customerID ? form.customerID : '',
          Status: form.Status ? form.Status : ''
        });
      }

      save(formdata) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/export/insertExportShipment/', formdata).subscribe(form => {
          this.Message = "Record Added Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/export-records']);
          }, 1000);
          this.isLoadingResults = false;
        }, err => {
          this.isLoadingResults = false;
        });
      }

      currencyButton() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/currency/currencies/');
        obs.subscribe(currency_Result => {
          this.tempcurrency_Result_Result = currency_Result;
          this.suggest('');
        });
      }

      suggest(currency_name) {
        this.currency_Result = this.tempcurrency_Result_Result.filter(currency => currency.currency_name.toLowerCase().startsWith(currency_name.toLowerCase())).slice(0, 5);
      }

      onChangeDate(event) {
        this.Date_dt = event;
        this.NDPort_val();
        this.NDDD_val();
      }

      onChangeLandingD_port(event) {
        this.LDPdate = event;
        this.NDPort_val();
        this.NDDD_val();
      }

      onChangeDD_to_client(event) {
        this.DoDto_client = event;
        this.NDPort_val();
        this.NDDD_val();
      }

      NDPort_val() {
        if (this.Date_dt && this.LDPdate) {
          let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.Date_dt);
          let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.LDPdate);
          let days = b.diff(a, 'days');

          if (days) {
            this.NDPdays = days;
          } else {
            this.NDPdays = 0;
          }
        } else {
          this.NDPdays = 0;
        }
      }

      NDDD_val() {
        if (this.Date_dt && this.DoDto_client) {
          let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.Date_dt);
          let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.DoDto_client);
          let ndddays = b.diff(a, 'days');

          if (ndddays) {
            this.NDDDdays = ndddays;
          } else {
            this.NDDDdays = 0;
          }
        } else {
          this.NDDDdays = 0;
        }
      }

      getPosts(event) {
        const selectE1 = event;
        this.exportValue = selectE1._element.nativeElement.dataset.somedata;
        this.CalculateInrValue();
      }

      applyFilter(event) {
        this.invoiceValue = event.target.value;
        this.CalculateInrValue();
      }

      CalculateInrValue() {
        if (this.invoiceValue && this.exportValue) {
          this.inrvalue = this.invoiceValue * this.exportValue;
        } else {
          this.inrvalue = 0;
        }
      }

    };

    ExportRecordAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    ExportRecordAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-export-record-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./export-record-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/export-record-add/export-record-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./export-record-add.component.scss */
      "./src/app/export-record-add/export-record-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], ExportRecordAddComponent);
    /***/
  },

  /***/
  "./src/app/export-record-edit/export-record-edit.component.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/export-record-edit/export-record-edit.component.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppExportRecordEditExportRecordEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-form-field {\n  display: block;\n  position: relative;\n  text-align: left;\n  margin-left: 5%;\n  width: 40%;\n}\n\n.button-row {\n  margin-left: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXhwb3J0LXJlY29yZC1lZGl0L0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXGV4cG9ydC1yZWNvcmQtZWRpdFxcZXhwb3J0LXJlY29yZC1lZGl0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9leHBvcnQtcmVjb3JkLWVkaXQvZXhwb3J0LXJlY29yZC1lZGl0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQ0NKOztBRENBO0VBQ0ksZUFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvZXhwb3J0LXJlY29yZC1lZGl0L2V4cG9ydC1yZWNvcmQtZWRpdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICB3aWR0aDogNDAlO1xyXG59XHJcbi5idXR0b24tcm93IHtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxufVxyXG4iLCIubWF0LWZvcm0tZmllbGQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIHdpZHRoOiA0MCU7XG59XG5cbi5idXR0b24tcm93IHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/export-record-edit/export-record-edit.component.ts":
  /*!********************************************************************!*\
    !*** ./src/app/export-record-edit/export-record-edit.component.ts ***!
    \********************************************************************/

  /*! exports provided: ExportRecordEditComponent */

  /***/
  function srcAppExportRecordEditExportRecordEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExportRecordEditComponent", function () {
      return ExportRecordEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! moment/moment.js */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment_moment_js__WEBPACK_IMPORTED_MODULE_7__);

    let ExportRecordEditComponent = class ExportRecordEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.yesnos = [{
          value: 'YES',
          viewValue: 'YES'
        }, {
          value: 'NO',
          viewValue: 'NO'
        }];
        this.bsononbsos = [{
          value: 'BSO',
          viewValue: 'BSO'
        }, {
          value: 'NON-BSO',
          viewValue: 'NON-BSO'
        }];
        this.carriers = [{
          value: 'FedEx',
          viewValue: 'FedEx'
        }, {
          value: 'DHL',
          viewValue: 'DHL'
        }, {
          value: 'UPS',
          viewValue: 'UPS'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }];
        this.contracts = [{
          value: 'FTE',
          viewValue: 'FTE'
        }, {
          value: 'FFS',
          viewValue: 'FFS'
        }, {
          value: 'MFG',
          viewValue: 'MFG'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }];
        this.ZoneSalesDistricts = [{
          value: 'US',
          viewValue: 'US'
        }, {
          value: 'APAC',
          viewValue: 'APAC'
        }, {
          value: 'EUR',
          viewValue: 'EUR'
        }, {
          value: 'ME',
          viewValue: 'ME'
        }];
        this.Unitofmeasures = [{
          value: 'mg',
          viewValue: 'mg'
        }, {
          value: 'ml',
          viewValue: 'ml'
        }, {
          value: 'g',
          viewValue: 'g'
        }, {
          value: 'kg',
          viewValue: 'kg'
        }, {
          value: 'L',
          viewValue: 'L'
        }];
        this.sbulocations = [{
          value: 'BLR',
          viewValue: 'BLR'
        }, {
          value: 'NRM',
          viewValue: 'NRM'
        }, {
          value: 'MPR',
          viewValue: 'MPR'
        }];
        this.packagesizes = [{
          value: 'Small - 25x20x22 cm',
          viewValue: 'Small - 25x20x22 cm'
        }, {
          value: 'Medium - 27x28x33 cm',
          viewValue: 'Medium - 27x28x33 cm'
        }, {
          value: 'Large - 32x33x41 cms',
          viewValue: 'Large - 32x33x41 cms'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }];
        this.storageconditions = [{
          value: '-20 to -80 Degrees Celsius',
          viewValue: '-20 to -80 Degrees Celsius'
        }, {
          value: '1.5 Kg Dry Ice',
          viewValue: '1.5 Kg Dry Ice'
        }, {
          value: '2 to 8 Degrees Celsius',
          viewValue: '2 to 8 Degrees Celsius'
        }, {
          value: 'Ambient',
          viewValue: 'Ambient'
        }, {
          value: 'Gel Packs',
          viewValue: 'Gel Packs'
        }, {
          value: 'Liquid Nitrogen',
          viewValue: 'Liquid Nitrogen'
        }];
        this.statusData = [{
          value: 'Pickup',
          viewValue: 'Pickup'
        }, {
          value: 'Departure',
          viewValue: 'Departure'
        }, {
          value: 'Arrival',
          viewValue: 'Arrival'
        }, {
          value: 'Delivery',
          viewValue: 'Delivery'
        }];
        this.Message = '';
        this.SBU_location = '';
        this.customerID = '';
        this.Compound_DM_Time = '';
        this.CR_DM_Date = '';
        this.Clearance_BSO_NON_BSO = '';
        this.Carrier = '';
        this.Contract = '';
        this.SOLD_TO = '';
        this.SHIP_TO = '';
        this.Destination = '';
        this.Zone_Sales_District = '';
        this.Description = '';
        this.QTY = '';
        this.SAP_Ref_No = '';
        this.Invoice_No = '';
        this.Invoice_Date = '';
        this.Clearance_charges = '';
        this.Carrier_Bill_Freight_charges = '';
        this.Tracking_No = '';
        this.Date = '';
        this.Shipment_Day_of_pick_up = '';
        this.Departure_from_India = '';
        this.Landing_Destination_Port = '';
        this.Destination_Customs_release_date = '';
        this.Date_of_Delivery_to_client = '';
        this.No_of_days_Door_to_Port = '';
        this.No_of_days_Door_to_Door = '';
        this.Remarks = '';
        this.HS_Code_No = '';
        this.No_of_Boxes = '';
        this.Gr_Wt = '';
        this.Unit_of_measure = '';
        this.Package_Size = '';
        this.Storage_Conditions = '';
        this.Net_Wt = '';
        this.UOM = '';
        this.Currency = '';
        this.Invoice_Value = '';
        this.Value_in_INR = '';
        this.FOB_Value = '';
        this.Shipping_Bill_Number = '';
        this.Shipping_Bill_Date = '';
        this.MAWB = '';
        this.HAWB = '';
        this.LEO_No = '';
        this.LEO_Date = '';
        this.Status = '';
        this.SB_original_Date_of_receipt = '';
        this.uploaded_finance_Share = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.currencyButton();
        this.NDDDdays = 0;
        this.NDPdays = 0;
        this.inrvalue = 0;
        this.getAwbDetails(this.route.snapshot.params['id']);
        this.exportForm = this.formBuilder.group({
          'SBU_location': [null],
          'Compound_DM_Time': [null],
          'CR_DM_Date': [null],
          'Clearance_BSO_NON_BSO': [null],
          'Carrier': [null],
          'Contract': [null],
          'SOLD_TO': [null],
          'SHIP_TO': [null],
          'Destination': [null],
          'Zone_Sales_District': [null],
          'Description': [null],
          'QTY': [null],
          'SAP_Ref_No': [null],
          'Invoice_No': [null],
          'Invoice_Date': [null],
          'Clearance_charges': [null],
          'Carrier_Bill_Freight_charges': [null],
          'Tracking_No': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'Date': [null],
          'Shipment_Day_of_pick_up': [null],
          'Departure_from_India': [null],
          'Landing_Destination_Port': [null],
          'Destination_Customs_release_date': [null],
          'Date_of_Delivery_to_client': [null],
          'No_of_days_Door_to_Port': [null],
          'No_of_days_Door_to_Door': [null],
          'Remarks': [null],
          'HS_Code_No': [null],
          'No_of_Boxes': [null],
          'Gr_Wt': [null],
          'Unit_of_measure': [null],
          'Package_Size': [null],
          'Storage_Conditions': [null],
          'Net_Wt': [null],
          'UOM': [null],
          'Currency': [null],
          'Invoice_Value': [null],
          'Value_in_INR': [null],
          'FOB_Value': [null],
          'Shipping_Bill_Number': [null],
          'Shipping_Bill_Date': [null],
          'MAWB': [null],
          'HAWB': [null],
          'LEO_No': [null],
          'LEO_Date': [null],
          'SB_original_Date_of_receipt': [null],
          'uploaded_finance_Share': [null],
          'customerID': [null],
          'Status': [null]
        });
      }

      getAwbDetails(AwbNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/export/getexport_shipmentDetails/' + AwbNo).subscribe(dataaa => {
          this.exportForm.setValue({
            Compound_DM_Time: dataaa.response[0].Compound_DM_Time,
            CR_DM_Date: dataaa.response[0].CR_DM_Date,
            Clearance_BSO_NON_BSO: dataaa.response[0].Clearance_BSO_NON_BSO,
            Carrier: dataaa.response[0].Carrier,
            Contract: dataaa.response[0].Contract,
            SOLD_TO: dataaa.response[0].SOLD_TO,
            SHIP_TO: dataaa.response[0].SHIP_TO,
            Destination: dataaa.response[0].Destination,
            Zone_Sales_District: dataaa.response[0].Zone_Sales_District,
            Description: dataaa.response[0].Description,
            QTY: dataaa.response[0].QTY,
            SAP_Ref_No: dataaa.response[0].SAP_Ref_No,
            Invoice_No: dataaa.response[0].Invoice_No,
            Invoice_Date: dataaa.response[0].Invoice_Date,
            Clearance_charges: dataaa.response[0].Clearance_charges,
            Carrier_Bill_Freight_charges: dataaa.response[0].Carrier_Bill_Freight_charges,
            Tracking_No: dataaa.response[0].Tracking_No,
            Date: dataaa.response[0].Date,
            Shipment_Day_of_pick_up: dataaa.response[0].Shipment_Day_of_pick_up,
            Departure_from_India: dataaa.response[0].Departure_from_India,
            Landing_Destination_Port: dataaa.response[0].Landing_Destination_Port,
            Destination_Customs_release_date: dataaa.response[0].Destination_Customs_release_date,
            Date_of_Delivery_to_client: dataaa.response[0].Date_of_Delivery_to_client,
            No_of_days_Door_to_Port: dataaa.response[0].No_of_days_Door_to_Port,
            No_of_days_Door_to_Door: dataaa.response[0].No_of_days_Door_to_Door,
            Remarks: dataaa.response[0].Remarks,
            HS_Code_No: dataaa.response[0].HS_Code_No,
            No_of_Boxes: dataaa.response[0].No_of_Boxes,
            Gr_Wt: dataaa.response[0].Gr_Wt,
            Unit_of_measure: dataaa.response[0].Unit_of_measure,
            Package_Size: dataaa.response[0].Package_Size,
            Storage_Conditions: dataaa.response[0].Storage_Conditions,
            Net_Wt: dataaa.response[0].Net_Wt,
            UOM: dataaa.response[0].UOM,
            Currency: dataaa.response[0].Currency,
            Invoice_Value: dataaa.response[0].Invoice_Value,
            Value_in_INR: dataaa.response[0].Value_in_INR,
            FOB_Value: dataaa.response[0].FOB_Value,
            Shipping_Bill_Number: dataaa.response[0].Shipping_Bill_Number,
            Shipping_Bill_Date: dataaa.response[0].Shipping_Bill_Date,
            MAWB: dataaa.response[0].MAWB,
            HAWB: dataaa.response[0].HAWB,
            LEO_No: dataaa.response[0].LEO_No,
            LEO_Date: dataaa.response[0].LEO_Date,
            SB_original_Date_of_receipt: dataaa.response[0].SB_original_Date_of_receipt,
            SBU_location: dataaa.response[0].SBU_location,
            uploaded_finance_Share: dataaa.response[0].uploaded_finance_Share,
            customerID: dataaa.response[0].customerID,
            Status: dataaa.response[0].Status ? dataaa.response[0].Status : ''
          });
        });
      }

      onFormSubmit(form) {
        let exportId = this.route.snapshot.params['id'];
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/export/export_shipmentsUpdate/' + exportId, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Shipment Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/export-records']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      currencyButton() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/currency/currencies/');
        obs.subscribe(currency_Result => {
          this.tempcurrency_Result_Result = currency_Result;
          this.suggest('');
        });
      }

      suggest(currency_name) {
        this.currency_Result = this.tempcurrency_Result_Result.filter(currency => currency.currency_name.toLowerCase().startsWith(currency_name.toLowerCase())).slice(0, 5);
      }

      onChangeDate(event) {
        this.Date_dt = event;
        this.NDPort_val();
        this.NDDD_val();
      }

      onChangeLandingD_port(event) {
        this.LDPdate = event;
        this.NDPort_val();
        this.NDDD_val();
      }

      onChangeDD_to_client(event) {
        this.DoDto_client = event;
        this.NDPort_val();
        this.NDDD_val();
      }

      NDPort_val() {
        if (this.Date_dt && this.LDPdate) {
          let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.Date_dt);
          let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.LDPdate);
          let days = b.diff(a, 'days');

          if (days) {
            this.NDPdays = days;
          } else {
            this.NDPdays = 0;
          }
        } else {
          this.NDPdays = 0;
        }
      }

      NDDD_val() {
        if (this.Date_dt && this.DoDto_client) {
          let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.Date_dt);
          let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.DoDto_client);
          let ndddays = b.diff(a, 'days');

          if (ndddays) {
            this.NDDDdays = ndddays;
          } else {
            this.NDDDdays = 0;
          }
        } else {
          this.NDDDdays = 0;
        }
      }

      getPosts(event) {
        const selectE1 = event;
        this.exportValue = selectE1._element.nativeElement.dataset.somedata;
        this.CalculateInrValue();
      }

      applyFilter(event) {
        this.invoiceValue = event.target.value;
        this.CalculateInrValue();
      }

      CalculateInrValue() {
        if (this.invoiceValue && this.exportValue) {
          this.inrvalue = this.invoiceValue * this.exportValue;
        } else {
          this.inrvalue = 0;
        }
      }

    };

    ExportRecordEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    ExportRecordEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-export-record-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./export-record-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/export-record-edit/export-record-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./export-record-edit.component.scss */
      "./src/app/export-record-edit/export-record-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], ExportRecordEditComponent);
    /***/
  },

  /***/
  "./src/app/export-records-list/export-records-list.component.scss":
  /*!************************************************************************!*\
    !*** ./src/app/export-records-list/export-records-list.component.scss ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppExportRecordsListExportRecordsListComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  float: left;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXhwb3J0LXJlY29yZHMtbGlzdC9EOlxcUHJvamVjdHNcXGd2a2FkbWluLWZyb250ZW5kL3NyY1xcYXBwXFxleHBvcnQtcmVjb3Jkcy1saXN0XFxleHBvcnQtcmVjb3Jkcy1saXN0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9leHBvcnQtcmVjb3Jkcy1saXN0L2V4cG9ydC1yZWNvcmRzLWxpc3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURBQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7QUNHSjs7QUREQztFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7QUNJRDs7QURGRTtFQUNFLCtCQUFBO0VBQ0gsbUJBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7QUNLRDs7QURIQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtBQ01BOztBREpBO0VBQ0UscUJBQUE7RUFDRSxXQUFBO0VBQ0gsZ0JBQUE7QUNPRDs7QURMQTtFQUNBLFVBQUE7QUNRQTs7QUROQTtFQUNBLFVBQUE7QUNTQTs7QURQQTtFQUNBLHlCQUFBO0FDVUE7O0FEUkE7RUFDQSxpQkFBQTtBQ1dBOztBRFRBO0VBQ0Esb0JBQUE7QUNZQTs7QURWQTtFQUNBLFdBQUE7QUNhQSIsImZpbGUiOiJzcmMvYXBwL2V4cG9ydC1yZWNvcmRzLWxpc3QvZXhwb3J0LXJlY29yZHMtbGlzdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtaGVhZGVyLWNlbGwge1xyXG4gICAgbWluLXdpZHRoOiAxMDBweDtcclxufVxyXG4ubWF0LWNlbGwubmctc3Rhci1pbnNlcnRlZCB7XHJcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG59XHJcbi5tYXQtdGFibGUge1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBvdmVyZmxvdy14OiBhdXRvO1xyXG59XHJcbiBtYXQtaGVhZGVyLWNlbGx7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2U5ZjhmZjtcclxuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcclxufVxyXG4gIG1hdC1jZWxsICwgbWF0LWhlYWRlci1jZWxse1xyXG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlOTtcclxuXHRhbGlnbi1zZWxmOiBzdHJldGNoO1x0XHJcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XHJcblx0cGFkZGluZzowIDhweDtcclxufVxyXG4udXBsb2FkLWYubmctc3Rhci1pbnNlcnRlZHtcclxuZGlzcGxheTpmbGV4O1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwICwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcblx0bWFyZ2luLWJvdHRvbTowO1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3Vwe1xyXG53aWR0aDo3NSU7XHJcbn1cclxuLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbndpZHRoOjI1JTtcclxufVxyXG4ubWF0LXRhYmxle1xyXG5ib3JkZXI6IDFweCBzb2xpZCAjZThlOGU5O1xyXG59XHJcbi51cGxvYWQtYnRue1xyXG50ZXh0LWFsaWduOnJpZ2h0O1xyXG59XHJcbi50b3AtYnRucyAuYnRue1xyXG5tYXJnaW46MCA1cHggMTBweCAwO1xyXG59XHJcbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvd3tcclxuYm9yZGVyOjBweFxyXG59IiwiLm1hdC1oZWFkZXItY2VsbCB7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG5cbi5tYXQtY2VsbC5uZy1zdGFyLWluc2VydGVkIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBvdmVyZmxvdy14OiBhdXRvO1xufVxuXG5tYXQtaGVhZGVyLWNlbGwge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxubWF0LWNlbGwsIG1hdC1oZWFkZXItY2VsbCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XG4gIGFsaWduLXNlbGY6IHN0cmV0Y2g7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xuICBwYWRkaW5nOiAwIDhweDtcbn1cblxuLnVwbG9hZC1mLm5nLXN0YXItaW5zZXJ0ZWQge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tYm90dG9tOiAwO1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCB7XG4gIHdpZHRoOiA3NSU7XG59XG5cbi5pbXBvcnQtc2VjIC51cGxvYWQtYnRuIHtcbiAgd2lkdGg6IDI1JTtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XG59XG5cbi51cGxvYWQtYnRuIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbi50b3AtYnRucyAuYnRuIHtcbiAgbWFyZ2luOiAwIDVweCAxMHB4IDA7XG59XG5cbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvdyB7XG4gIGJvcmRlcjogMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/export-records-list/export-records-list.component.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/export-records-list/export-records-list.component.ts ***!
    \**********************************************************************/

  /*! exports provided: ExportRecordsListComponent */

  /***/
  function srcAppExportRecordsListExportRecordsListComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExportRecordsListComponent", function () {
      return ExportRecordsListComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! xlsx */
    "./node_modules/xlsx/xlsx.js");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var _services_excel_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../services/excel.service */
    "./src/app/services/excel.service.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _dialogs_delete_delete_dialog_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./../dialogs/delete/delete.dialog.component */
    "./src/app/dialogs/delete/delete.dialog.component.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @app/_services/api-services.service */
    "./src/app/_services/api-services.service.ts");

    let ExportRecordsListComponent = class ExportRecordsListComponent {
      constructor(authenticationService, userService, httpClient, http, eleRef, excelService, dialog, dataService, apiService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.http = http;
        this.eleRef = eleRef;
        this.excelService = excelService;
        this.dialog = dialog;
        this.dataService = dataService;
        this.apiService = apiService;
        this.users = [];
        this.displayedColumns = ['id', 'SBU_location', 'Compound_DM_Time', 'CR_DM_Date', 'Clearance_BSO_NON_BSO', 'Carrier', 'SOLD_TO', 'SHIP_TO', 'Contract', 'Destination', 'QTY', 'SAP_Ref_No', 'Invoice_No', 'Invoice_Date', 'Clearance_charges', 'Carrier_Bill_Freight_charges', 'Tracking_No', 'Date', 'Shipment_Day_of_pick_up', 'Departure_from_India', 'Landing_Destination_Port', 'Destination_Customs_release_date', 'Date_of_Delivery_to_client', 'No_of_days_Door_to_Port', 'No_of_days_Door_to_Door', 'Remarks', 'HS_Code_No', 'No_of_Boxes', 'Gr_Wt', 'Unit_of_measure', 'Package_Size', 'Storage_Conditions', 'Net_Wt', 'UOM', 'Currency', 'Invoice_Value', 'Value_in_INR', 'FOB_Value', 'Shipping_Bill_Number', 'Shipping_Bill_Date', 'MAWB', 'HAWB', 'LEO_No', 'LEO_Date', 'SB_original_Date_of_receipt', 'uploaded_finance_Share', 'customerID', 'Status', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.paginateData = {
          pagePer: 10,
          pageNo: 1,
          searchKey: ""
        };
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngOnInit() {
        this.getTableData();
      }

      incomingfile(event) {
        this.file = event.target.files[0];
      }

      Upload() {
        this.isLoadingResults = true;
        let fileReader = new FileReader();

        fileReader.onload = e => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();

          for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);

          var bstr = arr.join("");
          var workbook = xlsx__WEBPACK_IMPORTED_MODULE_3__["read"](bstr, {
            'type': "binary",
            cellDates: true
          });
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          this.output = xlsx__WEBPACK_IMPORTED_MODULE_3__["utils"].sheet_to_json(worksheet, {
            raw: false
          });

          for (let i = 0; i < this.output.length; i++) {
            let object = {
              Date: this.output[i].Date ? new Date("".concat(this.output[i].Date).replace(/-/g, " ")) : '',
              CR_DM_Date: this.output[i].CR_DM_Date ? new Date("".concat(this.output[i].CR_DM_Date).replace(/-/g, " ")) : '',
              Invoice_Date: this.output[i].Invoice_Date ? new Date("".concat(this.output[i].Invoice_Date).replace(/-/g, " ")) : '',
              Departure_from_India: this.output[i].Departure_from_India ? new Date("".concat(this.output[i].Departure_from_India).replace(/-/g, " ")) : '',
              Landing_Destination_Port: this.output[i].Landing_Destination_Port ? new Date("".concat(this.output[i].Landing_Destination_Port).replace(/-/g, " ")) : '',
              Destination_Customs_release_date: this.output[i].Destination_Customs_release_date ? new Date("".concat(this.output[i].Destination_Customs_release_date).replace(/-/g, " ")) : '',
              Date_of_Delivery_to_client: this.output[i].Date_of_Delivery_to_client ? new Date("".concat(this.output[i].Date_of_Delivery_to_client).replace(/-/g, " ")) : '',
              SBU_location: this.output[i].SBU_location ? this.output[i].SBU_location : '',
              Compound_DM_Time: this.output[i].Compound_DM_Time ? this.output[i].Compound_DM_Time : '',
              Clearance_BSO_NON_BSO: this.output[i].Clearance_BSO_NON_BSO ? this.output[i].Clearance_BSO_NON_BSO : '',
              Carrier: this.output[i].Carrier ? this.output[i].Carrier : '',
              Contract: this.output[i].Contract ? this.output[i].Contract : '',
              SOLD_TO: this.output[i].SOLD_TO ? this.output[i].SOLD_TO : '',
              SHIP_TO: this.output[i].SHIP_TO ? this.output[i].SHIP_TO : '',
              Destination: this.output[i].Destination ? this.output[i].Destination : '',
              Zone_Sales_District: this.output[i].Zone_Sales_District ? this.output[i].Zone_Sales_District : '',
              Region: this.output[i].Region ? this.output[i].Region : '',
              Description: this.output[i].Description ? this.output[i].Description : '',
              QTY: this.output[i].QTY ? this.output[i].QTY : '',
              SAP_Ref_No: this.output[i].SAP_Ref_No ? this.output[i].SAP_Ref_No : '',
              Invoice_No: this.output[i].Invoice_No ? this.output[i].Invoice_No : '',
              Clearance_charges: this.output[i].Clearance_charges ? this.output[i].Clearance_charges : '',
              Carrier_Bill_Freight_charges: this.output[i].Carrier_Bill_Freight_charges ? this.output[i].Carrier_Bill_Freight_charges : '',
              Tracking_No: this.output[i].Tracking_No ? this.output[i].Tracking_No : '',
              // Date:new Date(`${this.output[i].Date}`.replace(/-/g, ` `))?this.output[i].Date:'',
              Shipment_Day_of_pick_up: this.output[i].Shipment_Day_of_pick_up ? this.output[i].Shipment_Day_of_pick_up : '',
              No_of_days_Door_to_Port: this.output[i].No_of_days_Door_to_Port ? this.output[i].No_of_days_Door_to_Port : '',
              No_of_days_Door_to_Door: this.output[i].No_of_days_Door_to_Door ? this.output[i].No_of_days_Door_to_Door : '',
              Remarks: this.output[i].Remarks ? this.output[i].Remarks : '',
              HS_Code_No: this.output[i].HS_Code_No ? this.output[i].HS_Code_No : '',
              No_of_Boxes: this.output[i].No_of_Boxes ? this.output[i].No_of_Boxes : '',
              Gr_Wt: this.output[i].Gr_Wt ? this.output[i].Gr_Wt : '',
              Unit_of_measure: this.output[i].Unit_of_measure ? this.output[i].Unit_of_measure : '',
              Package_Size: this.output[i].Package_Size ? this.output[i].Package_Size : '',
              Storage_Conditions: this.output[i].Storage_Conditions ? this.output[i].Storage_Conditions : '',
              Net_Wt: this.output[i].Net_Wt ? this.output[i].Net_Wt : '',
              UOM: this.output[i].UOM ? this.output[i].UOM : '',
              Currency: this.output[i].Currency ? this.output[i].Currency : '',
              Invoice_Value: this.output[i].Invoice_Value ? this.output[i].Invoice_Value : '',
              Value_in_INR: this.output[i].Value_in_INR ? this.output[i].Value_in_INR : '',
              FOB_Value: this.output[i].FOB_Value ? this.output[i].FOB_Value : '',
              Shipping_Bill_Number: this.output[i].Shipping_Bill_Number ? this.output[i].Shipping_Bill_Number : '',
              Shipping_Bill_Date: this.output[i].Shipping_Bill_Date ? this.output[i].Shipping_Bill_Date : '',
              MAWB: this.output[i].MAWB ? this.output[i].MAWB : '',
              HAWB: this.output[i].HAWB ? this.output[i].HAWB : '',
              LEO_No: this.output[i].LEO_No ? this.output[i].LEO_No : '',
              LEO_Date: this.output[i].LEO_Date ? this.output[i].LEO_Date : '',
              SB_original_Date_of_receipt: this.output[i].SB_original_Date_of_receipt ? this.output[i].SB_original_Date_of_receipt : '',
              uploaded_finance_Share: this.output[i].uploaded_finance_Share ? this.output[i].uploaded_finance_Share : '',
              customerID: this.output[i].customerID ? this.output[i].customerID : '',
              Status: this.output[i].Status ? this.output[i].Status : ''
            };
            console.log(object);
            this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].apiUrl_base) + '/export/exportExcelUpdate/', object).subscribe(objectss => {
              var conti = i + 1;
              this.Message = conti + " Shipments Imported";
              var cont = this.output.length - 5;

              if (cont == i) {
                this.Message = "File Successfully Imported";
                this.isLoadingResults = false;
                this.getTableData();
              }
            }, err => {});
          }
        };

        setTimeout(() => {
          this.Message = null;
          let smallBox = this.eleRef.nativeElement.querySelector('#accordionid');
          smallBox.dispatchEvent(new Event('click'));
        }, 1500);
        fileReader.readAsArrayBuffer(this.file);
      }

      deleteExportShipment(cid) {
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].apiUrl_base) + '/export/removeExportShipment/' + cid).subscribe(datar => {
          this.Message = "Record deleted Successfully";
          this.getTableData();
          setTimeout(() => {
            this.Message = null;
          }, 1000);
        }, err => {});
      }

      deleteItem(i, id, Compound_DM_Time, CR_DM_Date, Clearance_BSO_NON_BSO) {
        this.index = i;
        this.id = id;
        const dialogRef = this.dialog.open(_dialogs_delete_delete_dialog_component__WEBPACK_IMPORTED_MODULE_10__["DeleteDialogComponent"], {
          data: {
            id: id,
            Compound_DM_Time: Compound_DM_Time
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 1) {
            const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.id === this.id); // for delete we use splice in order to remove single object from DataService

            this.exampleDatabase.dataChange.value.splice(foundIndex, 1); // this.refreshTable();
          }
        });
      }

      getTableData() {
        this.loader = true;
        this.paginateData.searchKey = this.searchField;
        this.http.post(this.apiService.GET_EXPORT_ALL_SHIPMENTS, this.paginateData).subscribe(data => {
          console.log(data, 214);
          this.exportData = data;
          this.loader = false;
        });
      }

      getPaginatorData(e) {
        this.paginateData = {
          pagePer: e.pageSize,
          pageNo: e.pageIndex + 1,
          searchKey: this.searchField
        };
        window.scroll(0, 0);
        this.getTableData();
      }

      onSubmit() {
        var data = {
          pagePer: 10,
          pageNo: 1
        };
        data['searchKey'] = this.searchField.trim();
        this.loader = true;
        this.http.post(this.apiService.GET_EXPORT_ALL_SHIPMENTS, data).subscribe(data => {
          this.exportData = data;
          this.loader = false;
        });
      }

      exportAsXLSX() {
        this.excelLoader = true;
        this.http.get(this.apiService.GET_TOTAL_EXPORTS_SHIPMENTS).subscribe(data => {
          this.excelService.exportAsExcelFile(data, 'GVK-Import');
          this.excelLoader = false;
        }, err => {
          this.excelLoader = false;
        });
      }

    };

    ExportRecordsListComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]
    }, {
      type: _services_excel_service__WEBPACK_IMPORTED_MODULE_4__["ExcelService"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__["MatDialog"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_5__["DataService"]
    }, {
      type: _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_12__["ApiServicesService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__["MatPaginator"])], ExportRecordsListComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_9__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_9__["MatSort"])], ExportRecordsListComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], ExportRecordsListComponent.prototype, "filter", void 0);
    ExportRecordsListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-export-records-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./export-records-list.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/export-records-list/export-records-list.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./export-records-list.component.scss */
      "./src/app/export-records-list/export-records-list.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"], _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _services_excel_service__WEBPACK_IMPORTED_MODULE_4__["ExcelService"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__["MatDialog"], _services_data_service__WEBPACK_IMPORTED_MODULE_5__["DataService"], _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_12__["ApiServicesService"]])], ExportRecordsListComponent);
    /***/
  },

  /***/
  "./src/app/export-reports/export-reports.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/export-reports/export-reports.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppExportReportsExportReportsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".exp .fil-sec {\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n\n.fil-sec .d-flex .form-control {\n  margin-right: 5px;\n}\n\n.fil-sec .d-flex .form-control:last-child {\n  margin-right: 0;\n}\n\n.exp-sec h4 {\n  background: #e9f8ff;\n  padding: 5px 10px;\n  margin-bottom: 0;\n  text-align: center;\n  font-size: 16px;\n}\n\n.table th, .table td {\n  padding: 5px 6px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZXhwb3J0LXJlcG9ydHMvRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcZXhwb3J0LXJlcG9ydHNcXGV4cG9ydC1yZXBvcnRzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9leHBvcnQtcmVwb3J0cy9leHBvcnQtcmVwb3J0cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQTtFQUNJLGlCQUFBO0FDRUo7O0FEQUU7RUFDRSxlQUFBO0FDR0o7O0FEREE7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNJSjs7QURGQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNLSiIsImZpbGUiOiJzcmMvYXBwL2V4cG9ydC1yZXBvcnRzL2V4cG9ydC1yZXBvcnRzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4cCAuZmlsLXNlY3tcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG59XHJcbi5maWwtc2VjIC5kLWZsZXggLmZvcm0tY29udHJvbHtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gIH1cclxuICAuZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2w6bGFzdC1jaGlsZHtcclxuICAgIG1hcmdpbi1yaWdodDogMDtcclxuICB9XHJcbi5leHAtc2VjIGg0e1xyXG4gICAgYmFja2dyb3VuZDogI2U5ZjhmZjtcclxuICAgIHBhZGRpbmc6IDVweCAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG4udGFibGUgdGgsIC50YWJsZSB0ZCB7XHJcbiAgICBwYWRkaW5nOiA1cHggNnB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcbiIsIi5leHAgLmZpbC1zZWMge1xuICBtYXJnaW4tdG9wOiAxNXB4O1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufVxuXG4uZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2wge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbn1cblxuLmZpbC1zZWMgLmQtZmxleCAuZm9ybS1jb250cm9sOmxhc3QtY2hpbGQge1xuICBtYXJnaW4tcmlnaHQ6IDA7XG59XG5cbi5leHAtc2VjIGg0IHtcbiAgYmFja2dyb3VuZDogI2U5ZjhmZjtcbiAgcGFkZGluZzogNXB4IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4udGFibGUgdGgsIC50YWJsZSB0ZCB7XG4gIHBhZGRpbmc6IDVweCA2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/export-reports/export-reports.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/export-reports/export-reports.component.ts ***!
    \************************************************************/

  /*! exports provided: ExportReportsComponent */

  /***/
  function srcAppExportReportsExportReportsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExportReportsComponent", function () {
      return ExportReportsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @app/_services/api-services.service */
    "./src/app/_services/api-services.service.ts");
    /* harmony import */


    var _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @app/_services/authentication.service */
    "./src/app/_services/authentication.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");

    let ExportReportsComponent = class ExportReportsComponent {
      constructor(http, apiService, authService, fb) {
        this.http = http;
        this.apiService = apiService;
        this.authService = authService;
        this.fb = fb;
        this.bsononbsos = [{
          value: 'BSO',
          viewValue: 'Door to Port'
        }, {
          value: 'Non-BSO',
          viewValue: 'Door to Door'
        }];
        this.submitted = false;
        this.allSelected = false;
        this.countriesFilterData = [];
      }

      ngOnInit() {
        this.getDropDown();
        this.getZonesDropDown();
        this.user = this.authService.currentUserValue;
        this.settings = {
          singleSelection: false,
          enableCheckAll: true,
          allowSearchFilter: true,
          limitSelection: -1,
          clearSearchFilter: true,
          maxHeight: 197,
          itemsShowLimit: 3,
          closeDropDownOnSelection: false,
          showSelectedItemsAtTop: false,
          defaultOpen: false
        };
        this.searchForm = this.fb.group({
          'fromDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
          'toDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
          'carriers': [[]],
          'regions': [[]],
          'Destination': [[]],
          'Clearance_BSO_NON_BSO': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
          'days': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
          'userId': [this.user.id]
        });
      }

      get f() {
        return this.searchForm.controls;
      }

      getImportsReports() {
        const data = {};
        data['userId'] = this.user.id;
        this.http.post(this.apiService.GET_EXPORT_REPORTS, data).subscribe(data => {
          this.exportData = data;
        });
      }

      onSubmit() {
        this.submitted = true;

        if (this.searchForm.invalid) {
          return;
        }

        this.loading = true;
        this.http.post(this.apiService.GET_EXPORT_REPORTS, this.searchForm.value).subscribe(data => {
          this.exportData = data;
          this.getCummulativecount();
        });
      }

      getDropDown() {
        this.http.get(this.apiService.GET_EXPORT_DROPDOWNS).subscribe(data => {
          this.dropDownData = data;
        });
      }

      getZonesDropDown() {
        this.http.get(this.apiService.EXPORT_DROP_DOWN_LIST).subscribe(data => {
          this.zonesData = [];
          data.zones.forEach(obj => {
            this.zonesData.push(obj.Zone_Sales_District);
          });
        });
      }

      getCountries(arr) {
        var data = {
          region: arr
        };
        this.http.post(this.apiService.COUNTRIES_DROP_DOWN, data).subscribe(data => {
          this.countries = [];
          data.counties.forEach(obj => {
            this.countries.push(obj.Destination);
          });
        });
      }

      onItemSelect(item) {
        this.searchForm.patchValue({
          Destination: []
        });
        this.countriesFilterData.push(item);
        this.getCountries(this.countriesFilterData);
      }

      onDeSelect(item) {
        this.searchForm.patchValue({
          Destination: []
        });
        this.countriesFilterData.splice(this.countriesFilterData.indexOf(item), 1);
        this.getCountries(this.countriesFilterData);
      }

      onSelectAll(items) {
        this.searchForm.patchValue({
          Destination: []
        });
        this.countriesFilterData = items;
        this.getCountries(this.countriesFilterData);
      }

      onDeSelectAll(items) {
        this.searchForm.patchValue({
          Destination: []
        });
        this.countriesFilterData = items;
        this.getCountries(this.countriesFilterData);
      }

      getCummulativecount() {
        this.cummulativeCount = {
          "totalNo": 0,
          "onTime": 0,
          "delay": 0
        };

        for (let key in this.exportData.TotalsByCarrier) {
          this.cummulativeCount["totalNo"] += this.exportData.TotalsByCarrier[key].totalNo;
          this.cummulativeCount["onTime"] += this.exportData.TotalsByCarrier[key].onTime;
          this.cummulativeCount["delay"] += this.exportData.TotalsByCarrier[key].delay;
        }

        this.exportData.TotalsByCarrier['ZTotal'] = this.cummulativeCount;
        this.loading = false;
      }

    };

    ExportReportsComponent.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
    }, {
      type: _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_3__["ApiServicesService"]
    }, {
      type: _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
    }];

    ExportReportsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-export-reports',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./export-reports.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/export-reports/export-reports.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./export-reports.component.scss */
      "./src/app/export-reports/export-reports.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_3__["ApiServicesService"], _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]])], ExportReportsComponent);
    /***/
  },

  /***/
  "./src/app/footer/footer.component.scss":
  /*!**********************************************!*\
    !*** ./src/app/footer/footer.component.scss ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppFooterFooterComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/footer/footer.component.ts":
  /*!********************************************!*\
    !*** ./src/app/footer/footer.component.ts ***!
    \********************************************/

  /*! exports provided: FooterComponent */

  /***/
  function srcAppFooterFooterComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FooterComponent", function () {
      return FooterComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    let FooterComponent = class FooterComponent {
      constructor() {}

      ngOnInit() {}

    };
    FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-footer',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./footer.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/footer/footer.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./footer.component.scss */
      "./src/app/footer/footer.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], FooterComponent);
    /***/
  },

  /***/
  "./src/app/header/header.component.scss":
  /*!**********************************************!*\
    !*** ./src/app/header/header.component.scss ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppHeaderHeaderComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".sidenav a {\n  padding: 8px 8px 8px 8px;\n  text-decoration: none;\n  font-size: 16px;\n  color: #818181;\n  -webkit-transition: 0.3s;\n  transition: 0.3s;\n}\n\n.sidenav .closebtn {\n  display: none;\n}\n\n.open-icon {\n  display: none;\n}\n\n.sidenav-vertical .app-brand {\n  padding: 10px 10px 10px 10px !important;\n}\n\n.sidenav {\n  background-color: #e9f8ff !important;\n  padding-bottom: 30px;\n  overflow-y: auto;\n}\n\n.app-brand.m-v {\n  display: none;\n}\n\n@media screen and (max-width: 767px) {\n  .sidenav {\n    height: 100%;\n    width: 0;\n    position: fixed;\n    z-index: 99;\n    top: 0;\n    left: 0;\n    background-color: #111;\n    overflow-x: hidden;\n    -webkit-transition: 0.5s;\n    transition: 0.5s;\n    padding-top: 40px;\n  }\n\n  .sidenav .closebtn {\n    display: block;\n  }\n\n  .sidenav-divider {\n    display: none;\n  }\n\n  .open-icon {\n    display: block;\n  }\n\n  .sidenav-vertical .app-brand {\n    display: none;\n  }\n\n  .sidenav a:hover {\n    color: #f1f1f1;\n  }\n\n  .sidenav .closebtn {\n    position: absolute;\n    top: -10px;\n    right: 0px;\n    font-size: 36px;\n    margin-left: 50px;\n  }\n\n  .app-brand.m-v {\n    position: fixed;\n    top: 0px;\n    z-index: 9;\n    width: 100%;\n    background: #fff;\n    display: -webkit-box;\n    display: flex;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyL0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXGhlYWRlclxcaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksd0JBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBRUEsd0JBQUE7RUFBQSxnQkFBQTtBQ0FKOztBREVFO0VBQ0ksYUFBQTtBQ0NOOztBRENFO0VBQ0ksYUFBQTtBQ0VOOztBREFFO0VBQ0UsdUNBQUE7QUNHSjs7QUREQTtFQUNJLG9DQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQkFBQTtBQ0lKOztBREZBO0VBQ0ksYUFBQTtBQ0tKOztBREhFO0VBQ0U7SUFDSSxZQUFBO0lBQ0EsUUFBQTtJQUNBLGVBQUE7SUFDQSxXQUFBO0lBQ0EsTUFBQTtJQUNBLE9BQUE7SUFDQSxzQkFBQTtJQUNBLGtCQUFBO0lBQ0Esd0JBQUE7SUFBQSxnQkFBQTtJQUNBLGlCQUFBO0VDTU47O0VESEk7SUFDRSxjQUFBO0VDTU47O0VESkU7SUFDSSxhQUFBO0VDT047O0VETEk7SUFDRSxjQUFBO0VDUU47O0VETkU7SUFDSSxhQUFBO0VDU047O0VETkk7SUFDRSxjQUFBO0VDU047O0VETkk7SUFDRSxrQkFBQTtJQUNBLFVBQUE7SUFDQSxVQUFBO0lBQ0EsZUFBQTtJQUNBLGlCQUFBO0VDU047O0VETkk7SUFDRSxlQUFBO0lBQ0EsUUFBQTtJQUNBLFVBQUE7SUFDQSxXQUFBO0lBQ0EsZ0JBQUE7SUFDQSxvQkFBQTtJQUFBLGFBQUE7RUNTTjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zaWRlbmF2IGEge1xyXG4gICAgcGFkZGluZzogOHB4IDhweCA4cHggOHB4O1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgY29sb3I6ICM4MTgxODE7XHJcbiAgIFxyXG4gICAgdHJhbnNpdGlvbjogMC4zcztcclxuICB9XHJcbiAgLnNpZGVuYXYgLmNsb3NlYnRuIHtcclxuICAgICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgLm9wZW4taWNvbntcclxuICAgICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgLnNpZGVuYXYtdmVydGljYWwgLmFwcC1icmFuZCB7XHJcbiAgICBwYWRkaW5nOiAxMHB4IDEwcHggMTBweCAxMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLnNpZGVuYXZ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMzBweDtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbn1cclxuLmFwcC1icmFuZC5tLXZ7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG59XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY3cHgpIHtcclxuICAgIC5zaWRlbmF2IHtcclxuICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgd2lkdGg6IDA7XHJcbiAgICAgICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgICAgIHotaW5kZXg6IDk5O1xyXG4gICAgICAgIHRvcDogMDtcclxuICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMxMTE7XHJcbiAgICAgICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgICAgIHRyYW5zaXRpb246IDAuNXM7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgICAgXHJcbiAgICAgIH1cclxuICAgICAgLnNpZGVuYXYgLmNsb3NlYnRuIHtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIH1cclxuICAgIC5zaWRlbmF2LWRpdmlkZXJ7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgIH1cclxuICAgICAgLm9wZW4taWNvbntcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIH1cclxuICAgIC5zaWRlbmF2LXZlcnRpY2FsIC5hcHAtYnJhbmR7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgIH1cclxuICAgXHJcbiAgICAgIC5zaWRlbmF2IGE6aG92ZXIge1xyXG4gICAgICAgIGNvbG9yOiAjZjFmMWYxO1xyXG4gICAgICB9XHJcbiAgICAgIFxyXG4gICAgICAuc2lkZW5hdiAuY2xvc2VidG4ge1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICB0b3A6IC0xMHB4O1xyXG4gICAgICAgIHJpZ2h0OjBweDtcclxuICAgICAgICBmb250LXNpemU6IDM2cHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDUwcHg7XHJcbiAgICAgIH1cclxuICAgICAgXHJcbiAgICAgIC5hcHAtYnJhbmQubS12e1xyXG4gICAgICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgICAgICB0b3A6IDBweDtcclxuICAgICAgICB6LWluZGV4OiA5O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgfVxyXG4gIH1cclxuICAiLCIuc2lkZW5hdiBhIHtcbiAgcGFkZGluZzogOHB4IDhweCA4cHggOHB4O1xuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICM4MTgxODE7XG4gIHRyYW5zaXRpb246IDAuM3M7XG59XG5cbi5zaWRlbmF2IC5jbG9zZWJ0biB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5vcGVuLWljb24ge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uc2lkZW5hdi12ZXJ0aWNhbCAuYXBwLWJyYW5kIHtcbiAgcGFkZGluZzogMTBweCAxMHB4IDEwcHggMTBweCAhaW1wb3J0YW50O1xufVxuXG4uc2lkZW5hdiB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNlOWY4ZmYgIWltcG9ydGFudDtcbiAgcGFkZGluZy1ib3R0b206IDMwcHg7XG4gIG92ZXJmbG93LXk6IGF1dG87XG59XG5cbi5hcHAtYnJhbmQubS12IHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgLnNpZGVuYXYge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB3aWR0aDogMDtcbiAgICBwb3NpdGlvbjogZml4ZWQ7XG4gICAgei1pbmRleDogOTk7XG4gICAgdG9wOiAwO1xuICAgIGxlZnQ6IDA7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzExMTtcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XG4gICAgdHJhbnNpdGlvbjogMC41cztcbiAgICBwYWRkaW5nLXRvcDogNDBweDtcbiAgfVxuXG4gIC5zaWRlbmF2IC5jbG9zZWJ0biB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gIH1cblxuICAuc2lkZW5hdi1kaXZpZGVyIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgLm9wZW4taWNvbiB7XG4gICAgZGlzcGxheTogYmxvY2s7XG4gIH1cblxuICAuc2lkZW5hdi12ZXJ0aWNhbCAuYXBwLWJyYW5kIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG5cbiAgLnNpZGVuYXYgYTpob3ZlciB7XG4gICAgY29sb3I6ICNmMWYxZjE7XG4gIH1cblxuICAuc2lkZW5hdiAuY2xvc2VidG4ge1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IC0xMHB4O1xuICAgIHJpZ2h0OiAwcHg7XG4gICAgZm9udC1zaXplOiAzNnB4O1xuICAgIG1hcmdpbi1sZWZ0OiA1MHB4O1xuICB9XG5cbiAgLmFwcC1icmFuZC5tLXYge1xuICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICB0b3A6IDBweDtcbiAgICB6LWluZGV4OiA5O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgZGlzcGxheTogZmxleDtcbiAgfVxufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/header/header.component.ts":
  /*!********************************************!*\
    !*** ./src/app/header/header.component.ts ***!
    \********************************************/

  /*! exports provided: HeaderComponent */

  /***/
  function srcAppHeaderHeaderComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HeaderComponent", function () {
      return HeaderComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    let HeaderComponent = class HeaderComponent {
      constructor(router, authenticationService) {
        this.router = router;
        this.authenticationService = authenticationService;
      }

      ngOnInit() {
        this.superadmin = false;
        this.admin = false;
        var currentUser = localStorage.getItem('currentUser');
        var currentUserType = localStorage.getItem('currentUserType');
        this.utype = currentUserType;

        if (currentUser == null) {
          this.router.navigate(['/login']);
        }
      }

      checkSuperadmin() {
        if (this.utype == 1) {
          return true;
        } else {
          return false;
        }
      }

      logout() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
      }

    };

    HeaderComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }];

    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-header',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./header.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/header/header.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./header.component.scss */
      "./src/app/header/header.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]])], HeaderComponent);
    /***/
  },

  /***/
  "./src/app/home/home.component.css":
  /*!*****************************************!*\
    !*** ./src/app/home/home.component.css ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomeHomeComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "/* Structure */\r\n.container {\r\n  display: -webkit-box;\r\n  display: flex;\r\n  -webkit-box-orient: vertical;\r\n  -webkit-box-direction: normal;\r\n          flex-direction: column;\r\n}\r\n/* Toolbar */\r\n.spacer {\r\n  -webkit-box-flex: 1;\r\n          flex: 1 1 auto;\r\n}\r\n/* Filter */\r\n.form {\r\n  min-height: 56px;\r\n  max-height: 56px;\r\n  display: -webkit-box;\r\n  display: flex;\r\n  -webkit-box-align: center;\r\n          align-items: center;\r\n  padding: 8px 24px 0;\r\n  font-size: 20px;\r\n  -webkit-box-pack: justify;\r\n          justify-content: space-between;\r\n  border-bottom: 1px solid transparent;\r\n}\r\n.mat-form-field {\r\n  font-size: 14px;\r\n  -webkit-box-flex: 1;\r\n          flex-grow: 1;\r\n  margin-top: 8px;\r\n}\r\n/* Mat table */\r\n.no-results {\r\n  display: -webkit-box;\r\n  display: flex;\r\n  -webkit-box-pack: center;\r\n          justify-content: center;\r\n  padding: 14px;\r\n  font-size: 14px;\r\n  font-style: italic;\r\n}\r\n.mat-cell:nth-child(1),\r\n.mat-header-cell:nth-child(1){\r\n  -webkit-box-flex: 0;\r\n          flex: 0 0 6%;\r\n}\r\n.mat-cell:nth-child(2),\r\n.mat-header-cell:nth-child(2){\r\n  -webkit-box-flex: 0;\r\n          flex: 0 0 30%;\r\n}\r\n.mat-cell:nth-child(3),\r\n.mat-header-cell:nth-child(3){\r\n  -webkit-box-flex: 0;\r\n          flex: 0 0 6%;\r\n}\r\n.mat-cell:nth-child(7),\r\n.mat-header-cell:nth-child(7){\r\n  -webkit-box-flex: 0;\r\n          flex: 0 0 7%;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsY0FBYztBQUNkO0VBQ0Usb0JBQWE7RUFBYixhQUFhO0VBQ2IsNEJBQXNCO0VBQXRCLDZCQUFzQjtVQUF0QixzQkFBc0I7QUFDeEI7QUFFQSxZQUFZO0FBQ1o7RUFDRSxtQkFBYztVQUFkLGNBQWM7QUFDaEI7QUFFQSxXQUFXO0FBQ1g7RUFDRSxnQkFBZ0I7RUFDaEIsZ0JBQWdCO0VBQ2hCLG9CQUFhO0VBQWIsYUFBYTtFQUNiLHlCQUFtQjtVQUFuQixtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CLGVBQWU7RUFDZix5QkFBOEI7VUFBOUIsOEJBQThCO0VBQzlCLG9DQUFvQztBQUN0QztBQUVBO0VBQ0UsZUFBZTtFQUNmLG1CQUFZO1VBQVosWUFBWTtFQUNaLGVBQWU7QUFDakI7QUFFQSxjQUFjO0FBQ2Q7RUFDRSxvQkFBYTtFQUFiLGFBQWE7RUFDYix3QkFBdUI7VUFBdkIsdUJBQXVCO0VBQ3ZCLGFBQWE7RUFDYixlQUFlO0VBQ2Ysa0JBQWtCO0FBQ3BCO0FBRUE7O0VBRUUsbUJBQVk7VUFBWixZQUFZO0FBQ2Q7QUFFQTs7RUFFRSxtQkFBYTtVQUFiLGFBQWE7QUFDZjtBQUVBOztFQUVFLG1CQUFZO1VBQVosWUFBWTtBQUNkO0FBRUE7O0VBRUUsbUJBQVk7VUFBWixZQUFZO0FBQ2QiLCJmaWxlIjoic3JjL2FwcC9ob21lL2hvbWUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qIFN0cnVjdHVyZSAqL1xyXG4uY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbn1cclxuXHJcbi8qIFRvb2xiYXIgKi9cclxuLnNwYWNlciB7XHJcbiAgZmxleDogMSAxIGF1dG87XHJcbn1cclxuXHJcbi8qIEZpbHRlciAqL1xyXG4uZm9ybSB7XHJcbiAgbWluLWhlaWdodDogNTZweDtcclxuICBtYXgtaGVpZ2h0OiA1NnB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBwYWRkaW5nOiA4cHggMjRweCAwO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG4ubWF0LWZvcm0tZmllbGQge1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBmbGV4LWdyb3c6IDE7XHJcbiAgbWFyZ2luLXRvcDogOHB4O1xyXG59XHJcblxyXG4vKiBNYXQgdGFibGUgKi9cclxuLm5vLXJlc3VsdHMge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgcGFkZGluZzogMTRweDtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG59XHJcblxyXG4ubWF0LWNlbGw6bnRoLWNoaWxkKDEpLFxyXG4ubWF0LWhlYWRlci1jZWxsOm50aC1jaGlsZCgxKXtcclxuICBmbGV4OiAwIDAgNiU7XHJcbn1cclxuXHJcbi5tYXQtY2VsbDpudGgtY2hpbGQoMiksXHJcbi5tYXQtaGVhZGVyLWNlbGw6bnRoLWNoaWxkKDIpe1xyXG4gIGZsZXg6IDAgMCAzMCU7XHJcbn1cclxuXHJcbi5tYXQtY2VsbDpudGgtY2hpbGQoMyksXHJcbi5tYXQtaGVhZGVyLWNlbGw6bnRoLWNoaWxkKDMpe1xyXG4gIGZsZXg6IDAgMCA2JTtcclxufVxyXG5cclxuLm1hdC1jZWxsOm50aC1jaGlsZCg3KSxcclxuLm1hdC1oZWFkZXItY2VsbDpudGgtY2hpbGQoNyl7XHJcbiAgZmxleDogMCAwIDclO1xyXG59XHJcbiJdfQ== */";
    /***/
  },

  /***/
  "./src/app/home/home.component.ts":
  /*!****************************************!*\
    !*** ./src/app/home/home.component.ts ***!
    \****************************************/

  /*! exports provided: HomeComponent, ExampleDataSource, CSVRecord */

  /***/
  function srcAppHomeHomeComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomeComponent", function () {
      return HomeComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CSVRecord", function () {
      return CSVRecord;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var _dialogs_add_add_dialog_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./../dialogs/add/add.dialog.component */
    "./src/app/dialogs/add/add.dialog.component.ts");
    /* harmony import */


    var _dialogs_edit_edit_dialog_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ./../dialogs/edit/edit.dialog.component */
    "./src/app/dialogs/edit/edit.dialog.component.ts");
    /* harmony import */


    var _dialogs_delete_delete_dialog_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./../dialogs/delete/delete.dialog.component */
    "./src/app/dialogs/delete/delete.dialog.component.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    let HomeComponent = class HomeComponent {
      constructor(authenticationService, userService, httpClient, dialog, dataService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['id', 'Compound_DM_Time', 'CR_DM_Date', 'Clearance_BSO_NON_BSO', 'Carrier', 'Contract', 'actions'];
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        this.loadData(); //       this.loadAllUsers();
      }

      loadAllUsers() {
        this.userService.getAll().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["first"])()).subscribe(users => {
          this.users = users;
        });
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      refresh() {
        this.loadData();
      }

      addNew(issue) {
        const dialogRef = this.dialog.open(_dialogs_add_add_dialog_component__WEBPACK_IMPORTED_MODULE_10__["AddDialogComponent"], {
          data: {
            issue: issue
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 1) {
            // After dialog is closed we're doing frontend updates
            // For add we're just pushing a new row inside DataService
            this.exampleDatabase.dataChange.value.push(this.dataService.getDialogData());
            this.refreshTable();
          }
        });
      }

      startEdit(i, id, Compound_DM_Time, CR_DM_Date, Clearance_BSO_NON_BSO, Carrier, Contract) {
        this.id = id; // index row is used just for debugging proposes and can be removed

        this.index = i;
        const dialogRef = this.dialog.open(_dialogs_edit_edit_dialog_component__WEBPACK_IMPORTED_MODULE_11__["EditDialogComponent"], {
          data: {
            id: id,
            Compound_DM_Time: Compound_DM_Time,
            CR_DM_Date: CR_DM_Date,
            Clearance_BSO_NON_BSO: Clearance_BSO_NON_BSO,
            Carrier: Carrier,
            Contract: Contract
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 1) {
            // When using an edit things are little different, firstly we find record inside DataService by id
            const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.id === this.id); // Then you update that record using data from dialogData (values you enetered)

            this.exampleDatabase.dataChange.value[foundIndex] = this.dataService.getDialogData(); // And lastly refresh table

            this.refreshTable();
          }
        });
      }

      deleteItem(i, id, Compound_DM_Time, CR_DM_Date, Clearance_BSO_NON_BSO) {
        this.index = i;
        this.id = id;
        const dialogRef = this.dialog.open(_dialogs_delete_delete_dialog_component__WEBPACK_IMPORTED_MODULE_12__["DeleteDialogComponent"], {
          data: {
            id: id,
            Compound_DM_Time: Compound_DM_Time
          }
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result === 1) {
            const foundIndex = this.exampleDatabase.dataChange.value.findIndex(x => x.id === this.id); // for delete we use splice in order to remove single object from DataService

            this.exampleDatabase.dataChange.value.splice(foundIndex, 1);
            this.refreshTable();
          }
        });
      }

      refreshTable() {
        // Refreshing table using paginator
        // Thanks yeager-j for tips
        // https://github.com/marinantonio/angular-mat-table-crud/issues/12
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_13__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    HomeComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_3__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginator"])], HomeComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_8__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__["MatSort"])], HomeComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], HomeComponent.prototype, "filter", void 0);
    HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./home.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./home.component.css */
      "./src/app/home/home.component.css")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_3__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"], _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]])], HomeComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_9__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_13__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.dataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getAllIssues();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_13__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.data.slice().filter(issue => {
            const searchStr = (issue.id + issue.Compound_DM_Time + issue.CR_DM_Date + issue.Clearance_BSO_NON_BSO).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'id':
              [propertyA, propertyB] = [a.id, b.id];
              break;

            case 'Compound_DM_Time':
              [propertyA, propertyB] = [a.Compound_DM_Time, b.Compound_DM_Time];
              break;

            case 'CR_DM_Date':
              [propertyA, propertyB] = [a.CR_DM_Date, b.CR_DM_Date];
              break;

            case 'Clearance_BSO_NON_BSO':
              [propertyA, propertyB] = [a.Clearance_BSO_NON_BSO, b.Clearance_BSO_NON_BSO];
              break;

            case 'Carrier':
              [propertyA, propertyB] = [a.Carrier, b.Carrier];
              break;

            case 'Contract':
              [propertyA, propertyB] = [a.Contract, b.Contract];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'asc' ? 1 : -1);
        });
      }

    }

    class CSVRecord {
      constructor() {}

    }
    /***/

  },

  /***/
  "./src/app/home/index.ts":
  /*!*******************************!*\
    !*** ./src/app/home/index.ts ***!
    \*******************************/

  /*! exports provided: HomeComponent, ExampleDataSource, CSVRecord */

  /***/
  function srcAppHomeIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _home_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./home.component */
    "./src/app/home/home.component.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "HomeComponent", function () {
      return _home_component__WEBPACK_IMPORTED_MODULE_1__["HomeComponent"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return _home_component__WEBPACK_IMPORTED_MODULE_1__["ExampleDataSource"];
    });
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "CSVRecord", function () {
      return _home_component__WEBPACK_IMPORTED_MODULE_1__["CSVRecord"];
    });
    /***/

  },

  /***/
  "./src/app/import-record-add/import-record-add.component.scss":
  /*!********************************************************************!*\
    !*** ./src/app/import-record-add/import-record-add.component.scss ***!
    \********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppImportRecordAddImportRecordAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-form-field {\n  display: block;\n  position: relative;\n  text-align: left;\n  margin-left: 5%;\n  width: 40%;\n}\n\n.button-row {\n  margin-left: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW1wb3J0LXJlY29yZC1hZGQvRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcaW1wb3J0LXJlY29yZC1hZGRcXGltcG9ydC1yZWNvcmQtYWRkLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9pbXBvcnQtcmVjb3JkLWFkZC9pbXBvcnQtcmVjb3JkLWFkZC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7QUNDSjs7QURDQTtFQUNJLGVBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL2ltcG9ydC1yZWNvcmQtYWRkL2ltcG9ydC1yZWNvcmQtYWRkLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hdC1mb3JtLWZpZWxkIHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIHdpZHRoOiA0MCU7XHJcbn1cclxuLmJ1dHRvbi1yb3cge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG59XHJcbiIsIi5tYXQtZm9ybS1maWVsZCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgd2lkdGg6IDQwJTtcbn1cblxuLmJ1dHRvbi1yb3cge1xuICBtYXJnaW4tbGVmdDogNSU7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/import-record-add/import-record-add.component.ts":
  /*!******************************************************************!*\
    !*** ./src/app/import-record-add/import-record-add.component.ts ***!
    \******************************************************************/

  /*! exports provided: DD_MM_YYYY_Format, ImportRecordAddComponent */

  /***/
  function srcAppImportRecordAddImportRecordAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DD_MM_YYYY_Format", function () {
      return DD_MM_YYYY_Format;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImportRecordAddComponent", function () {
      return ImportRecordAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/material */
    "./node_modules/@angular/material/esm2015/material.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! moment/moment.js */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment_moment_js__WEBPACK_IMPORTED_MODULE_7__);
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    const DD_MM_YYYY_Format = {
      parse: {
        dateInput: {
          day: 'numeric',
          month: 'numeric',
          year: 'numeric'
        }
      },
      display: {
        dateInput: 'input',
        monthYearLabel: {
          year: 'numeric',
          month: 'short'
        },
        dateA11yLabel: {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        },
        monthYearA11yLabel: {
          year: 'numeric',
          month: 'long'
        }
      }
    };
    let ImportRecordAddComponent = class ImportRecordAddComponent {
      constructor(router, api, formBuilder, http) {
        this.router = router;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.yesnos = [{
          value: 'YES',
          viewValue: 'YES'
        }, {
          value: 'NO',
          viewValue: 'NO'
        }];
        this.importstatus = [{
          value: 'Cleared',
          viewValue: 'Cleared'
        }, {
          value: 'In-Transit',
          viewValue: 'In-Transit'
        }, {
          value: 'Under-Clearance',
          viewValue: 'Under-Clearance'
        }, {
          value: 'Waiting for Annex',
          viewValue: 'Waiting for Annex'
        }];
        this.sbulocations = [{
          value: 'BIO-MPR',
          viewValue: 'BIO-MPR'
        }, {
          value: 'BIO-NRM',
          viewValue: 'BIO-NRM'
        }, {
          value: 'BLR',
          viewValue: 'BLR'
        }, {
          value: 'NRM',
          viewValue: 'NRM'
        }, {
          value: 'COMBO',
          viewValue: 'COMBO'
        }, {
          value: 'FAS-MPR',
          viewValue: 'FAS-MPR'
        }, {
          value: 'MPR',
          viewValue: 'MPR'
        }, {
          value: 'Vizag',
          viewValue: 'Vizag'
        }];
        this.categories = [{
          value: 'CDS',
          viewValue: 'CDS'
        }, {
          value: 'CG-BIO',
          viewValue: 'CG-BIO'
        }, {
          value: 'CG-CDS',
          viewValue: 'CG-CDS'
        }, {
          value: 'CG-CMS',
          viewValue: 'CG-CMS'
        }, {
          value: 'CG-CS',
          viewValue: 'CG-CS'
        }, {
          value: 'CG-FAS',
          viewValue: 'CG-FAS'
        }, {
          value: 'CMS',
          viewValue: 'CMS'
        }, {
          value: 'CO-BIO',
          viewValue: 'CO-BIO'
        }, {
          value: 'CO-CDS',
          viewValue: 'CO-CDS'
        }, {
          value: 'CO-CS',
          viewValue: 'CO-CS'
        }, {
          value: 'CO-FAS',
          viewValue: 'CO-FAS'
        }, {
          value: 'LC',
          viewValue: 'LC'
        }];
        this.Rfps = [{
          value: 'Clearance Delay',
          viewValue: 'Clearance Delay'
        }, {
          value: 'Transit Delay',
          viewValue: 'Transit Delay'
        }, {
          value: 'Clearance and Transit Delay',
          viewValue: 'Clearance and Transit Delay'
        }, {
          value: 'Sea Shipment',
          viewValue: 'Sea Shipment'
        }, {
          value: 'SEZ Shipment',
          viewValue: 'SEZ Shipment'
        }, {
          value: 'Customs Holiday',
          viewValue: 'Customs Holiday'
        }, {
          value: 'Documents Delay',
          viewValue: 'Documents Delay'
        }, {
          value: 'Delayed Information',
          viewValue: 'Delayed Information'
        }, {
          value: 'DHL Dg Shipment',
          viewValue: 'DHL Dg Shipment'
        }, {
          value: 'BRO Delay',
          viewValue: 'BRO Delay'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }, {
          value: 'No Delay',
          viewValue: 'No Delay'
        }];
        this.Date = '';
        this.Rev_info = '';
        this.SBU_location = '';
        this.Req_sent_by = '';
        this.Vendor_name = '';
        this.Category = '';
        this.NRM = '';
        this.MPR = '';
        this.BLR = '';
        this.VPO = '';
        this.Country = '';
        this.No_of_chem = '';
        this.AWB_no = '';
        this.Remarks = '';
        this.Reasons = '';
        this.Status = '';
        this.Delivery_Date = '';
        this.Expected_Date_Delivery = '';
        this.Carrier = '';
        this.Pick_up_date = '';
        this.shpt_land_dt = '';
        this.Docs_shared_date = '';
        this.Port_of_clearance = '';
        this.CHA = '';
        this.Clearance_TAT = '';
        this.Transit_TAT = '';
        this.Total_TAT = '';
        this.PC_Meter = '';
        this.Bill_No = '';
        this.Clearance_Charges = '';
        this.Freight = '';
        this.BE_No = '';
        this.BE_Date = '';
        this.Penalty_Charges = '';
        this.Reason_for_penalty = '';
        this.Approval_status = '';
        this.DG = '';
        this.High_Value = '';
        this.Perishable = '';
        this.BRO = '';
        this.Reasons_For_Reports = '';
        this.Create_Date = '';
        this.Updated_date = '';
        this.isLoadingResults = false;
        this.Message = '';
      }

      ngOnInit() {
        this.vendorButton();
        this.carrierSelect();
        this.countrySelect();
        this.custumAgentSelect();
        this.Transit_TATdays = 0;
        this.Total_TATdays = 0;
        this.Clearance_TATdays = 0; //	this.VendorsList();

        this.importForm = this.formBuilder.group({
          'Date': [null],
          'Rev_info': [null],
          'SBU_location': [null],
          'Req_sent_by': [null],
          'Vendor_name': [null],
          'Category': [null],
          'NRM': [null],
          'MPR': [null],
          'BLR': [null],
          'VPO': [null],
          'Country': [null],
          'No_of_chem': [null],
          'AWB_no': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
          'Remarks': [null],
          'Reasons': [null],
          'Status': [null],
          'Delivery_Date': [null],
          'Expected_Date_Delivery': [null],
          'Carrier': [null],
          'Pick_up_date': [null],
          'shpt_land_dt': [null],
          'Docs_shared_date': [null],
          'Port_of_clearance': [null],
          'CHA': [null],
          'Clearance_TAT': [null],
          'Transit_TAT': [null],
          'Total_TAT': [null],
          'PC_Meter': [null],
          'Bill_No': [null],
          'Clearance_Charges': [null],
          'Freight': [null],
          'BE_No': [null],
          'BE_Date': [null],
          'Penalty_Charges': [null],
          'Reason_for_penalty': [null],
          'Approval_status': [null],
          'DG': [null],
          'High_Value': [null],
          'Perishable': [null],
          'BRO': [null],
          'Reasons_For_Reports': [null],
          'Zone': [''],
          'RemarksForReports': [''],
          'CMSshiptsBalanceDetails': [''],
          'OriginalBoESubmittedDate': [''],
          'CMS_CDS_Product_NameRrProjectCode': [''],
          'GrossWeight_Kg': [''],
          'DistanceInKms': [''],
          'Co2Emiission_Kg': ['']
        });
      }

      onFormSubmit(form) {
        this.save({
          AWB_no: form.AWB_no ? form.AWB_no : '',
          Rev_info: form.Rev_info ? form.Rev_info : '',
          SBU_location: form.SBU_location ? form.SBU_location : '',
          Delivery_Date: form.Delivery_Date ? form.Delivery_Date : '',
          Req_sent_by: form.Req_sent_by ? form.Req_sent_by : '',
          Vendor_name: form.Vendor_name ? form.Vendor_name : '',
          Category: form.Category ? form.Category : '',
          Create_Date: form.Create_Date ? form.Create_Date : '',
          NRM: form.NRM ? form.NRM : '',
          MPR: form.MPR ? form.MPR : '',
          VPO: form.VPO ? form.VPO : '',
          BLR: form.BLR ? form.BLR : '',
          Country: form.Country ? form.Country : '',
          No_of_chem: form.No_of_chem ? form.No_of_chem : '',
          Reasons: form.Reasons ? form.Reasons : '',
          Carrier: form.Carrier ? form.Carrier : '',
          Pick_up_date: form.Pick_up_date ? form.Pick_up_date : '',
          shpt_land_dt: form.shpt_land_dt ? form.shpt_land_dt : '',
          Docs_shared_date: form.Docs_shared_date ? form.Docs_shared_date : '',
          Port_of_clearance: form.Port_of_clearance ? form.Port_of_clearance : '',
          CHA: form.CHA ? form.CHA : '',
          Clearance_TAT: this.Clearance_TATdays ? this.Clearance_TATdays : '',
          Transit_TAT: this.Transit_TATdays ? this.Transit_TATdays : '',
          Total_TAT: this.Total_TATdays ? this.Total_TATdays : '',
          Date: form.Date ? form.Date : '',
          PC_Meter: form.PC_Meter ? form.PC_Meter : '',
          Bill_No: form.Bill_No ? form.Bill_No : '',
          Clearance_Charges: form.Clearance_Charges ? form.Clearance_Charges : '',
          Freight: form.Freight ? form.Freight : '',
          BE_No: form.BE_No ? form.BE_No : '',
          BE_Date: form.BE_Date ? form.BE_Date : '',
          Penalty_Charges: form.Penalty_Charges ? form.Penalty_Charges : '',
          Reason_for_penalty: form.Reason_for_penalty ? form.Reason_for_penalty : '',
          Approval_status: form.Approval_status ? form.Approval_status : '',
          DG: form.DG ? form.DG : '',
          High_Value: form.High_Value ? form.High_Value : '',
          Perishable: form.Perishable ? form.Perishable : '',
          BRO: form.BRO ? form.BRO : '',
          Status: form.Status ? form.Status : '',
          Remarks: form.Remarks ? form.Remarks : '',
          Reasons_For_Reports: form.Reasons_For_Reports ? form.Reasons_For_Reports : '',
          Expected_Date_Delivery: form.Expected_Date_Delivery ? form.Expected_Date_Delivery : '',
          Zone: form.Zone,
          RemarksForReports: form.RemarksForReports,
          CMSshiptsBalanceDetails: form.CMSshiptsBalanceDetails,
          OriginalBoESubmittedDate: form.OriginalBoESubmittedDate,
          CMS_CDS_Product_NameRrProjectCode: form.CMS_CDS_Product_NameRrProjectCode,
          GrossWeight_Kg: form.GrossWeight_Kg,
          DistanceInKms: form.DistanceInKms,
          Co2Emiission_Kg: form.Co2Emiission_Kg
        });
      }

      save(dataform) {
        console.log(dataform);
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].apiUrl_base) + '/import/importRecordAdd/', dataform).subscribe(result => {
          this.isLoadingResults = false;
          this.Message = "Record Added Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/import-records']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      vendorButton() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].apiUrl_base) + '/vendor/vendorsList');
        obs.subscribe(Vendor_Result => {
          this.tempVendor_Result = Vendor_Result;
          this.suggest('');
        });
      }

      suggest(vendor_name) {
        this.Vendor_Result = this.tempVendor_Result.filter(ven => ven.vendor_name.toLowerCase().startsWith(vendor_name.toLowerCase())).slice(0, 5);
      }

      carrierSelect() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].apiUrl_base) + '/carrier/carrierlist');
        obs.subscribe(carrier_Result => {
          this.tempcarrier_Result = carrier_Result;
          this.suggest_carrier('');
        });
      }

      suggest_carrier(carrier) {
        this.carrier_Result = this.tempcarrier_Result.filter(response => response.carrier.toLowerCase().startsWith(carrier.toLowerCase())).slice(0, 5);
      }

      countrySelect() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].apiUrl_base) + '/country/countries');
        obs.subscribe(country_Result => {
          this.tempcountry_Result = country_Result;
          this.suggest_country('');
        });
      }

      suggest_country(country) {
        this.country_Result = this.tempcountry_Result.filter(Cresponse => Cresponse.country.toLowerCase().startsWith(country.toLowerCase())).slice(0, 5);
      }

      custumAgentSelect() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].apiUrl_base) + '/cha/chalist/');
        obs.subscribe(cha_Result => {
          this.tempcha_Result = cha_Result;
          this.suggest_cha('');
        });
      }

      suggest_cha(cha_name) {
        this.cha_Result = this.tempcha_Result.filter(charesponsedd => charesponsedd.cha_name.toLowerCase().startsWith(cha_name.toLowerCase())).slice(0, 5);
      }

      onChangePickupdate(event) {
        var d = new Date(event);
        let date = [('0' + d.getDate()).slice(-2), ('0' + (d.getMonth() + 1)).slice(-2), d.getFullYear()].join('-');
        this.Pick_up_date = event;
        this.Transit_TATdaysValue();
        this.Clearance_TATdaysValue();
      }

      onChangeshipment(event) {
        this.shpt_land_dt = event;
        this.Transit_TATdaysValue();
        this.Clearance_TATdaysValue();
      }

      onChangeDelivery_Date(event) {
        this.Delivery_Date = event;
        this.Transit_TATdaysValue();
        this.Clearance_TATdaysValue();
      }

      Transit_TATdaysValue() {
        let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.Pick_up_date);
        let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.shpt_land_dt);
        let days = b.diff(a, 'days');

        if (days) {
          this.Transit_TATdays = days;
        } else {
          this.Transit_TATdays = 0;
        }
      }

      Clearance_TATdaysValue() {
        let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.Delivery_Date);
        let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.shpt_land_dt);
        let c = moment_moment_js__WEBPACK_IMPORTED_MODULE_7__(this.Pick_up_date);
        let TTAdays = a.diff(c, 'days');
        let totaldaysclear = a.diff(b, 'days');

        if (totaldaysclear) {
          this.Clearance_TATdays = totaldaysclear;
        } else {
          this.Clearance_TATdays = 0;
        }

        if (TTAdays) {
          this.Total_TATdays = TTAdays;
        } else {
          this.Total_TATdays = 0;
        }
      }

      onChange(event) {
        var d = new Date(event);
        let date = [('0' + d.getDate()).slice(-2), ('0' + (d.getMonth() + 1)).slice(-2), d.getFullYear()].join('-');
        this.Pick_up_date = event;
      }

    };

    ImportRecordAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
    }];

    ImportRecordAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-import-record-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./import-record-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/import-record-add/import-record-add.component.html")).default,
      providers: [{
        provide: _angular_material__WEBPACK_IMPORTED_MODULE_3__["MAT_DATE_FORMATS"],
        useValue: DD_MM_YYYY_Format
      }],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./import-record-add.component.scss */
      "./src/app/import-record-add/import-record-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]])], ImportRecordAddComponent);
    /***/
  },

  /***/
  "./src/app/import-record-edit/import-record-edit.component.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/import-record-edit/import-record-edit.component.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppImportRecordEditImportRecordEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-form-field {\n  display: block;\n  position: relative;\n  text-align: left;\n  margin-left: 5%;\n  width: 40%;\n}\n\n.button-row {\n  margin-left: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW1wb3J0LXJlY29yZC1lZGl0L0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXGltcG9ydC1yZWNvcmQtZWRpdFxcaW1wb3J0LXJlY29yZC1lZGl0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9pbXBvcnQtcmVjb3JkLWVkaXQvaW1wb3J0LXJlY29yZC1lZGl0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQ0NKOztBRENBO0VBQ0ksZUFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvaW1wb3J0LXJlY29yZC1lZGl0L2ltcG9ydC1yZWNvcmQtZWRpdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICB3aWR0aDogNDAlO1xyXG59XHJcbi5idXR0b24tcm93IHtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxufVxyXG4iLCIubWF0LWZvcm0tZmllbGQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIHdpZHRoOiA0MCU7XG59XG5cbi5idXR0b24tcm93IHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/import-record-edit/import-record-edit.component.ts":
  /*!********************************************************************!*\
    !*** ./src/app/import-record-edit/import-record-edit.component.ts ***!
    \********************************************************************/

  /*! exports provided: DD_MM_YYYY_Format, ImportRecordEditComponent */

  /***/
  function srcAppImportRecordEditImportRecordEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DD_MM_YYYY_Format", function () {
      return DD_MM_YYYY_Format;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImportRecordEditComponent", function () {
      return ImportRecordEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! moment/moment.js */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment_moment_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(moment_moment_js__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    const DD_MM_YYYY_Format = {
      parse: {
        dateInput: {
          day: 'numeric',
          month: 'numeric',
          year: 'numeric'
        }
      },
      display: {
        dateInput: 'input',
        monthYearLabel: {
          year: 'numeric',
          month: 'short'
        },
        dateA11yLabel: {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        },
        monthYearA11yLabel: {
          year: 'numeric',
          month: 'long'
        }
      }
    };
    let ImportRecordEditComponent = class ImportRecordEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.yesnos = [{
          value: 'YES',
          viewValue: 'YES'
        }, {
          value: 'NO',
          viewValue: 'NO'
        }];
        this.importstatus = [{
          value: 'Cleared',
          viewValue: 'Cleared'
        }, {
          value: 'In-Transit',
          viewValue: 'In-Transit'
        }, {
          value: 'Under-Clearance',
          viewValue: 'Under-Clearance'
        }, {
          value: 'Waiting for Annex',
          viewValue: 'Waiting for Annex'
        }];
        this.sbulocations = [{
          value: 'BIO-MPR',
          viewValue: 'BIO-MPR'
        }, {
          value: 'BIO-NRM',
          viewValue: 'BIO-NRM'
        }, {
          value: 'BLR',
          viewValue: 'BLR'
        }, {
          value: 'NRM',
          viewValue: 'NRM'
        }, {
          value: 'COMBO',
          viewValue: 'COMBO'
        }, {
          value: 'FAS-MPR',
          viewValue: 'FAS-MPR'
        }, {
          value: 'MPR',
          viewValue: 'MPR'
        }, {
          value: 'Vizag',
          viewValue: 'Vizag'
        }];
        this.categories = [{
          value: 'CDS',
          viewValue: 'CDS'
        }, {
          value: 'CG-BIO',
          viewValue: 'CG-BIO'
        }, {
          value: 'CG-CDS',
          viewValue: 'CG-CDS'
        }, {
          value: 'CG-CMS',
          viewValue: 'CG-CMS'
        }, {
          value: 'CG-CS',
          viewValue: 'CG-CS'
        }, {
          value: 'CG-FAS',
          viewValue: 'CG-FAS'
        }, {
          value: 'CMS',
          viewValue: 'CMS'
        }, {
          value: 'CO-BIO',
          viewValue: 'CO-BIO'
        }, {
          value: 'CO-CDS',
          viewValue: 'CO-CDS'
        }, {
          value: 'CO-CS',
          viewValue: 'CO-CS'
        }, {
          value: 'CO-FAS',
          viewValue: 'CO-FAS'
        }, {
          value: 'LC',
          viewValue: 'LC'
        }];
        this.Rfps = [{
          value: 'Clearance Delay',
          viewValue: 'Clearance Delay'
        }, {
          value: 'Transit Delay',
          viewValue: 'Transit Delay'
        }, {
          value: 'Clearance and Transit Delay',
          viewValue: 'Clearance and Transit Delay'
        }, {
          value: 'Sea Shipment',
          viewValue: 'Sea Shipment'
        }, {
          value: 'SEZ Shipment',
          viewValue: 'SEZ Shipment'
        }, {
          value: 'Customs Holiday',
          viewValue: 'Customs Holiday'
        }, {
          value: 'Documents Delay',
          viewValue: 'Documents Delay'
        }, {
          value: 'Delayed Information',
          viewValue: 'Delayed Information'
        }, {
          value: 'DHL Dg Shipment',
          viewValue: 'DHL Dg Shipment'
        }, {
          value: 'BRO Delay',
          viewValue: 'BRO Delay'
        }, {
          value: 'Others',
          viewValue: 'Others'
        }, {
          value: 'No Delay',
          viewValue: 'No Delay'
        }];
        this.Date = '';
        this.Rev_info = '';
        this.SBU_location = '';
        this.Req_sent_by = '';
        this.Vendor_name = '';
        this.Category = '';
        this.NRM = '';
        this.MPR = '';
        this.BLR = '';
        this.VPO = '';
        this.Country = '';
        this.No_of_chem = '';
        this.AWB_no = '';
        this.Remarks = '';
        this.Reasons = '';
        this.Status = '';
        this.Delivery_Date = '';
        this.Expected_Date_Delivery = '';
        this.Carrier = '';
        this.Pick_up_date = '';
        this.shpt_land_dt = '';
        this.Docs_shared_date = '';
        this.Port_of_clearance = '';
        this.CHA = '';
        this.Clearance_TAT = '';
        this.Transit_TAT = '';
        this.Total_TAT = '';
        this.PC_Meter = '';
        this.Bill_No = '';
        this.Clearance_Charges = '';
        this.Freight = '';
        this.BE_No = '';
        this.BE_Date = '';
        this.Penalty_Charges = '';
        this.Reason_for_penalty = '';
        this.Approval_status = '';
        this.DG = '';
        this.High_Value = '';
        this.Perishable = '';
        this.BRO = '';
        this.Reasons_For_Reports = '';
        this.Create_Date = '';
        this.Updated_date = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.vendorButton();
        this.carrierSelect();
        this.countrySelect();
        this.custumAgentSelect();
        this.Transit_TATdays = 0;
        this.Total_TATdays = 0;
        this.Clearance_TATdays = 0;
        this.getAwbDetails(this.route.snapshot.params['id']);
        this.importForm = this.formBuilder.group({
          'Date': [null],
          'Rev_info': [null],
          'SBU_location': [null],
          'Req_sent_by': [null],
          'Vendor_name': [null],
          'Category': [null],
          'NRM': [null],
          'MPR': [null],
          'BLR': [null],
          'VPO': [null],
          'Country': [null],
          'No_of_chem': [null],
          'AWB_no': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'Remarks': [null],
          'Reasons': [null],
          'Status': [null],
          'Delivery_Date': [null],
          'Expected_Date_Delivery': [null],
          'Carrier': [null],
          'Pick_up_date': [null],
          'shpt_land_dt': [null],
          'Docs_shared_date': [null],
          'Port_of_clearance': [null],
          'CHA': [null],
          'Clearance_TAT': [null],
          'Transit_TAT': [null],
          'Total_TAT': [null],
          'PC_Meter': [null],
          'Bill_No': [null],
          'Clearance_Charges': [null],
          'Freight': [null],
          'BE_No': [null],
          'BE_Date': [null],
          'Penalty_Charges': [null],
          'Reason_for_penalty': [null],
          'Approval_status': [null],
          'DG': [null],
          'High_Value': [null],
          'Perishable': [null],
          'BRO': [null],
          'Reasons_For_Reports': [null],
          'Zone': [null],
          'RemarksForReports': [null],
          'CMSshiptsBalanceDetails': [null],
          'OriginalBoESubmittedDate': [null],
          'CMS_CDS_Product_NameRrProjectCode': [null],
          'GrossWeight_Kg': [null],
          'DistanceInKms': [null],
          'Co2Emiission_Kg': [null]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        let importId = this.route.snapshot.params['id'];
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/import/updateDetails/' + importId, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/import-records']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      vendorButton() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/vendor/vendorsList');
        obs.subscribe(Vendor_Result => {
          this.tempVendor_Result = Vendor_Result;
          this.suggest('');
        });
      }

      suggest(vendor_name) {
        this.Vendor_Result = this.tempVendor_Result.filter(ven => ven.vendor_name.toLowerCase().startsWith(vendor_name.toLowerCase())).slice(0, 5);
      }

      carrierSelect() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/carrier/carrierlist');
        obs.subscribe(carrier_Result => {
          this.tempcarrier_Result = carrier_Result;
          this.suggest_carrier('');
        });
      }

      suggest_carrier(carrier) {
        this.carrier_Result = this.tempcarrier_Result.filter(response => response.carrier.toLowerCase().startsWith(carrier.toLowerCase())).slice(0, 5);
      }

      countrySelect() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/country/countries');
        obs.subscribe(country_Result => {
          this.tempcountry_Result = country_Result;
          this.suggest_country('');
        });
      }

      suggest_country(country) {
        this.country_Result = this.tempcountry_Result.filter(Cresponse => Cresponse.country.toLowerCase().startsWith(country.toLowerCase())).slice(0, 5);
      }

      custumAgentSelect() {
        let obs = this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/cha/chalist/');
        obs.subscribe(cha_Result => {
          this.tempcha_Result = cha_Result;
          this.suggest_cha('');
        });
      }

      suggest_cha(cha_name) {
        this.cha_Result = this.tempcha_Result.filter(charesponsedd => charesponsedd.cha_name.toLowerCase().startsWith(cha_name.toLowerCase())).slice(0, 5);
      }

      onChangePickupdate(event) {
        var d = new Date(event);
        let date = [('0' + d.getDate()).slice(-2), ('0' + (d.getMonth() + 1)).slice(-2), d.getFullYear()].join('-');
        this.Pick_up_date = event;
        this.Transit_TATdaysValue();
        this.Clearance_TATdaysValue();
      }

      onChangeshipment(event) {
        this.shpt_land_dt = event;
        this.Transit_TATdaysValue();
        this.Clearance_TATdaysValue();
      }

      onChangeDelivery_Date(event) {
        this.Delivery_Date = event;
        this.Transit_TATdaysValue();
        this.Clearance_TATdaysValue();
      }

      Transit_TATdaysValue() {
        let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.Pick_up_date);
        let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.shpt_land_dt);
        let days = b.diff(a, 'days');

        if (days) {
          this.Transit_TATdays = days;
        } else {
          this.Transit_TATdays = 0;
        }
      }

      Clearance_TATdaysValue() {
        let a = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.Delivery_Date);
        let b = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.shpt_land_dt);
        let c = moment_moment_js__WEBPACK_IMPORTED_MODULE_6__(this.Pick_up_date);
        let TTAdays = a.diff(c, 'days');
        let totaldaysclear = a.diff(b, 'days');

        if (totaldaysclear) {
          this.Clearance_TATdays = totaldaysclear;
        } else {
          this.Clearance_TATdays = 0;
        }

        if (TTAdays) {
          this.Total_TATdays = TTAdays;
        } else {
          this.Total_TATdays = 0;
        }
      }

      onChange(event) {
        var d = new Date(event);
        let date = [('0' + d.getDate()).slice(-2), ('0' + (d.getMonth() + 1)).slice(-2), d.getFullYear()].join('-');
        this.Pick_up_date = event;
      }

      getAwbDetails(AwbNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].apiUrl_base) + '/import/getImportRecord/' + AwbNo).subscribe(dataaa => {
          this.id = dataaa.response[0].id;
          this.importForm.setValue({
            Date: dataaa.response[0].Date,
            Rev_info: dataaa.response[0].Rev_info,
            SBU_location: dataaa.response[0].SBU_location,
            Req_sent_by: dataaa.response[0].Req_sent_by,
            Vendor_name: dataaa.response[0].Vendor_name,
            Category: dataaa.response[0].Category,
            NRM: dataaa.response[0].NRM,
            MPR: dataaa.response[0].MPR,
            BLR: dataaa.response[0].BLR,
            VPO: dataaa.response[0].VPO,
            Country: dataaa.response[0].Country,
            No_of_chem: dataaa.response[0].No_of_chem,
            AWB_no: dataaa.response[0].AWB_no,
            Remarks: dataaa.response[0].Remarks,
            Reasons: dataaa.response[0].Reasons,
            Status: dataaa.response[0].Status,
            Delivery_Date: dataaa.response[0].Delivery_Date,
            Expected_Date_Delivery: dataaa.response[0].Expected_Date_Delivery,
            Carrier: dataaa.response[0].Carrier,
            Pick_up_date: dataaa.response[0].Pick_up_date,
            shpt_land_dt: dataaa.response[0].shpt_land_dt,
            Docs_shared_date: dataaa.response[0].Docs_shared_date,
            Port_of_clearance: dataaa.response[0].Port_of_clearance,
            CHA: dataaa.response[0].CHA,
            Clearance_TAT: dataaa.response[0].Clearance_TAT,
            Transit_TAT: dataaa.response[0].Transit_TAT,
            Total_TAT: dataaa.response[0].Total_TAT,
            PC_Meter: dataaa.response[0].PC_Meter,
            Bill_No: dataaa.response[0].Bill_No,
            Clearance_Charges: dataaa.response[0].Clearance_Charges,
            Freight: dataaa.response[0].Freight,
            Penalty_Charges: dataaa.response[0].Penalty_Charges,
            BE_No: dataaa.response[0].BE_No,
            BE_Date: dataaa.response[0].BE_Date,
            Reason_for_penalty: dataaa.response[0].Reason_for_penalty,
            Approval_status: dataaa.response[0].Approval_status,
            DG: dataaa.response[0].DG,
            High_Value: dataaa.response[0].High_Value,
            Perishable: dataaa.response[0].Perishable,
            BRO: dataaa.response[0].BRO,
            Reasons_For_Reports: dataaa.response[0].Reasons_For_Reports,
            Zone: dataaa.response[0].Zone,
            RemarksForReports: dataaa.response[0].RemarksForReports,
            CMSshiptsBalanceDetails: dataaa.response[0].CMSshiptsBalanceDetails,
            OriginalBoESubmittedDate: dataaa.response[0].OriginalBoESubmittedDate,
            CMS_CDS_Product_NameRrProjectCode: dataaa.response[0].CMS_CDS_Product_NameRrProjectCode,
            GrossWeight_Kg: dataaa.response[0].GrossWeight_Kg,
            DistanceInKms: dataaa.response[0].DistanceInKms,
            Co2Emiission_Kg: dataaa.response[0].Co2Emiission_Kg
          });
        });
      }

    };

    ImportRecordEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    ImportRecordEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-import-record-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./import-record-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/import-record-edit/import-record-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./import-record-edit.component.scss */
      "./src/app/import-record-edit/import-record-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], ImportRecordEditComponent);
    /***/
  },

  /***/
  "./src/app/import-records-list/import-records-list.component.scss":
  /*!************************************************************************!*\
    !*** ./src/app/import-records-list/import-records-list.component.scss ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppImportRecordsListImportRecordsListComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n\n.table-responsive {\n  margin-bottom: 50px;\n}\n\n.custom-modal {\n  position: fixed;\n  top: 10%;\n  width: 100%;\n  z-index: 999;\n  left: 0;\n  display: none;\n}\n\n.bg-modal {\n  position: fixed;\n  background: #000;\n  opacity: 0.5;\n  top: 0px;\n  bottom: 0px;\n  width: 100%;\n  left: 0px;\n  right: 0px;\n}\n\n.custom-modal .modal-body {\n  padding: 10px 15px;\n}\n\n.custom-modal .modal-header, .custom-modal .modal-footer {\n  padding: 5px 15px;\n}\n\n.fil-sec {\n  margin-bottom: 15px;\n}\n\n.fil-sec .d-flex .form-control {\n  margin-right: 5px;\n}\n\n.fil-sec .d-flex .form-control:last-child {\n  margin-right: 0;\n}\n\na {\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW1wb3J0LXJlY29yZHMtbGlzdC9EOlxcUHJvamVjdHNcXGd2a2FkbWluLWZyb250ZW5kL3NyY1xcYXBwXFxpbXBvcnQtcmVjb3Jkcy1saXN0XFxpbXBvcnQtcmVjb3Jkcy1saXN0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9pbXBvcnQtcmVjb3Jkcy1saXN0L2ltcG9ydC1yZWNvcmRzLWxpc3QuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURBQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7QUNHSjs7QUREQztFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7QUNJRDs7QURGRTtFQUNFLCtCQUFBO0VBQ0gsbUJBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7QUNLRDs7QURIQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtBQ01BOztBREpBO0VBQ0UscUJBQUE7RUFDRCxnQkFBQTtBQ09EOztBRExBO0VBQ0EsVUFBQTtBQ1FBOztBRE5BO0VBQ0EsVUFBQTtBQ1NBOztBRFBBO0VBQ0EseUJBQUE7QUNVQTs7QURSQTtFQUNBLGlCQUFBO0FDV0E7O0FEVEE7RUFDQSxvQkFBQTtBQ1lBOztBRFZBO0VBQ0EsV0FBQTtBQ2FBOztBRFhBO0VBQ0UsbUJBQUE7QUNjRjs7QURaQTtFQUNFLGVBQUE7RUFDRSxRQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxPQUFBO0VBQ0EsYUFBQTtBQ2VKOztBRGJBO0VBQ0UsZUFBQTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0FDZ0JKOztBRGRBO0VBQ0Usa0JBQUE7QUNpQkY7O0FEZkE7RUFDRSxpQkFBQTtBQ2tCRjs7QURoQkE7RUFDRSxtQkFBQTtBQ21CRjs7QURqQkE7RUFDRSxpQkFBQTtBQ29CRjs7QURsQkE7RUFDRSxlQUFBO0FDcUJGOztBRG5CQTtFQUNFLGVBQUE7QUNzQkYiLCJmaWxlIjoic3JjL2FwcC9pbXBvcnQtcmVjb3Jkcy1saXN0L2ltcG9ydC1yZWNvcmRzLWxpc3QuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWF0LWhlYWRlci1jZWxsIHtcclxuICAgIG1pbi13aWR0aDogMTAwcHg7XHJcbn1cclxuLm1hdC1jZWxsLm5nLXN0YXItaW5zZXJ0ZWQge1xyXG4gICAgbWluLXdpZHRoOiAxMDBweDtcclxufVxyXG4ubWF0LXRhYmxlIHtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgb3ZlcmZsb3cteDogYXV0bztcclxufVxyXG4gbWF0LWhlYWRlci1jZWxse1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICNlOWY4ZmY7XHJcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbn1cclxuICBtYXQtY2VsbCAsIG1hdC1oZWFkZXItY2VsbHtcclxuICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XHJcblx0YWxpZ24tc2VsZjogc3RyZXRjaDtcdFxyXG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xyXG5cdHBhZGRpbmc6MCA4cHg7XHJcbn1cclxuLnVwbG9hZC1mLm5nLXN0YXItaW5zZXJ0ZWR7XHJcbmRpc3BsYXk6ZmxleDtcclxufVxyXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCAsIC5pbXBvcnQtc2VjIC51cGxvYWQtYnRue1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuXHRtYXJnaW4tYm90dG9tOjA7XHJcbn1cclxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXB7XHJcbndpZHRoOjc1JTtcclxufVxyXG4uaW1wb3J0LXNlYyAudXBsb2FkLWJ0bntcclxud2lkdGg6MjUlO1xyXG59XHJcbi5tYXQtdGFibGV7XHJcbmJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbn1cclxuLnVwbG9hZC1idG57XHJcbnRleHQtYWxpZ246cmlnaHQ7XHJcbn1cclxuLnRvcC1idG5zIC5idG57XHJcbm1hcmdpbjowIDVweCAxMHB4IDA7XHJcbn1cclxubWF0LWZvb3Rlci1yb3csIG1hdC1oZWFkZXItcm93LCBtYXQtcm93e1xyXG5ib3JkZXI6MHB4XHJcbn1cclxuLnRhYmxlLXJlc3BvbnNpdmV7XHJcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcclxufVxyXG4uY3VzdG9tLW1vZGFse1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHRvcDogMTAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICB6LWluZGV4OiA5OTk7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG4uYmctbW9kYWx7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgYmFja2dyb3VuZDogIzAwMDtcclxuICAgIG9wYWNpdHk6IDAuNTtcclxuICAgIHRvcDogMHB4O1xyXG4gICAgYm90dG9tOiAwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGxlZnQ6IDBweDtcclxuICAgIHJpZ2h0OiAwcHg7XHJcbn1cclxuLmN1c3RvbS1tb2RhbCAubW9kYWwtYm9keXtcclxuICBwYWRkaW5nOiAxMHB4IDE1cHg7XHJcbn1cclxuLmN1c3RvbS1tb2RhbCAubW9kYWwtaGVhZGVyICwgLmN1c3RvbS1tb2RhbCAubW9kYWwtZm9vdGVye1xyXG4gIHBhZGRpbmc6IDVweCAxNXB4O1xyXG59XHJcbi5maWwtc2Vje1xyXG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuLmZpbC1zZWMgLmQtZmxleCAuZm9ybS1jb250cm9se1xyXG4gIG1hcmdpbi1yaWdodDogNXB4O1xyXG59XHJcbi5maWwtc2VjIC5kLWZsZXggLmZvcm0tY29udHJvbDpsYXN0LWNoaWxke1xyXG4gIG1hcmdpbi1yaWdodDogMDtcclxufVxyXG5he1xyXG4gIGN1cnNvcjogcG9pbnRlclxyXG59IiwiLm1hdC1oZWFkZXItY2VsbCB7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG5cbi5tYXQtY2VsbC5uZy1zdGFyLWluc2VydGVkIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBvdmVyZmxvdy14OiBhdXRvO1xufVxuXG5tYXQtaGVhZGVyLWNlbGwge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxubWF0LWNlbGwsIG1hdC1oZWFkZXItY2VsbCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XG4gIGFsaWduLXNlbGY6IHN0cmV0Y2g7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xuICBwYWRkaW5nOiAwIDhweDtcbn1cblxuLnVwbG9hZC1mLm5nLXN0YXItaW5zZXJ0ZWQge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG5cbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwIHtcbiAgd2lkdGg6IDc1JTtcbn1cblxuLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICB3aWR0aDogMjUlO1xufVxuXG4ubWF0LXRhYmxlIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxuLnVwbG9hZC1idG4ge1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cblxuLnRvcC1idG5zIC5idG4ge1xuICBtYXJnaW46IDAgNXB4IDEwcHggMDtcbn1cblxubWF0LWZvb3Rlci1yb3csIG1hdC1oZWFkZXItcm93LCBtYXQtcm93IHtcbiAgYm9yZGVyOiAwcHg7XG59XG5cbi50YWJsZS1yZXNwb25zaXZlIHtcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcbn1cblxuLmN1c3RvbS1tb2RhbCB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiAxMCU7XG4gIHdpZHRoOiAxMDAlO1xuICB6LWluZGV4OiA5OTk7XG4gIGxlZnQ6IDA7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG5cbi5iZy1tb2RhbCB7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgYmFja2dyb3VuZDogIzAwMDtcbiAgb3BhY2l0eTogMC41O1xuICB0b3A6IDBweDtcbiAgYm90dG9tOiAwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBsZWZ0OiAwcHg7XG4gIHJpZ2h0OiAwcHg7XG59XG5cbi5jdXN0b20tbW9kYWwgLm1vZGFsLWJvZHkge1xuICBwYWRkaW5nOiAxMHB4IDE1cHg7XG59XG5cbi5jdXN0b20tbW9kYWwgLm1vZGFsLWhlYWRlciwgLmN1c3RvbS1tb2RhbCAubW9kYWwtZm9vdGVyIHtcbiAgcGFkZGluZzogNXB4IDE1cHg7XG59XG5cbi5maWwtc2VjIHtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbn1cblxuLmZpbC1zZWMgLmQtZmxleCAuZm9ybS1jb250cm9sIHtcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XG59XG5cbi5maWwtc2VjIC5kLWZsZXggLmZvcm0tY29udHJvbDpsYXN0LWNoaWxkIHtcbiAgbWFyZ2luLXJpZ2h0OiAwO1xufVxuXG5hIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/import-records-list/import-records-list.component.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/import-records-list/import-records-list.component.ts ***!
    \**********************************************************************/

  /*! exports provided: ImportRecordsListComponent */

  /***/
  function srcAppImportRecordsListImportRecordsListComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImportRecordsListComponent", function () {
      return ImportRecordsListComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! xlsx */
    "./node_modules/xlsx/xlsx.js");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var _services_excel_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../services/excel.service */
    "./src/app/services/excel.service.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @app/_services/api-services.service */
    "./src/app/_services/api-services.service.ts");

    let ImportRecordsListComponent = class ImportRecordsListComponent {
      constructor(authenticationService, userService, httpClient, http, dialog, dataService, excelService, apiService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.http = http;
        this.dialog = dialog;
        this.dataService = dataService;
        this.excelService = excelService;
        this.apiService = apiService;
        this.users = [];
        this.displayedColumns = ['id', 'AWB No', 'Date', 'Rev_info', 'SBU_location', 'Req_sent_by', 'Vendor_name', 'Category', 'Contract', 'NRM', 'MPR', 'BLR', 'VPO', 'Country', 'No_of_chem', 'Remarks', 'Reasons', 'Status', 'Delivery_Date', 'Expected_Date_Delivery', 'Carrier', 'Pick_up_date', 'shpt_land_dt', 'Docs_shared_date', 'Port_of_clearance', 'CHA', 'Clearance_TAT', 'Transit_TAT', 'Total_TAT', 'PC_Meter', 'Bill_No', 'Clearance_Charges', 'Freight', 'BE_No', 'BE_Date', 'Penalty_Charges', 'Reason_for_penalty', 'Approval_status', 'DG', 'High_Value', 'Perishable', 'BRO', 'Reasons_For_Reports', "Zone", "RemarksForReports", "CMSshiptsBalanceDetails", "OriginalBoESubmittedDate", "CMS_CDS_Product_NameRrProjectCode", "GrossWeight_Kg", "DistanceInKms", "Co2Emiission_Kg", 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.paginateData = {
          pagePer: 10,
          pageNo: 1,
          searchKey: ""
        };
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngOnInit() {
        this.getTableData();
      }

      incomingfile(event) {
        this.file = event.target.files[0];
      }

      Upload() {
        this.isLoadingResults = true;
        let fileReader = new FileReader();

        fileReader.onload = e => {
          this.arrayBuffer = fileReader.result;
          var data = new Uint8Array(this.arrayBuffer);
          var arr = new Array();

          for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);

          var bstr = arr.join("");
          var workbook = xlsx__WEBPACK_IMPORTED_MODULE_3__["read"](bstr, {
            'type': "binary",
            cellDates: true
          });
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          this.output = xlsx__WEBPACK_IMPORTED_MODULE_3__["utils"].sheet_to_json(worksheet, {
            raw: true
          });

          for (let i = 0; i < this.output.length; i++) {
            var AWB = this.output[i].AWB_no;
            let object = {
              AWB_no: this.output[i].AWB_no ? this.output[i].AWB_no : '',
              Rev_info: this.output[i].Rev_info ? this.output[i].Rev_info : '',
              SBU_location: this.output[i].SBU_location ? this.output[i].SBU_location : '',
              Delivery_Date: this.output[i].Delivery_Date ? this.output[i].Delivery_Date : '',
              Req_sent_by: this.output[i].Req_sent_by ? this.output[i].Req_sent_by : '',
              Vendor_name: this.output[i].Vendor_name ? this.output[i].Vendor_name : '',
              Category: this.output[i].Category ? this.output[i].Category : '',
              Create_Date: this.output[i].Create_Date ? this.output[i].Create_Date : '',
              NRM: this.output[i].NRM ? this.output[i].NRM : '',
              MPR: this.output[i].MPR ? this.output[i].MPR : '',
              VPO: this.output[i].VPO ? this.output[i].VPO : '',
              BLR: this.output[i].BLR ? this.output[i].BLR : '',
              Country: this.output[i].Country ? this.output[i].Country : '',
              No_of_chem: this.output[i].No_of_chem ? this.output[i].No_of_chem : '',
              Reasons: this.output[i].Reasons ? this.output[i].Reasons : '',
              Carrier: this.output[i].Carrier ? this.output[i].Carrier : '',
              Pick_up_date: this.output[i].Pick_up_date ? this.output[i].Pick_up_date : '',
              shpt_land_dt: this.output[i].shpt_land_dt ? this.output[i].shpt_land_dt : '',
              Docs_shared_date: this.output[i].Docs_shared_date ? this.output[i].Docs_shared_date : '',
              Port_of_clearance: this.output[i].Port_of_clearance ? this.output[i].Port_of_clearance : '',
              CHA: this.output[i].CHA ? this.output[i].CHA : '',
              Clearance_TAT: this.output[i].Clearance_TAT ? this.output[i].Clearance_TAT : '',
              Transit_TAT: this.output[i].Transit_TAT ? this.output[i].Transit_TAT : '',
              Total_TAT: this.output[i].Total_TAT ? this.output[i].Total_TAT : '',
              Date: this.output[i].Date ? this.output[i].Date : '',
              PC_Meter: this.output[i].PC_Meter ? this.output[i].PC_Meter : '',
              Bill_No: this.output[i].Bill_No ? this.output[i].Bill_No : '',
              Clearance_Charges: this.output[i].Clearance_Charges ? this.output[i].Clearance_Charges : '',
              Freight: this.output[i].Freight ? this.output[i].Freight : '',
              BE_No: this.output[i].BE_No ? this.output[i].BE_No : '',
              BE_Date: this.output[i].BE_Date ? this.output[i].BE_Date : '',
              Penalty_Charges: this.output[i].Penalty_Charges ? this.output[i].Penalty_Charges : '',
              Reason_for_penalty: this.output[i].Reason_for_penalty ? this.output[i].Reason_for_penalty : '',
              Remarks: this.output[i].Remarks ? this.output[i].Remarks : '',
              Approval_status: this.output[i].Approval_status ? this.output[i].Approval_status : '',
              DG: this.output[i].DG ? this.output[i].DG : '',
              High_Value: this.output[i].High_Value ? this.output[i].High_Value : '',
              Perishable: this.output[i].Perishable ? this.output[i].Perishable : '',
              BRO: this.output[i].BRO ? this.output[i].BRO : '',
              Status: this.output[i].Status ? this.output[i].Status : '',
              Reasons_For_Reports: this.output[i].Reasons_For_Reports ? this.output[i].Reasons_For_Reports : '',
              Expected_Date_Delivery: this.output[i].Expected_Date_Delivery ? this.output[i].Expected_Date_Delivery : '',
              Updated_date: this.output[i].Updated_date ? this.output[i].Updated_date : '',
              Zone: this.output[i].Zone ? this.output[i].Zone : '',
              RemarksForReports: this.output[i].RemarksForReports ? this.output[i].RemarksForReports : '',
              CMSshiptsBalanceDetails: this.output[i].CMSshiptsBalanceDetails ? this.output[i].CMSshiptsBalanceDetails : '',
              OriginalBoESubmittedDate: this.output[i].OriginalBoESubmittedDate ? this.output[i].OriginalBoESubmittedDate : '',
              CMS_CDS_Product_NameRrProjectCode: this.output[i].CMS_CDS_Product_NameRrProjectCode ? this.output[i].CMS_CDS_Product_NameRrProjectCode : '',
              GrossWeight_Kg: this.output[i].GrossWeight_Kg ? this.output[i].GrossWeight_Kg : '',
              DistanceInKms: this.output[i].DistanceInKms ? this.output[i].DistanceInKms : '',
              Co2Emiission_Kg: this.output[i].Co2Emiission_Kg ? this.output[i].Co2Emiission_Kg : ''
            };
            this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_10__["environment"].apiUrl_base) + '/import/importRecordExelAdd/', object).subscribe(object => {
              var conti = i + 1;
              this.Message = conti + " Shipments Imported";
              var cont = this.output.length - 5;

              if (cont == i) {
                this.Message = "File Successfully Import";
                this.isLoadingResults = false;
              }
            }, err => {
              this.isLoadingResults = false;
              this.getTableData();
            });
          }
        };

        setTimeout(() => {
          document.getElementById("accordionid").click();
          this.Message = null;
        }, 26500);
        fileReader.readAsArrayBuffer(this.file);
      }

      deleteimportshipment(cid) {
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_10__["environment"].apiUrl_base) + '/import/removeimportShipment/' + cid).subscribe(datar => {
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
          }, 1000);
          this.getTableData();
        }, err => {});
      }

      getTableData() {
        this.loader = true;
        this.paginateData.searchKey = this.searchField;
        this.http.post(this.apiService.GET_IMPORT_ALL_SHIPMENTS, this.paginateData).subscribe(data => {
          this.importedData = data;
          this.loader = false;
        });
      }

      getPaginatorData(e) {
        this.paginateData = {
          pagePer: e.pageSize,
          pageNo: e.pageIndex + 1,
          searchKey: this.searchField
        };
        window.scroll(0, 0);
        this.getTableData();
      }

      onSubmit() {
        var data = {
          pagePer: 10,
          pageNo: 1
        };
        data['searchKey'] = this.searchField.trim();
        this.loader = true;
        this.http.post(this.apiService.GET_IMPORT_ALL_SHIPMENTS, data).subscribe(data => {
          this.importedData = data;
          this.loader = false;
        });
      }

      exportAsXLSX() {
        this.excelLoader = true;
        this.http.get(this.apiService.GET_TOTAL_IMPORT_SHIPMENTS).subscribe(data => {
          this.excelService.exportAsExcelFile(data, 'GVK-Import');
          this.excelLoader = false;
        }, err => {
          this.excelLoader = false;
        });
      }

    };

    ImportRecordsListComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__["MatDialog"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_5__["DataService"]
    }, {
      type: _services_excel_service__WEBPACK_IMPORTED_MODULE_4__["ExcelService"]
    }, {
      type: _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_11__["ApiServicesService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_8__["MatPaginator"])], ImportRecordsListComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_9__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_9__["MatSort"])], ImportRecordsListComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], ImportRecordsListComponent.prototype, "filter", void 0);
    ImportRecordsListComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-import-records-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./import-records-list.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/import-records-list/import-records-list.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./import-records-list.component.scss */
      "./src/app/import-records-list/import-records-list.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"], _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_7__["MatDialog"], _services_data_service__WEBPACK_IMPORTED_MODULE_5__["DataService"], _services_excel_service__WEBPACK_IMPORTED_MODULE_4__["ExcelService"], _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_11__["ApiServicesService"]])], ImportRecordsListComponent);
    /***/
  },

  /***/
  "./src/app/import-reports/import-reports.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/import-reports/import-reports.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppImportReportsImportReportsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".exp .fil-sec {\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n\n.fil-sec .d-flex .form-control {\n  margin-right: 5px;\n}\n\n.fil-sec .d-flex .form-control:last-child {\n  margin-right: 0;\n}\n\n.exp-sec h4 {\n  background: #e9f8ff;\n  padding: 5px 10px;\n  margin-bottom: 0;\n  text-align: center;\n  font-size: 16px;\n}\n\n.table th, .table td {\n  padding: 5px 6px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaW1wb3J0LXJlcG9ydHMvRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcaW1wb3J0LXJlcG9ydHNcXGltcG9ydC1yZXBvcnRzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9pbXBvcnQtcmVwb3J0cy9pbXBvcnQtcmVwb3J0cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQTtFQUNJLGlCQUFBO0FDRUo7O0FEQUU7RUFDRSxlQUFBO0FDR0o7O0FEREE7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNJSjs7QURGQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNLSiIsImZpbGUiOiJzcmMvYXBwL2ltcG9ydC1yZXBvcnRzL2ltcG9ydC1yZXBvcnRzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4cCAuZmlsLXNlY3tcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG59XHJcbi5maWwtc2VjIC5kLWZsZXggLmZvcm0tY29udHJvbHtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gIH1cclxuICAuZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2w6bGFzdC1jaGlsZHtcclxuICAgIG1hcmdpbi1yaWdodDogMDtcclxuICB9XHJcbi5leHAtc2VjIGg0e1xyXG4gICAgYmFja2dyb3VuZDogI2U5ZjhmZjtcclxuICAgIHBhZGRpbmc6IDVweCAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG4udGFibGUgdGgsIC50YWJsZSB0ZCB7XHJcbiAgICBwYWRkaW5nOiA1cHggNnB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59IiwiLmV4cCAuZmlsLXNlYyB7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG5cbi5maWwtc2VjIC5kLWZsZXggLmZvcm0tY29udHJvbCB7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xufVxuXG4uZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2w6bGFzdC1jaGlsZCB7XG4gIG1hcmdpbi1yaWdodDogMDtcbn1cblxuLmV4cC1zZWMgaDQge1xuICBiYWNrZ3JvdW5kOiAjZTlmOGZmO1xuICBwYWRkaW5nOiA1cHggMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi50YWJsZSB0aCwgLnRhYmxlIHRkIHtcbiAgcGFkZGluZzogNXB4IDZweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/import-reports/import-reports.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/import-reports/import-reports.component.ts ***!
    \************************************************************/

  /*! exports provided: ImportReportsComponent */

  /***/
  function srcAppImportReportsImportReportsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ImportReportsComponent", function () {
      return ImportReportsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @app/_services/api-services.service */
    "./src/app/_services/api-services.service.ts");
    /* harmony import */


    var _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @app/_services/authentication.service */
    "./src/app/_services/authentication.service.ts");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! xlsx */
    "./node_modules/xlsx/xlsx.js");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_6__);

    let ImportReportsComponent = class ImportReportsComponent {
      constructor(fb, http, apiService, authService) {
        this.fb = fb;
        this.http = http;
        this.apiService = apiService;
        this.authService = authService;
        this.carrierShow = true;
        this.chaShow = true;
        this.submitted = false;
        this.carriers = ['FedEx DG', 'FedEx-Non DG', 'FedEx All', 'DHL DG', 'DHL-Non DG', 'DHL All', 'OTHERS'];
        this.cha = ['DHL', 'OSBL', 'CSR', 'OTHERS'];
        this.cat = ['Clearance TAT', 'Transit TAT'];
      }

      ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
          this.user = this.authService.currentUserValue;
          this.searchForm = this.fb.group({
            'carriers': [[]],
            'cha': [[]],
            'category': [[]],
            'days': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'fromDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'toDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'userId': [this.user.id],
            'zone': [[]]
          });
          this.settings = {
            singleSelection: false,
            enableCheckAll: true,
            allowSearchFilter: true,
            limitSelection: -1,
            clearSearchFilter: true,
            maxHeight: 197,
            itemsShowLimit: 2,
            closeDropDownOnSelection: false,
            showSelectedItemsAtTop: false,
            defaultOpen: false
          };
          yield this.zonesList();
        });
      }

      onSubmit() {
        this.submitted = true;

        if (this.searchForm.invalid) {
          return;
        }

        this.loading = true;
        this.http.post(this.apiService.GET_IMPORT_REPORTS, this.searchForm.value).subscribe(data => {
          this.importData = data;

          if (this.importData.response['Transit TAT']) {
            var a = [];

            for (let data in this.importData.response['Transit TAT']) {
              a.push(data);
            }

            if (a.includes('FedEx-Non DG') && a.includes('FedEx DG')) {
              const index = a.indexOf("FedEx All");

              if (index > -1) {
                a.splice(index, 1);
              }
            }

            if (a.includes('DHL DG') && a.includes('DHL-Non DG')) {
              const index = a.indexOf("DHL All");

              if (index > -1) {
                a.splice(index, 1);
              }
            }

            var totalNo = 0;
            var onTime = 0;
            var delay = 0;
            a.forEach(obj => {
              var res = this.importData.response['Transit TAT'][obj];
              totalNo += res.totalNo;
              onTime += res.onTime;
              delay += res.delay;
            });
            this.importData["totalShipments"]['Transit TAT'] = {
              totalNo: totalNo,
              onTime: onTime,
              delay: delay
            };
          }

          this.loading = false;
        });
      }

      get f() {
        return this.searchForm.controls;
      }

      onItemSelect(item) {
        if (this.searchForm.value.category.length == 2) {
          this.carrierShow = true;
          this.chaShow = true;
        } else if (item == 'Clearance TAT') {
          this.carrierShow = false;
          this.chaShow = true;
        } else if (item == 'Transit TAT') {
          this.carrierShow = true;
          this.chaShow = false;
        }
      }

      onDeSelect(item) {
        var data = this.searchForm.value.category;

        if (item == 'Clearance TAT' && data[0] == 'Transit TAT') {
          this.carrierShow = true;
          this.chaShow = false;
        } else if (item == 'Transit TAT' && data[0] == 'Clearance TAT') {
          this.carrierShow = false;
          this.chaShow = true;
        } else {
          this.carrierShow = true;
          this.chaShow = true;
        }
      }

      onSelectAll(item) {
        this.carrierShow = true;
        this.chaShow = true;
      }

      onDeSelectAll(item) {
        this.carrierShow = true;
        this.chaShow = true;
      }

      zonesList() {
        this.zonesLoader = true;
        this.http.get(this.apiService.ZONES_LIST).subscribe(data => {
          this.zonesData = [];
          data['zones'].forEach(obj => {
            if (obj.Zone) {
              this.zonesData.push(obj.Zone);
            }
          });
          this.zonesLoader = false;
        });
      }

      exportAsXLSX() {
        var ws;
        var wb;
        wb = xlsx__WEBPACK_IMPORTED_MODULE_6__["utils"].book_new();
        let element = document.getElementById('excel-table');
        ws = xlsx__WEBPACK_IMPORTED_MODULE_6__["utils"].table_to_sheet(element);
        xlsx__WEBPACK_IMPORTED_MODULE_6__["utils"].book_append_sheet(wb, ws);
        xlsx__WEBPACK_IMPORTED_MODULE_6__["writeFile"](wb, "reports.xlsx");
      }

    };

    ImportReportsComponent.ctorParameters = () => [{
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
    }, {
      type: _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"]
    }, {
      type: _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]
    }];

    ImportReportsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-import-reports',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./import-reports.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/import-reports/import-reports.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./import-reports.component.scss */
      "./src/app/import-reports/import-reports.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"], _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]])], ImportReportsComponent);
    /***/
  },

  /***/
  "./src/app/login/index.ts":
  /*!********************************!*\
    !*** ./src/app/login/index.ts ***!
    \********************************/

  /*! exports provided: LoginComponent */

  /***/
  function srcAppLoginIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _login_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./login.component */
    "./src/app/login/login.component.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "LoginComponent", function () {
      return _login_component__WEBPACK_IMPORTED_MODULE_1__["LoginComponent"];
    });
    /***/

  },

  /***/
  "./src/app/login/login.component.scss":
  /*!********************************************!*\
    !*** ./src/app/login/login.component.scss ***!
    \********************************************/

  /*! exports provided: default */

  /***/
  function srcAppLoginLoginComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".d-none.d-lg-flex.col-lg-8.align-items-center.ui-bg-cover.ui-bg-overlay-container.p-5 {\n  float: left;\n}\n\n.btn-primary {\n  background: #26B4FF !important;\n  color: #fff;\n}\n\napp-footer span {\n  display: none;\n}\n\n.footer-text.font-weight-bolder {\n  display: none !important;\n}\n\napp-footer {\n  display: none !important;\n}\n\nspan.footer-text.font-weight-bolder {\n  display: none;\n}\n\napp-footer pt-3 {\n  position: absolute;\n  width: 100%;\n  bottom: 0;\n  text-align: right;\n  padding: 10px 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcbG9naW5cXGxvZ2luLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9sb2dpbi9sb2dpbi5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLFdBQUE7QUNBSjs7QURHQTtFQUNBLDhCQUFBO0VBQ0EsV0FBQTtBQ0FBOztBREVBO0VBRUksYUFBQTtBQ0FKOztBREdBO0VBQ0ksd0JBQUE7QUNBSjs7QURFQTtFQUVJLHdCQUFBO0FDQUo7O0FER0E7RUFDSSxhQUFBO0FDQUo7O0FERUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQ0NBIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZC1ub25lLmQtbGctZmxleC5jb2wtbGctOC5hbGlnbi1pdGVtcy1jZW50ZXIudWktYmctY292ZXIudWktYmctb3ZlcmxheS1jb250YWluZXIucC01IHtcclxuXHJcbiAgICBmbG9hdDogbGVmdDtcclxuXHJcbn1cclxuLmJ0bi1wcmltYXJ5e1xyXG5iYWNrZ3JvdW5kOiAjMjZCNEZGICFpbXBvcnRhbnQ7XHJcbmNvbG9yOiNmZmY7XHJcbn1cclxuYXBwLWZvb3RlciBzcGFue1xyXG5cclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcblxyXG59XHJcbi5mb290ZXItdGV4dC5mb250LXdlaWdodC1ib2xkZXIge1xyXG4gICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xyXG59XHJcbmFwcC1mb290ZXIge1xyXG5cclxuICAgIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcclxuXHJcbn1cclxuc3Bhbi5mb290ZXItdGV4dC5mb250LXdlaWdodC1ib2xkZXIge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxufVxyXG5hcHAtZm9vdGVyIHB0LTN7XHJcbnBvc2l0aW9uOiBhYnNvbHV0ZTtcclxud2lkdGg6IDEwMCU7XHJcbmJvdHRvbTogMDtcclxudGV4dC1hbGlnbjogcmlnaHQ7XHJcbnBhZGRpbmc6IDEwcHggMTVweDtcclxufSIsIi5kLW5vbmUuZC1sZy1mbGV4LmNvbC1sZy04LmFsaWduLWl0ZW1zLWNlbnRlci51aS1iZy1jb3Zlci51aS1iZy1vdmVybGF5LWNvbnRhaW5lci5wLTUge1xuICBmbG9hdDogbGVmdDtcbn1cblxuLmJ0bi1wcmltYXJ5IHtcbiAgYmFja2dyb3VuZDogIzI2QjRGRiAhaW1wb3J0YW50O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuYXBwLWZvb3RlciBzcGFuIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLmZvb3Rlci10ZXh0LmZvbnQtd2VpZ2h0LWJvbGRlciB7XG4gIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcbn1cblxuYXBwLWZvb3RlciB7XG4gIGRpc3BsYXk6IG5vbmUgIWltcG9ydGFudDtcbn1cblxuc3Bhbi5mb290ZXItdGV4dC5mb250LXdlaWdodC1ib2xkZXIge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG5hcHAtZm9vdGVyIHB0LTMge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICBib3R0b206IDA7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBwYWRkaW5nOiAxMHB4IDE1cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/login/login.component.ts":
  /*!******************************************!*\
    !*** ./src/app/login/login.component.ts ***!
    \******************************************/

  /*! exports provided: LoginComponent */

  /***/
  function srcAppLoginLoginComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginComponent", function () {
      return LoginComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");

    let LoginComponent = class LoginComponent {
      constructor(formBuilder, route, router, authenticationService, alertService) {
        this.formBuilder = formBuilder;
        this.route = route;
        this.router = router;
        this.authenticationService = authenticationService;
        this.alertService = alertService;
        this.loading = false;
        this.submitted = false; // redirect to home if already logged in

        if (this.authenticationService.currentUserValue) {
          this.router.navigate(['/import-records']);
        }
      }

      ngOnInit() {
        this.loginForm = this.formBuilder.group({
          email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
          password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]
        }); // get return url from route parameters or default to '/'

        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/import-records';
      } // convenience getter for easy access to form fields


      get f() {
        return this.loginForm.controls;
      }

      onSubmit() {
        this.submitted = true; // stop here if form is invalid

        if (this.loginForm.invalid) {
          return;
        }

        this.loading = true;
        this.authenticationService.login(this.f.email.value, this.f.password.value).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["first"])()).subscribe(data => {
          if (data) {
            this.router.navigate([this.returnUrl]);
          } else {
            this.alertService.error('Enter Valid Credentials');
            this.loading = false;
          }
        }, error => {
          this.alertService.error(error);
          this.loading = false;
        });
      }

    };

    LoginComponent.ctorParameters = () => [{
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_5__["AlertService"]
    }];

    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./login.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./login.component.scss */
      "./src/app/login/login.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _app_services__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_5__["AlertService"]])], LoginComponent);
    /***/
  },

  /***/
  "./src/app/models/issue.ts":
  /*!*********************************!*\
    !*** ./src/app/models/issue.ts ***!
    \*********************************/

  /*! exports provided: Issue */

  /***/
  function srcAppModelsIssueTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Issue", function () {
      return Issue;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    class Issue {}
    /***/

  },

  /***/
  "./src/app/navbar/navbar.component.scss":
  /*!**********************************************!*\
    !*** ./src/app/navbar/navbar.component.scss ***!
    \**********************************************/

  /*! exports provided: default */

  /***/
  function srcAppNavbarNavbarComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL25hdmJhci9uYXZiYXIuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/navbar/navbar.component.ts":
  /*!********************************************!*\
    !*** ./src/app/navbar/navbar.component.ts ***!
    \********************************************/

  /*! exports provided: NavbarComponent */

  /***/
  function srcAppNavbarNavbarComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NavbarComponent", function () {
      return NavbarComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    let NavbarComponent = class NavbarComponent {
      constructor() {}

      ngOnInit() {}

    };
    NavbarComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-navbar',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./navbar.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/navbar/navbar.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./navbar.component.scss */
      "./src/app/navbar/navbar.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], NavbarComponent);
    /***/
  },

  /***/
  "./src/app/overall-reports/overall-reports.component.scss":
  /*!****************************************************************!*\
    !*** ./src/app/overall-reports/overall-reports.component.scss ***!
    \****************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOverallReportsOverallReportsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".exp .fil-sec {\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n\n.fil-sec .d-flex .form-control {\n  margin-right: 5px;\n}\n\n.fil-sec .d-flex .form-control:last-child {\n  margin-right: 0;\n}\n\n.exp-sec h4 {\n  background: #e9f8ff;\n  padding: 5px 10px;\n  margin-bottom: 0;\n  text-align: center;\n  font-size: 16px;\n}\n\n.table th, .table td {\n  padding: 5px 6px;\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvb3ZlcmFsbC1yZXBvcnRzL0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXG92ZXJhbGwtcmVwb3J0c1xcb3ZlcmFsbC1yZXBvcnRzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9vdmVyYWxsLXJlcG9ydHMvb3ZlcmFsbC1yZXBvcnRzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7RUFDQSxtQkFBQTtBQ0NKOztBRENBO0VBQ0ksaUJBQUE7QUNFSjs7QURBRTtFQUNFLGVBQUE7QUNHSjs7QUREQTtFQUNJLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ0lKOztBREZBO0VBQ0ksZ0JBQUE7RUFDQSxrQkFBQTtBQ0tKIiwiZmlsZSI6InNyYy9hcHAvb3ZlcmFsbC1yZXBvcnRzL292ZXJhbGwtcmVwb3J0cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5leHAgLmZpbC1zZWN7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufVxyXG4uZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2x7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICB9XHJcbiAgLmZpbC1zZWMgLmQtZmxleCAuZm9ybS1jb250cm9sOmxhc3QtY2hpbGR7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgfVxyXG4uZXhwLXNlYyBoNHtcclxuICAgIGJhY2tncm91bmQ6ICNlOWY4ZmY7XHJcbiAgICBwYWRkaW5nOiA1cHggMTBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuLnRhYmxlIHRoLCAudGFibGUgdGQge1xyXG4gICAgcGFkZGluZzogNXB4IDZweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufSIsIi5leHAgLmZpbC1zZWMge1xuICBtYXJnaW4tdG9wOiAxNXB4O1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufVxuXG4uZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2wge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbn1cblxuLmZpbC1zZWMgLmQtZmxleCAuZm9ybS1jb250cm9sOmxhc3QtY2hpbGQge1xuICBtYXJnaW4tcmlnaHQ6IDA7XG59XG5cbi5leHAtc2VjIGg0IHtcbiAgYmFja2dyb3VuZDogI2U5ZjhmZjtcbiAgcGFkZGluZzogNXB4IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4udGFibGUgdGgsIC50YWJsZSB0ZCB7XG4gIHBhZGRpbmc6IDVweCA2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/overall-reports/overall-reports.component.ts":
  /*!**************************************************************!*\
    !*** ./src/app/overall-reports/overall-reports.component.ts ***!
    \**************************************************************/

  /*! exports provided: OverallReportsComponent */

  /***/
  function srcAppOverallReportsOverallReportsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OverallReportsComponent", function () {
      return OverallReportsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @app/_services/api-services.service */
    "./src/app/_services/api-services.service.ts");
    /* harmony import */


    var _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @app/_services/authentication.service */
    "./src/app/_services/authentication.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! xlsx */
    "./node_modules/xlsx/xlsx.js");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_6__);

    let OverallReportsComponent = class OverallReportsComponent {
      constructor(http, apiService, authService, fb) {
        this.http = http;
        this.apiService = apiService;
        this.authService = authService;
        this.fb = fb;
        this.carrierShow = true;
        this.chaShow = true;
        this.submitted = false;
        this.carriers = ['FedEx DG', 'FedEx-Non DG', 'FedEx All', 'DHL DG', 'DHL-Non DG', 'DHL All', 'OTHERS'];
        this.cha = ['DHL', 'OSBL', 'CSR', 'OTHERS'];
        this.cat = ['Clearance TAT', 'Transit TAT'];
      }

      ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
          this.user = this.authService.currentUserValue;
          this.searchForm = this.fb.group({
            'carriers': [[]],
            'cha': [[]],
            'category': [[]],
            'fromDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            'toDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required],
            'userId': [this.user.id],
            'zone': [[]]
          });
          this.settings = {
            singleSelection: false,
            enableCheckAll: true,
            allowSearchFilter: true,
            limitSelection: -1,
            clearSearchFilter: true,
            maxHeight: 197,
            itemsShowLimit: 2,
            closeDropDownOnSelection: false,
            showSelectedItemsAtTop: false,
            defaultOpen: false
          };
          yield this.zonesList();
        });
      }

      get f() {
        return this.searchForm.controls;
      }

      onSubmit() {
        this.submitted = true;

        if (this.searchForm.invalid) {
          return;
        }

        this.loading = true;
        this.http.post(this.apiService.GET_OVERALL_REPORTS, this.searchForm.value).subscribe(data => {
          this.importData = data;

          if (this.importData.response['Transit TAT']) {
            //Transit TAT CALCULATION
            var a = [];

            for (let data in this.importData.response['Transit TAT']) {
              a.push(data);
            }

            if (a.includes('FedEx-Non DG') && a.includes('FedEx DG') && a.includes('FedEx All')) {
              const index1 = a.indexOf("FedEx-Non DG");

              if (index1 > -1) {
                a.splice(index1, 1);
              }

              const index2 = a.indexOf("FedEx DG");

              if (index2 > -1) {
                a.splice(index2, 1);
              }
            }

            if (a.includes('DHL DG') && a.includes('DHL-Non DG') && a.includes('DHL All')) {
              const index3 = a.indexOf("DHL DG");

              if (index3 > -1) {
                a.splice(index3, 1);
              }

              const index4 = a.indexOf("DHL-Non DG");

              if (index4 > -1) {
                a.splice(index4, 1);
              }
            }

            var totalNo = 0;
            var onTime = 0;
            var delay = 0;
            a.forEach(obj => {
              var res = this.importData.response['Transit TAT'][obj];
              totalNo += res.totalNo;
              onTime += res.onTime;
              delay += res.delay;
            });
            this.importData["totalShipments"]['Transit TAT'] = {
              totalNo: totalNo,
              onTime: onTime,
              delay: delay
            };
          }

          this.loading = false;
        });
      }

      onItemSelect(item) {
        if (this.searchForm.value.category.length == 2) {
          this.carrierShow = true;
          this.chaShow = true;
        } else if (item == 'Clearance TAT') {
          this.carrierShow = false;
          this.chaShow = true;
        } else if (item == 'Transit TAT') {
          this.carrierShow = true;
          this.chaShow = false;
        }
      }

      onDeSelect(item) {
        var data = this.searchForm.value.category;

        if (item == 'Clearance TAT' && data[0] == 'Transit TAT') {
          this.carrierShow = true;
          this.chaShow = false;
        } else if (item == 'Transit TAT' && data[0] == 'Clearance TAT') {
          this.carrierShow = false;
          this.chaShow = true;
        } else {
          this.carrierShow = true;
          this.chaShow = true;
        }
      }

      onSelectAll(item) {
        this.carrierShow = true;
        this.chaShow = true;
      }

      onDeSelectAll(item) {
        this.carrierShow = true;
        this.chaShow = true;
      }

      zonesList() {
        this.zonesLoader = true;
        this.http.get(this.apiService.ZONES_LIST).subscribe(data => {
          this.zonesData = [];
          data['zones'].forEach(obj => {
            if (obj.Zone) {
              this.zonesData.push(obj.Zone);
            }
          });
          this.zonesLoader = false;
        });
      }

      exportAsXLSX() {
        var ws;
        var wb;
        wb = xlsx__WEBPACK_IMPORTED_MODULE_6__["utils"].book_new();
        let element = document.getElementById('excel-table');
        ws = xlsx__WEBPACK_IMPORTED_MODULE_6__["utils"].table_to_sheet(element);
        xlsx__WEBPACK_IMPORTED_MODULE_6__["utils"].book_append_sheet(wb, ws);
        xlsx__WEBPACK_IMPORTED_MODULE_6__["writeFile"](wb, "reports.xlsx");
      }

    };

    OverallReportsComponent.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
    }, {
      type: _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_3__["ApiServicesService"]
    }, {
      type: _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]
    }];

    OverallReportsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-overall-reports',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./overall-reports.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/overall-reports/overall-reports.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./overall-reports.component.scss */
      "./src/app/overall-reports/overall-reports.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"], _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_3__["ApiServicesService"], _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_4__["AuthenticationService"], _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"]])], OverallReportsComponent);
    /***/
  },

  /***/
  "./src/app/privacy-policy/privacy-policy.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/privacy-policy/privacy-policy.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPrivacyPolicyPrivacyPolicyComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ByaXZhY3ktcG9saWN5L3ByaXZhY3ktcG9saWN5LmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/privacy-policy/privacy-policy.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/privacy-policy/privacy-policy.component.ts ***!
    \************************************************************/

  /*! exports provided: PrivacyPolicyComponent */

  /***/
  function srcAppPrivacyPolicyPrivacyPolicyComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PrivacyPolicyComponent", function () {
      return PrivacyPolicyComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let PrivacyPolicyComponent = class PrivacyPolicyComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.page_name = '';
        this.page_description = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getpageDetails(2);
        this.settingForm = this.formBuilder.group({
          'page_description': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        let cid = 2;
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/settings/pageUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/custom-holidays']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      getpageDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/settings/pagedetails/' + cNo).subscribe(dataaa => {
          this.settingForm.setValue({
            page_description: dataaa[0].page_description
          });
        });
      }

    };

    PrivacyPolicyComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    PrivacyPolicyComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-privacy-policy',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./privacy-policy.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/privacy-policy/privacy-policy.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./privacy-policy.component.scss */
      "./src/app/privacy-policy/privacy-policy.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], PrivacyPolicyComponent);
    /***/
  },

  /***/
  "./src/app/register/index.ts":
  /*!***********************************!*\
    !*** ./src/app/register/index.ts ***!
    \***********************************/

  /*! exports provided: RegisterComponent */

  /***/
  function srcAppRegisterIndexTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _register_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./register.component */
    "./src/app/register/register.component.ts");
    /* harmony reexport (safe) */


    __webpack_require__.d(__webpack_exports__, "RegisterComponent", function () {
      return _register_component__WEBPACK_IMPORTED_MODULE_1__["RegisterComponent"];
    });
    /***/

  },

  /***/
  "./src/app/register/register.component.ts":
  /*!************************************************!*\
    !*** ./src/app/register/register.component.ts ***!
    \************************************************/

  /*! exports provided: RegisterComponent */

  /***/
  function srcAppRegisterRegisterComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RegisterComponent", function () {
      return RegisterComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");

    let RegisterComponent = class RegisterComponent {
      constructor(formBuilder, router, authenticationService, userService, alertService) {
        this.formBuilder = formBuilder;
        this.router = router;
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.alertService = alertService;
        this.loading = false;
        this.submitted = false; // redirect to home if already logged in

        if (this.authenticationService.currentUserValue) {
          this.router.navigate(['/']);
        }
      }

      ngOnInit() {
        this.registerForm = this.formBuilder.group({
          firstName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
          lastName: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
          username: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
          password: ['', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(6)]]
        });
      } // convenience getter for easy access to form fields


      get f() {
        return this.registerForm.controls;
      }

      onSubmit() {
        this.submitted = true; // stop here if form is invalid

        if (this.registerForm.invalid) {
          return;
        }

        this.loading = true;
        this.userService.register(this.registerForm.value).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["first"])()).subscribe(data => {
          this.alertService.success('Registration successful', true);
          this.router.navigate(['/login']);
        }, error => {
          this.alertService.error(error);
          this.loading = false;
        });
      }

    };

    RegisterComponent.ctorParameters = () => [{
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_5__["UserService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_5__["AlertService"]
    }];

    RegisterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./register.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/register/register.component.html")).default
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _app_services__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_5__["UserService"], _app_services__WEBPACK_IMPORTED_MODULE_5__["AlertService"]])], RegisterComponent);
    /***/
  },

  /***/
  "./src/app/services/data.service.ts":
  /*!******************************************!*\
    !*** ./src/app/services/data.service.ts ***!
    \******************************************/

  /*! exports provided: DataService */

  /***/
  function srcAppServicesDataServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DataService", function () {
      return DataService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    const httpOptions = {
      headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
        'Content-Type': 'application/json'
      })
    };
    let DataService = class DataService {
      constructor(httpClient) {
        this.httpClient = httpClient;
        this.apiUrl = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + "/products";
        this.API_URL = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/export/export_shipments/';
        this.API_URL_AllImportRecords = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/import/allshipments';
        this.API_URL_Vendorslist = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/vendor/vendorsList';
        this.API_URL_Countries = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/country/countries';
        this.API_URL_carriers = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/carrier/carrierlist';
        this.API_URL_Currenylist = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/currency/currencies/';
        this.API_URL_chalist = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/cha/chalist/';
        this.API_URL_userslist = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/users/userslist/';
        this.API_URL_settings = "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].apiUrl_base) + '/settings/pageslist/';
        this.settingChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.dataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.importDataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.carrierDataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.userDataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.countriesDataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.vendorDataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.currencyDataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.chaDataChange = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
        this.isLoadingResults = false;
      }

      get data() {
        return this.dataChange.value;
      }

      get settingdat() {
        return this.settingChange.value;
      }

      get vendorData() {
        return this.vendorDataChange.value;
      }

      get carrierData() {
        return this.carrierDataChange.value;
      }

      get userData() {
        return this.userDataChange.value;
      }

      get countriesData() {
        return this.countriesDataChange.value;
      }

      get currencyData() {
        return this.currencyDataChange.value;
      }

      get chaData() {
        return this.chaDataChange.value;
      }

      get importData() {
        return this.importDataChange.value;
      }

      getDialogData() {
        return this.dialogData;
      }
      /** Get All Export Records */


      getAllIssues() {
        this.httpClient.get(this.API_URL).subscribe(data => {
          this.dataChange.next(data);
        }, error => {});
      }
      /** Get All Import Records */


      getAllImportRecords() {
        this.httpClient.get(this.API_URL_AllImportRecords).subscribe(data => {
          this.isLoadingResults = false;
          this.importDataChange.next(data);
        }, error => {});
      }
      /** CRUD getVendors */


      getVendors() {
        this.httpClient.get(this.API_URL_Vendorslist).subscribe(datav => {
          this.vendorDataChange.next(datav);
        }, error => {});
      }
      /** CRUD getCurrency */


      getCurrency() {
        this.httpClient.get(this.API_URL_Currenylist).subscribe(datav => {
          this.currencyDataChange.next(datav);
        }, error => {});
      }
      /** CRUD getCha*/


      getCha() {
        this.httpClient.get(this.API_URL_chalist).subscribe(datavss => {
          this.chaDataChange.next(datavss);
        }, error => {});
      }
      /** CRUD get Carriers */


      getCarriers() {
        this.httpClient.get(this.API_URL_carriers).subscribe(datav => {
          this.carrierDataChange.next(datav);
        }, error => {});
      }
      /** CRUD get Users */


      getUsers() {
        this.httpClient.get(this.API_URL_userslist).subscribe(datav => {
          this.userDataChange.next(datav.result);
        }, error => {});
      }
      /** CRUD get Countries */


      getCountries() {
        this.httpClient.get(this.API_URL_Countries).subscribe(datav => {
          this.countriesDataChange.next(datav);
        }, error => {});
      } // DEMO ONLY, you can find working methods below


      addIssue(issue) {
        this.dialogData = issue;
      }

      updateIssue(issue) {
        this.dialogData = issue;
      }

      deleteIssue(id) {}

    };

    DataService.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
    }];

    DataService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])], DataService);
    /***/
  },

  /***/
  "./src/app/services/excel.service.ts":
  /*!*******************************************!*\
    !*** ./src/app/services/excel.service.ts ***!
    \*******************************************/

  /*! exports provided: ExcelService */

  /***/
  function srcAppServicesExcelServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExcelService", function () {
      return ExcelService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! file-saver */
    "./node_modules/file-saver/dist/FileSaver.min.js");
    /* harmony import */


    var file_saver__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_2__);
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! xlsx */
    "./node_modules/xlsx/xlsx.js");
    /* harmony import */


    var xlsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_3__);

    const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const EXCEL_EXTENSION = '.xlsx';
    let ExcelService = class ExcelService {
      constructor() {}

      exportAsExcelFile(json, excelFileName) {
        const worksheet = xlsx__WEBPACK_IMPORTED_MODULE_3__["utils"].json_to_sheet(json);
        const workbook = {
          Sheets: {
            'data': worksheet
          },
          SheetNames: ['data']
        };
        const excelBuffer = xlsx__WEBPACK_IMPORTED_MODULE_3__["write"](workbook, {
          bookType: 'xlsx',
          type: 'array'
        }); //const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

        this.saveAsExcelFile(excelBuffer, excelFileName);
      }

      saveAsExcelFile(buffer, fileName) {
        const data = new Blob([buffer], {
          type: EXCEL_TYPE
        });
        file_saver__WEBPACK_IMPORTED_MODULE_2__["saveAs"](data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
      }

    };
    ExcelService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], ExcelService);
    /***/
  },

  /***/
  "./src/app/settings-add/settings-add.component.scss":
  /*!**********************************************************!*\
    !*** ./src/app/settings-add/settings-add.component.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSettingsAddSettingsAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NldHRpbmdzLWFkZC9zZXR0aW5ncy1hZGQuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/settings-add/settings-add.component.ts":
  /*!********************************************************!*\
    !*** ./src/app/settings-add/settings-add.component.ts ***!
    \********************************************************/

  /*! exports provided: SettingsAddComponent */

  /***/
  function srcAppSettingsAddSettingsAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SettingsAddComponent", function () {
      return SettingsAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let SettingsAddComponent = class SettingsAddComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.page_name = '';
        this.page_description = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.settingForm = this.formBuilder.group({
          'page_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'page_description': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/settings/pageadd/', form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record  Successfully inserted";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/custom-holidays']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

    };

    SettingsAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    SettingsAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-settings-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./settings-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/settings-add/settings-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./settings-add.component.scss */
      "./src/app/settings-add/settings-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], SettingsAddComponent);
    /***/
  },

  /***/
  "./src/app/settings-edit/settings-edit.component.scss":
  /*!************************************************************!*\
    !*** ./src/app/settings-edit/settings-edit.component.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSettingsEditSettingsEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NldHRpbmdzLWVkaXQvc2V0dGluZ3MtZWRpdC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/settings-edit/settings-edit.component.ts":
  /*!**********************************************************!*\
    !*** ./src/app/settings-edit/settings-edit.component.ts ***!
    \**********************************************************/

  /*! exports provided: SettingsEditComponent */

  /***/
  function srcAppSettingsEditSettingsEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SettingsEditComponent", function () {
      return SettingsEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let SettingsEditComponent = class SettingsEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.page_name = '';
        this.page_description = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getpageDetails(this.route.snapshot.params['id']);
        this.settingForm = this.formBuilder.group({
          'page_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'page_description': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        let cid = this.route.snapshot.params['id'];
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/settings/pageUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/settings']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      getpageDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/settings/pagedetails/' + cNo).subscribe(dataaa => {
          this.settingForm.setValue({
            page_name: dataaa[0].page_name,
            page_description: dataaa[0].page_description
          });
        });
      }

    };

    SettingsEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    SettingsEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-settings-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./settings-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/settings-edit/settings-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./settings-edit.component.scss */
      "./src/app/settings-edit/settings-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], SettingsEditComponent);
    /***/
  },

  /***/
  "./src/app/settings/settings.component.scss":
  /*!**************************************************!*\
    !*** ./src/app/settings/settings.component.scss ***!
    \**************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSettingsSettingsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  float: left;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3MvRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcc2V0dGluZ3NcXHNldHRpbmdzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9zZXR0aW5ncy9zZXR0aW5ncy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FDQ0o7O0FEQ0E7RUFDSSxnQkFBQTtBQ0VKOztBREFBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtBQ0dKOztBRERDO0VBQ0EseUJBQUE7RUFDQSxnQ0FBQTtBQ0lEOztBREZFO0VBQ0UsK0JBQUE7RUFDSCxtQkFBQTtFQUNBLGdDQUFBO0VBQ0EsY0FBQTtBQ0tEOztBREhBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0FDTUE7O0FESkE7RUFDRSxxQkFBQTtFQUNFLFdBQUE7RUFDSCxnQkFBQTtBQ09EOztBRExBO0VBQ0EsVUFBQTtBQ1FBOztBRE5BO0VBQ0EsVUFBQTtBQ1NBOztBRFBBO0VBQ0EseUJBQUE7QUNVQTs7QURSQTtFQUNBLGlCQUFBO0FDV0E7O0FEVEE7RUFDQSxvQkFBQTtBQ1lBOztBRFZBO0VBQ0EsV0FBQTtBQ2FBIiwiZmlsZSI6InNyYy9hcHAvc2V0dGluZ3Mvc2V0dGluZ3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWF0LWhlYWRlci1jZWxsIHtcclxuICAgIG1pbi13aWR0aDogMTAwcHg7XHJcbn1cclxuLm1hdC1jZWxsLm5nLXN0YXItaW5zZXJ0ZWQge1xyXG4gICAgbWluLXdpZHRoOiAxMDBweDtcclxufVxyXG4ubWF0LXRhYmxlIHtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgb3ZlcmZsb3cteDogYXV0bztcclxufVxyXG4gbWF0LWhlYWRlci1jZWxse1xyXG5cdGJhY2tncm91bmQtY29sb3I6ICNlOWY4ZmY7XHJcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbn1cclxuICBtYXQtY2VsbCAsIG1hdC1oZWFkZXItY2VsbHtcclxuICAgIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XHJcblx0YWxpZ24tc2VsZjogc3RyZXRjaDtcdFxyXG5cdGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xyXG5cdHBhZGRpbmc6MCA4cHg7XHJcbn1cclxuLnVwbG9hZC1mLm5nLXN0YXItaW5zZXJ0ZWR7XHJcbmRpc3BsYXk6ZmxleDtcclxufVxyXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCAsIC5pbXBvcnQtc2VjIC51cGxvYWQtYnRue1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG5cdG1hcmdpbi1ib3R0b206MDtcclxufVxyXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cHtcclxud2lkdGg6NzUlO1xyXG59XHJcbi5pbXBvcnQtc2VjIC51cGxvYWQtYnRue1xyXG53aWR0aDoyNSU7XHJcbn1cclxuLm1hdC10YWJsZXtcclxuYm9yZGVyOiAxcHggc29saWQgI2U4ZThlOTtcclxufVxyXG4udXBsb2FkLWJ0bntcclxudGV4dC1hbGlnbjpyaWdodDtcclxufVxyXG4udG9wLWJ0bnMgLmJ0bntcclxubWFyZ2luOjAgNXB4IDEwcHggMDtcclxufVxyXG5tYXQtZm9vdGVyLXJvdywgbWF0LWhlYWRlci1yb3csIG1hdC1yb3d7XHJcbmJvcmRlcjowcHhcclxufSIsIi5tYXQtaGVhZGVyLWNlbGwge1xuICBtaW4td2lkdGg6IDEwMHB4O1xufVxuXG4ubWF0LWNlbGwubmctc3Rhci1pbnNlcnRlZCB7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG5cbi5tYXQtdGFibGUge1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgb3ZlcmZsb3cteDogYXV0bztcbn1cblxubWF0LWhlYWRlci1jZWxsIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U5ZjhmZjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XG59XG5cbm1hdC1jZWxsLCBtYXQtaGVhZGVyLWNlbGwge1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU5O1xuICBhbGlnbi1zZWxmOiBzdHJldGNoO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcbiAgcGFkZGluZzogMCA4cHg7XG59XG5cbi51cGxvYWQtZi5uZy1zdGFyLWluc2VydGVkIHtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXAsIC5pbXBvcnQtc2VjIC51cGxvYWQtYnRuIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBmbG9hdDogbGVmdDtcbiAgbWFyZ2luLWJvdHRvbTogMDtcbn1cblxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXAge1xuICB3aWR0aDogNzUlO1xufVxuXG4uaW1wb3J0LXNlYyAudXBsb2FkLWJ0biB7XG4gIHdpZHRoOiAyNSU7XG59XG5cbi5tYXQtdGFibGUge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU5O1xufVxuXG4udXBsb2FkLWJ0biB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4udG9wLWJ0bnMgLmJ0biB7XG4gIG1hcmdpbjogMCA1cHggMTBweCAwO1xufVxuXG5tYXQtZm9vdGVyLXJvdywgbWF0LWhlYWRlci1yb3csIG1hdC1yb3cge1xuICBib3JkZXI6IDBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/settings/settings.component.ts":
  /*!************************************************!*\
    !*** ./src/app/settings/settings.component.ts ***!
    \************************************************/

  /*! exports provided: SettingsComponent, ExampleDataSource */

  /***/
  function srcAppSettingsSettingsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SettingsComponent", function () {
      return SettingsComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let SettingsComponent = class SettingsComponent {
      constructor(authenticationService, userService, httpClient, dialog, http, dataService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.http = http;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['page_name', 'page_description', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        this.loadData(); //       this.loadAllUsers();
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      deletecha(cid) {
        this.isLoadingResults = true;
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].apiUrl_base) + '/users/deletepage/' + cid).subscribe(datar => {
          this.isLoadingResults = false;
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
            this.refresh();
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      refresh() {
        this.loadData();
      }

      refreshTable() {
        // Refreshing table using paginator
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    SettingsComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_6__["MatPaginator"])], SettingsComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_7__["MatSort"])], SettingsComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], SettingsComponent.prototype, "filter", void 0);
    SettingsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-settings',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./settings.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./settings.component.scss */
      "./src/app/settings/settings.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_5__["MatDialog"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]])], SettingsComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_8__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_9__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.chaDataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getCha();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_9__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_10__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.chaData.slice().filter(cha => {
            const searchStr = (cha.id + cha.cha_name + cha.create_date).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'id':
              [propertyA, propertyB] = [a.id, b.id];
              break;

            case 'cha_name':
              [propertyA, propertyB] = [a.cha_name, b.cha_name];
              break;

            case 'create_date':
              [propertyA, propertyB] = [a.create_date, b.create_date];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'desc' ? 1 : -1);
        });
      }

    }
    /***/

  },

  /***/
  "./src/app/user-logs/user-logs.component.scss":
  /*!****************************************************!*\
    !*** ./src/app/user-logs/user-logs.component.scss ***!
    \****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUserLogsUserLogsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3VzZXItbG9ncy91c2VyLWxvZ3MuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/user-logs/user-logs.component.ts":
  /*!**************************************************!*\
    !*** ./src/app/user-logs/user-logs.component.ts ***!
    \**************************************************/

  /*! exports provided: UserLogsComponent */

  /***/
  function srcAppUserLogsUserLogsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserLogsComponent", function () {
      return UserLogsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let UserLogsComponent = class UserLogsComponent {
      constructor(http, router, formBuilder) {
        this.http = http;
        this.router = router;
        this.formBuilder = formBuilder;
        this.currentDate = new Date();
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.blogForm = this.formBuilder.group({
          fromDate: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required],
          toDate: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]
        });
        let params = {};
        params['userId'] = 1;
        this.UserLogs(params);
      }

      UserLogs(params) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].apiUrl_base) + '/api/user-logs/', params).subscribe(datar => {
          this.dataSource = datar.data;
          this.isLoadingResults = false;
        }, err => {
          this.isLoadingResults = false;
        });
      }

      onFormSubmit() {
        let params = {};
        params['userId'] = 1;
        params['fromDate'] = this.blogForm.value.fromDate;
        params['toDate'] = this.blogForm.value.toDate;
        this.UserLogs(params);
      }

      setFromDate(event) {
        if (!this.blogForm.value.toDate) {
          this.blogForm.patchValue({
            toDate: event.target.value
          });
        }
      }

      setToDate(event) {
        if (!this.blogForm.value.fromDate) {
          this.blogForm.patchValue({
            fromDate: event.target.value
          });
        }
      }

    };

    UserLogsComponent.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
    }];

    UserLogsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-user-logs',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./user-logs.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/user-logs/user-logs.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./user-logs.component.scss */
      "./src/app/user-logs/user-logs.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]])], UserLogsComponent);
    /***/
  },

  /***/
  "./src/app/users-add/users-add.component.scss":
  /*!****************************************************!*\
    !*** ./src/app/users-add/users-add.component.scss ***!
    \****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUsersAddUsersAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-form-field {\n  display: block;\n  position: relative;\n  text-align: left;\n  margin-left: 5%;\n  width: 90%;\n}\n\n.button-row {\n  margin-left: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnMtYWRkL0Q6XFxQcm9qZWN0c1xcZ3ZrYWRtaW4tZnJvbnRlbmQvc3JjXFxhcHBcXHVzZXJzLWFkZFxcdXNlcnMtYWRkLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91c2Vycy1hZGQvdXNlcnMtYWRkLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQ0NKOztBRENBO0VBQ0ksZUFBQTtBQ0VKIiwiZmlsZSI6InNyYy9hcHAvdXNlcnMtYWRkL3VzZXJzLWFkZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtZm9ybS1maWVsZCB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICB3aWR0aDogOTAlO1xyXG59XHJcbi5idXR0b24tcm93IHtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxufSIsIi5tYXQtZm9ybS1maWVsZCB7XG4gIGRpc3BsYXk6IGJsb2NrO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIG1hcmdpbi1sZWZ0OiA1JTtcbiAgd2lkdGg6IDkwJTtcbn1cblxuLmJ1dHRvbi1yb3cge1xuICBtYXJnaW4tbGVmdDogNSU7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/users-add/users-add.component.ts":
  /*!**************************************************!*\
    !*** ./src/app/users-add/users-add.component.ts ***!
    \**************************************************/

  /*! exports provided: UsersAddComponent */

  /***/
  function srcAppUsersAddUsersAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UsersAddComponent", function () {
      return UsersAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let UsersAddComponent = class UsersAddComponent {
      constructor(router, api, formBuilder, http) {
        this.router = router;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.yesnos = [{
          value: '1',
          viewValue: 'Active'
        }, {
          value: '2',
          viewValue: 'Inactive'
        }];
        this.usertypes = [{
          value: '3',
          viewValue: 'Super User'
        }, {
          value: '4',
          viewValue: 'Import User'
        }, {
          value: '5',
          viewValue: 'Export User'
        }];
        this.adminsusertypes = [{
          value: '2',
          viewValue: 'Admin'
        }, {
          value: '3',
          viewValue: 'Super User'
        }, {
          value: '4',
          viewValue: 'Import User'
        }, {
          value: '5',
          viewValue: 'Export User'
        }];
        this.email = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.userForm = this.formBuilder.group({
          'username': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'fullname': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'designation': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'department': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'email': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'usertype': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'status': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'customerID': [null]
        });
        var currentTrackUser = localStorage.getItem('currentUser');
        this.userdetails = JSON.parse(currentTrackUser);
        this.adminusertype = this.userdetails.usertype;

        if (this.adminusertype == 1) {
          this.superadmin = true;
        } else {
          this.superadmin = false;
        }
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/users/userAdd/', form).subscribe(forms => {
          this.isLoadingResults = false;
          this.Message = "User added Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/users']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

    };

    UsersAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    UsersAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-users-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./users-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/users-add/users-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./users-add.component.scss */
      "./src/app/users-add/users-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], UsersAddComponent);
    /***/
  },

  /***/
  "./src/app/users-edit/users-edit.component.scss":
  /*!******************************************************!*\
    !*** ./src/app/users-edit/users-edit.component.scss ***!
    \******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppUsersEditUsersEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-form-field {\n  display: block;\n  position: relative;\n  text-align: left;\n  margin-left: 5%;\n  width: 90%;\n}\n\n.button-row {\n  margin-left: 5%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnMtZWRpdC9EOlxcUHJvamVjdHNcXGd2a2FkbWluLWZyb250ZW5kL3NyY1xcYXBwXFx1c2Vycy1lZGl0XFx1c2Vycy1lZGl0LmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91c2Vycy1lZGl0L3VzZXJzLWVkaXQuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxVQUFBO0FDQ0o7O0FEQ0E7RUFDSSxlQUFBO0FDRUoiLCJmaWxlIjoic3JjL2FwcC91c2Vycy1lZGl0L3VzZXJzLWVkaXQuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWF0LWZvcm0tZmllbGQge1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUlO1xyXG4gICAgd2lkdGg6IDkwJTtcclxufVxyXG4uYnV0dG9uLXJvdyB7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbn0iLCIubWF0LWZvcm0tZmllbGQge1xuICBkaXNwbGF5OiBibG9jaztcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0ZXh0LWFsaWduOiBsZWZ0O1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIHdpZHRoOiA5MCU7XG59XG5cbi5idXR0b24tcm93IHtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/users-edit/users-edit.component.ts":
  /*!****************************************************!*\
    !*** ./src/app/users-edit/users-edit.component.ts ***!
    \****************************************************/

  /*! exports provided: UsersEditComponent */

  /***/
  function srcAppUsersEditUsersEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UsersEditComponent", function () {
      return UsersEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let UsersEditComponent = class UsersEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.yesnos = [{
          value: '1',
          viewValue: 'Active'
        }, {
          value: '2',
          viewValue: 'Inactive'
        }];
        this.usertypes = [{
          value: '3',
          viewValue: 'Super User'
        }, {
          value: '4',
          viewValue: 'Import User'
        }, {
          value: '5',
          viewValue: 'Export User'
        }];
        this.adminsusertypes = [{
          value: '2',
          viewValue: 'Admin'
        }, {
          value: '3',
          viewValue: 'Super User'
        }, {
          value: '4',
          viewValue: 'Import User'
        }, {
          value: '5',
          viewValue: 'Export User'
        }];
        this.email = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getUserDetails(this.route.snapshot.params['id']);
        this.userForm = this.formBuilder.group({
          'username': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'fullname': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'designation': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'department': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'email': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'usertype': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'status': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
          'customerID': [null]
        });
        var currentTrackUser = localStorage.getItem('currentUser');
        this.userdetails = JSON.parse(currentTrackUser);
        this.adminusertype = this.userdetails.usertype;

        if (this.adminusertype == 1) {
          this.superadmin = true;
        } else {
          this.superadmin = false;
        }
      }

      onFormSubmit(form) {
        if (this.adminpanelusertype == 2 && this.adminusertype == 2) {
          alert("You don't have access.. ! ");
          this.router.navigate(['/users']);
        }

        let cid = this.route.snapshot.params['id'];
        this.isLoadingResults = true;
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/users/userUpdate/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "User Updated Successfully";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/users']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      getUserDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/users/userdetails/' + cNo).subscribe(dataaa => {
          console.log(dataaa);
          this.userForm.setValue({
            username: dataaa.result[0].username,
            fullname: dataaa.result[0].fullname,
            designation: dataaa.result[0].designation,
            department: dataaa.result[0].department,
            email: dataaa.result[0].email,
            password: dataaa.result[0].password,
            usertype: dataaa.result[0].usertype,
            status: dataaa.result[0].status,
            customerID: dataaa.result[0].customerID
          });
          this.adminpanelusertype = dataaa.result[0].usertype;
        });
      }

    };

    UsersEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    UsersEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-users-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./users-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/users-edit/users-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./users-edit.component.scss */
      "./src/app/users-edit/users-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], UsersEditComponent);
    /***/
  },

  /***/
  "./src/app/users/users.component.scss":
  /*!********************************************!*\
    !*** ./src/app/users/users.component.scss ***!
    \********************************************/

  /*! exports provided: default */

  /***/
  function srcAppUsersUsersComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-table {\n  background: white;\n  overflow-x: auto;\n  text-align: center;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\nmat-cell.mat-column-Date {\n  min-width: 100px;\n}\n\nmat-cell.mat-column-Vendor_name, mat-cell.mat-column-Remarks {\n  min-width: 200px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdXNlcnMvRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcdXNlcnNcXHVzZXJzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC91c2Vycy91c2Vycy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDRixrQkFBQTtBQ0FBOztBREdBO0VBQ0EseUJBQUE7RUFDQSxnQ0FBQTtBQ0FBOztBREVBO0VBQ0UsK0JBQUE7RUFDRixtQkFBQTtFQUNBLGdDQUFBO0VBQ0EsY0FBQTtBQ0NBOztBRENBO0VBQ0EsZ0JBQUE7QUNFQTs7QURBQTtFQUNBLGdCQUFBO0FDR0E7O0FEREE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7QUNJQTs7QURGQTtFQUNBLFVBQUE7QUNLQTs7QURIQTtFQUNBLFVBQUE7QUNNQTs7QURKQTtFQUNBLHlCQUFBO0FDT0E7O0FETEE7RUFDQSxpQkFBQTtBQ1FBOztBRE5BO0VBQ0Esb0JBQUE7QUNTQTs7QURQQTtFQUNBLFdBQUE7QUNVQSIsImZpbGUiOiJzcmMvYXBwL3VzZXJzL3VzZXJzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi5tYXQtdGFibGUge1xyXG4gIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gIG92ZXJmbG93LXg6IGF1dG87XHJcbnRleHQtYWxpZ246Y2VudGVyO1xyXG59XHJcblxyXG5tYXQtaGVhZGVyLWNlbGx7XHJcbmJhY2tncm91bmQtY29sb3I6ICNlOWY4ZmY7XHJcbmJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xyXG59XHJcbm1hdC1jZWxsICwgbWF0LWhlYWRlci1jZWxse1xyXG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbmFsaWduLXNlbGY6IHN0cmV0Y2g7XHRcclxuYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbnBhZGRpbmc6MCA4cHg7XHJcbn1cclxubWF0LWNlbGwubWF0LWNvbHVtbi1EYXRle1xyXG5taW4td2lkdGg6MTAwcHg7XHJcbn1cclxubWF0LWNlbGwubWF0LWNvbHVtbi1WZW5kb3JfbmFtZSAsIG1hdC1jZWxsLm1hdC1jb2x1bW4tUmVtYXJrc3tcclxubWluLXdpZHRoOjIwMHB4O1xyXG59XHJcbi51cGxvYWQtZi5uZy1zdGFyLWluc2VydGVke1xyXG5kaXNwbGF5OmZsZXg7XHJcbn1cclxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXB7XHJcbndpZHRoOjc1JTtcclxufVxyXG4uaW1wb3J0LXNlYyAudXBsb2FkLWJ0bntcclxud2lkdGg6MjUlO1xyXG59XHJcbi5tYXQtdGFibGV7XHJcbmJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XHJcbn1cclxuLnVwbG9hZC1idG57XHJcbnRleHQtYWxpZ246cmlnaHQ7XHJcbn1cclxuLnRvcC1idG5zIC5idG57XHJcbm1hcmdpbjowIDVweCAxMHB4IDA7XHJcbn1cclxubWF0LWZvb3Rlci1yb3csIG1hdC1oZWFkZXItcm93LCBtYXQtcm93e1xyXG5ib3JkZXI6MHB4XHJcbn0iLCIubWF0LXRhYmxlIHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIG92ZXJmbG93LXg6IGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxubWF0LWhlYWRlci1jZWxsIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2U5ZjhmZjtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XG59XG5cbm1hdC1jZWxsLCBtYXQtaGVhZGVyLWNlbGwge1xuICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjZThlOGU5O1xuICBhbGlnbi1zZWxmOiBzdHJldGNoO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcbiAgcGFkZGluZzogMCA4cHg7XG59XG5cbm1hdC1jZWxsLm1hdC1jb2x1bW4tRGF0ZSB7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG5cbm1hdC1jZWxsLm1hdC1jb2x1bW4tVmVuZG9yX25hbWUsIG1hdC1jZWxsLm1hdC1jb2x1bW4tUmVtYXJrcyB7XG4gIG1pbi13aWR0aDogMjAwcHg7XG59XG5cbi51cGxvYWQtZi5uZy1zdGFyLWluc2VydGVkIHtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmltcG9ydC1zZWMgLmZvcm0tZ3JvdXAge1xuICB3aWR0aDogNzUlO1xufVxuXG4uaW1wb3J0LXNlYyAudXBsb2FkLWJ0biB7XG4gIHdpZHRoOiAyNSU7XG59XG5cbi5tYXQtdGFibGUge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU5O1xufVxuXG4udXBsb2FkLWJ0biB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xufVxuXG4udG9wLWJ0bnMgLmJ0biB7XG4gIG1hcmdpbjogMCA1cHggMTBweCAwO1xufVxuXG5tYXQtZm9vdGVyLXJvdywgbWF0LWhlYWRlci1yb3csIG1hdC1yb3cge1xuICBib3JkZXI6IDBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/users/users.component.ts":
  /*!******************************************!*\
    !*** ./src/app/users/users.component.ts ***!
    \******************************************/

  /*! exports provided: UsersComponent, ExampleDataSource */

  /***/
  function srcAppUsersUsersComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UsersComponent", function () {
      return UsersComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let UsersComponent = class UsersComponent {
      constructor(router, authenticationService, userService, httpClient, dialog, http, dataService) {
        this.router = router;
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.http = http;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['username', 'fullname', 'designation', 'department', 'email', 'customerID', 'password', 'usertype', 'status', 'create_date', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        var currentUserType = localStorage.getItem('currentUserType');
        this.loadData(); //       this.loadAllUsers();
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      deleteUser(cid) {
        this.isLoadingResults = true;
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_12__["environment"].apiUrl_base) + '/users/Deleteuser/' + cid).subscribe(datar => {
          this.isLoadingResults = false;
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
            this.refresh();
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      refresh() {
        this.loadData();
      }

      refreshTable() {
        // Refreshing table using paginator
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    UsersComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginator"])], UsersComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_8__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__["MatSort"])], UsersComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], UsersComponent.prototype, "filter", void 0);
    UsersComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-users',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./users.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/users/users.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./users.component.scss */
      "./src/app/users/users.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _app_services__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_2__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]])], UsersComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_9__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_10__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.userDataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getUsers();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_11__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.userData.slice().filter(cuser => {
            const searchStr = (cuser.username + cuser.fullname + cuser.designation + cuser.department + cuser.email + cuser.usertype + cuser.status + cuser.create_date).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'username':
              [propertyA, propertyB] = [a.username, b.username];
              break;

            case 'fullname':
              [propertyA, propertyB] = [a.fullname, b.fullname];
              break;

            case 'designation':
              [propertyA, propertyB] = [a.designation, b.designation];
              break;

            case 'department':
              [propertyA, propertyB] = [a.department, b.department];
              break;

            case 'email':
              [propertyA, propertyB] = [a.email, b.email];
              break;

            case 'password':
              [propertyA, propertyB] = [a.password, b.password];
              break;

            case 'usertype':
              [propertyA, propertyB] = [a.usertype, b.usertype];
              break;

            case 'status':
              [propertyA, propertyB] = [a.status, b.status];
              break;

            case 'create_date':
              [propertyA, propertyB] = [a.create_date, b.create_date];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'desc' ? 1 : -1);
        });
      }

    }
    /***/

  },

  /***/
  "./src/app/vendor-add/vendor-add.component.scss":
  /*!******************************************************!*\
    !*** ./src/app/vendor-add/vendor-add.component.scss ***!
    \******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppVendorAddVendorAddComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ZlbmRvci1hZGQvdmVuZG9yLWFkZC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/vendor-add/vendor-add.component.ts":
  /*!****************************************************!*\
    !*** ./src/app/vendor-add/vendor-add.component.ts ***!
    \****************************************************/

  /*! exports provided: VendorAddComponent */

  /***/
  function srcAppVendorAddVendorAddComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VendorAddComponent", function () {
      return VendorAddComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let VendorAddComponent = class VendorAddComponent {
      constructor(router, api, formBuilder, http) {
        this.router = router;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.vendor_name = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.vendorForm = this.formBuilder.group({
          'vendor_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        this.http.post("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/vendor/vendoradd/', form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record  Successfully inserted";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/vendors']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

    };

    VendorAddComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    VendorAddComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-vendor-add',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./vendor-add.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/vendor-add/vendor-add.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./vendor-add.component.scss */
      "./src/app/vendor-add/vendor-add.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], VendorAddComponent);
    /***/
  },

  /***/
  "./src/app/vendor-edit/vendor-edit.component.scss":
  /*!********************************************************!*\
    !*** ./src/app/vendor-edit/vendor-edit.component.scss ***!
    \********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppVendorEditVendorEditComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3ZlbmRvci1lZGl0L3ZlbmRvci1lZGl0LmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/vendor-edit/vendor-edit.component.ts":
  /*!******************************************************!*\
    !*** ./src/app/vendor-edit/vendor-edit.component.ts ***!
    \******************************************************/

  /*! exports provided: VendorEditComponent */

  /***/
  function srcAppVendorEditVendorEditComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VendorEditComponent", function () {
      return VendorEditComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let VendorEditComponent = class VendorEditComponent {
      constructor(router, route, api, formBuilder, http) {
        this.router = router;
        this.route = route;
        this.api = api;
        this.formBuilder = formBuilder;
        this.http = http;
        this.vendor_name = '';
        this.Message = '';
        this.isLoadingResults = false;
      }

      ngOnInit() {
        this.getvendorDetails(this.route.snapshot.params['id']);
        this.vendorForm = this.formBuilder.group({
          'vendor_name': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
      }

      onFormSubmit(form) {
        this.isLoadingResults = true;
        let cid = this.route.snapshot.params['id'];
        this.http.put("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/vendor/updateVendorDetails/' + cid, form).subscribe(form => {
          this.isLoadingResults = false;
          this.Message = "Record  Successfully updated";
          setTimeout(() => {
            this.Message = null;
            this.router.navigate(['/vendors']);
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      } // get currencies details


      getvendorDetails(cNo) {
        this.http.get("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].apiUrl_base) + '/vendor/vendors/' + cNo).subscribe(dataaa => {
          this.vendorForm.setValue({
            vendor_name: dataaa[0].vendor_name
          });
        });
      }

    };

    VendorEditComponent.ctorParameters = () => [{
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
    }, {
      type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }];

    VendorEditComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-vendor-edit',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./vendor-edit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/vendor-edit/vendor-edit.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./vendor-edit.component.scss */
      "./src/app/vendor-edit/vendor-edit.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _services_data_service__WEBPACK_IMPORTED_MODULE_3__["DataService"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])], VendorEditComponent);
    /***/
  },

  /***/
  "./src/app/vendors/vendors.component.scss":
  /*!************************************************!*\
    !*** ./src/app/vendors/vendors.component.scss ***!
    \************************************************/

  /*! exports provided: default */

  /***/
  function srcAppVendorsVendorsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".mat-header-cell {\n  min-width: 100px;\n}\n\n.mat-cell.ng-star-inserted {\n  min-width: 100px;\n}\n\n.mat-table {\n  background: white;\n  overflow-x: auto;\n}\n\nmat-header-cell {\n  background-color: #e9f8ff;\n  border-bottom: 1px solid #e8e8e9;\n}\n\nmat-cell, mat-header-cell {\n  border-right: 1px solid #e8e8e9;\n  align-self: stretch;\n  border-bottom: 1px solid #e8e8e9;\n  padding: 0 8px;\n}\n\n.upload-f.ng-star-inserted {\n  display: -webkit-box;\n  display: flex;\n}\n\n.import-sec .form-group, .import-sec .upload-btn {\n  display: inline-block;\n  float: left;\n  margin-bottom: 0;\n}\n\n.import-sec .form-group {\n  width: 75%;\n}\n\n.import-sec .upload-btn {\n  width: 25%;\n}\n\n.mat-table {\n  border: 1px solid #e8e8e9;\n}\n\n.upload-btn {\n  text-align: right;\n}\n\n.top-btns .btn {\n  margin: 0 5px 10px 0;\n}\n\nmat-footer-row, mat-header-row, mat-row {\n  border: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdmVuZG9ycy9EOlxcUHJvamVjdHNcXGd2a2FkbWluLWZyb250ZW5kL3NyY1xcYXBwXFx2ZW5kb3JzXFx2ZW5kb3JzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC92ZW5kb3JzL3ZlbmRvcnMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtBQ0NKOztBRENBO0VBQ0ksZ0JBQUE7QUNFSjs7QURBQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7QUNHSjs7QUREQztFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7QUNJRDs7QURGRTtFQUNFLCtCQUFBO0VBQ0gsbUJBQUE7RUFDQSxnQ0FBQTtFQUNBLGNBQUE7QUNLRDs7QURIQTtFQUNBLG9CQUFBO0VBQUEsYUFBQTtBQ01BOztBREpBO0VBQ0UscUJBQUE7RUFDRSxXQUFBO0VBQ0gsZ0JBQUE7QUNPRDs7QURMQTtFQUNBLFVBQUE7QUNRQTs7QUROQTtFQUNBLFVBQUE7QUNTQTs7QURQQTtFQUNBLHlCQUFBO0FDVUE7O0FEUkE7RUFDQSxpQkFBQTtBQ1dBOztBRFRBO0VBQ0Esb0JBQUE7QUNZQTs7QURWQTtFQUNBLFdBQUE7QUNhQSIsImZpbGUiOiJzcmMvYXBwL3ZlbmRvcnMvdmVuZG9ycy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXQtaGVhZGVyLWNlbGwge1xyXG4gICAgbWluLXdpZHRoOiAxMDBweDtcclxufVxyXG4ubWF0LWNlbGwubmctc3Rhci1pbnNlcnRlZCB7XHJcbiAgICBtaW4td2lkdGg6IDEwMHB4O1xyXG59XHJcbi5tYXQtdGFibGUge1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICBvdmVyZmxvdy14OiBhdXRvO1xyXG59XHJcbiBtYXQtaGVhZGVyLWNlbGx7XHJcblx0YmFja2dyb3VuZC1jb2xvcjogI2U5ZjhmZjtcclxuXHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcclxufVxyXG4gIG1hdC1jZWxsICwgbWF0LWhlYWRlci1jZWxse1xyXG4gICAgYm9yZGVyLXJpZ2h0OiAxcHggc29saWQgI2U4ZThlOTtcclxuXHRhbGlnbi1zZWxmOiBzdHJldGNoO1x0XHJcblx0Ym9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNlOGU4ZTk7XHJcblx0cGFkZGluZzowIDhweDtcclxufVxyXG4udXBsb2FkLWYubmctc3Rhci1pbnNlcnRlZHtcclxuZGlzcGxheTpmbGV4O1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3VwICwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcblx0bWFyZ2luLWJvdHRvbTowO1xyXG59XHJcbi5pbXBvcnQtc2VjIC5mb3JtLWdyb3Vwe1xyXG53aWR0aDo3NSU7XHJcbn1cclxuLmltcG9ydC1zZWMgLnVwbG9hZC1idG57XHJcbndpZHRoOjI1JTtcclxufVxyXG4ubWF0LXRhYmxle1xyXG5ib3JkZXI6IDFweCBzb2xpZCAjZThlOGU5O1xyXG59XHJcbi51cGxvYWQtYnRue1xyXG50ZXh0LWFsaWduOnJpZ2h0O1xyXG59XHJcbi50b3AtYnRucyAuYnRue1xyXG5tYXJnaW46MCA1cHggMTBweCAwO1xyXG59XHJcbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvd3tcclxuYm9yZGVyOjBweFxyXG59IiwiLm1hdC1oZWFkZXItY2VsbCB7XG4gIG1pbi13aWR0aDogMTAwcHg7XG59XG5cbi5tYXQtY2VsbC5uZy1zdGFyLWluc2VydGVkIHtcbiAgbWluLXdpZHRoOiAxMDBweDtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBvdmVyZmxvdy14OiBhdXRvO1xufVxuXG5tYXQtaGVhZGVyLWNlbGwge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2U4ZThlOTtcbn1cblxubWF0LWNlbGwsIG1hdC1oZWFkZXItY2VsbCB7XG4gIGJvcmRlci1yaWdodDogMXB4IHNvbGlkICNlOGU4ZTk7XG4gIGFsaWduLXNlbGY6IHN0cmV0Y2g7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZThlOGU5O1xuICBwYWRkaW5nOiAwIDhweDtcbn1cblxuLnVwbG9hZC1mLm5nLXN0YXItaW5zZXJ0ZWQge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCwgLmltcG9ydC1zZWMgLnVwbG9hZC1idG4ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIGZsb2F0OiBsZWZ0O1xuICBtYXJnaW4tYm90dG9tOiAwO1xufVxuXG4uaW1wb3J0LXNlYyAuZm9ybS1ncm91cCB7XG4gIHdpZHRoOiA3NSU7XG59XG5cbi5pbXBvcnQtc2VjIC51cGxvYWQtYnRuIHtcbiAgd2lkdGg6IDI1JTtcbn1cblxuLm1hdC10YWJsZSB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTk7XG59XG5cbi51cGxvYWQtYnRuIHtcbiAgdGV4dC1hbGlnbjogcmlnaHQ7XG59XG5cbi50b3AtYnRucyAuYnRuIHtcbiAgbWFyZ2luOiAwIDVweCAxMHB4IDA7XG59XG5cbm1hdC1mb290ZXItcm93LCBtYXQtaGVhZGVyLXJvdywgbWF0LXJvdyB7XG4gIGJvcmRlcjogMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/vendors/vendors.component.ts":
  /*!**********************************************!*\
    !*** ./src/app/vendors/vendors.component.ts ***!
    \**********************************************/

  /*! exports provided: VendorsComponent, ExampleDataSource */

  /***/
  function srcAppVendorsVendorsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "VendorsComponent", function () {
      return VendorsComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ExampleDataSource", function () {
      return ExampleDataSource;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _app_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @app/_services */
    "./src/app/_services/index.ts");
    /* harmony import */


    var _services_data_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./../services/data.service */
    "./src/app/services/data.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/material/dialog */
    "./node_modules/@angular/material/esm2015/dialog.js");
    /* harmony import */


    var _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/material/paginator */
    "./node_modules/@angular/material/esm2015/paginator.js");
    /* harmony import */


    var _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/material/sort */
    "./node_modules/@angular/material/esm2015/sort.js");
    /* harmony import */


    var _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! @angular/cdk/collections */
    "./node_modules/@angular/cdk/esm2015/collections.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! @environments/environment */
    "./src/environments/environment.ts");

    let VendorsComponent = class VendorsComponent {
      constructor(authenticationService, userService, httpClient, dialog, http, dataService) {
        this.authenticationService = authenticationService;
        this.userService = userService;
        this.httpClient = httpClient;
        this.dialog = dialog;
        this.http = http;
        this.dataService = dataService;
        this.users = [];
        this.displayedColumns = ['id', 'vendor_name', 'create_date', 'actions'];
        this.Message = '';
        this.isLoadingResults = false;
        this.currentUserSubscription = this.authenticationService.currentUser.subscribe(user => {
          this.currentUser = user;
        });
      }

      ngAfterViewInit() {}

      ngOnInit() {
        this.loadData(); //       this.loadAllUsers();
      }

      loadAllUsers() {
        this.userService.getAll().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["first"])()).subscribe(users => {
          this.users = users;
        });
      }

      ngOnDestroy() {
        this.currentUserSubscription.unsubscribe();
      }

      deleteVendor(cid) {
        this.isLoadingResults = true;
        this.http.delete("".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_11__["environment"].apiUrl_base) + '/vendor/deleteVendor/' + cid).subscribe(datar => {
          this.isLoadingResults = false;
          this.Message = "Record deleted Successfully";
          setTimeout(() => {
            this.Message = null;
            this.refresh();
          }, 1000);
        }, err => {
          this.isLoadingResults = false;
        });
      }

      refresh() {
        this.loadData();
      }

      refreshTable() {
        // Refreshing table using paginator
        this.paginator._changePageSize(this.paginator.pageSize);
      }

      loadData() {
        this.exampleDatabase = new _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"](this.httpClient);
        this.dataSource = new ExampleDataSource(this.exampleDatabase, this.paginator, this.sort);
        Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["fromEvent"])(this.filter.nativeElement, 'keyup') // .debounceTime(150)
        // .distinctUntilChanged()
        .subscribe(() => {
          if (!this.dataSource) {
            return;
          }

          this.dataSource.filter = this.filter.nativeElement.value;
        });
      }

    };

    VendorsComponent.ctorParameters = () => [{
      type: _app_services__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]
    }, {
      type: _app_services__WEBPACK_IMPORTED_MODULE_3__["UserService"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }, {
      type: _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"]
    }, {
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]
    }, {
      type: _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]
    }];

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginator"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_paginator__WEBPACK_IMPORTED_MODULE_7__["MatPaginator"])], VendorsComponent.prototype, "paginator", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_angular_material_sort__WEBPACK_IMPORTED_MODULE_8__["MatSort"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_material_sort__WEBPACK_IMPORTED_MODULE_8__["MatSort"])], VendorsComponent.prototype, "sort", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filter', {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])], VendorsComponent.prototype, "filter", void 0);
    VendorsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-vendors',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./vendors.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/vendors/vendors.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./vendors.component.scss */
      "./src/app/vendors/vendors.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_app_services__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"], _app_services__WEBPACK_IMPORTED_MODULE_3__["UserService"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], _angular_material_dialog__WEBPACK_IMPORTED_MODULE_6__["MatDialog"], _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"], _services_data_service__WEBPACK_IMPORTED_MODULE_4__["DataService"]])], VendorsComponent);

    class ExampleDataSource extends _angular_cdk_collections__WEBPACK_IMPORTED_MODULE_9__["DataSource"] {
      constructor(_exampleDatabase, _paginator, _sort) {
        super();
        this._exampleDatabase = _exampleDatabase;
        this._paginator = _paginator;
        this._sort = _sort;
        this._filterChange = new rxjs__WEBPACK_IMPORTED_MODULE_10__["BehaviorSubject"]('');
        this.filteredData = [];
        this.renderedData = []; // Reset to the first page when the user changes the filter.

        this._filterChange.subscribe(() => this._paginator.pageIndex = 0);
      }

      get filter() {
        return this._filterChange.value;
      }

      set filter(filter) {
        this._filterChange.next(filter);
      }
      /** Connect function called by the table to retrieve one stream containing the data to render. */


      connect() {
        // Listen for any changes in the base data, sorting, filtering, or pagination
        const displayDataChanges = [this._exampleDatabase.vendorDataChange, this._sort.sortChange, this._filterChange, this._paginator.page];

        this._exampleDatabase.getVendors();

        return Object(rxjs__WEBPACK_IMPORTED_MODULE_10__["merge"])(...displayDataChanges).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(() => {
          // Filter data
          this.filteredData = this._exampleDatabase.vendorData.slice().filter(vendor => {
            const searchStr = (vendor.id + vendor.vendor_name + vendor.create_date).toLowerCase();
            return searchStr.indexOf(this.filter.toLowerCase()) !== -1;
          }); // Sort filtered data

          const sortedData = this.sortData(this.filteredData.slice()); // Grab the page's slice of the filtered sorted data.

          const startIndex = this._paginator.pageIndex * this._paginator.pageSize;
          this.renderedData = sortedData.splice(startIndex, this._paginator.pageSize);
          return this.renderedData;
        }));
      }

      disconnect() {}
      /** Returns a sorted copy of the database data. */


      sortData(data) {
        if (!this._sort.active || this._sort.direction === '') {
          return data;
        }

        return data.sort((a, b) => {
          let propertyA = '';
          let propertyB = '';

          switch (this._sort.active) {
            case 'id':
              [propertyA, propertyB] = [a.id, b.id];
              break;

            case 'vendor_name':
              [propertyA, propertyB] = [a.vendor_name, b.vendor_name];
              break;

            case 'create_date':
              [propertyA, propertyB] = [a.create_date, b.create_date];
              break;
          }

          const valueA = isNaN(+propertyA) ? propertyA : +propertyA;
          const valueB = isNaN(+propertyB) ? propertyB : +propertyB;
          return (valueA < valueB ? -1 : 1) * (this._sort.direction === 'desc' ? 1 : -1);
        });
      }

    }
    /***/

  },

  /***/
  "./src/app/weekly-reports/weekly-reports.component.scss":
  /*!**************************************************************!*\
    !*** ./src/app/weekly-reports/weekly-reports.component.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppWeeklyReportsWeeklyReportsComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".exp .fil-sec {\n  margin-top: 15px;\n  margin-bottom: 15px;\n}\n\n.fil-sec .d-flex .form-control {\n  margin-right: 5px;\n}\n\n.fil-sec .d-flex .form-control:last-child {\n  margin-right: 0;\n}\n\n.exp-sec h4 {\n  background: #e9f8ff;\n  padding: 5px 10px;\n  margin-bottom: 0;\n  text-align: center;\n  font-size: 16px;\n}\n\n.table th, .table td {\n  padding: 5px 6px;\n  text-align: center;\n}\n\n.table-striped tbody tr:nth-of-type(2n+1) {\n  background-color: #e9f8ff !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvd2Vla2x5LXJlcG9ydHMvRDpcXFByb2plY3RzXFxndmthZG1pbi1mcm9udGVuZC9zcmNcXGFwcFxcd2Vla2x5LXJlcG9ydHNcXHdlZWtseS1yZXBvcnRzLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC93ZWVrbHktcmVwb3J0cy93ZWVrbHktcmVwb3J0cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURDQTtFQUNJLGlCQUFBO0FDRUo7O0FEQUU7RUFDRSxlQUFBO0FDR0o7O0FEREE7RUFDSSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNJSjs7QURGQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUNLSjs7QURGQTtFQUNJLG9DQUFBO0FDS0oiLCJmaWxlIjoic3JjL2FwcC93ZWVrbHktcmVwb3J0cy93ZWVrbHktcmVwb3J0cy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5leHAgLmZpbC1zZWN7XHJcbiAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxufVxyXG4uZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2x7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICB9XHJcbiAgLmZpbC1zZWMgLmQtZmxleCAuZm9ybS1jb250cm9sOmxhc3QtY2hpbGR7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgfVxyXG4uZXhwLXNlYyBoNHtcclxuICAgIGJhY2tncm91bmQ6ICNlOWY4ZmY7XHJcbiAgICBwYWRkaW5nOiA1cHggMTBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuLnRhYmxlIHRoLCAudGFibGUgdGQge1xyXG4gICAgcGFkZGluZzogNXB4IDZweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuLnRhYmxlLXN0cmlwZWQgdGJvZHkgdHI6bnRoLW9mLXR5cGUoMm4rMSkge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2U5ZjhmZiAhaW1wb3J0YW50O1xyXG59XHJcbiIsIi5leHAgLmZpbC1zZWMge1xuICBtYXJnaW4tdG9wOiAxNXB4O1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xufVxuXG4uZmlsLXNlYyAuZC1mbGV4IC5mb3JtLWNvbnRyb2wge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbn1cblxuLmZpbC1zZWMgLmQtZmxleCAuZm9ybS1jb250cm9sOmxhc3QtY2hpbGQge1xuICBtYXJnaW4tcmlnaHQ6IDA7XG59XG5cbi5leHAtc2VjIGg0IHtcbiAgYmFja2dyb3VuZDogI2U5ZjhmZjtcbiAgcGFkZGluZzogNXB4IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDA7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4udGFibGUgdGgsIC50YWJsZSB0ZCB7XG4gIHBhZGRpbmc6IDVweCA2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuLnRhYmxlLXN0cmlwZWQgdGJvZHkgdHI6bnRoLW9mLXR5cGUoMm4rMSkge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTlmOGZmICFpbXBvcnRhbnQ7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/weekly-reports/weekly-reports.component.ts":
  /*!************************************************************!*\
    !*** ./src/app/weekly-reports/weekly-reports.component.ts ***!
    \************************************************************/

  /*! exports provided: WeeklyReportsComponent */

  /***/
  function srcAppWeeklyReportsWeeklyReportsComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "WeeklyReportsComponent", function () {
      return WeeklyReportsComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @app/_services/api-services.service */
    "./src/app/_services/api-services.service.ts");
    /* harmony import */


    var _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @app/_services/authentication.service */
    "./src/app/_services/authentication.service.ts");

    let WeeklyReportsComponent = class WeeklyReportsComponent {
      constructor(http, apiService, authService, fb) {
        this.http = http;
        this.apiService = apiService;
        this.authService = authService;
        this.fb = fb;
        this.submitted = false;
        this.loading = false;
        this.showTable = false;
      }

      ngOnInit() {
        this.today = new Date();
        this.user = this.authService.currentUserValue;
        this.searchForm = this.fb.group({
          'fromDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
          'toDate': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
          'userId': [this.user.id]
        });
      }

      get f() {
        return this.searchForm.controls;
      }

      onSubmit() {
        this.submitted = true;

        if (this.searchForm.invalid) {
          return;
        }

        this.loading = true;
        this.http.post(this.apiService.WEEKELY_REPORTS, this.searchForm.value).subscribe(data => {
          this.showTable = true;
          this.recordsData = data;
          var No_of_Shipments = 0;
          var Gross_Weight_Handled_in_Kgs = 0;
          var Net_Weight_Handled_in_Kgs = 0;

          for (let [key, data] of Object.entries(this.recordsData.count[0])) {
            No_of_Shipments += data['noItems'];
            Gross_Weight_Handled_in_Kgs += data['Gr_Wt'];
            Net_Weight_Handled_in_Kgs += data['Net_Wt'];
          }

          this.table1 = {
            'No_of_Shipments': No_of_Shipments,
            'Gross_Weight_Handled_in_Kgs': Gross_Weight_Handled_in_Kgs,
            'Net_Weight_Handled_in_Kgs': Net_Weight_Handled_in_Kgs
          };
          No_of_Shipments = 0;
          Gross_Weight_Handled_in_Kgs = 0;
          Net_Weight_Handled_in_Kgs = 0;

          for (let [key, data] of Object.entries(this.recordsData.count[1])) {
            No_of_Shipments += data['noItems'];
            Gross_Weight_Handled_in_Kgs += data['Gr_Wt'];
            Net_Weight_Handled_in_Kgs += data['Net_Wt'];
          }

          this.table2 = {
            'No_of_Shipments': No_of_Shipments,
            'Gross_Weight_Handled_in_Kgs': Gross_Weight_Handled_in_Kgs,
            'Net_Weight_Handled_in_Kgs': Net_Weight_Handled_in_Kgs
          };
          this.loading = false;
        });
      }

    };

    WeeklyReportsComponent.ctorParameters = () => [{
      type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
    }, {
      type: _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"]
    }, {
      type: _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"]
    }, {
      type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
    }];

    WeeklyReportsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-weekly-reports',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./weekly-reports.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/weekly-reports/weekly-reports.component.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./weekly-reports.component.scss */
      "./src/app/weekly-reports/weekly-reports.component.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"], _app_services_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"], _app_services_authentication_service__WEBPACK_IMPORTED_MODULE_5__["AuthenticationService"], _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])], WeeklyReportsComponent);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");

    const environment = {
      production: false,
      //apiUrl: 'https://ets.gvkbio.com/api',
      //apiUrl_base: 'https://ets.gvkbio.com'
      apiUrl: 'https://ets.aragen.com/api',
      apiUrl_base: 'https://ets.aragen.com'
    };
    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"]).catch(err => console.error(err));
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! D:\Projects\gvkadmin-frontend\src\main.ts */
    "./src/main.ts");
    /***/
  },

  /***/
  1:
  /*!********************!*\
    !*** fs (ignored) ***!
    \********************/

  /*! no static exports found */

  /***/
  function _(module, exports) {
    /* (ignored) */

    /***/
  },

  /***/
  2:
  /*!************************!*\
    !*** crypto (ignored) ***!
    \************************/

  /*! no static exports found */

  /***/
  function _(module, exports) {
    /* (ignored) */

    /***/
  },

  /***/
  3:
  /*!************************!*\
    !*** stream (ignored) ***!
    \************************/

  /*! no static exports found */

  /***/
  function _(module, exports) {
    /* (ignored) */

    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map