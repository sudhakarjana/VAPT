'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');
var dateFormat = require('dateformat');


app.get('/allshipments', function(req, res){
    db.executeSql("select * from gvk_import_shipments ORDER BY id DESC", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else 
         //console.log('response',recordset);
         res.send(JSON.stringify(recordset.recordset));
});
});
app.post('/allshipments', function(req, res){
if(req.body.pagePer && req.body.pageNo){
 var pagePer = req.body.pagePer
  var key = req.body.searchKey
  var pageNo = req.body.pageNo
  var offset = (pageNo-1) * pagePer
  console.log(26,key)
  if(key){
	var where = "WHERE AWB_no LIKE '%"+key+"%' OR Country LIKE '%"+key+"%'"
  }else{
	var where = ""
  }
  var sql = "select * from gvk_import_shipments "+where+" ORDER BY id DESC OFFSET "+offset+" ROWS FETCH NEXT "+pagePer+" ROWS ONLY; select * from gvk_import_shipments "+where+""
  db.executeSql(sql, function(err, recordset){
        if (err)  {      
        res.json({error:true,message:"sql error",sql:sql,pagePer:pagePer,pageNo:pageNo});
		}else {
         //console.log('response',recordset);
         res.json({error:false,records:recordset.recordsets[0],count:recordset.recordsets[1].length,pagePer:pagePer,pageNo:pageNo});
		}
});
}else{
	res.json({error:true,message:"Required all fields",});
	
}
});

// Get Import Record by Id;

app.get('/getImportRecord/:id',(req, res) => {
  let sql = "SELECT * FROM gvk_import_shipments WHERE id="+req.params.id;
  let query = db.executeSql(sql, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results.recordset}));
  });
});


app.post('/importRecordExelAdd', function(req, res){
    var data= req.body;	
    const awb_no = req.body.AWB_no;
	if (data.Rev_info) {
		//var Rev_info_d = new Date(data.Rev_info);
		//var Rev_info_d = Rev_info.setHours(Rev_info.getHours() + 4);
		//var Rev_info=dateFormat(Rev_info_d, "yyyy-mm-dd");
		var Rev_info = data.Rev_info;
	} else {
		var Rev_info = '';
	}	
	if(data.Date){
		var Datess = new Date(data.Date);
		var Date_date_d = Datess.setHours(Datess.getHours() + 4);
		var Date_date =dateFormat(Date_date_d, "yyyy-mm-dd");
	}else{ var Date_date='';	}

	if(data.Delivery_Date){
		var Delivery_Date_d = new Date(data.Delivery_Date);
		var Delivery_Date_d = Delivery_Date_d.setHours(Delivery_Date_d.getHours() + 4);
		var Delivery_Date =dateFormat(Delivery_Date_d, "yyyy-mm-dd");
	}else{ var Delivery_Date='';	}

	if(data.Expected_Date_Delivery){
		var Expected_Date_Delivery_d = new Date(data.Expected_Date_Delivery);
		var Expected_Date_Delivery_d = Expected_Date_Delivery_d.setHours(Expected_Date_Delivery_d.getHours() + 4);
		var Expected_Date_Delivery =dateFormat(Expected_Date_Delivery_d, "yyyy-mm-dd");

	}else{ var Expected_Date_Delivery='';	}

	if(data.Pick_up_date){
		var Pick_up_date_d = new Date(data.Pick_up_date);
		var Pick_up_date_d = Pick_up_date_d.setHours(Pick_up_date_d.getHours() + 4);
		var Pick_up_date =dateFormat(Pick_up_date_d, "yyyy-mm-dd");
	}else{ var Pick_up_date='';	}

	if(data.shpt_land_dt){
		var shpt_land_dt_d = new Date(data.shpt_land_dt);
		var shpt_land_dt_d = shpt_land_dt_d.setHours(shpt_land_dt_d.getHours() + 4);
		var shpt_land_dt =dateFormat(shpt_land_dt_d, "yyyy-mm-dd");
	}else{ var shpt_land_dt='';	}

	if(data.Docs_shared_date){
		var Docs_shared_date_d = new Date(data.Docs_shared_date);
		var Docs_shared_date_d = Docs_shared_date_d.setHours(Docs_shared_date_d.getHours() + 4);
		var Docs_shared_date =dateFormat(Docs_shared_date_d, "yyyy-mm-dd");
	}else{ var Docs_shared_date='';	}

	if(data.BE_Date){
		var BE_Date_d = new Date(data.BE_Date);
		var BE_Date_d = BE_Date_d.setHours(BE_Date_d.getHours() + 4);
		var BE_Date =dateFormat(BE_Date_d, "yyyy-mm-dd");
	}else{ var BE_Date='';	}

    var sql = "select * from gvk_import_shipments where AWB_No='" +awb_no+"';";
    db.executeSql(sql, function(err, recordset){
        if (err){   
			res.json({msg:'error is here',error:true,err:sql}) 
		}else if(Array.isArray(recordset.recordset) && recordset.recordset.length != 0){    
        var data= req.body;
        var sqlUpdate = "UPDATE gvk_import_shipments SET Approval_status='" +data.Approval_status+"', BE_Date='"+BE_Date+"', BE_No='"+data.BE_No+"',VPO='"+data.VPO+"', BLR='"+data.BLR+"', BRO='"+data.BRO+"', Bill_No='"+data.Bill_No+"', CHA='"
        +data.CHA+"', Carrier='"+data.Carrier+"', Category='"+data.Category+"', Clearance_Charges='"+data.Clearance_Charges+"', Clearance_TAT='"+data.Clearance_TAT+"' , Country='"+data.Country+"',DG='"
        +data.DG+"', Date='"+Date_date+"', Delivery_Date='"+Delivery_Date+"', Docs_shared_date='"+Docs_shared_date+"', Freight='"+data.Freight+"', High_Value='"+data.High_Value+"', MPR='"+data.MPR+"', NRM='"+data.NRM+"', No_of_chem='"
        +data.No_of_chem+"' , PC_Meter='"+data.PC_Meter+"', Penalty_Charges='"+data.Penalty_Charges+"', Perishable='"+data.Perishable+"', Pick_up_date='"+Pick_up_date+"', Port_of_clearance='"+data.Port_of_clearance+"', Reason_for_penalty='"+data.Reason_for_penalty+"', Reasons='"
        +data.Reasons+"', Expected_Date_Delivery='"+Expected_Date_Delivery+"', Remarks='"+data.Remarks+"', Req_sent_by='"+data.Req_sent_by+"', Rev_info='"+Rev_info+"', Reasons_For_Reports='"+data.Reasons_For_Reports+"', SBU_location='"+data.SBU_location+"', Status='"+data.Status+"', Total_TAT='"+data.Total_TAT+"' , Transit_TAT='"+data.Transit_TAT+"', Vendor_name='"+data.Vendor_name+"', shpt_land_dt='"+shpt_land_dt+"', Zone='"+data.Zone+"', RemarksForReports='"+data.RemarksForReports+"', CMSshiptsBalanceDetails='"+data.CMSshiptsBalanceDetails+"', OriginalBoESubmittedDate='"+data.OriginalBoESubmittedDate+"', CMS_CDS_Product_NameRrProjectCode='"+data.CMS_CDS_Product_NameRrProjectCode+"', GrossWeight_Kg='"+data.GrossWeight_Kg+"' , DistanceInKms='"+data.DistanceInKms+"', Co2Emiission_Kg='"+data.Co2Emiission_Kg+"' where AWB_no='"+data.AWB_no+"';";
        db.executeSql(sqlUpdate, function(err, recordset){
            if(err){
				console.log(err,124)
				  res.json({msg:"Error in update sql",AWB:data.AWB_no,error:true,sql:sql})
             }else{
                  res.json({error:false,msg:'update success'});
			}
		})
          }else if(Array.isArray(recordset.recordset) && recordset.recordset.length == 0){
         var data = req.body;
        var sqlInsert = "INSERT INTO dbo.gvk_import_shipments(AWB_no, Rev_info, SBU_location, Delivery_Date, Req_sent_by, Vendor_name, Category, NRM, MPR, VPO, BLR, Country, No_of_chem, Reasons, Carrier, Pick_up_date, shpt_land_dt, Docs_shared_date, Port_of_clearance, CHA, Clearance_TAT, Transit_TAT, Total_TAT, Date, PC_Meter, Bill_No, Clearance_charges, Freight, BE_No, BE_Date, Penalty_Charges, Reason_for_penalty, Remarks, Approval_status, DG, High_Value, Perishable, BRO, Status, Expected_Date_Delivery,Reasons_For_Reports, Zone,RemarksForReports,CMSshiptsBalanceDetails,OriginalBoESubmittedDate,CMS_CDS_Product_NameRrProjectCode,GrossWeight_Kg,DistanceInKms,Co2Emiission_Kg) VALUES";
         sqlInsert += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
        data.AWB_no?data.AWB_no:'',Rev_info?Rev_info:'', data.SBU_location?data.SBU_location:'',Delivery_Date?Delivery_Date:'', data.Req_sent_by?data.Req_sent_by:'',
        data.Vendor_name?data.Vendor_name:'', data.Category?data.Category:'', data.NRM?data.NRM:'', data.MPR?data.MPR:'', data.VPO?data.VPO:'', data.BLR?data.BLR:'', data.Country?data.Country:'',
        data.No_of_chem?data.No_of_chem:'', data.Reasons?data.Reasons:'', data.Carrier?data.Carrier:'', Pick_up_date?Pick_up_date:'', shpt_land_dt?shpt_land_dt:'', 
        Docs_shared_date?Docs_shared_date:'', data.Port_of_clearance?data.Port_of_clearance:'', data.CHA?data.CHA:'', data.Clearance_TAT?data.Clearance_TAT:'', data.Transit_TAT?data.Transit_TAT:'', 
        data.Total_TAT?data.Total_TAT:'', Date_date?Date_date:'', data.PC_Meter?data.PC_Meter:'',data.Bill_No?data.Bill_No:'', data.Clearance_charges?data.Clearance_charges:'',
        data.Freight?data.Freight:'', data.BE_No?data.BE_No:'', BE_Date?BE_Date:'', data.Penalty_Charges?data.Penalty_Charges:'', data.Reason_for_penalty?data.Reason_for_penalty:'', data.Remarks?data.Remarks:'',
        data.Approval_status?data.Approval_status:'', data.DG?data.DG:'', data.High_Value?data.High_Value:'', data.Perishable?data.Perishable:'', data.BRO?data.BRO:'', data.Status?data.Status:'',Expected_Date_Delivery?Expected_Date_Delivery:'',data.Reasons_For_Reports?data.Reasons_For_Reports:'',data.Zone?data.Zone:'',data.RemarksForReports?data.RemarksForReports:'',data.CMSshiptsBalanceDetails?data.CMSshiptsBalanceDetails:'',data.OriginalBoESubmittedDate?data.OriginalBoESubmittedDate:'',data.CMS_CDS_Product_NameRrProjectCode?data.CMS_CDS_Product_NameRrProjectCode:'',data.GrossWeight_Kg?data.GrossWeight_Kg:'',data.DistanceInKms?data.DistanceInKms:'',data.Co2Emiission_Kg?data.Co2Emiission_Kg:'');
         db.executeSql(sqlInsert, function(err, recordset){
             if(err){
				 				console.log(err,143)

				  res.json({msg:"Error in insert sql",AWB:data.AWB_no,error:true,err:err})
             }else{
                  res.json({error:false,msg:'success'});
             }             
         }); 
        
        }else{
			 res.json({error:true,msg:'success',err:data.AWB_No});
		}
});
});


//GVK  Import Shipment data

app.post('/importRecordAdd',(req, res) => {
var data = req.body; 

	if (data.Rev_info) {
		var Rev = new Date(data.Rev_info);
		var Rev_info_d = Rev.setHours(Rev.getHours() + 4);
		var Rev_info=dateFormat(Rev_info_d, "yyyy-mm-dd");
	} else {
		var Rev_info = '';
	}	
	if(data.Date){
		var Datess = new Date(data.Date);
		var Date_date_d = Datess.setHours(Datess.getHours() + 4);
		var Date_date =dateFormat(Date_date_d, "yyyy-mm-dd");
	}else{ var Date_date='';	}

	if(data.Delivery_Date){
		var Delivery_Date_d = new Date(data.Delivery_Date);
		var Delivery_Date_d = Delivery_Date_d.setHours(Delivery_Date_d.getHours() + 4);
		var Delivery_Date =dateFormat(Delivery_Date_d, "yyyy-mm-dd");
	}else{ var Delivery_Date='';	}

	if(data.Expected_Date_Delivery){
		var Expected_Date_Delivery_d = new Date(data.Expected_Date_Delivery);
		var Expected_Date_Delivery_d = Expected_Date_Delivery_d.setHours(Expected_Date_Delivery_d.getHours() + 4);
		var Expected_Date_Delivery =dateFormat(Expected_Date_Delivery_d, "yyyy-mm-dd");

	}else{ var Expected_Date_Delivery='';	}

	if(data.Pick_up_date){
		var Pick_up_date_d = new Date(data.Pick_up_date);
		var Pick_up_date_d = Pick_up_date_d.setHours(Pick_up_date_d.getHours() + 4);
		var Pick_up_date =dateFormat(Pick_up_date_d, "yyyy-mm-dd");
	}else{ var Pick_up_date='';	}

	if(data.shpt_land_dt){
		var shpt_land_dt_d = new Date(data.shpt_land_dt);
		var shpt_land_dt_d = shpt_land_dt_d.setHours(shpt_land_dt_d.getHours() + 4);
		var shpt_land_dt =dateFormat(shpt_land_dt_d, "yyyy-mm-dd");
	}else{ var shpt_land_dt='';	}

	if(data.Docs_shared_date){
		var Docs_shared_date_d = new Date(data.Docs_shared_date);
		var Docs_shared_date_d = Docs_shared_date_d.setHours(Docs_shared_date_d.getHours() + 4);
		var Docs_shared_date =dateFormat(Docs_shared_date_d, "yyyy-mm-dd");
	}else{ var Docs_shared_date='';	}

	if(data.BE_Date){
		var BE_Date_d = new Date(data.BE_Date);
		var BE_Date_d = BE_Date_d.setHours(BE_Date_d.getHours() + 4);
		var BE_Date =dateFormat(BE_Date_d, "yyyy-mm-dd");
	}else{ var BE_Date='';	}

        var sql = "INSERT INTO dbo.gvk_import_shipments(AWB_no, Rev_info, SBU_location, Delivery_Date, Req_sent_by, Vendor_name, Category, NRM, MPR, VPO, BLR, Country, No_of_chem, Reasons, Carrier, Pick_up_date, shpt_land_dt, Docs_shared_date, Port_of_clearance, CHA, Clearance_TAT, Transit_TAT, Total_TAT, Date, PC_Meter, Bill_No, Clearance_charges, Freight, BE_No, BE_Date, Penalty_Charges, Reason_for_penalty, Remarks, Approval_status, DG, High_Value, Perishable, BRO, Status, Reasons_For_Reports,Expected_Date_Delivery) VALUES";
         sql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
        data.AWB_no?data.AWB_no:'',Rev_info?Rev_info:'', data.SBU_location?data.SBU_location:'',Delivery_Date?Delivery_Date:'', data.Req_sent_by?data.Req_sent_by:'',
        data.Vendor_name?data.Vendor_name:'', data.Category?data.Category:'', data.NRM?data.NRM:'', data.MPR?data.MPR:'', data.VPO?data.VPO:'', data.BLR?data.BLR:'', data.Country?data.Country:'',
        data.No_of_chem?data.No_of_chem:'', data.Reasons?data.Reasons:'', data.Carrier?data.Carrier:'', Pick_up_date?Pick_up_date:'', shpt_land_dt?shpt_land_dt:'', 
        Docs_shared_date?Docs_shared_date:'', data.Port_of_clearance?data.Port_of_clearance:'', data.CHA?data.CHA:'', data.Clearance_TAT?data.Clearance_TAT:'', data.Transit_TAT?data.Transit_TAT:'', 
        data.Total_TAT?data.Total_TAT:'', Date_date?Date_date:'', data.PC_Meter?data.PC_Meter:'',data.Bill_No?data.Bill_No:'', data.Clearance_charges?data.Clearance_charges:'',
        data.Freight?data.Freight:'', data.BE_No?data.BE_No:'', BE_Date?BE_Date:'', data.Penalty_Charges?data.Penalty_Charges:'', data.Reason_for_penalty?data.Reason_for_penalty:'', data.Remarks?data.Remarks:'',
        data.Approval_status?data.Approval_status:'', data.DG?data.DG:'', data.High_Value?data.High_Value:'', data.Perishable?data.Perishable:'', data.BRO?data.BRO:'', data.Status?data.Status:'',data.Reasons_For_Reports?data.Reasons_For_Reports:'',Expected_Date_Delivery?Expected_Date_Delivery:'');
  let query = db.executeSql(sql,(err, results) => {
    if(err){
		res.json({error:true,message:err})
	}else{			
		res.json({"status": 200, "error": req.body, "response": results});
	}
  });
});

/// Edit Import record By ID

app.put('/importRecordEdit/:id',(req, res) => {
  var dataa = req.body;
  let sql = "UPDATE gvk_import_shipments SET ? WHERE id="+req.params.id;
  let query = db.executeSql(sql, dataa, (err, results) => {
    if(err) throw err;
    res.send(JSON.stringify({"status": 200, "error": null, "response": results}));
  });
});
app.put('/updateDetails/:ID', function(req, res){
    const id = req.params.ID;
    var data= req.body;
	if (data.Rev_info) {
		var Rev_info_d = new Date(data.Rev_info);
		var Rev_info_d = Rev_info.setHours(Rev_info.getHours() + 4);
		var Rev_info=dateFormat(Rev_info_d, "yyyy-mm-dd");
	} else {
		var Rev_info = '';
	}	
	if(data.Date){
		var Datess = new Date(data.Date);
		var Date_date_d = Datess.setHours(Datess.getHours() + 4);
		var Date_date =dateFormat(Date_date_d, "yyyy-mm-dd");
	}else{ var Date_date='';	}

	if(data.Delivery_Date){
		var Delivery_Date_d = new Date(data.Delivery_Date);
		var Delivery_Date_d = Delivery_Date_d.setHours(Delivery_Date_d.getHours() + 4);
		var Delivery_Date =dateFormat(Delivery_Date_d, "yyyy-mm-dd");
	}else{ var Delivery_Date='';	}

	if(data.Expected_Date_Delivery){
		var Expected_Date_Delivery_d = new Date(data.Expected_Date_Delivery);
		var Expected_Date_Delivery_d = Expected_Date_Delivery_d.setHours(Expected_Date_Delivery_d.getHours() + 4);
		var Expected_Date_Delivery =dateFormat(Expected_Date_Delivery_d, "yyyy-mm-dd");

	}else{ var Expected_Date_Delivery='';	}

	if(data.Pick_up_date){
		var Pick_up_date_d = new Date(data.Pick_up_date);
		var Pick_up_date_d = Pick_up_date_d.setHours(Pick_up_date_d.getHours() + 4);
		var Pick_up_date =dateFormat(Pick_up_date_d, "yyyy-mm-dd");
	}else{ var Pick_up_date='';	}

	if(data.shpt_land_dt){
		var shpt_land_dt_d = new Date(data.shpt_land_dt);
		var shpt_land_dt_d = shpt_land_dt_d.setHours(shpt_land_dt_d.getHours() + 4);
		var shpt_land_dt =dateFormat(shpt_land_dt_d, "yyyy-mm-dd");
	}else{ var shpt_land_dt='';	}

	if(data.Docs_shared_date){
		var Docs_shared_date_d = new Date(data.Docs_shared_date);
		var Docs_shared_date_d = Docs_shared_date_d.setHours(Docs_shared_date_d.getHours() + 4);
		var Docs_shared_date =dateFormat(Docs_shared_date_d, "yyyy-mm-dd");
	}else{ var Docs_shared_date='';	}

	if(data.BE_Date){
		var BE_Date_d = new Date(data.BE_Date);
		var BE_Date_d = BE_Date_d.setHours(BE_Date_d.getHours() + 4);
		var BE_Date =dateFormat(BE_Date_d, "yyyy-mm-dd");
	}else{ var BE_Date='';	}

    var sql = "UPDATE gvk_import_shipments SET AWB_no='"+data.AWB_no+"', Approval_status='" +data.Approval_status+"', BE_Date='" +BE_Date+"', BE_No='" +data.BE_No+"', BLR='" +data.BLR+"', CHA='" +data.CHA+"', Carrier='" +data.Carrier+"' , Category='" +data.Category+"' , Clearance_Charges='" +data.Clearance_Charges+"', Clearance_TAT='" +data.Clearance_TAT+"', Country='" +data.Country+"', DG='" +data.DG+"', Date='" +Date_date+"', Delivery_Date='" +Delivery_Date+"', Docs_shared_date='" +Docs_shared_date+"', Expected_Date_Delivery='" +Expected_Date_Delivery+"', Freight='" +data.Freight+"', High_Value='" +data.High_Value+"', MPR='" +data.MPR+"', NRM='" +data.NRM+"', No_of_chem='" +data.No_of_chem+"', Penalty_Charges='" +data.Penalty_Charges+"', Perishable='" +data.Perishable+"', Pick_up_date='" +Pick_up_date+"', Port_of_clearance='" +data.Port_of_clearance+"', Reason_for_penalty='" +data.Reason_for_penalty+"', Reasons='" +data.Reasons+"', Reasons_For_Reports='" +data.Reasons_For_Reports+"', Remarks='" +data.Remarks+"', Req_sent_by='" +data.Req_sent_by+"', Rev_info='" +Rev_info+"', SBU_location='" +data.SBU_location+"', Status='" +data.Status+"', Total_TAT='" +data.Total_TAT+"', Transit_TAT='" +data.Transit_TAT+"', VPO='" +data.VPO+"', Vendor_name='" +data.Vendor_name+"', shpt_land_dt='" +shpt_land_dt+"', Zone='"+data.Zone+"', RemarksForReports='"+data.RemarksForReports+"', CMSshiptsBalanceDetails='"+data.CMSshiptsBalanceDetails+"', OriginalBoESubmittedDate='"+data.OriginalBoESubmittedDate+"', CMS_CDS_Product_NameRrProjectCode='"+data.CMS_CDS_Product_NameRrProjectCode+"', GrossWeight_Kg='"+data.GrossWeight_Kg+"' , DistanceInKms='"+data.DistanceInKms+"', Co2Emiission_Kg='"+data.Co2Emiission_Kg+"' where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is here", err);
        else
    res.send(JSON.stringify({"status": 200, "error":data, "response": recordset}));
    })
})


/// DELETE Row in Import Shipment

app.delete('/removeimportShipment/:id', function(req, res){
    console.log('connection established')
    const id = req.params.id;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_import_shipments WHERE id IN ("+id+");";
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})


module.exports = app;