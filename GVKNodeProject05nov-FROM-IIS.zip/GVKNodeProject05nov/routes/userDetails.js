 'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

// app.get('/user', function(req, res){
//     // var req = new sql.Request(connection);
//     console.log('connection established')
//     db.executeSql("select * from Users", function(err, recordset){
//         if (err)        
//         console.log('error is here', err);
//          else  
//          //console.log('response',recordset);
//          res.send(recordset)
//     });
// });
 
app.post('/user', function(req, res){
     const email = req.body.email;
    //  console.log("retret", email);
     const password = req.body.password;  
    //  console.log("retret", password);
     var sql = "select * from Users where email='"+email+"' and password='"+password+"';";
    console.log('Query is',sql);
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});
  
app.get('/user/:email', function(req, res){
  // var req = new sql.Request(connection);
  // console.log('connection established')
   const email = req.params.email;    
   var sql = "select * from Users where email='"+email+"';";
  // console.log(sql)
  //  var sql = "select * from User where email =+email";
  db.executeSql(sql, function(err, recordset){
      if (err)        
      console.log('error is here', err);
       else  
       //console.log('response',recordset);
       res.send(recordset)
  });
});

  app.post('/userDetails', function(req, res){
    console.log('connection established')
   var data = req.body
    var sql = "INSERT INTO Users (email, password) VALUES";
    sql += util.format("('%s', '%s')", data.email, data.password)    
     db.executeSql(sql, function(err, recordset){
            if(err){
            console.log("Error in the query")
          } else{
            //console.log('record inserted')
            res.send(JSON.stringify(recordset))
          }
    });
});

module.exports = app;