const nodemailer        = require('nodemailer'),
      nodemailerMailgun = require('nodemailer-mailgun-transport'),
      fs                = require('fs');
var middlewareObj = {};

// Check Candidate logged in

middlewareObj.shipmentUpdate = function(userParams)
{
  const auth = {
    auth: {
      api_key: process.env.MAILGUN_API,
      domain: process.env.MAILGUN_DOMAIN
    }
  }
  var transporter = nodemailer.createTransport( nodemailerMailgun(auth) );
  
  var mailOptions = {
    from: 'SheJobs Admin <admin@mails.she-jobs.com>',
    to: userParams.email,
    subject: userParams.subject,
    html: `
          <h4> Hi ,</h4> 
          <p>Your Resume uploded in SheJobs`        
  };
  
  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
      let params = {}
      params['status'] = false
      params['message'] = error
      return params
    } else {
      console.log('resume parser  Email sent');
      let params = {}
      params['status'] = true
      params['message'] = 'Done'
      return params
    }
  });
}

module.exports = middlewareObj;