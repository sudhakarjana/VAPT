'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.get('/userslist', function(req, res){
    var sql = "select * from gvk_users ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err){
         res.json({error:true,result:err});
		}else{
         res.json({error:false,result:recordset.recordset});
        }
    });
});
app.get('/userdetails/:ID', function(req, res){
    const id = req.params.ID;
    var sql = "select * from gvk_users where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err){
         res.json({error:true,result:err});
		}else{
         res.json({error:false,result:recordset.recordset});
        }
    });
});

app.post('/userAdd', function(req, res){
    console.log('connection established')
   var data = req.body;
   var sql = "INSERT INTO gvk_users (email, password,usertype,status,fullname,username,designation,department,customerID) VALUES";
    sql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s')", data.email, data.password, data.usertype, data.status,data.fullname,data.username,data.designation,data.department,data.customerID)    
     db.executeSql(sql, function(err, recordset){
        if(err){
         res.json({error:true,result:err});
		}else{
         res.json({error:false,result:recordset.recordset});
        }
    });
});

app.put('/userUpdate/:ID', function(req, res){
    const id = req.params.ID;
    var data= req.body;
    var sql = "UPDATE gvk_users SET email='"+data.email+"', password='"+data.password+"', status='"+data.status+"', usertype='"+data.usertype+"' , department='"+data.department+"', designation='"+data.designation+"' , fullname='"+data.fullname+"', username='"+data.username+"' , customerID='"+data.customerID+"' where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err){
         res.json({error:true,result:err});
		}else{
         res.json({error:false,result:recordset.recordset});
        }
    })
})

app.delete('/Deleteuser/:ID', function(req, res){
    const id = req.params.ID;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_users WHERE id="+id+";";
    db.executeSql(sql, function(err, recordset){
       if(err){
			res.json({error:true,result:err});
		}else{
         res.json({error:false,result:recordset.recordset});
        }
    });
})
module.exports = app;