'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.get('/vendorsList', function(req, res){
    var sql = "select * from gvk_vendor ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});
app.get('/vendors/:ID', function(req, res){
    const id = req.params.ID;
    var sql = "select * from gvk_vendor where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});

app.post('/vendoradd', function(req, res){
    console.log('connection established')
   var data = req.body;
   data.Create_Date =  new Date();
    var sql = "INSERT INTO gvk_vendor (vendor_name) VALUES";
    sql += util.format("('%s')", data.vendor_name)    
     db.executeSql(sql, function(err, recordset){
            if(err){
            console.log("Error in the query")
          } else{
            //console.log('record inserted')
            res.send(JSON.stringify(recordset))
          }
    });
});

app.put('/updateVendorDetails/:ID', function(req, res){
    const id = req.params.ID;
    var data= req.body;
    var sql = "UPDATE gvk_vendor SET vendor_name='"+data.vendor_name+"' where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is here", err);
        else
        res.send(recordset)
    })
})

app.delete('/deleteVendor/:ID', function(req, res){
    console.log('connection established')
    const id = req.params.ID;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_vendor WHERE ID="+id+";";
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})
module.exports = app;