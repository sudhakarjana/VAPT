'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.post('/insertExportShipment', function(req, res){
    
    var data =req.body;
    var sql = "INSERT into dbo.gvk_export_shipments(SBU_location, Compound_DM_Time, CR_DM_Date, Clearance_BSO_NON_BSO, Carrier, Contract, SOLD_TO, SHIP_TO, Destination, Zone_Sales_District,\
        Description, QTY, SAP_Ref_No, Invoice_No, Invoice_Date, Clearance_charges, Carrier_Bill_Freight_charges, Tracking_No, Date, Shipment_Day_of_pick_up,\
        Departure_from_India, Landing_Destination_Port, Destination_Customs_release_date, Date_of_Delivery_to_client, No_of_days_Door_to_Port,\
        No_of_days_Door_to_Door, Remarks, HS_Code_No, No_of_Boxes, Gr_Wt, Unit_of_measure, Package_Size, Storage_Conditions, Net_Wt, UOM,\
        Currency, Invoice_Value, Value_in_INR, FOB_Value, Shipping_Bill_Number, Shipping_Bill_Date, MAWB, HAWB, LEO_No, LEO_Date,\
        SB_original_Date_of_receipt, uploaded_finance_Share, create_date, update_date, customerID,Status) VALUES";
    sql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',\
                        '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',\
                        '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s')",
                        data.SBU_location, data.Compound_DM_Time, data.CR_DM_Date, data.Clearance_BSO_NON_BSO, data.Carrier, data.Contract, data.SOLD_TO, data.SHIP_TO, data.Destination, data.Zone_Sales_District,
                        data.Description, data.QTY, data.SAP_Ref_No, data.Invoice_No, data.Invoice_Date, data.Clearance_charges, data.Carrier_Bill_Freight_charges, data.Tracking_No, data.Date, data.Shipment_Day_of_pick_up,
                        data.Departure_from_India, data.Landing_Destination_Port, data.Destination_Customs_release_date, data.Date_of_Delivery_to_client, data.No_of_days_Door_to_Port,
                        data.No_of_days_Door_to_Door, data.Remarks, data.HS_Code_No, data.No_of_Boxes, data.Gr_Wt, data.Unit_of_measure, data.Package_Size, data.Storage_Conditions, data.Net_Wt, data.UOM,
                        data.Currency, data.Invoice_Value, data.Value_in_INR, data.FOB_Value, data.Shipping_Bill_Number, data.Shipping_Bill_Date, data.MAWB, data.HAWB, data.LEO_No, data.LEO_Date,
                        data.SB_original_Date_of_receipt, data.uploaded_finance_Share, data.create_date, data.update_date, data.customerID, data.Status);
                        db.executeSql(sql, function(err, recordset){
                            if(err)
                            console.log('error is:', err);
                            else{
                                res.send(JSON.stringify(recordset));
                            }
                        })
})
app.get('/export_shipments', function(req, res){
    var sql= "select * from gvk_export_shipments ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is:", err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    })
})
app.post('/allshipments', function(req, res){
if(req.body.pagePer && req.body.pageNo){
 var pagePer = req.body.pagePer
  var key = req.body.searchKey
  var pageNo = req.body.pageNo
  var offset = (pageNo-1) * pagePer
  if(key){
	var where = "WHERE Invoice_No LIKE '%"+key+"%' OR SBU_location LIKE '%"+key+"%' OR Tracking_No LIKE '%"+key+"%'"
  }else{
	var where = ""
  }
  var sql = "select * from gvk_export_shipments "+where+" ORDER BY id DESC OFFSET "+offset+" ROWS FETCH NEXT "+pagePer+" ROWS ONLY; select * from gvk_export_shipments "+where+""
  db.executeSql(sql, function(err, recordset){
        if (err)  {      
      //  console.log('error is here', err);
		res.json({error:true,message:"sql error",sql:sql,pagePer:pagePer,pageNo:pageNo});
		}else {
        // console.log('response',sql);
         res.json({error:false,records:recordset.recordsets[0],count:recordset.recordsets[1].length,pagePer:pagePer,pageNo:pageNo,params:req.body});
		}
});
}else{
	res.json({error:true,message:"Required all fields",});
	
}
});

app.get('/getexport_shipmentDetails/:id', function(req, res){
    var id = req.params.id;
    var sql = "select * from gvk_export_shipments where id='"+id+"';";
    db.executeSql(sql, function(err, results){
        if(err)
        console.log("error is:", err)
        else{
		res.send(JSON.stringify({"status": 200, "error": null, "response": results.recordset}));
        }
    })
})

app.put('/export_shipmentsUpdate/:ID', function(req, res){
    const id = req.params.ID;
    var data = req.body;
    var sql = "UPDATE gvk_export_shipments SET SBU_location='"+data.SBU_location+"',Compound_DM_Time='" +data.Compound_DM_Time+"',CR_DM_Date='"+data.CR_DM_Date+"',Clearance_BSO_NON_BSO='"+data.Clearance_BSO_NON_BSO+"',Carrier='"+data.Carrier+"', Contract='"+data.Contract+"', SOLD_TO='"+data.SOLD_TO+"',SHIP_TO='"+data.SHIP_TO+"',Destination='"+data.Destination+"', Zone_Sales_District='"
    +data.Zone_Sales_District+"',Description='"+data.Description+"',QTY='"+data.QTY+"', SAP_Ref_No='"+data.SAP_Ref_No+"', Invoice_No='"+data.Invoice_No+"', Invoice_Date='"+data.Invoice_Date+"',Clearance_charges='"+data.Clearance_charges+"', Carrier_Bill_Freight_charges='"+data.Carrier_Bill_Freight_charges+"', Tracking_No='"+data.Tracking_No+"', Date='"
    +data.Date+"', Shipment_Day_of_pick_up='" +data.Shipment_Day_of_pick_up+"', Departure_from_India='"+data.Departure_from_India+"', Landing_Destination_Port='"+data.Landing_Destination_Port+"', Destination_Customs_release_date='"+data.Destination_Customs_release_date+"', Date_of_Delivery_to_client='"+data.Date_of_Delivery_to_client+"', No_of_days_Door_to_Port='"
    +data.No_of_days_Door_to_Port+"', No_of_days_Door_to_Door='"+data.No_of_days_Door_to_Door+"', Remarks='"+data.Remarks+"', HS_Code_No='"+data.HS_Code_No+"', No_of_Boxes='"+data.No_of_Boxes+"', Gr_Wt='"+data.Gr_Wt+"', Unit_of_measure='"+data.Unit_of_measure+"', Package_Size='"+data.Package_Size+"', Storage_Conditions='"+data.Storage_Conditions+"',Net_Wt='"
    +data.Net_Wt+"', UOM='"+data.UOM+"', Currency='"+data.Currency+"', Invoice_Value='"+data.Invoice_Value+"', Value_in_INR='"+data.Value_in_INR+"', FOB_Value='"+data.FOB_Value+"', Shipping_Bill_Number='"+data.Shipping_Bill_Number+"', Shipping_Bill_Date='"+data.Shipping_Bill_Date+"', MAWB='"+data.MAWB+"', HAWB='"+data.HAWB+"', LEO_No='"+data.LEO_No+"',LEO_Date='"
    +data.LEO_Date+"', SB_original_Date_of_receipt='"+data.SB_original_Date_of_receipt+"', uploaded_finance_Share='"+data.uploaded_finance_Share+"', customerID='"+data.customerID+"', Status='"+data.Status+"' WHERE id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is:", err)
        else{
            res.send(recordset);
        }
    })
})

app.post('/exportExcelUpdate', function (req, res) {
    const Invoice_No = req.body.Invoice_No;
	var Regiondata = req.body.Region
	var Region = Regiondata.replace(/ /g, "")
    if (Invoice_No) {
        var sql = "select * from gvk_export_shipments where Invoice_No='" + Invoice_No + "';";
        db.executeSql(sql, function (err, recordset) {
            if (err){
                res.json({error:true,sql:sql});
            }else if (recordset.recordset.length != 0) {
                var data = req.body;
                  if (data.Invoice_Date) {
                        var InvoiceDate = data.Invoice_Date
                    } else {
                        var InvoiceDate = '';
                    }
                    if (data.Shipment_Day_of_pick_up) {
                        var Shipment_Day_of_pickup = data.Shipment_Day_of_pick_up
                    } else {
                        var Shipment_Day_of_pickup = '';
                    }
                    if (data.Date) {
                        var Datenewd = data.Date;
                    } else {
                        var Datenewd = '';
                    }
                    if (data.Departure_from_India) {
                        var Departure_fromIndia = data.Departure_from_India
                    } else {
                        var Departure_fromIndia = '';
                    }
                    if (data.Landing_Destination_Port) {
                        var Landing_DestinationPort = data.Landing_Destination_Port
                    } else {
                        var Landing_DestinationPort = '';
                    }
                    if (data.Destination_Customs_release_date) {
                        var Destination_Customs_releasedate = data.Destination_Customs_release_date
                    } else {
                        var Destination_Customs_releasedate = '';
                    }
                    if (data.Date_of_Delivery_to_client) {
                        var Date_of_Delivery_toclient = data.Date_of_Delivery_to_client
                    } else {
                        var Date_of_Delivery_toclient = '';
                    }
                    if (data.CR_DM_Date) {
                        var CR_DMDate = data.CR_DM_Date
                    } else {
                        var CR_DMDate = '';
                    }
                if (data.SHIP_TO) {
                    var SHIP_TO = data.SHIP_TO;
                    var SHIPTO = SHIP_TO.replace(/[^a-zA-Z ]/g, " ");

                } else {
                    var SHIPTO = '';
                }
                if (data.Remarks) {
                    var Remarks = data.Remarks;
                    var Remarksss = Remarks.replace(/[^a-zA-Z ]/g, " ");
                } else {
                    var Remarksss = '';
                }
				if (data.Destination) {
					var Destination = data.Destination;
					var DestinationData = Destination.replace(/[^a-zA-Z ]/g, " ");
				} else {
					var DestinationData = '';
				}
				if (data.Storage_Conditions) {
					var Storage_Conditions = data.Storage_Conditions;
					var Storage_Condition = Storage_Conditions.replace(/[^a-zA-Z ]/g, " ");
				} else {
					var Storage_Condition = '';
				}
				if (data.UOM) {
					var UOM = data.UOM;
					var UOM_data= UOM.replace(/[^a-zA-Z ]/g, " ");
				} else {
					var UOM_data = '';
				}


                var sql = "UPDATE gvk_export_shipments SET SBU_location='" + data.SBU_location + "',Compound_DM_Time='" + data.Compound_DM_Time + "',CR_DM_Date='" + CR_DMDate + "',Clearance_BSO_NON_BSO='" + data.Clearance_BSO_NON_BSO + "',Carrier='" + data.Carrier + "', Contract='" + data.Contract + "', SOLD_TO='" + data.SOLD_TO + "',SHIP_TO='" + SHIPTO + "',Destination='" + DestinationData + "', Zone_Sales_District='"
                + data.Zone_Sales_District + "', Region='"
                + Region + "',Description='" + data.Description + "',QTY='" + data.QTY + "', SAP_Ref_No='" + data.SAP_Ref_No + "', Invoice_Date='" + InvoiceDate + "',Clearance_charges='" + data.Clearance_charges + "', Carrier_Bill_Freight_charges='" + data.Carrier_Bill_Freight_charges + "', Tracking_No='" + data.Tracking_No + "', Date='"
                + Datenewd + "', Shipment_Day_of_pick_up='" + Shipment_Day_of_pickup + "', Departure_from_India='" + Departure_fromIndia + "', Landing_Destination_Port='" + Landing_DestinationPort + "', Destination_Customs_release_date='" + Destination_Customs_releasedate + "', Date_of_Delivery_to_client='" + Date_of_Delivery_toclient + "', No_of_days_Door_to_Port='"
                + data.No_of_days_Door_to_Port + "', No_of_days_Door_to_Door='" + data.No_of_days_Door_to_Door + "', Remarks='" + Remarksss + "', HS_Code_No='" + data.HS_Code_No + "', No_of_Boxes='" + data.No_of_Boxes + "', Gr_Wt='" + data.Gr_Wt + "', Unit_of_measure='" + data.Unit_of_measure + "', Package_Size='" + data.Package_Size + "', Storage_Conditions='" + Storage_Condition + "',Net_Wt='"
                + data.Net_Wt + "', UOM='" + UOM_data + "', Currency='" + data.Currency + "', Invoice_Value='" + data.Invoice_Value + "', Value_in_INR='" + data.Value_in_INR + "', FOB_Value='" + data.FOB_Value + "', Shipping_Bill_Number='" + data.Shipping_Bill_Number + "', Shipping_Bill_Date='" + data.Shipping_Bill_Date + "', MAWB='" + data.MAWB + "', HAWB='" + data.HAWB + "', LEO_No='" + data.LEO_No + "',LEO_Date='"
                + data.LEO_Date + "', SB_original_Date_of_receipt='" + data.SB_original_Date_of_receipt + "', uploaded_finance_Share='" + data.uploaded_finance_Share + "', customerID='" + data.customerID + "', Status='" + data.Status + "' WHERE Invoice_No='" + data.Invoice_No + "'";
                
                db.executeSql(sql, function (err, recordset) {
                    if (err){
                      res.json({error:true,sql:sql});
                        }else {
                           res.json({error:false,recordset});
					}
                })
            }
            else if (recordset.recordset.length == 0) {
                var data = req.body;
                const Invoice_No = req.body.Invoice_No;
                if (Invoice_No) {
					if (data.Invoice_Date) {
                        var InvoiceDate = data.Invoice_Date
                    } else {
                        var InvoiceDate = '';
                    }
                    if (data.Shipment_Day_of_pick_up) {
                        var Shipment_Day_of_pickup = data.Shipment_Day_of_pick_up
                    } else {
                        var Shipment_Day_of_pickup = '';
                    }
                    if (data.Date) {
                        var Datenew = data.Date;
                    } else {
                        var Datenew = '';
                    }
                    if (data.Departure_from_India) {
                        var Departure_fromIndia = data.Departure_from_India
                    } else {
                        var Departure_fromIndia = '';
                    }
                    if (data.Landing_Destination_Port) {
                        var Landing_DestinationPort = data.Landing_Destination_Port
                    } else {
                        var Landing_DestinationPort = '';
                    }
                    if (data.Destination_Customs_release_date) {
                        var Destination_Customs_releasedate = data.Destination_Customs_release_date
                    } else {
                        var Destination_Customs_releasedate = '';
                    }
                    if (data.Date_of_Delivery_to_client) {
                        var Date_of_Delivery_toclient = data.Date_of_Delivery_to_client
                    } else {
                        var Date_of_Delivery_toclient = '';
                    }
                    if (data.CR_DM_Date) {
                        var CR_DMDate = data.CR_DM_Date
                    } else {
                        var CR_DMDate = '';
                    }
                    if (data.SHIP_TO) {
                    var SHIP_TO = data.SHIP_TO;
                    var SHIPTO = SHIP_TO.replace(/[^a-zA-Z ]/g, " ");

                } else {
                    var SHIPTO = '';
                }
                if (data.Remarks) {
                    var Remarks = data.Remarks;
                    var Remarksss = Remarks.replace(/[^a-zA-Z ]/g, " ");
                } else {
                    var Remarksss = '';
                }
				if (data.Destination) {
					var Destination = data.Destination;
					var DestinationData = Destination.replace(/[^a-zA-Z ]/g, " ");
				} else {
					var DestinationData = '';
				}
				if (data.Storage_Conditions) {
					var Storage_Conditions = data.Storage_Conditions;
					var Storage_Condition = Storage_Conditions.replace(/[^a-zA-Z ]/g, " ");
				} else {
					var Storage_Condition = '';
				}
				if (data.UOM) {
					var UOM = data.UOM;
					var UOM_data= UOM.replace(/[^a-zA-Z ]/g, " ");
				} else {
					var UOM_data = '';
				}
                    var sql = "INSERT into dbo.gvk_export_shipments(SBU_location, Compound_DM_Time, CR_DM_Date, Clearance_BSO_NON_BSO, Carrier, Contract, SOLD_TO, SHIP_TO, Destination, Zone_Sales_District, Region,\
            Description, QTY, SAP_Ref_No, Invoice_No, Invoice_Date, Clearance_charges, Carrier_Bill_Freight_charges, Tracking_No, Date, Shipment_Day_of_pick_up,\
            Departure_from_India, Landing_Destination_Port, Destination_Customs_release_date, Date_of_Delivery_to_client, No_of_days_Door_to_Port,\
            No_of_days_Door_to_Door, Remarks, HS_Code_No, No_of_Boxes, Gr_Wt, Unit_of_measure, Package_Size, Storage_Conditions, Net_Wt, UOM,\
            Currency, Invoice_Value, Value_in_INR, FOB_Value, Shipping_Bill_Number, Shipping_Bill_Date, MAWB, HAWB, LEO_No, LEO_Date,\
            SB_original_Date_of_receipt, uploaded_finance_Share, customerID,Status) VALUES";
                    sql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',\
         '%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',\
         '%s','%s','%s','%s','%s','%s','%s','%s','%s')",
                    data.SBU_location, data.Compound_DM_Time, CR_DMDate, data.Clearance_BSO_NON_BSO, data.Carrier, data.Contract, data.SOLD_TO, SHIPTO, DestinationData, data.Zone_Sales_District, Region,
                    data.Description, data.QTY, data.SAP_Ref_No, data.Invoice_No, InvoiceDate, data.Clearance_charges, data.Carrier_Bill_Freight_charges, data.Tracking_No, Datenew, Shipment_Day_of_pickup,
                    Departure_fromIndia, Landing_DestinationPort, Destination_Customs_releasedate, Date_of_Delivery_toclient, data.No_of_days_Door_to_Port,
                    data.No_of_days_Door_to_Door, Remarksss, data.HS_Code_No, data.No_of_Boxes, data.Gr_Wt, data.Unit_of_measure, data.Package_Size, Storage_Condition, data.Net_Wt, UOM_data,
                    data.Currency, data.Invoice_Value, data.Value_in_INR, data.FOB_Value, data.Shipping_Bill_Number, data.Shipping_Bill_Date, data.MAWB, data.HAWB, data.LEO_No, data.LEO_Date,
                    data.SB_original_Date_of_receipt, data.uploaded_finance_Share, data.customerID, data.Status);
                    db.executeSql(sql, function (err, recordset) {
                        if (err){
				            console.log("Error in the sql", sql);
							res.json({error:true,sql:sql});
                        }else {
                           res.json({error:false,recordset:recordset});
                        }
                    });

                }
            }
        });
    }
});


app.delete('/removeExportShipment/:ID', function(req, res){
    const id= req.params.ID;
    var sql ="DELETE FROM gvk_export_shipments where id IN ("+id+");";
    db.executeSql(sql, function(err, recordset){
        if(err)
        res.json({error:true,sql:sql});
        else{
            res.json({error:false,recordset:recordset});
        }
    })

})

app.get('/UOM', function(req, res){
    db.executeSql("select * from Export_UOM", function(err, recordset){
        if(err)
       res.json({error:true,sql:sql});
        else{
             res.json({error:false,recordset:recordset});
        }
    })    
});
app.get('/Currency', function(req, res){
    db.executeSql("select * from Export_Currency", function(err, recordset){
        if(err)
        res.json({error:true,sql:sql});
        else{
             res.json({error:false,recordset:recordset});
        }
    })    
})


module.exports = app;