(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _product_result_product_result_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./product-result/product-result.component */ "./src/app/product-result/product-result.component.ts");
/* harmony import */ var _import_records_import_records_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./import-records/import-records.component */ "./src/app/import-records/import-records.component.ts");
/* harmony import */ var _export_records_export_records_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./export-records/export-records.component */ "./src/app/export-records/export-records.component.ts");
/* harmony import */ var _import_shipment_details_import_shipment_details_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./import-shipment-details/import-shipment-details.component */ "./src/app/import-shipment-details/import-shipment-details.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./privacy-policy/privacy-policy.component */ "./src/app/privacy-policy/privacy-policy.component.ts");
/* harmony import */ var _terms_conditions_terms_conditions_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./terms-conditions/terms-conditions.component */ "./src/app/terms-conditions/terms-conditions.component.ts");
/* harmony import */ var _export_shipments_list_export_shipments_list_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./export-shipments-list/export-shipments-list.component */ "./src/app/export-shipments-list/export-shipments-list.component.ts");
/* harmony import */ var _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./change-password/change-password.component */ "./src/app/change-password/change-password.component.ts");
/* harmony import */ var _saved_search_saved_search_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./saved-search/saved-search.component */ "./src/app/saved-search/saved-search.component.ts");
/* harmony import */ var _dhl_tracking_dhl_tracking_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./dhl-tracking/dhl-tracking.component */ "./src/app/dhl-tracking/dhl-tracking.component.ts");
/* harmony import */ var _fedex_tracking_fedex_tracking_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./fedex-tracking/fedex-tracking.component */ "./src/app/fedex-tracking/fedex-tracking.component.ts");
/* harmony import */ var _src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../src/services/auth.guard */ "./src/services/auth.guard.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
















var routes = [
    {
        path: 'login',
        component: _login_login_component__WEBPACK_IMPORTED_MODULE_2__["LoginComponent"]
    },
    { path: 'privacy-policy', component: _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_8__["PrivacyPolicyComponent"] },
    { path: 'change-password', component: _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_11__["ChangePasswordComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'import-records', component: _import_records_import_records_component__WEBPACK_IMPORTED_MODULE_4__["ImportRecordsComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'import-records/:awbNo', component: _import_records_import_records_component__WEBPACK_IMPORTED_MODULE_4__["ImportRecordsComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'export-records/:awbNo', component: _export_records_export_records_component__WEBPACK_IMPORTED_MODULE_5__["ExportRecordsComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'export-records', component: _export_records_export_records_component__WEBPACK_IMPORTED_MODULE_5__["ExportRecordsComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'export-shipments-list/:awbNo', component: _export_shipments_list_export_shipments_list_component__WEBPACK_IMPORTED_MODULE_10__["ExportShipmentsListComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'terms-conditions', component: _terms_conditions_terms_conditions_component__WEBPACK_IMPORTED_MODULE_9__["TermsConditionsComponent"] },
    { path: 'productDetails', component: _product_result_product_result_component__WEBPACK_IMPORTED_MODULE_3__["ProductResultComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'productDetails/:awbNo', component: _product_result_product_result_component__WEBPACK_IMPORTED_MODULE_3__["ProductResultComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'importdatails/:awbNo', component: _import_shipment_details_import_shipment_details_component__WEBPACK_IMPORTED_MODULE_6__["ImportShipmentDetailsComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'saved-search', component: _saved_search_saved_search_component__WEBPACK_IMPORTED_MODULE_12__["SavedSearchComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'track/:id', component: _dhl_tracking_dhl_tracking_component__WEBPACK_IMPORTED_MODULE_13__["DhlTrackingComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: 'fedex-tracking/:id', component: _fedex_tracking_fedex_tracking_component__WEBPACK_IMPORTED_MODULE_14__["FedexTrackingComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: '', component: _home_home_component__WEBPACK_IMPORTED_MODULE_7__["HomeComponent"], canActivate: [_src_services_auth_guard__WEBPACK_IMPORTED_MODULE_15__["AuthGuard"]] },
    { path: '**', redirectTo: '' }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<router-outlet></router-outlet>\r\n<div *ngIf=\"aggreymessage\" class=\"no-margin agree-sec\">\r\n<p>This Website uses cookies to provide you with a personalized browsing experience. By using this Website you agree to our use of cookies as explained in our Privacy Policy. Please read our Privacy Policy for more information on how we use cookies and how you can manage them.</p>\r\n\t\t\t\t\t\t\t\t<button (click)=\"createCookie()\" class=\"btn-1\">I Agree</button>\t\t\t\t\t\t\t</div>\r\n<!--<div class=\"col-sm-12 no-margin footer-sec\">\r\n<p>© {{cyear | date:'yyyy'}} &nbsp;|  Aragen Life Sciences Private Limited, All Rights Reserved | <a routerLink=\"/terms-conditions\">Terms &amp; Conditions</a> | <a routerLink=\"/privacy-policy\" >Privacy Policy</a> \r\n</p>\t\t\t\t\t\t\t\r\n</div>-->"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var ngx_cookie_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ngx-cookie-service */ "./node_modules/ngx-cookie-service/ngx-cookie-service.es5.js");
/* harmony import */ var _ng_idle_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-idle/core */ "./node_modules/@ng-idle/core/fesm5/ng-idle-core.js");
/* harmony import */ var _ng_idle_keepalive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ng-idle/keepalive */ "./node_modules/@ng-idle/keepalive/fesm5/ng-idle-keepalive.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var AppComponent = /** @class */ (function () {
    function AppComponent(cookieService, idle, keepalive, router) {
        var _this = this;
        this.cookieService = cookieService;
        this.idle = idle;
        this.keepalive = keepalive;
        this.router = router;
        this.title = 'eCule Logi Tracker';
        this.cyear = new Date();
        this.idleState = 'Not started.';
        this.timedOut = false;
        this.lastPing = null;
        router.events.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["filter"])(function (event) { return event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_4__["NavigationEnd"]; }))
            .subscribe(function (event) {
            var url = event['url'].split("?")[0];
            if (url != '/login') {
                idle.setIdle(5);
                // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
                idle.setTimeout(3600);
                // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
                idle.setInterrupts(_ng_idle_core__WEBPACK_IMPORTED_MODULE_2__["DEFAULT_INTERRUPTSOURCES"]);
                idle.onIdleEnd.subscribe(function () {
                    _this.idleState = 'No longer idle.';
                    _this.reset();
                });
                idle.onTimeout.subscribe(function () {
                    _this.idleState = 'Timed out!';
                    _this.timedOut = true;
                    localStorage.removeItem('currentTrackUser');
                    _this.router.navigate(['/login']);
                });
                idle.onIdleStart.subscribe(function () {
                    _this.idleState = 'You\'ve gone idle!';
                    // this.childModal.show();
                });
                idle.onTimeoutWarning.subscribe(function (countdown) {
                    _this.idleState = 'You will time out in ' + countdown + ' seconds!';
                });
                // sets the ping interval to 15 seconds
                keepalive.interval(15);
                keepalive.onPing.subscribe(function () { return _this.lastPing = new Date(); });
                _this.reset();
            }
        });
    }
    AppComponent.prototype.ngOnInit = function () {
        this.aggreymessage = true;
        var ssss = this.getCookie('gvkTrackCookie');
        if (ssss === 'savedCookie') {
            this.aggreymessage = false;
        }
    };
    AppComponent.prototype.createCookie = function () {
        this.cookieService.set('gvkTrackCookie', 'savedCookie');
        var sddsss = this.getCookie('gvkTrackCookie');
        if (sddsss === 'savedCookie') {
            this.aggreymessage = false;
        }
    };
    AppComponent.prototype.getCookie = function (key) {
        return this.cookieService.get(key);
    };
    AppComponent.prototype.deleteCookie = function (key) {
        return this.cookieService.delete(key);
    };
    AppComponent.prototype.reset = function () {
        this.idle.watch();
        this.idleState = 'Started.';
        this.timedOut = false;
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        __metadata("design:paramtypes", [ngx_cookie_service__WEBPACK_IMPORTED_MODULE_1__["CookieService"], _ng_idle_core__WEBPACK_IMPORTED_MODULE_2__["Idle"], _ng_idle_keepalive__WEBPACK_IMPORTED_MODULE_3__["Keepalive"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! .//app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var ngx_cookie_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-cookie-service */ "./node_modules/ngx-cookie-service/ngx-cookie-service.es5.js");
/* harmony import */ var _product_product_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./product/product.component */ "./src/app/product/product.component.ts");
/* harmony import */ var _product_result_product_result_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./product-result/product-result.component */ "./src/app/product-result/product-result.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _user_screen_user_screen_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./user-screen/user-screen.component */ "./src/app/user-screen/user-screen.component.ts");
/* harmony import */ var _import_records_import_records_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./import-records/import-records.component */ "./src/app/import-records/import-records.component.ts");
/* harmony import */ var _export_records_export_records_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./export-records/export-records.component */ "./src/app/export-records/export-records.component.ts");
/* harmony import */ var _home_home_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./home/home.component */ "./src/app/home/home.component.ts");
/* harmony import */ var _import_shipment_details_import_shipment_details_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./import-shipment-details/import-shipment-details.component */ "./src/app/import-shipment-details/import-shipment-details.component.ts");
/* harmony import */ var _my_pipe__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./my-pipe */ "./src/app/my-pipe.ts");
/* harmony import */ var _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./privacy-policy/privacy-policy.component */ "./src/app/privacy-policy/privacy-policy.component.ts");
/* harmony import */ var _terms_conditions_terms_conditions_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./terms-conditions/terms-conditions.component */ "./src/app/terms-conditions/terms-conditions.component.ts");
/* harmony import */ var _export_shipments_list_export_shipments_list_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./export-shipments-list/export-shipments-list.component */ "./src/app/export-shipments-list/export-shipments-list.component.ts");
/* harmony import */ var _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./change-password/change-password.component */ "./src/app/change-password/change-password.component.ts");
/* harmony import */ var _saved_search_saved_search_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./saved-search/saved-search.component */ "./src/app/saved-search/saved-search.component.ts");
/* harmony import */ var _dhl_tracking_dhl_tracking_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./dhl-tracking/dhl-tracking.component */ "./src/app/dhl-tracking/dhl-tracking.component.ts");
/* harmony import */ var _fedex_tracking_fedex_tracking_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./fedex-tracking/fedex-tracking.component */ "./src/app/fedex-tracking/fedex-tracking.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _ng_idle_keepalive__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! @ng-idle/keepalive */ "./node_modules/@ng-idle/keepalive/fesm5/ng-idle-keepalive.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



// @ts-ignore






















 // this includes the core NgIdleModule but includes keepalive providers for easy wireup
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"],
                _product_product_component__WEBPACK_IMPORTED_MODULE_8__["ProductComponent"],
                _product_result_product_result_component__WEBPACK_IMPORTED_MODULE_9__["ProductResultComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_10__["LoginComponent"],
                _user_screen_user_screen_component__WEBPACK_IMPORTED_MODULE_11__["UserScreenComponent"],
                _import_records_import_records_component__WEBPACK_IMPORTED_MODULE_12__["ImportRecordsComponent"],
                _export_records_export_records_component__WEBPACK_IMPORTED_MODULE_13__["ExportRecordsComponent"],
                _home_home_component__WEBPACK_IMPORTED_MODULE_14__["HomeComponent"],
                _import_shipment_details_import_shipment_details_component__WEBPACK_IMPORTED_MODULE_15__["ImportShipmentDetailsComponent"],
                _my_pipe__WEBPACK_IMPORTED_MODULE_16__["Mypipe"],
                _privacy_policy_privacy_policy_component__WEBPACK_IMPORTED_MODULE_17__["PrivacyPolicyComponent"],
                _terms_conditions_terms_conditions_component__WEBPACK_IMPORTED_MODULE_18__["TermsConditionsComponent"],
                _export_shipments_list_export_shipments_list_component__WEBPACK_IMPORTED_MODULE_19__["ExportShipmentsListComponent"],
                _change_password_change_password_component__WEBPACK_IMPORTED_MODULE_20__["ChangePasswordComponent"],
                _saved_search_saved_search_component__WEBPACK_IMPORTED_MODULE_21__["SavedSearchComponent"],
                _dhl_tracking_dhl_tracking_component__WEBPACK_IMPORTED_MODULE_22__["DhlTrackingComponent"],
                _fedex_tracking_fedex_tracking_component__WEBPACK_IMPORTED_MODULE_23__["FedexTrackingComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_24__["FooterComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_2__["NgbModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["ReactiveFormsModule"],
                _ng_idle_keepalive__WEBPACK_IMPORTED_MODULE_25__["NgIdleKeepaliveModule"].forRoot(),
            ],
            providers: [
                ngx_cookie_service__WEBPACK_IMPORTED_MODULE_7__["CookieService"],
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/change-password/change-password.component.css":
/*!***************************************************************!*\
  !*** ./src/app/change-password/change-password.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n\tbox-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li:hover{\r\n\tcursor:pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}"

/***/ }),

/***/ "./src/app/change-password/change-password.component.html":
/*!****************************************************************!*\
  !*** ./src/app/change-password/change-password.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n   <div class=\"small1\">\r\n      <div class=\"small ball smallball1\"></div>\r\n      <div class=\"small ball smallball2\"></div>\r\n      <div class=\"small ball smallball3\"></div>\r\n      <div class=\"small ball smallball4\"></div>\r\n   </div>\r\n   <div class=\"small2\">\r\n      <div class=\"small ball smallball5\"></div>\r\n      <div class=\"small ball smallball6\"></div>\r\n      <div class=\"small ball smallball7\"></div>\r\n      <div class=\"small ball smallball8\"></div>\r\n   </div>\r\n   <div class=\"bigcon\">\r\n      <div class=\"big ball\"></div>\r\n   </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n   <!-- Header -->\r\n   <div class=\"logo-home\">\r\n      <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n      <div class=\"logout\">\r\n         <a routerLink=\"/\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a>\r\n         <a routerLink=\"/change-password\" style=\"border-bottom:1.5px solid #dc402a;color:#262e7f !important;\"><i\r\n               class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n         <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n      </div>\r\n\r\n      <div class=\"text-center\">\r\n         <div>\r\n            <img src=\"../assets/images/gvk2.png\">\r\n         </div>\r\n      </div>\r\n\r\n\r\n   </div>\r\n   <!-- Content Wrapper -->\r\n   <article>\r\n      <!-- Breadcrumb -->\r\n      <section>\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row\">\r\n\r\n               <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                  <div class=\"title-wrap\">\r\n                     <!-- <h2 class=\"section-title section-title_exim\"> eCule Logi Tracker </h2> -->\r\n                     <p class=\"c-blue\"> Track your shipment &amp; see the current status </p>\r\n                  </div>\r\n               </div>\r\n\r\n            </div>\r\n         </div>\r\n      </section>\r\n      <!-- /.Breadcrumb -->\r\n      <!-- Tracking -->\r\n      <section class=\"tracking-wrap\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row pad-10\">\r\n               <div class=\"col-md-8 col-md-offset-2  wow fadeInUp\" data-wow-offset=\"50\" data-wow-delay=\".30s\"\r\n                  style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;\">\r\n\r\n\r\n                  <div class=\"row\">\r\n                     <div class=\"col-md-offset-3 col-md-6\">\r\n                        <div class=\"btn-success text-center\"> {{changemessage}} </div>\r\n                        <div class=\"panel panel-default\">\r\n                           <div class=\"panel-body\">\r\n                              <p class=\"text-center c-blue\"><strong>Change Password</strong></p>\r\n                              <form [formGroup]=\"changePasswordForm\"\r\n                                 (ngSubmit)=\"changePassword(changePasswordForm.value)\">\r\n                                 <div class=\"form-group\"\r\n                                    [ngClass]=\"{'has-error':!changePasswordForm.controls['old_password'].valid && changePasswordForm.controls['old_password'].touched}\">\r\n\r\n                                    <input type=\"password\" name=\"old_password\" class=\"form-control\" id=\"oldPassword\"\r\n                                       placeholder=\"Old Password\" (ngModelChange)=\"valuechange($event)\"\r\n                                       [formControl]=\"changePasswordForm.controls['old_password']\" />\r\n                                    <small\r\n                                       *ngIf=\"changePasswordForm.controls['old_password'].hasError('required') && changePasswordForm.controls['old_password'].touched\"\r\n                                       class=\"text-danger\">Old Password Required.</small>\r\n                                    <small\r\n                                       *ngIf=\"wrongchangePasswordForm && changePasswordForm.controls['old_password'].touched\"\r\n                                       class=\"text-danger\"> Enter Valid Old Password</small>\r\n                                 </div>\r\n                                 <div class=\"form-group\"\r\n                                    [ngClass]=\"{'has-error':!changePasswordForm.controls['new_password'].valid && changePasswordForm.controls['new_password'].touched}\">\r\n\r\n                                    <input type=\"password\" name=\"new_password\" class=\"form-control\"\r\n                                       placeholder=\"New Password\"\r\n                                       [formControl]=\"changePasswordForm.controls['new_password']\" />\r\n                                    <small\r\n                                       *ngIf=\"changePasswordForm.controls['new_password'].hasError('required') && changePasswordForm.controls['new_password'].touched\"\r\n                                       class=\"text-danger\">New Password Required</small>\r\n                                 </div>\r\n                                 <div class=\"form-group\"\r\n                                    [ngClass]=\"{'has-error':!changePasswordForm.controls['confirm_new_password'].valid && changePasswordForm.controls['confirm_new_password'].touched}\">\r\n\r\n                                    <input type=\"password\" name=\"confirm_new_password\" class=\"form-control\"\r\n                                       placeholder=\"Confirm New Password\"\r\n                                       [formControl]=\"changePasswordForm.controls['confirm_new_password']\" />\r\n                                    <small\r\n                                       *ngIf=\"changePasswordForm.controls['confirm_new_password'].hasError('required') && changePasswordForm.controls['confirm_new_password'].touched\"\r\n                                       class=\"text-danger\">Confirm New Required</small>\r\n                                    <small\r\n                                       *ngIf=\"changePasswordForm.controls['confirm_new_password'].hasError('passwordMatch') && changePasswordForm.controls['confirm_new_password'].touched\"\r\n                                       class=\"text-danger\">Password mismatch</small>\r\n                                 </div>\r\n                                 <div class=\"form-group text-center\">\r\n                                    <button type=\"submit\" class=\"btn-1 btn bg-red\"\r\n                                       [disabled]=\"!changePasswordForm.valid\">Change Password</button>\r\n                                 </div>\r\n                              </form>\r\n                           </div>\r\n                        </div>\r\n                     </div>\r\n                  </div>\r\n               </div>\r\n            </div>\r\n\r\n         </div>\r\n      </section>\r\n      <!-- /.Tracking -->\r\n   </article>\r\n   <!-- /.Content Wrapper -->\r\n   <!-- Footer -->\r\n   <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<div class=\"search-popup\">\r\n   <div>\r\n      <div class=\"popup-box-inner\">\r\n         <form>\r\n            <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n         </form>\r\n      </div>\r\n   </div>\r\n   <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n</div>\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/change-password/change-password.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/change-password/change-password.component.ts ***!
  \**************************************************************/
/*! exports provided: ChangePasswordComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePasswordComponent", function() { return ChangePasswordComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _core_api_services_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../core/api-services.service */ "./src/app/core/api-services.service.ts");
/* harmony import */ var _core_social_http_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../core/social-http.service */ "./src/app/core/social-http.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var ChangePasswordComponent = /** @class */ (function () {
    function ChangePasswordComponent(router, http, apiService, fb) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.apiService = apiService;
        this.showActions = false;
        this.previousUrl = undefined;
        this.currentUrl = undefined;
        this.href = "";
        this.prvurl = "";
        this.changePasswordForm = fb.group({
            'old_password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'new_password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required],
            'confirm_new_password': [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, this.passwordMatch]]
        });
        this.currentUrl = this.router.url;
        router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_1__["NavigationEnd"]) {
                _this.previousUrl = _this.currentUrl;
                var px = _this.previousUrl.split("/");
                _this.prvurl = px[2];
                _this.currentUrl = event.url;
            }
            ;
        });
    }
    ChangePasswordComponent.prototype.ngOnInit = function () {
        this.href = this.router.url;
        var stringToSplit = this.href;
        var x = stringToSplit.split("/");
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        this.userdetails = JSON.parse(currentTrackUser);
    };
    ChangePasswordComponent.prototype.save = function (dataform) {
        var _this = this;
        this.edited = true;
        this.http.post(this.apiService.CHANGE_PASSWORD, dataform)
            .then(function (dataaa) {
            _this.edited = false;
            _this.changemessage = "Successfully password upadted.";
            setTimeout(function () {
                this.logout();
            }.bind(_this), 1500);
        });
    };
    ChangePasswordComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    ChangePasswordComponent.prototype.passwordMatch = function (control) {
        var paswd = control.root.get('new_password');
        if (paswd && control.value != paswd.value) {
            return {
                passwordMatch: false
            };
        }
        return null;
    };
    ChangePasswordComponent.prototype.valuechange = function (newValue) {
        if (!newValue) {
            this.wrongchangePasswordForm = false;
        }
        if (this.userdetails.password == newValue) {
            this.wrongchangePasswordForm = false;
        }
        else {
            this.wrongchangePasswordForm = true;
        }
    };
    ChangePasswordComponent.prototype.changePassword = function (value) {
        if (this.changePasswordForm.valid) {
            var oldpassword = this.changePasswordForm.value.old_password;
            var dbpassword = this.userdetails.password;
            var userid = this.userdetails.id;
            var new_password = this.changePasswordForm.value.new_password;
            if (oldpassword == dbpassword) {
                this.save({ new_password: new_password, uid: userid });
            }
            else {
                this.wrongchangePasswordForm = true;
            }
        }
    };
    ChangePasswordComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-change-password',
            template: __webpack_require__(/*! ./change-password.component.html */ "./src/app/change-password/change-password.component.html"),
            styles: [__webpack_require__(/*! ./change-password.component.css */ "./src/app/change-password/change-password.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _core_social_http_service__WEBPACK_IMPORTED_MODULE_4__["SocialHttpClient"],
            _core_api_services_service__WEBPACK_IMPORTED_MODULE_3__["ApiServicesService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]])
    ], ChangePasswordComponent);
    return ChangePasswordComponent;
}());



/***/ }),

/***/ "./src/app/core/api-services.service.ts":
/*!**********************************************!*\
  !*** ./src/app/core/api-services.service.ts ***!
  \**********************************************/
/*! exports provided: ApiServicesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiServicesService", function() { return ApiServicesService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var ApiServicesService = /** @class */ (function () {
    function ApiServicesService() {
        this.API_URL = 'https://ets.aragen.com/api/';
        //Login
        this.SIGIN = this.API_URL + "signIn";
        //Logout
        //Pasword
        this.CHANGE_PASSWORD = this.API_URL + "changePassword";
        //Imports
        this.SEARCH_IMPORTS = this.API_URL + "getImportRecords";
        //Exports
        this.SEARCH_EXPORTS = this.API_URL + "getExportRecords";
        //Notes
        this.NOTES = "settings/pagedetails/";
        //Saved Search Imports
        this.SAVED_SEARCH_IMPORTS = this.API_URL + "import-saved-searchs-list";
        //Saved Search Exports
        this.SAVED_SEARCH_EXPORTS = this.API_URL + "export-saved-searchs-list";
        //Delete search
        this.DELETE_SAVED_SEARCH = this.API_URL + "delete-search";
        //Email Updates
        this.EMAIL_UPDATES = this.API_URL + "subscribe-shipment";
        //TO top searches
        this.TO_TOP_SEARCH = this.API_URL + "sort-saved-searchs-list";
        //feddex tracking
        this.FEDEX_TRACKING = this.API_URL + "fedex-live-track";
    }
    ApiServicesService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        })
    ], ApiServicesService);
    return ApiServicesService;
}());



/***/ }),

/***/ "./src/app/core/social-http.service.ts":
/*!*********************************************!*\
  !*** ./src/app/core/social-http.service.ts ***!
  \*********************************************/
/*! exports provided: SocialHttpClient */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SocialHttpClient", function() { return SocialHttpClient; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm5/operators/index.js");
/* harmony import */ var _api_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api-services.service */ "./src/app/core/api-services.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var SocialHttpClient = /** @class */ (function () {
    function SocialHttpClient(http, env) {
        this.http = http;
        this.env = env;
    }
    SocialHttpClient.prototype.handleError = function (error) {
        if (error.error instanceof ErrorEvent) {
            // Handler network error
            Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["retry"])(2);
        }
        else {
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(error.error);
        }
        return Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["throwError"])(error.message);
    };
    SocialHttpClient.prototype.changeToFormData = function (body, file) {
        var formData = new FormData();
        Object.keys(body).forEach(function (k) {
            formData.append(k, body[k]);
        });
        if (file != null) {
            formData.append('attachment', file);
        }
        return formData;
    };
    SocialHttpClient.prototype.get = function (url, options) {
        if (options === void 0) { options = {}; }
        return this.http.get(url, options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)).toPromise();
    };
    SocialHttpClient.prototype.post = function (url, body, options) {
        if (options === void 0) { options = {}; }
        return this.http.post(url, body, options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)).toPromise();
    };
    SocialHttpClient.prototype.postAttachment = function (url, body, options, attachment) {
        if (options === void 0) { options = {}; }
        return this.http.post(url, this.changeToFormData(body, attachment), options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)).toPromise();
    };
    SocialHttpClient.prototype.put = function (url, body, options, attachment) {
        if (options === void 0) { options = {}; }
        return this.http.put(url, this.changeToFormData(body, attachment), options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)).toPromise();
    };
    SocialHttpClient.prototype.putService = function (url, body, options) {
        if (options === void 0) { options = {}; }
        return this.http.put(url, body, options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)).toPromise();
    };
    SocialHttpClient.prototype.delete = function (url, options) {
        if (options === void 0) { options = {}; }
        return this.http.request('delete', url, options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError)).toPromise();
    };
    SocialHttpClient.prototype.postObservable = function (url, body, options) {
        if (options === void 0) { options = {}; }
        return this.http.post(url, body, options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    };
    SocialHttpClient.prototype.getObservable = function (url, options) {
        if (options === void 0) { options = {}; }
        return this.http.get(url, options).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["catchError"])(this.handleError));
    };
    SocialHttpClient = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"]])
    ], SocialHttpClient);
    return SocialHttpClient;
}());



/***/ }),

/***/ "./src/app/dhl-tracking/dhl-tracking.component.css":
/*!*********************************************************!*\
  !*** ./src/app/dhl-tracking/dhl-tracking.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n\tbox-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li:hover{\r\n\tcursor:pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}\r\n.switch {\r\n    position: relative;\r\n    display: inline-block;\r\n    width: 55px;\r\n    height: 25px;\r\n  }\r\n.switch input { \r\n    opacity: 0;\r\n    width: 0;\r\n    height: 0;\r\n  }\r\n.slider {\r\n    position: absolute;\r\n    cursor: pointer;\r\n    top: 0;\r\n    left: 0;\r\n    right: 0;\r\n    bottom: 0;\r\n    background-color: #ccc;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\n.slider:before {\r\n    position: absolute;\r\n    content: \"\";\r\n    height: 20px;\r\n    width: 20px;\r\n    left: 4px;\r\n    bottom: 3px;\r\n    background-color: white;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\ninput:checked + .slider {\r\n    background-color: #2196F3;\r\n  }\r\ninput:focus + .slider {\r\n    box-shadow: 0 0 1px #2196F3;\r\n  }\r\ninput:checked + .slider:before {\r\n    -webkit-transform: translateX(26px);\r\n    transform: translateX(28px);\r\n  }\r\n/* Rounded sliders */\r\n.slider.round {\r\n    border-radius: 34px;\r\n  }\r\n.slider.round:before {\r\n    border-radius: 50%;\r\n  }\r\n.btn-primary {\r\n    color: #fff;\r\n   \r\n}\r\n.border-left {\r\n    border-top: 3px dashed #262e7f;\r\n    margin-left: 0;\r\n    position: absolute;\r\n    width: 98%;\r\n    left: 0;\r\n}\r\n.border-right{\r\n    display:none;\r\n}\r\n.progress-wrap .themeclr-border{\r\n    left:auto;\r\n    right:0px;\r\n}\r\n.dot-right{\r\n    display: none;\r\n}\r\n.progress-wrap{\r\n    margin-top: 15px;\r\n}\r\n.wrapper-line {\r\n    border: solid 1px rgba(255,255,255,.1);\r\n    overflow: hidden;\r\n}\r\n.padding40 {\r\n    padding: 40px;\r\n}\r\n.progress {\r\n    height: 20px;\r\n    margin-bottom: 20px;\r\n    overflow: hidden;\r\n    background-color: #f5f5f5;\r\n    border-radius: 4px;\r\n    box-shadow: inset 0 1px 2px rgb(0 0 0 / 10%);\r\n}\r\nul.progress {\r\n    list-style: none;\r\n    margin: 0;\r\n    padding: 0;\r\n    background: #555;\r\n}\r\nul.progress li {\r\n    background-color: #555;\r\n    text-transform: uppercase;\r\n    font-size: 11px;\r\n}\r\nul.progress li {\r\n    float: left;\r\n    line-height: 20px;\r\n    height: 20px;\r\n    min-width: 24%;\r\n    position: relative;\r\n}\r\nul.progress li:before {\r\n    content: '';\r\n    position: absolute;\r\n    width: 0;\r\n    height: 0;\r\n    right: 0px;\r\n    border-style: solid;\r\n    border-width: 10px 0 10px 10px;\r\n    border-color: transparent transparent transparent #1A1E20;\r\n}\r\nul.progress li a {\r\n    padding: 0px 0px 0px 6px;\r\n    color: #FFF;\r\n    text-decoration: none;\r\n}\r\nul.progress li:after {\r\n    content: '';\r\n    position: absolute;\r\n    width: 0;\r\n    height: 0;\r\n    right: 4px;\r\n    border-style: solid;\r\n    border-width: 10px 0 10px 10px;\r\n    border-color: transparent transparent transparent #555;\r\n}\r\n.divider-double {\r\n    clear: both;\r\n    height: 30px;\r\n}\r\n.timeline {\r\n    list-style: none;\r\n    padding: 20px 0 20px;\r\n    position: relative;\r\n}\r\n.timeline:before {\r\n    top: 0;\r\n    bottom: 0;\r\n    position: absolute;\r\n    content: \" \";\r\n    width: 2px;\r\n    background-color: transparent;\r\n    left: 50%;\r\n    border-left: 2px dashed #ee1c25;\r\n    margin-left: -1.5px;\r\n}\r\n.timeline.custom-tl:before {\r\n    left: 130px;\r\n}\r\n.timeline > li {\r\n    margin-bottom: 20px;\r\n    position: relative;\r\n}\r\n.timeline.custom-tl > li {\r\n    border-bottom: dashed 1px rgba(255,255,255,.1);\r\n    padding-bottom: 20px;\r\n}\r\n.timeline > li:before, .timeline > li:after {\r\n    content: \" \";\r\n    display: table;\r\n}\r\n.zoomIn {\r\n    -webkit-animation-name: zoomIn;\r\n    animation-name: zoomIn;\r\n}\r\n.timeline-date {\r\n    position: absolute;\r\n    left: 0;\r\n    top: -16px;\r\n    font-weight: bold;\r\n    color: #262e7f;\r\n}\r\n.timeline-date > span {\r\n    display: block;\r\n    font-size: 12px;\r\n    text-align: center;\r\n    color: #555;\r\n}\r\n.success {\r\n    display: none;\r\n    padding: 2px 10px 2px 10px;\r\n    background: #E5EAD4;\r\n    color: #555;\r\n    width: 280px;\r\n    font-size: 12px;\r\n}\r\n.timeline-badge.success {\r\n    display: block;\r\n    background-color: #ee1c25 !important;\r\n}\r\n.timeline > li > .timeline-badge {\r\n    color: #fff;\r\n    width: 30px;\r\n    height: 30px;\r\n    line-height: 27px;\r\n    font-size: 12px;\r\n    text-align: center;\r\n    position: absolute;\r\n    top: -20px;\r\n    left: 50%;\r\n    margin-left: -25px;\r\n    background-color: #999999;\r\n    z-index: 100;\r\n    border-top-right-radius: 50%;\r\n    border-top-left-radius: 50%;\r\n    border-bottom-right-radius: 50%;\r\n    border-bottom-left-radius: 50%;\r\n}\r\n.timeline.custom-tl > li > .timeline-badge {\r\n    background: #D03232;\r\n}\r\n.timeline.custom-tl > li > .timeline-badge {\r\n    left: 140px;\r\n}\r\n.timeline > li > .timeline-panel {\r\n    width: 46%;\r\n    float: left;\r\n    border: 1px solid #d4d4d4;\r\n    border-radius: 2px;\r\n    padding: 20px;\r\n    position: relative;\r\n    box-shadow: 0 1px 6px rgb(0 0 0 / 18%);\r\n}\r\n.timeline > li > .timeline-panel {\r\n    border: 1px solid #d4d4d4;\r\n    -webkit-box-shadow: 0 1px 6px rgb(0 0 0 / 18%);\r\n}\r\n.timeline.custom-tl > li > .timeline-panel {\r\n    border: none;\r\n    box-shadow: none;\r\n    width: 100%;\r\n    color: #262e7f;\r\n}\r\n.timeline > li.timeline-inverted > .timeline-panel {\r\n    float: right;\r\n}\r\n.timeline.custom-tl > li.timeline-inverted > .timeline-panel {\r\n    float: none;\r\n    left: 150px;\r\n    top: -16px;\r\n    padding: 0 20px;\r\n}\r\n.timeline-body > .location {\r\n    display: block;\r\n    text-transform: uppercase;\r\n    color: #262e7f;\r\n}\r\n.timeline-body > .location a {\r\n    margin-left: 10px;\r\n    text-transform: none;\r\n    color: #262e7f;\r\n}\r\n.grey{\r\n    color: #898989;\r\n}\r\n.wrapper-line{\r\n    background:#fff;\r\n    text-align: left;\r\n    border-radius: 5px;\r\n}\r\n.head-sec{\r\n    position: relative;\r\n}\r\n.head-sec a{\r\n    position: absolute;\r\n    right: 0px;\r\n    top: 0px;\r\n}"

/***/ }),

/***/ "./src/app/dhl-tracking/dhl-tracking.component.html":
/*!**********************************************************!*\
  !*** ./src/app/dhl-tracking/dhl-tracking.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"loader\">\r\n   <div class=\"small1\">\r\n      <div class=\"small ball smallball1\"></div>\r\n      <div class=\"small ball smallball2\"></div>\r\n      <div class=\"small ball smallball3\"></div>\r\n      <div class=\"small ball smallball4\"></div>\r\n   </div>\r\n   <div class=\"small2\">\r\n      <div class=\"small ball smallball5\"></div>\r\n      <div class=\"small ball smallball6\"></div>\r\n      <div class=\"small ball smallball7\"></div>\r\n      <div class=\"small ball smallball8\"></div>\r\n   </div>\r\n   <div class=\"bigcon\">\r\n      <div class=\"big ball\"></div>\r\n   </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n   <!-- Header -->\r\n   <div class=\"logo-home\">\r\n      <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n      <div class=\"logout\">\r\n         <a routerLink=\"/\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a>\r\n         <a routerLink=\"/change-password\"><i class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n         <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n      </div>\r\n    \r\n         <div class=\"text-center\">\r\n         <div>\r\n            <img src=\"../assets/images/gvk2.png\" >\r\n         </div>\r\n      </div>\r\n      \r\n        \r\n      </div>\r\n   <!-- Content Wrapper -->\r\n   <article>\r\n      <!-- Breadcrumb -->\r\n      <section class=\"theme-breadcrumb pad-30\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row\">\r\n               <div class=\"col-sm-12 text-center\">\r\n                  <!-- <a routerLink=\"/\"><img src=\"../assets/images/gvk2.png\"></a> -->\r\n               </div>\r\n               <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                  <div class=\"title-wrap\">\r\n                   \r\n                   \r\n                        <p class=\"c-blue\"> Track your shipment &amp; see the current status</p>\r\n                        <a (click)=\"goback()\" class=\"pull-right\"><i    aria-hidden=\"true\" class=\"fa fa-undo c-red\" style=\"cursor:pointer\"></i></a>\r\n                     \r\n                  </div>\r\n                  <h2 *ngIf=\"error;else show_tarcking\">{{error.detail}}</h2>\r\n                  <ng-template #show_tarcking>\r\n                     <div class=\"track-head\">\r\n                     <div class=\"row progress-content upper-text\">\r\n                        <div class=\"col-md-3 col-xs-8 text-left col-sm-2\">\r\n                           <p class=\"fs-12 no-margin c-blue\"> FROM </p>\r\n                        </div>\r\n                        <div class=\"col-md-6 col-xs-8 col-sm-3\">\r\n                           <p class=\"fs-12 no-margin\"> \r\n                              <!-- [ <b class=\"black-clr\">6 DAYS </b> ] -->\r\n                            </p>\r\n                        </div>\r\n                        <div class=\"col-md-3 col-xs-8 col-sm-2 text-right\">\r\n                           <p class=\"fs-12 no-margin c-red\"> to </p>\r\n                        </div>\r\n                     </div>\r\n                     <div class=\"progress-wrap\">\r\n                        \r\n                        <div class=\"progress-status\">\r\n                           <span class=\"border-left\"></span>\r\n                           <span class=\"border-right\"></span>\r\n                           <span class=\"dot dot-left wow fadeIn\" data-wow-offset=\"50\" data-wow-delay=\".40s\"\r\n                              style=\"visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;\"></span>\r\n                           <span class=\"themeclr-border wow fadeIn\" data-wow-offset=\"50\" data-wow-delay=\".50s\"\r\n                              style=\"visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;\"> <span\r\n                                 class=\"dot dot-center theme-clr-bg\"></span> </span>\r\n                           <span class=\"dot dot-right wow fadeIn\" data-wow-offset=\"50\" data-wow-delay=\".60s\"\r\n                              style=\"visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;\"></span>\r\n                        </div>\r\n                        <div class=\"row progress-content upper-text\">\r\n                           <div class=\"col-md-3 col-xs-8 text-left col-sm-2\">\r\n                              <p class=\"c-blue no-margin\">{{trackingData?.origin.address.addressLocality}}</p>\r\n                           </div>\r\n                           <div class=\"col-md-6 col-xs-8 col-sm-3\">\r\n                              <p class=\"fs-12 no-margin\"> \r\n                                 <!-- [ <b class=\"black-clr\">6 DAYS </b> ] -->\r\n                               </p>\r\n                           </div>\r\n                           <div class=\"col-md-3 col-xs-8 col-sm-2 text-right\">\r\n                              <p class=\"c-red no-margin\">{{trackingData?.destination.address.addressLocality}}</p>\r\n                           </div>\r\n                        </div>\r\n               </div>\r\n               <div class=\"text-center\">\r\n                  <p class=\"c-blue no-margin\">Tracking ID: {{trackingData?.id}}</p>\r\n               </div>\r\n            </div>\r\n               <div class=\"row\">\r\n                        <div class=\"col-md-12\">\r\n                           \r\n\r\n                           <div class=\"divider-double\"></div>\r\n\r\n                           <div class=\"wrapper-line padding40 rounded10\">\r\n                              <ul class=\"timeline custom-tl\" >\r\n                                    <li class=\"timeline-inverted\" *ngFor=\"let a of trackingData?.events\">\r\n                                       <div class=\"timeline-date wow zoomIn\" data-wow-delay=\".2s\" *ngFor=\"let b of a | keyvalue\">\r\n                                          {{b.key}}\r\n                                       </div>\r\n                                       <div class=\"timeline-badge success\"><i class=\"fa fa-check wow zoomIn\"></i>\r\n                                       </div>\r\n                                       <div class=\"timeline-panel wow fadeInRight\" data-wow-delay=\".6s\" *ngFor=\"let data of a | keyvalue \">\r\n                                          <div class=\"timeline-body\"  *ngFor=\"let data of data.value \">\r\n                                            <span class=\"grey\"> {{data?.description}}</span>\r\n                                             <span class=\"location c-blue\"><b>{{data?.location.address.addressLocality}} </b>\r\n                                                </span>\r\n                                                <span>\r\n                                                   {{data?.timestamp | date : ' h:mm a'}}\r\n                                                </span>\r\n                                                <hr>\r\n                                           </div>\r\n                                       </div>\r\n                                    </li>\r\n                                \r\n                              </ul>\r\n                           </div>\r\n                        </div>\r\n               </div>\r\n                  </ng-template>\r\n               </div>\r\n            </div>\r\n         </div>\r\n      </section>\r\n   </article>\r\n   <!-- /.Content Wrapper -->\r\n   <!-- Footer -->\r\n   <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<div class=\"search-popup\">\r\n   <div>\r\n      <div class=\"popup-box-inner\">\r\n         <form>\r\n            <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n         </form>\r\n      </div>\r\n   </div>\r\n   <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n</div>\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/dhl-tracking/dhl-tracking.component.ts":
/*!********************************************************!*\
  !*** ./src/app/dhl-tracking/dhl-tracking.component.ts ***!
  \********************************************************/
/*! exports provided: DhlTrackingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DhlTrackingComponent", function() { return DhlTrackingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var DhlTrackingComponent = /** @class */ (function () {
    function DhlTrackingComponent(location, route, router, http) {
        this.location = location;
        this.route = route;
        this.router = router;
        this.http = http;
        this.loader = false;
    }
    DhlTrackingComponent.prototype.ngOnInit = function () {
        var id = this.route.snapshot.params.id;
        this.trackingid = id;
        this.getLiveTrackingDetails(id);
    };
    DhlTrackingComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    DhlTrackingComponent.prototype.getLiveTrackingDetails = function (id) {
        var _this = this;
        this.loader = true;
        this.http.get('https://api-eu.dhl.com/track/shipments?trackingNumber=' + id, { headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({ 'DHL-API-Key': 'RmWu1XoZx3GOJ8U6DOAjAarleQhSEZEg' }) })
            .subscribe({
            next: function (data) {
                _this.trackingData = data['shipments'][0];
                var b = Array();
                var a = data['shipments'][0]['events'];
                a.forEach(function (data, index) {
                    var z = new Date(data.timestamp).toDateString().toString();
                    if (z in b) {
                        b[z].push(data);
                    }
                    else {
                        b[z] = [data];
                    }
                });
                var s = [];
                for (var _i = 0, _a = Object.entries(b); _i < _a.length; _i++) {
                    var _b = _a[_i], key = _b[0], value = _b[1];
                    s.push((_c = {}, _c[key] = value, _c));
                }
                data['shipments'][0]['events'] = s;
                _this.loader = false;
                var _c;
            },
            error: function (err) {
                _this.error = err.error;
                _this.loader = false;
            }
        });
    };
    DhlTrackingComponent.prototype.goback = function () {
        if (this.route.snapshot.queryParams.type == "imports") {
            this.router.navigate(['/import-records/' + this.trackingid], { queryParams: { tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
        else if (this.route.snapshot.queryParams.type == "exports") {
            this.router.navigate(['/export-records/' + this.trackingid], { queryParams: { tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
        else {
            this.location.back();
        }
    };
    DhlTrackingComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-dhl-tracking',
            template: __webpack_require__(/*! ./dhl-tracking.component.html */ "./src/app/dhl-tracking/dhl-tracking.component.html"),
            styles: [__webpack_require__(/*! ./dhl-tracking.component.css */ "./src/app/dhl-tracking/dhl-tracking.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], DhlTrackingComponent);
    return DhlTrackingComponent;
}());



/***/ }),

/***/ "./src/app/export-records/export-records.component.css":
/*!*************************************************************!*\
  !*** ./src/app/export-records/export-records.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n\tbox-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li:hover{\r\n\tcursor:pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}\r\n.switch {\r\n    position: relative;\r\n    display: inline-block;\r\n    width: 55px;\r\n    height: 25px;\r\n  }\r\n.switch input { \r\n    opacity: 0;\r\n    width: 0;\r\n    height: 0;\r\n  }\r\n.slider {\r\n    position: absolute;\r\n    cursor: pointer;\r\n    top: 0;\r\n    left: 0;\r\n    right: 0;\r\n    bottom: 0;\r\n    background-color: #ccc;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\n.slider:before {\r\n    position: absolute;\r\n    content: \"\";\r\n    height: 20px;\r\n    width: 20px;\r\n    left: 4px;\r\n    bottom: 3px;\r\n    background-color: white;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\ninput:checked + .slider {\r\n    background-color: #2196F3;\r\n  }\r\ninput:focus + .slider {\r\n    box-shadow: 0 0 1px #2196F3;\r\n  }\r\ninput:checked + .slider:before {\r\n    -webkit-transform: translateX(26px);\r\n    transform: translateX(28px);\r\n  }\r\n/* Rounded sliders */\r\n.slider.round {\r\n    border-radius: 34px;\r\n  }\r\n.slider.round:before {\r\n    border-radius: 50%;\r\n  }\r\n.btn-primary {\r\n    color: #fff;\r\n   \r\n}\r\n  "

/***/ }),

/***/ "./src/app/export-records/export-records.component.html":
/*!**************************************************************!*\
  !*** ./src/app/export-records/export-records.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n   <div class=\"small1\">\r\n      <div class=\"small ball smallball1\"></div>\r\n      <div class=\"small ball smallball2\"></div>\r\n      <div class=\"small ball smallball3\"></div>\r\n      <div class=\"small ball smallball4\"></div>\r\n   </div>\r\n   <div class=\"small2\">\r\n      <div class=\"small ball smallball5\"></div>\r\n      <div class=\"small ball smallball6\"></div>\r\n      <div class=\"small ball smallball7\"></div>\r\n      <div class=\"small ball smallball8\"></div>\r\n   </div>\r\n   <div class=\"bigcon\">\r\n      <div class=\"big ball\"></div>\r\n   </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n\r\n\r\n   <article>\r\n\r\n      <div class=\"logo-home\">\r\n         <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n         <div class=\"logout\">\r\n            <a routerLink=\"/\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a>\r\n            <a routerLink=\"/change-password\"><i class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n            <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n         </div>\r\n\r\n         <div class=\"text-center\">\r\n            <div>\r\n               <img src=\"../assets/images/gvk2.png\">\r\n            </div>\r\n         </div>\r\n\r\n\r\n      </div>\r\n\r\n\r\n\r\n      <!-- Tracking -->\r\n      <section class=\"pb-50 tracking-wrap\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row\">\r\n\r\n               <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                  <div class=\"title-wrap\">\r\n                     <!-- <h2 class=\"section-title section-title_exim\">eCule <span class=\"theme-clr\"> Logi Tracker</span>\r\n                           </h2> -->\r\n                     <p class=\"c-blue\">Track your shipment &amp; see the current status</p>\r\n                     <p *ngIf=\"note\"><small>Note : {{note}}</small></p>\r\n\r\n                  </div>\r\n\r\n\r\n\r\n\r\n               </div>\r\n\r\n            </div>\r\n            <div class=\"row track-inner\">\r\n               <div class=\"col-md-8 col-md-offset-2  wow fadeInUp\">\r\n                  <div>\r\n                     <form class=\"row\">\r\n                        <div class=\"col-md-12 col-sm-12\">\r\n                           <div class=\"form-group\">\r\n                              <div class=\"track-input\">\r\n                                 <input type=\"text\" name=\"AWB_no\" class=\"form-control\" [(ngModel)]='recordsCount'\r\n                                    required=\"\" placeholder=\"Enter your Tracking (or) Invoice No (or) Client Name \">\r\n                                 <button class=\"btn-1\" (click)=\"getAwbDetailsSubmit(recordsCount)\">TRACK</button>\r\n                              </div>\r\n                              <div ng-model=\"message\" style=\"color: red; font-size: 14px; text-align: center;\">\r\n                                 <div ng-hide=\"message\">{{message}}</div>\r\n                              </div>\r\n                           </div>\r\n\r\n                        </div>\r\n                        <div class=\"col-md-8 col-sm-8\">\r\n                           <p class=\"c-blue no-margin\"><small>Note: Please expect delay of status update during the\r\n                                 public holidays.</small> </p>\r\n\r\n                        </div>\r\n                        <div class=\"col-md-4 col-sm-4\">\r\n\r\n                           <div class=\"text-right\">\r\n\r\n                              <div *ngIf=\"back; then multishipments else single\"></div>\r\n                              <ng-template #multishipments>\r\n                                 <a (click)=\"backloaction()\"> <i class=\"fa fa-undo c-red\" aria-hidden=\"true\"></i></a>\r\n                              </ng-template>\r\n                              <ng-template #single>\r\n                                 <a (click)=\"backloaction()\"> <i class=\"fa fa-undo c-red\" aria-hidden=\"true\"></i></a>\r\n                              </ng-template>\r\n                           </div>\r\n                        </div>\r\n                     </form>\r\n                  </div>\r\n               </div>\r\n            </div>\r\n            <div *ngIf=\"showActions\">\r\n               <div class=\"row\">\r\n                  <div class=\"col-md-2\"></div>\r\n                  <div class=\"col-md-8 wow fadeInRight\">\r\n                     <div class=\"prod-info block-clr\">\r\n                        <div *ngIf=\"multiple; then multishipments else single\"></div>\r\n                        <ng-template #single>\r\n                           <ul *ngFor=\"let import of data\">\r\n                              <li (click)=\"getAwbDetails(import.Tracking_No)\" class=\"single-li\">\r\n                                 <span class=\"title-2\">{{import.Tracking_No}} </span>\r\n                                 <span class=\"colon\">- </span>\r\n                                 <span class=\"fs-16\"> {{import.Date | date}}</span>\r\n                              </li>\r\n\r\n\r\n                           </ul>\r\n\r\n                        </ng-template>\r\n\r\n                        <ng-template #multishipments>\r\n                           <ul *ngFor=\"let export of data\">\r\n                              <li>\r\n                                 <span class=\"title-2\">Email Update</span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\"><label class=\"switch\">\r\n                                       <input type=\"checkbox\" (change)=\"updateEmails(export)\"\r\n                                          [checked]=\"export.subscribe == 1 ? true : false \">\r\n                                       <span class=\"slider round\"></span>\r\n                                    </label></span>\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Ship To</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.SHIP_TO}}</span> </li>\r\n                              <li> <span class=\"title-2\">Invoice No</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Invoice_No}}</span> </li>\r\n                              <li> <span class=\"title-2\">Invoice Date</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Invoice_Date | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Carrier</span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\"> {{export.Carrier}}</span> </li>\r\n                              <li> <span class=\"title-2\">Tracking Number</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Tracking_No}}</span> </li>\r\n                              <li> <span class=\"title-2\">Shipment pick up Date</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Date | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Departure from India</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Departure_from_India | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Destination Arrival</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Landing_Destination_Port | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Destination Customs release date</span><span class=\"colon\">:\r\n                                 </span> <span class=\"fs-16\"> {{export.Destination_Customs_release_date | date}}</span>\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Delivery to Client</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Date_of_Delivery_to_client | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Remarks</span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\"> {{export.Remarks}}</span> </li>\r\n                              <li *ngIf=\"export.Date_of_Delivery_to_client\"> <span class=\"title-2\"> Final Status\r\n                                 </span><span class=\"colon\">: </span> <span class=\"fs-16\"> Shipment Delivered</span>\r\n                              </li>\r\n\r\n                           </ul>\r\n                        </ng-template>\r\n                        <div class=\"text-center\">\r\n                           <button (click)=\"trackDetails()\"\r\n                              *ngIf='(data[0].Carrier == \"DHL\") || (data[0].Carrier == \"FedEx\") ' class=\"btn-1\">Live\r\n                              Track</button>\r\n                        </div>\r\n\r\n                     </div>\r\n                  </div>\r\n                  <div class=\"col-md-2\"></div>\r\n               </div>\r\n            </div>\r\n         </div>\r\n      </section>\r\n      <!-- /.Tracking -->\r\n   </article>\r\n   <!-- /.Content Wrapper -->\r\n   <!-- Footer -->\r\n   <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<div class=\"search-popup\">\r\n   <div>\r\n      <div class=\"popup-box-inner\">\r\n         <form>\r\n            <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n         </form>\r\n      </div>\r\n   </div>\r\n   <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n</div>\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/export-records/export-records.component.ts":
/*!************************************************************!*\
  !*** ./src/app/export-records/export-records.component.ts ***!
  \************************************************************/
/*! exports provided: ExportRecordsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExportRecordsComponent", function() { return ExportRecordsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _core_social_http_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../core/social-http.service */ "./src/app/core/social-http.service.ts");
/* harmony import */ var _core_api_services_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../core/api-services.service */ "./src/app/core/api-services.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ExportRecordsComponent = /** @class */ (function () {
    function ExportRecordsComponent(router, http, httpClient, route, location, apiServices) {
        var _this = this;
        this.router = router;
        this.http = http;
        this.httpClient = httpClient;
        this.route = route;
        this.location = location;
        this.apiServices = apiServices;
        this.showActions = false;
        this.previousUrl = undefined;
        this.currentUrl = undefined;
        this.href = "";
        this.prvurl = "";
        this.currentUrl = this.router.url;
        router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_4__["NavigationEnd"]) {
                _this.previousUrl = _this.currentUrl;
                var px = _this.previousUrl.split("/");
                _this.prvurl = px[2];
                _this.currentUrl = event.url;
            }
            ;
        });
    }
    ExportRecordsComponent.prototype.ngOnInit = function () {
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        var userdetails = JSON.parse(currentTrackUser);
        this.userType = userdetails.usertype;
        this.user = userdetails;
        this.href = this.router.url;
        if (this.route.snapshot.params.awbNo) {
            this.getAwbDetails(this.route.snapshot.params.awbNo);
        }
        this.getnoteDetails(1);
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        var userdetails = JSON.parse(currentTrackUser);
        this.userType = userdetails.usertype;
        if (this.userType == 4) {
            this.router.navigate(['/']);
        }
        this.back = false;
        this.edited = true;
        setTimeout(function () {
            this.edited = false;
        }.bind(this), 500);
    };
    ExportRecordsComponent.prototype.backloaction = function () {
        if (this.route.snapshot.queryParams.tracking_numbers) {
            this.router.navigate(['export-shipments-list/' + this.route.snapshot.queryParams.tracking_numbers]);
        }
        else {
            this.router.navigate(['/']);
        }
    };
    ExportRecordsComponent.prototype.getAwbDetails = function (AwbNo) {
        var AwbNo = AwbNo.replace(/^,|,$/g, '');
        var AwbNoss1 = AwbNo.replace('%20', ' ');
        var AwbNosss2 = AwbNoss1.replace('%20', ' ');
        var AwbNosss3 = AwbNosss2.replace('%20', ' ');
        var AwbNosss4 = AwbNosss3.replace('%20', ' ');
        var AwbNosss5 = AwbNosss4.replace('%20', ' ');
        var AwbNosss6 = AwbNosss5.replace('%20', ' ');
        var AwbNosss7 = AwbNosss6.replace('%20', ' ');
        var AwbNosss8 = AwbNosss7.replace('%20', ' ');
        var AwbNosss9 = AwbNosss8.replace('%20', ' ');
        var AwbNosss10 = AwbNosss9.replace('%20', ' ');
        var AwbNosss11 = AwbNosss10.replace('%20', ' ');
        var AwbNosss12 = AwbNosss11.replace('%20', ' ');
        this.recordsCount = AwbNosss12;
        if (AwbNo) {
            this.save({ key: AwbNosss12 ? AwbNosss12 : '' });
        }
        else {
            this.edited = false;
            this.showActions = false;
            this.message = "Please Enter Tracking No / Invioce.No / Client Name";
        }
    };
    ExportRecordsComponent.prototype.getAwbDetailsSubmit = function (AwbNo) {
        var AwbNoss1 = AwbNo.replace('%20', ' ');
        var AwbNosss2 = AwbNoss1.replace('%20', ' ');
        var AwbNosss3 = AwbNosss2.replace('%20', ' ');
        var AwbNosss4 = AwbNosss3.replace('%20', ' ');
        var AwbNosss5 = AwbNosss4.replace('%20', ' ');
        var AwbNosss6 = AwbNosss5.replace('%20', ' ');
        var AwbNosss7 = AwbNosss6.replace('%20', ' ');
        var AwbNosss8 = AwbNosss7.replace('%20', ' ');
        var AwbNosss9 = AwbNosss8.replace('%20', ' ');
        var AwbNosss10 = AwbNosss9.replace('%20', ' ');
        var AwbNosss11 = AwbNosss10.replace('%20', ' ');
        var AwbNosss12 = AwbNosss11.replace('%20', ' ');
        this.recordsCount = AwbNosss12;
        if (AwbNo) {
            this.save({ key: AwbNosss12 ? AwbNosss12 : '', save: 1 });
        }
        else {
            this.edited = false;
            this.showActions = false;
            this.message = "Please Enter Tracking No / Invioce.No / Client Name";
        }
    };
    ExportRecordsComponent.prototype.save = function (dataform) {
        var _this = this;
        this.edited = true;
        dataform['userId'] = this.user.id;
        this.http.post(this.apiServices.SEARCH_EXPORTS, dataform)
            .then(function (dataaa) {
            if (dataaa.permission == 0) {
                _this.message = "Sorry, you don't have access to this shipment.Please contact administrator";
                _this.edited = false;
            }
            else {
                if (dataaa.record.length > 0) {
                    _this.totalData = dataaa;
                    _this.data = dataaa.record;
                    _this.message = '';
                    _this.tableName = dataaa.table;
                    _this.showActions = true;
                    if (dataaa.record.length == 1) {
                        _this.edited = false;
                        _this.multiple = true;
                        _this.back = true;
                        _this.vendor = dataaa.record[0].SHIP_TO;
                    }
                    else {
                        var rurl = 'export-shipments-list/' + dataform['key'];
                        _this.router.navigate([rurl]);
                        _this.multiple = false;
                        _this.back = false;
                        _this.edited = false;
                    }
                }
                else {
                    _this.edited = false;
                    _this.showActions = false;
                    _this.message = "The shipment details not found, Hence  please check with respective SCM Team";
                }
                _this.response = dataaa.status;
            }
        });
    };
    ExportRecordsComponent.prototype.getnoteDetails = function (cNo) {
        var _this = this;
        this.httpClient.get('https://ets.aragen.com/settings/pagedetails/' + cNo)
            .subscribe(function (dataaa) {
            _this.note = dataaa[0].page_description;
        });
    };
    ExportRecordsComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    ExportRecordsComponent.prototype.updateEmails = function (data) {
        var _this = this;
        var params = {};
        params['userId'] = this.user.id;
        params['shipmentId'] = data.id;
        if (this.totalData.table == 'gvk_import_records') {
            params['shipmentType'] = 'gvk_import_shipments';
        }
        else if (this.totalData.table == 'gvk_export_records') {
            params['shipmentType'] = 'gvk_export_shipments';
        }
        if (data.subscribe == 0) {
            params['subscribe'] = 1;
        }
        else if (data.subscribe == 1) {
            params['subscribe'] = 0;
        }
        this.http.post(this.apiServices.EMAIL_UPDATES, params)
            .then(function (dataaa) {
            _this.data[0]['subscribe'] = params['subscribe'];
        });
    };
    ExportRecordsComponent.prototype.trackDetails = function () {
        if (this.data[0].Carrier.toLowerCase() == 'fedex') {
            this.router.navigate(['/fedex-tracking/' + this.data[0].Tracking_No], { queryParams: { type: "exports", tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
        else if (this.data[0].Carrier.toLowerCase() == 'dhl') {
            this.router.navigate(['/track/' + this.data[0].Tracking_No], { queryParams: { type: "exports", tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
    };
    ExportRecordsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-export-records',
            template: __webpack_require__(/*! ./export-records.component.html */ "./src/app/export-records/export-records.component.html"),
            styles: [__webpack_require__(/*! ./export-records.component.css */ "./src/app/export-records/export-records.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _core_social_http_service__WEBPACK_IMPORTED_MODULE_2__["SocialHttpClient"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
            _angular_common__WEBPACK_IMPORTED_MODULE_5__["Location"],
            _core_api_services_service__WEBPACK_IMPORTED_MODULE_3__["ApiServicesService"]])
    ], ExportRecordsComponent);
    return ExportRecordsComponent;
}());



/***/ }),

/***/ "./src/app/export-shipments-list/export-shipments-list.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/export-shipments-list/export-shipments-list.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n\tbox-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li:hover{\r\n\tcursor:pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}"

/***/ }),

/***/ "./src/app/export-shipments-list/export-shipments-list.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/export-shipments-list/export-shipments-list.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n   <div class=\"small1\">\r\n      <div class=\"small ball smallball1\"></div>\r\n      <div class=\"small ball smallball2\"></div>\r\n      <div class=\"small ball smallball3\"></div>\r\n      <div class=\"small ball smallball4\"></div>\r\n   </div>\r\n   <div class=\"small2\">\r\n      <div class=\"small ball smallball5\"></div>\r\n      <div class=\"small ball smallball6\"></div>\r\n      <div class=\"small ball smallball7\"></div>\r\n      <div class=\"small ball smallball8\"></div>\r\n   </div>\r\n   <div class=\"bigcon\">\r\n      <div class=\"big ball\"></div>\r\n   </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n   <!-- Header -->\r\n   <!-- /.Header -->\r\n   <div class=\"logout\">\r\n      <a routerLink=\"/\">Home</a>\r\n      <a routerLink=\"/change-password\">Change Password</a>\r\n      <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n   </div>\r\n   <!-- Content Wrapper -->\r\n   <article>\r\n      <!-- Breadcrumb -->\r\n      <section class=\"theme-breadcrumb pad-30\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row\">\r\n               <div class=\"col-sm-12 text-center\">\r\n                  <a routerLink=\"/\"><img src=\"../assets/images/gvk2.png\" style=\"width: 300px;\"></a>\r\n               </div>\r\n               <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                  <div class=\"title-wrap\">\r\n                     <!-- <h2 class=\"section-title section-title_exim\"> eCule <span class=\"theme-clr\"> Logi Tracker</span> </h2> -->\r\n                     <p class=\"fs-16\"> <b>Track your shipment &amp; see the current status </b></p>\r\n                     <p class=\"fs-16 no-margin\" *ngIf=\"note\"><b>Note : </b>{{note}}</p>\r\n                  </div>\r\n               </div>\r\n\r\n            </div>\r\n         </div>\r\n      </section>\r\n      <!-- /.Breadcrumb -->\r\n      <!-- Tracking -->\r\n      <section class=\"pb-120 tracking-wrap\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row pad-10\">\r\n               <div class=\"col-md-8 col-md-offset-2 tracking-form wow fadeInUp\" data-wow-offset=\"50\"\r\n                  data-wow-delay=\".30s\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;\">\r\n                  <h2 class=\"title-1\"> TRACK YOUR EXPORT SHIPMENT </h2>\r\n\r\n                  <div class=\"row\">\r\n                     <form class=\"\">\r\n                        <div class=\"col-md-8 col-sm-8\">\r\n                           <div class=\"form-group\">\r\n                              <input type=\"text\" style=\"background: none; border-color: #ee1c25;\" name=\"AWB_no\"\r\n                                 class=\"form-control box-shadow\" [(ngModel)]='recordsCount' required=\"\"\r\n                                 placeholder=\"Enter your Tracking (or) Invoice No (or) Client Name \">\r\n                              <p><b>Note: Please expect delay of status update during the public holidays.</b></p>\r\n                           </div>\r\n                           <div ng-model=\"message\"\r\n                              style=\"color: red; font-size: 18px; text-align: center; font-weight: bold\">\r\n                              <div ng-hide=\"message\">{{message}}</div>\r\n                           </div>\r\n                        </div>\r\n                        <div class=\"col-md-4 col-sm-4\">\r\n                           <div class=\"form-group\">\r\n                              <button class=\"btn-1\" (click)=\"getAwbDetails(recordsCount)\">TRACK</button>\r\n                              <div *ngIf=\"back; then multishipments else single\"></div>\r\n                              <ng-template #multishipments>\r\n                                 <a (click)=\"backloaction()\"> <i class=\"fa fa-reply\" aria-hidden=\"true\"\r\n                                       style=\"font-size: 27px;color: red;margin-left: 88%;margin-top: 12px;cursor:pointer\"></i></a>\r\n                              </ng-template>\r\n                              <ng-template #single>\r\n                                 <a (click)=\"backloaction()\"> <i class=\"fa fa-reply\" aria-hidden=\"true\"\r\n                                       style=\"font-size: 27px;color: red;margin-left: 88%;margin-top: 12px;cursor: pointer;\"></i></a>\r\n                              </ng-template>\r\n                           </div>\r\n                        </div>\r\n                     </form>\r\n                  </div>\r\n               </div>\r\n            </div>\r\n            <div *ngIf=\"showActions\">\r\n               <div class=\"row\">\r\n                  <div class=\"col-md-2\"></div>\r\n                  <div class=\"col-md-8 pad-30 wow fadeInRight\" data-wow-offset=\"50\" data-wow-delay=\".30s\"\r\n                     style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;\">\r\n                     <div class=\"prod-info block-clr\">\r\n                        <div *ngIf=\"multiple; then multishipments else single\"></div>\r\n                        <ng-template #single>\r\n                           <ul *ngFor=\"let import of data\">\r\n                              <li (click)=\"getAwbDetails(import.Tracking_No)\" class=\"single-li\">\r\n                                 <span class=\"title-2\">{{import.Tracking_No}} </span>\r\n                                 <span class=\"colon\">- </span>\r\n                                 <span class=\"fs-16\"> {{import.Date | date}}</span>\r\n                              </li>\r\n\r\n\r\n                           </ul>\r\n\r\n                        </ng-template>\r\n\r\n                        <ng-template #multishipments>\r\n                           <ul *ngFor=\"let export of data\">\r\n                              <li> <span class=\"title-2\">Ship To</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.SHIP_TO}}</span> </li>\r\n                              <li> <span class=\"title-2\">Invoice No</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Invoice_No}}</span> </li>\r\n                              <li> <span class=\"title-2\">Invoice Date</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Invoice_Date | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Carrier</span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\"> {{export.Carrier}}</span> </li>\r\n                              <li> <span class=\"title-2\">Tracking Number</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Tracking_No}}</span> </li>\r\n                              <li> <span class=\"title-2\">Shipment pick up Date</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Date | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Departure from India</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Departure_from_India | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Destination Arrival</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Landing_Destination_Port | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Destination Customs release date</span><span class=\"colon\">:\r\n                                 </span> <span class=\"fs-16\"> {{export.Destination_Customs_release_date | date}}</span>\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Delivery to Client</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\"> {{export.Date_of_Delivery_to_client | date}}</span> </li>\r\n                              <li> <span class=\"title-2\">Remarks</span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\"> {{export.Remarks}}</span> </li>\r\n                              <li *ngIf=\"export.Date_of_Delivery_to_client\"> <span class=\"title-2\"> Final Status\r\n                                 </span><span class=\"colon\">: </span> <span class=\"fs-16\"> Shipment Delivered</span>\r\n                              </li>\r\n\r\n                           </ul>\r\n                        </ng-template>\r\n\r\n                     </div>\r\n                  </div>\r\n                  <div class=\"col-md-2\"></div>\r\n               </div>\r\n            </div>\r\n         </div>\r\n      </section>\r\n      <!-- /.Tracking -->\r\n   </article>\r\n   <!-- /.Content Wrapper -->\r\n   <!-- Footer -->\r\n   <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<div class=\"search-popup\">\r\n   <div>\r\n      <div class=\"popup-box-inner\">\r\n         <form>\r\n            <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n         </form>\r\n      </div>\r\n   </div>\r\n   <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n</div>"

/***/ }),

/***/ "./src/app/export-shipments-list/export-shipments-list.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/export-shipments-list/export-shipments-list.component.ts ***!
  \**************************************************************************/
/*! exports provided: ExportShipmentsListComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExportShipmentsListComponent", function() { return ExportShipmentsListComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../core/api-services.service */ "./src/app/core/api-services.service.ts");
/* harmony import */ var _core_social_http_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../core/social-http.service */ "./src/app/core/social-http.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ExportShipmentsListComponent = /** @class */ (function () {
    function ExportShipmentsListComponent(router, httpClient, route, location, http, apiService) {
        var _this = this;
        this.router = router;
        this.httpClient = httpClient;
        this.route = route;
        this.location = location;
        this.http = http;
        this.apiService = apiService;
        this.showActions = false;
        this.previousUrl = undefined;
        this.currentUrl = undefined;
        this.href = "";
        this.prvurl = "";
        this.currentUrl = this.router.url;
        router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                _this.previousUrl = _this.currentUrl;
                var px = _this.previousUrl.split("/");
                _this.prvurl = px[2];
                _this.currentUrl = event.url;
            }
            ;
        });
    }
    ExportShipmentsListComponent.prototype.ngOnInit = function () {
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        var userdetails = JSON.parse(currentTrackUser);
        this.userType = userdetails.usertype;
        this.user = userdetails;
        this.href = this.router.url;
        var stringToSplit = this.href;
        var x = stringToSplit.split("/");
        if (x[2]) {
            this.trackingsids = x[2];
            this.getAwbDetails(x[2]);
        }
        this.getnoteDetails(1);
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        var userdetails = JSON.parse(currentTrackUser);
        this.userType = userdetails.usertype;
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        if (this.userType == 4) {
            this.router.navigate(['/']);
        }
        this.back = false;
        this.edited = true;
        setTimeout(function () {
            this.edited = false;
        }.bind(this), 500);
    };
    ExportShipmentsListComponent.prototype.backloaction = function () {
        this.router.navigate(['/']);
    };
    ExportShipmentsListComponent.prototype.getAwbDetails = function (AwbNo) {
        if (AwbNo.split(',').length > 1) {
            this.trackingsids = AwbNo;
        }
        var AwbNoss1 = AwbNo.replace('%20', ' ');
        var AwbNosss2 = AwbNoss1.replace('%20', ' ');
        var AwbNosss3 = AwbNosss2.replace('%20', ' ');
        var AwbNosss4 = AwbNosss3.replace('%20', ' ');
        var AwbNosss5 = AwbNosss4.replace('%20', ' ');
        var AwbNosss6 = AwbNosss5.replace('%20', ' ');
        var AwbNosss7 = AwbNosss6.replace('%20', ' ');
        var AwbNosss8 = AwbNosss7.replace('%20', ' ');
        var AwbNosss9 = AwbNosss8.replace('%20', ' ');
        var AwbNosss10 = AwbNosss9.replace('%20', ' ');
        var AwbNosss11 = AwbNosss10.replace('%20', ' ');
        var AwbNosss12 = AwbNosss11.replace('%20', ' ');
        this.recordsCount = AwbNosss12;
        if (AwbNo) {
            this.save({ key: AwbNosss12 ? AwbNosss12 : '' });
        }
        else {
            this.edited = false;
            this.showActions = false;
            this.message = "Please Enter Tracking No / Invioce.No / Client Name";
        }
    };
    ExportShipmentsListComponent.prototype.save = function (dataform) {
        var _this = this;
        dataform['userId'] = this.user.id;
        this.edited = true;
        this.http.post(this.apiService.SEARCH_EXPORTS, dataform)
            .then(function (dataaa) {
            if (dataaa.record.length > 0) {
                _this.data = dataaa.record;
                _this.message = '';
                _this.tableName = dataaa.table;
                _this.showActions = true;
                if (dataaa.record.length == 1) {
                    _this.edited = false;
                    var rurl = 'export-records/' + dataform['key'];
                    _this.router.navigate([rurl], { queryParams: { "tracking_numbers": _this.trackingsids } });
                    _this.multiple = true;
                    _this.back = true;
                    //			this.vendor=dataaa.record[0].SHIP_TO;				
                }
                else {
                    _this.multiple = false;
                    _this.back = false;
                    _this.edited = false;
                }
            }
            else {
                _this.edited = false;
                _this.showActions = false;
                _this.message = "The shipment details not found, Hence  please check with respective SCM Team";
            }
            _this.response = dataaa.status;
        });
    };
    ExportShipmentsListComponent.prototype.getnoteDetails = function (cNo) {
        var _this = this;
        this.httpClient.get('https://ets.aragen.com/settings/pagedetails/' + cNo)
            .subscribe(function (dataaa) {
            _this.note = dataaa[0].page_description;
        });
    };
    ExportShipmentsListComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    ExportShipmentsListComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-export-shipments-list',
            template: __webpack_require__(/*! ./export-shipments-list.component.html */ "./src/app/export-shipments-list/export-shipments-list.component.html"),
            styles: [__webpack_require__(/*! ./export-shipments-list.component.css */ "./src/app/export-shipments-list/export-shipments-list.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"],
            _core_social_http_service__WEBPACK_IMPORTED_MODULE_5__["SocialHttpClient"],
            _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"]])
    ], ExportShipmentsListComponent);
    return ExportShipmentsListComponent;
}());



/***/ }),

/***/ "./src/app/fedex-tracking/fedex-tracking.component.css":
/*!*************************************************************!*\
  !*** ./src/app/fedex-tracking/fedex-tracking.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n\tbox-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li:hover{\r\n\tcursor:pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}\r\n.switch {\r\n    position: relative;\r\n    display: inline-block;\r\n    width: 55px;\r\n    height: 25px;\r\n  }\r\n.switch input { \r\n    opacity: 0;\r\n    width: 0;\r\n    height: 0;\r\n  }\r\n.slider {\r\n    position: absolute;\r\n    cursor: pointer;\r\n    top: 0;\r\n    left: 0;\r\n    right: 0;\r\n    bottom: 0;\r\n    background-color: #ccc;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\n.slider:before {\r\n    position: absolute;\r\n    content: \"\";\r\n    height: 20px;\r\n    width: 20px;\r\n    left: 4px;\r\n    bottom: 3px;\r\n    background-color: white;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\ninput:checked + .slider {\r\n    background-color: #2196F3;\r\n  }\r\ninput:focus + .slider {\r\n    box-shadow: 0 0 1px #2196F3;\r\n  }\r\ninput:checked + .slider:before {\r\n    -webkit-transform: translateX(26px);\r\n    transform: translateX(28px);\r\n  }\r\n/* Rounded sliders */\r\n.slider.round {\r\n    border-radius: 34px;\r\n  }\r\n.slider.round:before {\r\n    border-radius: 50%;\r\n  }\r\n.btn-primary {\r\n    color: #fff;\r\n   \r\n}\r\n.border-left {\r\n    border-top: 3px dashed #262e7f;\r\n    margin-left: 0;\r\n    position: absolute;\r\n    width: 98%;\r\n    left: 0;\r\n}\r\n.border-right{\r\n    display:none;\r\n}\r\n.progress-wrap .themeclr-border{\r\n    left:auto;\r\n    right:0px;\r\n}\r\n.dot-right{\r\n    display: none;\r\n}\r\n.progress-wrap{\r\n    margin-top: 15px;\r\n}\r\n.wrapper-line {\r\n    border: solid 1px rgba(255,255,255,.1);\r\n    overflow: hidden;\r\n}\r\n.padding40 {\r\n    padding: 40px;\r\n}\r\n.progress {\r\n    height: 20px;\r\n    margin-bottom: 20px;\r\n    overflow: hidden;\r\n    background-color: #f5f5f5;\r\n    border-radius: 4px;\r\n    box-shadow: inset 0 1px 2px rgb(0 0 0 / 10%);\r\n}\r\nul.progress {\r\n    list-style: none;\r\n    margin: 0;\r\n    padding: 0;\r\n    background: #555;\r\n}\r\nul.progress li {\r\n    background-color: #555;\r\n    text-transform: uppercase;\r\n    font-size: 11px;\r\n}\r\nul.progress li {\r\n    float: left;\r\n    line-height: 20px;\r\n    height: 20px;\r\n    min-width: 24%;\r\n    position: relative;\r\n}\r\nul.progress li:before {\r\n    content: '';\r\n    position: absolute;\r\n    width: 0;\r\n    height: 0;\r\n    right: 0px;\r\n    border-style: solid;\r\n    border-width: 10px 0 10px 10px;\r\n    border-color: transparent transparent transparent #1A1E20;\r\n}\r\nul.progress li a {\r\n    padding: 0px 0px 0px 6px;\r\n    color: #FFF;\r\n    text-decoration: none;\r\n}\r\nul.progress li:after {\r\n    content: '';\r\n    position: absolute;\r\n    width: 0;\r\n    height: 0;\r\n    right: 4px;\r\n    border-style: solid;\r\n    border-width: 10px 0 10px 10px;\r\n    border-color: transparent transparent transparent #555;\r\n}\r\n.divider-double {\r\n    clear: both;\r\n    height: 30px;\r\n}\r\n.timeline {\r\n    list-style: none;\r\n    padding: 20px 0 20px;\r\n    position: relative;\r\n}\r\n.timeline:before {\r\n    top: 0;\r\n    bottom: 0;\r\n    position: absolute;\r\n    content: \" \";\r\n    width: 2px;\r\n    background-color: transparent;\r\n    left: 50%;\r\n    border-left: 2px dashed #ee1c25;\r\n    margin-left: -1.5px;\r\n}\r\n.timeline.custom-tl:before {\r\n    left: 130px;\r\n}\r\n.timeline > li {\r\n    margin-bottom: 20px;\r\n    position: relative;\r\n}\r\n.timeline.custom-tl > li {\r\n    border-bottom: dashed 1px rgba(255,255,255,.1);\r\n    padding-bottom: 20px;\r\n}\r\n.timeline > li:before, .timeline > li:after {\r\n    content: \" \";\r\n    display: table;\r\n}\r\n.zoomIn {\r\n    -webkit-animation-name: zoomIn;\r\n    animation-name: zoomIn;\r\n}\r\n.timeline-date {\r\n    position: absolute;\r\n    left: 0;\r\n    top: -16px;\r\n    font-weight: bold;\r\n    color: #262e7f;\r\n}\r\n.timeline-date > span {\r\n    display: block;\r\n    font-size: 12px;\r\n    text-align: center;\r\n    color: #555;\r\n}\r\n.success {\r\n    display: none;\r\n    padding: 2px 10px 2px 10px;\r\n    background: #E5EAD4;\r\n    color: #555;\r\n    width: 280px;\r\n    font-size: 12px;\r\n}\r\n.timeline-badge.success {\r\n    display: block;\r\n    background-color: #ee1c25 !important;\r\n}\r\n.timeline > li > .timeline-badge {\r\n    color: #fff;\r\n    width: 30px;\r\n    height: 30px;\r\n    line-height: 27px;\r\n    font-size: 12px;\r\n    text-align: center;\r\n    position: absolute;\r\n    top: -20px;\r\n    left: 50%;\r\n    margin-left: -25px;\r\n    background-color: #999999;\r\n    z-index: 100;\r\n    border-top-right-radius: 50%;\r\n    border-top-left-radius: 50%;\r\n    border-bottom-right-radius: 50%;\r\n    border-bottom-left-radius: 50%;\r\n}\r\n.timeline.custom-tl > li > .timeline-badge {\r\n    background: #D03232;\r\n}\r\n.timeline.custom-tl > li > .timeline-badge {\r\n    left: 140px;\r\n}\r\n.timeline > li > .timeline-panel {\r\n    width: 46%;\r\n    float: left;\r\n    border: 1px solid #d4d4d4;\r\n    border-radius: 2px;\r\n    padding: 20px;\r\n    position: relative;\r\n    box-shadow: 0 1px 6px rgb(0 0 0 / 18%);\r\n}\r\n.timeline > li > .timeline-panel {\r\n    border: 1px solid #d4d4d4;\r\n    -webkit-box-shadow: 0 1px 6px rgb(0 0 0 / 18%);\r\n}\r\n.timeline.custom-tl > li > .timeline-panel {\r\n    border: none;\r\n    box-shadow: none;\r\n    width: 100%;\r\n    color: #262e7f;\r\n}\r\n.timeline > li.timeline-inverted > .timeline-panel {\r\n    float: right;\r\n}\r\n.timeline.custom-tl > li.timeline-inverted > .timeline-panel {\r\n    float: none;\r\n    left: 150px;\r\n    top: -16px;\r\n    padding: 0 20px;\r\n}\r\n.timeline-body > .location {\r\n    display: block;\r\n    text-transform: uppercase;\r\n    color: #262e7f;\r\n}\r\n.timeline-body > .location a {\r\n    margin-left: 10px;\r\n    text-transform: none;\r\n    color: #262e7f;\r\n}\r\n.grey{\r\n    color: #898989;\r\n}\r\n.wrapper-line{\r\n    background:#fff;\r\n    text-align: left;\r\n    border-radius: 5px;\r\n}\r\n.head-sec{\r\n    position: relative;\r\n}\r\n.head-sec a{\r\n    position: absolute;\r\n    right: 0px;\r\n    top: 0px;\r\n}"

/***/ }),

/***/ "./src/app/fedex-tracking/fedex-tracking.component.html":
/*!**************************************************************!*\
  !*** ./src/app/fedex-tracking/fedex-tracking.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"loader\">\r\n   <div class=\"small1\">\r\n      <div class=\"small ball smallball1\"></div>\r\n      <div class=\"small ball smallball2\"></div>\r\n      <div class=\"small ball smallball3\"></div>\r\n      <div class=\"small ball smallball4\"></div>\r\n   </div>\r\n   <div class=\"small2\">\r\n      <div class=\"small ball smallball5\"></div>\r\n      <div class=\"small ball smallball6\"></div>\r\n      <div class=\"small ball smallball7\"></div>\r\n      <div class=\"small ball smallball8\"></div>\r\n   </div>\r\n   <div class=\"bigcon\">\r\n      <div class=\"big ball\"></div>\r\n   </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n   <!-- Header -->\r\n   <div class=\"logo-home\">\r\n      <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n      <div class=\"logout\">\r\n         <a routerLink=\"/\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a>\r\n         <a routerLink=\"/change-password\"><i class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n         <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n      </div>\r\n    \r\n         <div class=\"text-center\">\r\n         <div>\r\n            <img src=\"../assets/images/gvk2.png\" >\r\n         </div>\r\n      </div>\r\n      \r\n        \r\n      </div>\r\n   <article>\r\n      <!-- Breadcrumb -->\r\n      <section class=\"theme-breadcrumb\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row\">\r\n             \r\n               <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                  <div class=\"title-wrap\">\r\n                     \r\n                    \r\n                     <p class=\"c-blue\">Track your shipment &amp; see the current status   </p>\r\n                     <a (click)=\"goback()\" class=\"pull-right\"><i aria-hidden=\"true\" class=\"fa fa-undo c-red\" style=\"cursor:pointer\"></i></a>\r\n                     \r\n                  </div>\r\n                  <h2 *ngIf=\"error;else show_tarcking\">{{error.message}}</h2>\r\n                  <ng-template #show_tarcking>\r\n                     <div class=\"track-head\">\r\n                     <div class=\"row progress-content upper-text\">\r\n                        <div class=\"col-md-3 col-xs-8 text-left col-sm-2\">\r\n                           <p class=\"fs-12 no-margin c-blue\"> FROM </p>\r\n                        </div>\r\n                        <div class=\"col-md-6 col-xs-8 col-sm-3\">\r\n                           <p class=\"fs-12 no-margin\"> \r\n                              <!-- [ <b class=\"black-clr\">6 DAYS </b> ] -->\r\n                            </p>\r\n                        </div>\r\n                        <div class=\"col-md-3 col-xs-8 col-sm-2 text-right\">\r\n                           <p class=\"fs-12 no-margin c-red\"> to </p>\r\n                        </div>\r\n                     </div>\r\n                     <div class=\"progress-wrap\">\r\n                        <div class=\"progress-status\">\r\n                           <span class=\"border-left\"></span>\r\n                           <span class=\"border-right\"></span>\r\n                           <span class=\"dot dot-left wow fadeIn\" data-wow-offset=\"50\" data-wow-delay=\".40s\"\r\n                              style=\"visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;\"></span>\r\n                           <span class=\"themeclr-border wow fadeIn\" data-wow-offset=\"50\" data-wow-delay=\".50s\"\r\n                              style=\"visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;\"> <span\r\n                                 class=\"dot dot-center theme-clr-bg\"></span> </span>\r\n                           <span class=\"dot dot-right wow fadeIn\" data-wow-offset=\"50\" data-wow-delay=\".60s\"\r\n                              style=\"visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;\"></span>\r\n                        </div>\r\n                        <div class=\"row progress-content upper-text\">\r\n                           <div class=\"col-md-3 col-xs-8 text-left col-sm-2\">\r\n                              <p class=\"c-blue no-margin\">\r\n                                 {{data?.response.output.completeTrackResults[0].trackResults[0].originLocation.locationContactAndAddress.address.city}}, {{data?.response.output.completeTrackResults[0].trackResults[0].originLocation.locationContactAndAddress.address.countryName}}\r\n                              </p>\r\n                           </div>\r\n                           <div class=\"col-md-6 col-xs-8 col-sm-3\">\r\n                              <p class=\"fs-12 no-margin\"> \r\n                                 <!-- [ <b class=\"black-clr\">6 DAYS </b> ] -->\r\n                               </p>\r\n                           </div>\r\n                           <div class=\"col-md-3 col-xs-8 col-sm-2 text-right\">\r\n                              <p class=\"c-red no-margin\">{{data?.response.output.completeTrackResults[0].trackResults[0].destinationLocation.locationContactAndAddress.address.city}}, {{data?.response.output.completeTrackResults[0].trackResults[0].destinationLocation.locationContactAndAddress.address.countryName}}\r\n\r\n                              </p>\r\n                           </div>\r\n                        </div>\r\n               </div>\r\n               <div class=\"text-center\">\r\n                  <p class=\"c-blue no-margin\">\r\n                     Tracking ID:{{data?.response.output.completeTrackResults[0].trackingNumber}}\r\n                  </p>\r\n               </div>\r\n            </div>\r\n               <div class=\"row\">\r\n                        <div class=\"col-md-12\">\r\n                           \r\n\r\n                           <div class=\"divider-double\"></div>\r\n\r\n                           <div class=\"wrapper-line padding40 rounded10\">\r\n                              <ul class=\"timeline custom-tl\" >\r\n                                    <li class=\"timeline-inverted\" *ngFor=\"let a of scanEvents\">\r\n                                       <div class=\"timeline-date wow zoomIn\" data-wow-delay=\".2s\" *ngFor=\"let b of a | keyvalue\">\r\n                                          {{b.key}}\r\n                                       </div>\r\n                                       <div class=\"timeline-badge success\"><i class=\"fa fa-check wow zoomIn\"></i>\r\n                                       </div>\r\n                                       <div class=\"timeline-panel wow fadeInRight\" data-wow-delay=\".6s\" *ngFor=\"let data of a | keyvalue \">\r\n                                          <div class=\"timeline-body\"  *ngFor=\"let data of data.value \">\r\n                                            <ng-container *ngIf=\"data?.exceptionDescription; else show_event\">\r\n                                             <span class=\"grey\"> {{data?.exceptionDescription}}</span> \r\n                                             </ng-container> \r\n                                            <ng-template #show_event>\r\n                                             <span class=\"grey\"> {{data?.eventDescription}}</span>\r\n                                            </ng-template>\r\n                                             <span class=\"location\"><b>\r\n                                                {{data?.scanLocation.city}}, {{data?.scanLocation.countryName ? data?.scanLocation.countryName : data?.scanLocation.countryCode}} \r\n                                             </b>\r\n                                             </span>\r\n                                                <span>{{data?.date | date : ' h:mm a'}}</span>\r\n                                                <hr>\r\n                                           </div>\r\n                                       </div>\r\n                                    </li>\r\n                                \r\n                              </ul>\r\n                           </div>\r\n                        </div>\r\n               </div>\r\n                  </ng-template>\r\n               </div>\r\n            </div>\r\n         </div>\r\n      </section>\r\n   </article>\r\n   <!-- /.Content Wrapper -->\r\n   <!-- Footer -->\r\n   <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<div class=\"search-popup\">\r\n   <div>\r\n      <div class=\"popup-box-inner\">\r\n         <form>\r\n            <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n         </form>\r\n      </div>\r\n   </div>\r\n   <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n</div>\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/fedex-tracking/fedex-tracking.component.ts":
/*!************************************************************!*\
  !*** ./src/app/fedex-tracking/fedex-tracking.component.ts ***!
  \************************************************************/
/*! exports provided: FedexTrackingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FedexTrackingComponent", function() { return FedexTrackingComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _core_api_services_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../core/api-services.service */ "./src/app/core/api-services.service.ts");
/* harmony import */ var _core_social_http_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../core/social-http.service */ "./src/app/core/social-http.service.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var FedexTrackingComponent = /** @class */ (function () {
    function FedexTrackingComponent(route, location, router, http, apiService) {
        this.route = route;
        this.location = location;
        this.router = router;
        this.http = http;
        this.apiService = apiService;
        this.loader = false;
    }
    FedexTrackingComponent.prototype.ngOnInit = function () {
        this.trackingid = this.route.snapshot.params.id;
        var id = this.route.snapshot.params.id;
        this.getLiveTrackingDetails(id);
    };
    FedexTrackingComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    FedexTrackingComponent.prototype.getLiveTrackingDetails = function (id) {
        var _this = this;
        this.loader = true;
        this.http.post(this.apiService.FEDEX_TRACKING, { id: id })
            .then(function (data) {
            _this.data = data;
            if (data.response.output.completeTrackResults[0].trackResults[0].error) {
                _this.error = data.response.output.completeTrackResults[0].trackResults[0].error;
            }
            else {
                _this.scanEvents = data.response.output.completeTrackResults[0].trackResults[0].scanEvents;
                var b = Array();
                _this.scanEvents.forEach(function (data, index) {
                    var z = new Date(data.date).toDateString().toString();
                    if (z in b) {
                        b[z].push(data);
                    }
                    else {
                        b[z] = [data];
                    }
                });
                var s = [];
                for (var _i = 0, _a = Object.entries(b); _i < _a.length; _i++) {
                    var _b = _a[_i], key = _b[0], value = _b[1];
                    s.push((_c = {}, _c[key] = value, _c));
                }
                _this.scanEvents = s;
                _this.loader = false;
            }
            var _c;
        })
            .catch(function (err) {
            _this.loader = false;
        });
    };
    FedexTrackingComponent.prototype.goback = function () {
        if (this.route.snapshot.queryParams.type == "imports") {
            this.router.navigate(['/import-records/' + this.trackingid], { queryParams: { tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
        else if (this.route.snapshot.queryParams.type == "exports") {
            this.router.navigate(['/export-records/' + this.trackingid], { queryParams: { tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
        else {
            this.location.back();
        }
    };
    FedexTrackingComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-fedex-tracking',
            template: __webpack_require__(/*! ./fedex-tracking.component.html */ "./src/app/fedex-tracking/fedex-tracking.component.html"),
            styles: [__webpack_require__(/*! ./fedex-tracking.component.css */ "./src/app/fedex-tracking/fedex-tracking.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["ActivatedRoute"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["Location"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
            _core_social_http_service__WEBPACK_IMPORTED_MODULE_3__["SocialHttpClient"],
            _core_api_services_service__WEBPACK_IMPORTED_MODULE_2__["ApiServicesService"]])
    ], FedexTrackingComponent);
    return FedexTrackingComponent;
}());



/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p class=\"no-margin\">\r\n  © 2021 | Aragen Life Sciences Private Limited, All Rights Reserved | Terms & Conditions | privacy-policy\r\n</p>\r\n"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/home/home.component.css":
/*!*****************************************!*\
  !*** ./src/app/home/home.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".btn-1.btn-black {\r\n    background: #978282;\r\n}\r\n.logout a {\r\n    \r\n    color: #c52726;\r\n    \r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}"

/***/ }),

/***/ "./src/app/home/home.component.html":
/*!******************************************!*\
  !*** ./src/app/home/home.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n    <div class=\"small1\">\r\n       <div class=\"small ball smallball1\"></div>\r\n       <div class=\"small ball smallball2\"></div>\r\n       <div class=\"small ball smallball3\"></div>\r\n       <div class=\"small ball smallball4\"></div>\r\n    </div>\r\n    <div class=\"small2\">\r\n       <div class=\"small ball smallball5\"></div>\r\n       <div class=\"small ball smallball6\"></div>\r\n       <div class=\"small ball smallball7\"></div>\r\n       <div class=\"small ball smallball8\"></div>\r\n    </div>\r\n    <div class=\"bigcon\">\r\n       <div class=\"big ball\"></div>\r\n    </div>\r\n </div>\r\n <!-- /.Preloader -->\t\r\n <!-- Main Wrapper -->        \r\n <main class=\"wrapper\">\r\n    <!-- Content Wrapper -->\r\n    <article>\r\n      <div class=\"logout\">\r\n         <a  style=\"cursor:pointer\" routerLink=\"/change-password\"><i class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n         <a style=\"cursor:pointer\" (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n      </div>\r\n                <!-- Banner -->\r\n       <section class=\"banner banner-style2 mask-overlay white-clr\">\r\n\t   <div>\r\n         <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n          <div class=\"container theme-container rel-div\">\r\n          \r\n<div class=\"row\">\r\n             <div class=\"col-md-8 col-md-offset-2\">\r\n              \r\n                                <div class=\"tracking-form\">\r\n                                 <img src=\"../assets/images/gvk2.png\" height=\"100px\">\r\n                             \r\n                <div class=\"text-center btn-sec\" [ngSwitch]=\"userType\">\r\n                     <div *ngSwitchCase=\"1\">\r\n                        <button class=\"btn-1\" routerLink=\"/import-records\" >Track import shipment</button>\r\n                        <button class=\"btn-1\" routerLink=\"/export-records\" >Track export shipment</button>\r\n                        <button class=\"btn-1\" routerLink=\"/saved-search\" >Saved search</button>\r\n               </div>\r\n               <div *ngSwitchCase=\"2\">\r\n                  <button class=\"btn-1\" routerLink=\"/import-records\" >Track import shipment</button>\r\n                        <button class=\"btn-1\" routerLink=\"/export-records\" >Track export shipment</button>\r\n                        <button class=\"btn-1\" routerLink=\"/saved-search\" >Saved search</button>\r\n               </div>\r\n               <div *ngSwitchCase=\"3\">\r\n                  <button class=\"btn-1\" routerLink=\"/import-records\" >Track import shipment</button>\r\n                  <button class=\"btn-1\" routerLink=\"/export-records\" >Track export shipment</button>\r\n                  <button class=\"btn-1\" routerLink=\"/saved-search\" >Saved search</button>\r\n               </div>\r\n               <div *ngSwitchCase=\"4\">\r\n                  <button class=\"btn-1\" routerLink=\"/import-records\" >Track import shipment</button>\r\n                  <button class=\"btn-1\" routerLink=\"/saved-search\" >Saved search</button>\r\n               </div>\r\n                     <div *ngSwitchCase=\"5\">        \r\n                         <button class=\"btn-1\" routerLink=\"/export-records\" >Track export shipment</button>\r\n                        <button class=\"btn-1\" routerLink=\"/saved-search\" >Saved search</button>\r\n                     </div>\r\n\t\t </div>\r\n       </div>\r\n               \r\n             </div>\r\n             </div>\r\n             </div>\r\n\t\t\t </div>\r\n       </section>\r\n       <!-- /.Banner -->\r\n    </article>\r\n    <!-- /.Content Wrapper -->\r\n </main>\r\n <!-- / Main Wrapper -->\r\n <!-- Top -->\r\n <div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n <!-- Search Popup -->\r\n <div class=\"search-popup\">\r\n    <div>\r\n       <div class=\"popup-box-inner\">\r\n          <form>\r\n             <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n          </form>\r\n       </div>\r\n    </div>\r\n    <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n </div>\r\n "

/***/ }),

/***/ "./src/app/home/home.component.ts":
/*!****************************************!*\
  !*** ./src/app/home/home.component.ts ***!
  \****************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var HomeComponent = /** @class */ (function () {
    function HomeComponent(http, router) {
        this.http = http;
        this.router = router;
    }
    HomeComponent.prototype.ngOnInit = function () {
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        var userdetails = JSON.parse(currentTrackUser);
        this.userType = userdetails.usertype;
        this.edited = true;
        //wait 3 Seconds and hide
        setTimeout(function () {
            this.edited = false;
        }.bind(this), 1000);
    };
    HomeComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    HomeComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-home',
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/home/home.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ }),

/***/ "./src/app/import-records/import-records.component.css":
/*!*************************************************************!*\
  !*** ./src/app/import-records/import-records.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li {\r\n    box-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\nli.single-li:hover {\r\n    cursor: pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}\r\n.switch {\r\n    position: relative;\r\n    display: inline-block;\r\n    width: 55px;\r\n    height: 25px;\r\n  }\r\n.switch input { \r\n    opacity: 0;\r\n    width: 0;\r\n    height: 0;\r\n  }\r\n.slider {\r\n    position: absolute;\r\n    cursor: pointer;\r\n    top: 0;\r\n    left: 0;\r\n    right: 0;\r\n    bottom: 0;\r\n    background-color: #ccc;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\n.slider:before {\r\n    position: absolute;\r\n    content: \"\";\r\n    height: 20px;\r\n    width: 20px;\r\n    left: 4px;\r\n    bottom: 3px;\r\n    background-color: white;\r\n    -webkit-transition: .4s;\r\n    transition: .4s;\r\n  }\r\ninput:checked + .slider {\r\n    background-color: #2196F3;\r\n  }\r\ninput:focus + .slider {\r\n    box-shadow: 0 0 1px #2196F3;\r\n  }\r\ninput:checked + .slider:before {\r\n    -webkit-transform: translateX(26px);\r\n    transform: translateX(28px);\r\n  }\r\n/* Rounded sliders */\r\n.slider.round {\r\n    border-radius: 34px;\r\n  }\r\n.slider.round:before {\r\n    border-radius: 50%;\r\n  }\r\n.btn-primary {\r\n    color: #fff;\r\n   \r\n}\r\n  "

/***/ }),

/***/ "./src/app/import-records/import-records.component.html":
/*!**************************************************************!*\
  !*** ./src/app/import-records/import-records.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n   <div class=\"small1\">\r\n      <div class=\"small ball smallball1\"></div>\r\n      <div class=\"small ball smallball2\"></div>\r\n      <div class=\"small ball smallball3\"></div>\r\n      <div class=\"small ball smallball4\"></div>\r\n   </div>\r\n   <div class=\"small2\">\r\n      <div class=\"small ball smallball5\"></div>\r\n      <div class=\"small ball smallball6\"></div>\r\n      <div class=\"small ball smallball7\"></div>\r\n      <div class=\"small ball smallball8\"></div>\r\n   </div>\r\n   <div class=\"bigcon\">\r\n      <div class=\"big ball\"></div>\r\n   </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n   <!-- Header -->\r\n   <!-- /.Header -->\r\n   <!-- Content Wrapper -->\r\n   <article>\r\n      <div class=\"logo-home\">\r\n         <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n      <div class=\"logout\">\r\n         <a routerLink=\"/\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a>\r\n         <a routerLink=\"/change-password\"><i class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n         <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n      </div>\r\n    \r\n         <div class=\"text-center\">\r\n         <div>\r\n            <img src=\"../assets/images/gvk2.png\" >\r\n         </div>\r\n      </div>\r\n      \r\n        \r\n      </div>\r\n      \r\n      \r\n         \r\n      \r\n      <!-- /.Breadcrumb -->\r\n      <!-- Tracking -->\r\n      <section class=\"pb-50 tracking-wrap\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row\">\r\n              \r\n               <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                  <div class=\"title-wrap\">\r\n                     <!-- <h2 class=\"section-title section-title_exim\">eCule <span class=\"theme-clr\"> Logi Tracker</span>\r\n                     </h2> -->\r\n                     <p class=\"c-blue\"> Track your shipment &amp; see the current status </p>\r\n                     <p  *ngIf=\"note\"><small>Note : {{note}}</small></p>\r\n\r\n                  </div>\r\n               </div>\r\n\r\n            </div>\r\n            <div class=\"row track-inner\">\r\n               <div class=\"col-md-8 col-md-offset-2\" >\r\n                  \r\n\r\n                  <div>\r\n                     <form class=\"row\">\r\n                        <div class=\"col-md-12 col-sm-12\">\r\n                           <div class=\"form-group\">\r\n                              <div class=\"track-input\">\r\n                              <input type=\"text\" name=\"AWB_no\"\r\n                                 class=\"form-control\" [(ngModel)]='recordsCount' required=\"\"\r\n                                 placeholder=\"Enter AWB No. (or) PO No. (or) Vendor/Client \">\r\n                                 <button class=\"btn-1\"  (click)=\"getAwbDetailsSubmit(recordsCount)\">TRACK</button>\r\n                              </div>\r\n                              <div ng-model=\"message\"\r\n                              style=\"color: red; font-size: 14px; text-align: center; font-weight:normal\">\r\n                              <div ng-hide=\"message\">{{message}}</div>\r\n                           </div>\r\n                              \r\n                           </div>\r\n                          \r\n                        </div>\r\n                        <div class=\"col-md-8\">\r\n                           <p class=\"c-blue no-margin\"><small>Note:Please expect delay of status update during the public holidays.</small></p>\r\n                        </div>\r\n                        <div class=\"col-md-4 col-sm-4\">\r\n                           <div class=\"text-right\">\r\n                              \r\n                              <div *ngIf=\"back; then multishipments else single\"></div>\r\n                              <ng-template #multishipments>\r\n                                 <a (click)=\"getAwbDetailssubmit()\"> <i class=\"fa fa-undo c-red\" aria-hidden=\"true\"></i></a>\r\n                              </ng-template>\r\n                              <ng-template #single>\r\n                                 <a (click)=\"getAwbDetailssubmit()\"> <i class=\"fa fa-undo c-red\" aria-hidden=\"true\"></i></a>\r\n                              </ng-template>\r\n\r\n\r\n                           </div>\r\n                        </div>\r\n                     </form>\r\n\r\n                  </div>\r\n               </div>\r\n            </div>\r\n            <div *ngIf=\"showActions\">\r\n               <div class=\"row\">\r\n                  <div class=\"col-md-2\"></div>\r\n                  <div class=\"col-md-8 wow fadeInRight\" data-wow-offset=\"50\" data-wow-delay=\".30s\"\r\n                     style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;\">\r\n                     <div class=\"prod-info block-clr\">\r\n                        <div *ngIf=\"multiple; then multishipments else single\"></div>\r\n                        <ng-template #single>\r\n                           <ul *ngFor=\"let import of data\" class=\"multi-ul\">\r\n                              <li (click)=\"getAwbDetails(import.AWB_no)\" class=\"single-li\">\r\n                                 <span class=\"title-2\">{{import.AWB_no}} </span>\r\n                                 <span class=\"colon\">- </span>\r\n                                 <div *ngIf=\"import.Pick_up_date;then no_pkdate else pkdate\"></div>\r\n                                 <ng-template #no_pkdate><span class=\"fs-16\">{{import.Pick_up_date | date}}</span>\r\n                                 </ng-template>\r\n                                 <ng-template #pkdate><span class=\"fs-16\">Shipment not yet picked-up</span>\r\n                                 </ng-template>\r\n\r\n                              </li>\r\n\r\n\r\n                           </ul>\r\n\r\n                        </ng-template>\r\n\r\n                        <ng-template #multishipments>\r\n                           <ul *ngFor=\"let import of data\">\r\n                              <li>\r\n                                 <span class=\"title-2\">Email Update</span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\"><label class=\"switch\">\r\n                                    <input type=\"checkbox\" (change)=\"updateEmails(import)\" [checked]=\"import.subscribe == 1 ? true : false \">\r\n                                    <span class=\"slider round\"></span>\r\n                                  </label></span>\r\n                              </li>\r\n                              <li>\r\n                                 <span class=\"title-2\">AWB No. </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.AWB_no}}</span>\r\n                              </li>\r\n                              <li>\r\n                                 <span class=\"title-2\">Carrier </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.Carrier}}</span>\r\n                              </li>\r\n                              <li>\r\n                                 <span class=\"title-2\">Location </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.SBU_location}}</span>\r\n                              </li>\r\n                              <li>\r\n                                 <span class=\"title-2\">PO No. </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.NRM}}{{import.MPR}}{{import.BLR}}{{import.VPO}}</span>\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Vendor Name </span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\">{{import.Vendor_name}}</span> </li>\r\n                              <li> <span class=\"title-2\">Pick up Date </span><span class=\"colon\">: </span>\r\n\r\n                                 <div *ngIf=\"import.Pick_up_date;then no_pkdate else pkdate\"></div>\r\n                                 <ng-template #no_pkdate><span class=\"fs-16\">{{import.Pick_up_date | date }}\r\n                                    </span> </ng-template>\r\n                                 <ng-template #pkdate><span class=\"fs-16\">Shipment not yet picked-up</span>\r\n                                 </ng-template>\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Landed Date</span><span class=\"colon\">: </span>\r\n                                 <div *ngIf=\"import.shpt_land_dt;then no_shdate else shdate\"></div>\r\n                                 <ng-template #no_shdate><span class=\"fs-16\">{{import.shpt_land_dt | date }}</span>\r\n                                 </ng-template>\r\n                                 <ng-template #shdate><span class=\"fs-16\">{{import.shpt_land_dt}}</span> </ng-template>\r\n\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Port of clearance</span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\">{{import.Port_of_clearance}}</span> </li>\r\n                              <li> <span class=\"title-2\">Clearance Status</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\">{{import.Status}}</span> </li>\r\n                              <li> <span class=\"title-2\">Expected Delivery Date</span><span class=\"colon\">: </span>\r\n                                 <div *ngIf=\"import.Expected_Date_Delivery;then no_expdate else expdate\"></div>\r\n                                 <ng-template #no_expdate><span class=\"fs-16\">{{import.Expected_Date_Delivery | date\r\n                                       }}</span> </ng-template>\r\n                                 <ng-template #expdate><span class=\"fs-16\">{{import.Expected_Date_Delivery}}</span>\r\n                                 </ng-template>\r\n                              </li>\r\n                              <li> <span class=\"title-2\"> Actual Delivery Date</span><span class=\"colon\">: </span>\r\n                                 <div *ngIf=\"import.Delivery_Date;then no_dlvdate else dddate\"></div>\r\n                                 <ng-template #no_dlvdate><span class=\"fs-16\">{{import.Delivery_Date | date}}</span>\r\n                                 </ng-template>\r\n                                 <ng-template #dddate><span class=\"fs-16\">{{import.Delivery_Date}}</span> </ng-template>\r\n\r\n                              </li>\r\n                              <div *ngIf=\"import.Delivery_Date;then content else other_content\"></div>\r\n                              <ng-template #other_content>\r\n                                 <li> <span class=\"title-2\"> Remarks</span> <span class=\"colon\">: </span><span\r\n                                       class=\"fs-16\">{{import.Remarks}}</span> </li>\r\n                              </ng-template>\r\n                              <ng-template #content>\r\n                                 <li> <span class=\"title-2\"> Final Status</span><span class=\"colon\">: </span> <span\r\n                                       class=\"fs-16\">Shipment Delivered</span> </li>\r\n                              </ng-template>\r\n\r\n                           </ul>\r\n                           \r\n                        <div class=\"text-center\">\r\n                              <button (click)=\"trackDetails()\"  *ngIf='(data[0].Carrier == \"DHL\") || (data[0].Carrier == \"Fedex\") ' class=\"btn-1\">Live Track</button>\r\n                           </div>\r\n                           <!-- *ngIf=\"{{ data.import.Carrier == ('DHL' || 'Fedex') }}\" -->\r\n\r\n                        </ng-template>\r\n\r\n\r\n                     </div>\r\n                  </div>\r\n                  <div class=\"col-md-2\"></div>\r\n               </div>\r\n            </div>\r\n         </div>\r\n      </section>\r\n      <!-- /.Tracking -->\r\n   </article>\r\n   <!-- /.Content Wrapper -->\r\n   <!-- Footer -->\r\n   <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/import-records/import-records.component.ts":
/*!************************************************************!*\
  !*** ./src/app/import-records/import-records.component.ts ***!
  \************************************************************/
/*! exports provided: ImportRecordsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportRecordsComponent", function() { return ImportRecordsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../core/api-services.service */ "./src/app/core/api-services.service.ts");
/* harmony import */ var _core_social_http_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../core/social-http.service */ "./src/app/core/social-http.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ImportRecordsComponent = /** @class */ (function () {
    function ImportRecordsComponent(router, httpClient, route, location, apiService, http) {
        var _this = this;
        this.router = router;
        this.httpClient = httpClient;
        this.route = route;
        this.location = location;
        this.apiService = apiService;
        this.http = http;
        this.showActions = false;
        this.previousUrl = undefined;
        this.currentUrl = undefined;
        this.href = "";
        this.prvurl = "";
        this.currentUrl = this.router.url;
        router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                _this.previousUrl = _this.currentUrl;
                var px = _this.previousUrl.split("/");
                _this.prvurl = px[2];
                _this.currentUrl = event.url;
            }
            ;
        });
    }
    ImportRecordsComponent.prototype.ngOnInit = function () {
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        var userdetails = JSON.parse(currentTrackUser);
        this.userType = userdetails.usertype;
        this.user = userdetails;
        this.href = this.router.url;
        if (this.route.snapshot.params.awbNo) {
            this.getAwbDetails(this.route.snapshot.params.awbNo);
        }
        this.getnoteDetails(1);
        if (this.userType == 5) {
            this.router.navigate(['/']);
        }
        this.back = false;
        this.edited = true;
        setTimeout(function () {
            this.edited = false;
        }.bind(this), 500);
    };
    ImportRecordsComponent.prototype.getAwbDetailssubmit = function () {
        if (this.route.snapshot.queryParams.tracking_numbers) {
            this.router.navigate(['importdatails/' + this.route.snapshot.queryParams.tracking_numbers]);
        }
        else {
            this.router.navigate(['/']);
        }
    };
    ImportRecordsComponent.prototype.getAwbDetails = function (AwbNo) {
        var AwbNoss1 = AwbNo.replace('%20', ' ');
        var AwbNosss2 = AwbNoss1.replace('%20', ' ');
        var AwbNosss3 = AwbNosss2.replace('%20', ' ');
        var AwbNosss4 = AwbNosss3.replace('%20', ' ');
        var AwbNosss5 = AwbNosss4.replace('%20', ' ');
        var AwbNosss6 = AwbNosss5.replace('%20', ' ');
        var AwbNosss7 = AwbNosss6.replace('%20', ' ');
        var AwbNosss8 = AwbNosss7.replace('%20', ' ');
        var AwbNosss9 = AwbNosss8.replace('%20', ' ');
        var AwbNosss10 = AwbNosss9.replace('%20', ' ');
        var AwbNosss11 = AwbNosss10.replace('%20', ' ');
        var AwbNosss12 = AwbNosss11.replace('%20', ' ');
        this.recordsCount = AwbNosss12;
        if (AwbNo) {
            this.save({ key: AwbNosss12 ? AwbNosss12 : '' });
        }
        else {
            this.edited = false;
            this.showActions = false;
            this.message = "Please Enter AWB .No / PO.No / Vendor Name";
        }
    };
    ImportRecordsComponent.prototype.getAwbDetailsSubmit = function (AwbNo) {
        var AwbNo = AwbNo.replace(/^,|,$/g, '');
        var AwbNoss1 = AwbNo.replace('%20', ' ');
        var AwbNosss2 = AwbNoss1.replace('%20', ' ');
        var AwbNosss3 = AwbNosss2.replace('%20', ' ');
        var AwbNosss4 = AwbNosss3.replace('%20', ' ');
        var AwbNosss5 = AwbNosss4.replace('%20', ' ');
        var AwbNosss6 = AwbNosss5.replace('%20', ' ');
        var AwbNosss7 = AwbNosss6.replace('%20', ' ');
        var AwbNosss8 = AwbNosss7.replace('%20', ' ');
        var AwbNosss9 = AwbNosss8.replace('%20', ' ');
        var AwbNosss10 = AwbNosss9.replace('%20', ' ');
        var AwbNosss11 = AwbNosss10.replace('%20', ' ');
        var AwbNosss12 = AwbNosss11.replace('%20', ' ');
        this.recordsCount = AwbNosss12;
        if (AwbNo) {
            this.save({ key: AwbNosss12 ? AwbNosss12 : '', save: 1 });
        }
        else {
            this.edited = false;
            this.showActions = false;
            this.message = "Please Enter AWB .No / PO.No / Vendor Name";
        }
    };
    ImportRecordsComponent.prototype.getnoteDetails = function (cNo) {
        var _this = this;
        this.httpClient.get('https://ets.aragen.com/settings/pagedetails/' + cNo)
            .subscribe(function (dataaa) {
            _this.note = dataaa[0].page_description;
        });
    };
    // https://ets.gvkbio.com
    ImportRecordsComponent.prototype.save = function (dataform) {
        var _this = this;
        dataform['userId'] = this.user.id;
        this.edited = true;
        this.http.post(this.apiService.SEARCH_IMPORTS, dataform)
            .then(function (dataaa) {
            if (dataaa.record.length > 0) {
                _this.data = dataaa.record;
                _this.totalData = dataaa;
                if (dataaa.record.length == 1) {
                    _this.multiple = true;
                    _this.back = true;
                    _this.vendor = _this.prvurl;
                    _this.edited = false;
                }
                else {
                    var rurl = 'importdatails/' + dataform['key'];
                    _this.router.navigate([rurl]);
                    _this.vendor = _this.prvurl;
                    _this.multiple = false;
                    _this.back = false;
                }
                _this.message = '';
                _this.tableName = dataaa.table;
                _this.showActions = true;
            }
            else {
                _this.edited = false;
                _this.showActions = false;
                _this.message = "The shipment details not found, Hence  please check with respective SCM Team";
            }
            _this.response = dataaa.status;
        });
    };
    ImportRecordsComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    ImportRecordsComponent.prototype.updateEmails = function (data) {
        var _this = this;
        var params = {};
        params['userId'] = this.user.id;
        params['shipmentId'] = data.id;
        if (this.totalData.table == 'gvk_import_records') {
            params['shipmentType'] = 'gvk_import_shipments';
        }
        else if (this.totalData == 'gvk_export_records') {
            params['shipmentType'] = 'gvk_export_shipments';
        }
        if (data.subscribe == 0) {
            params['subscribe'] = 1;
        }
        else if (data.subscribe == 1) {
            params['subscribe'] = 0;
        }
        this.http.post(this.apiService.EMAIL_UPDATES, params)
            .then(function (dataaa) {
            _this.data[0]['subscribe'] = params['subscribe'];
        });
    };
    ImportRecordsComponent.prototype.trackDetails = function () {
        if (this.data[0].Carrier.toLowerCase() == 'fedex') {
            this.router.navigate(['/fedex-tracking/' + this.data[0].AWB_no], { queryParams: { type: "imports", tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
        else if (this.data[0].Carrier.toLowerCase() == 'dhl') {
            this.router.navigate(['/track/' + this.data[0].AWB_no], { queryParams: { type: "imports", tracking_numbers: this.route.snapshot.queryParams.tracking_numbers } });
        }
    };
    ImportRecordsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-import-records',
            template: __webpack_require__(/*! ./import-records.component.html */ "./src/app/import-records/import-records.component.html"),
            styles: [__webpack_require__(/*! ./import-records.component.css */ "./src/app/import-records/import-records.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"],
            _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"],
            _core_social_http_service__WEBPACK_IMPORTED_MODULE_5__["SocialHttpClient"]])
    ], ImportRecordsComponent);
    return ImportRecordsComponent;
}());



/***/ }),

/***/ "./src/app/import-shipment-details/import-shipment-details.component.css":
/*!*******************************************************************************!*\
  !*** ./src/app/import-shipment-details/import-shipment-details.component.css ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li {\r\n    box-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\nli.single-li:hover {\r\n    cursor: pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}"

/***/ }),

/***/ "./src/app/import-shipment-details/import-shipment-details.component.html":
/*!********************************************************************************!*\
  !*** ./src/app/import-shipment-details/import-shipment-details.component.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n   <div class=\"small1\">\r\n      <div class=\"small ball smallball1\"></div>\r\n      <div class=\"small ball smallball2\"></div>\r\n      <div class=\"small ball smallball3\"></div>\r\n      <div class=\"small ball smallball4\"></div>\r\n   </div>\r\n   <div class=\"small2\">\r\n      <div class=\"small ball smallball5\"></div>\r\n      <div class=\"small ball smallball6\"></div>\r\n      <div class=\"small ball smallball7\"></div>\r\n      <div class=\"small ball smallball8\"></div>\r\n   </div>\r\n   <div class=\"bigcon\">\r\n      <div class=\"big ball\"></div>\r\n   </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n   <!-- Header -->\r\n   <!-- /.Header -->\r\n   <!-- Content Wrapper -->\r\n   <article>\r\n      <div class=\"logo-home\">\r\n         <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n         <div class=\"logout\">\r\n            <a routerLink=\"/\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a>\r\n            <a routerLink=\"/change-password\"><i class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n            <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n         </div>\r\n       \r\n            <div class=\"text-center\">\r\n            <div>\r\n               <img src=\"../assets/images/gvk2.png\" >\r\n            </div>\r\n         </div>\r\n         \r\n           \r\n         </div>\r\n     \r\n      <!-- Tracking -->\r\n      <section class=\"pb-50 tracking-wrap\">\r\n         <div class=\"theme-container container \">\r\n            <div class=\"row\">\r\n              \r\n               <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                  <div class=\"title-wrap\">\r\n                     <!-- <h2 class=\"section-title section-title_exim\">eCule <span class=\"theme-clr\"> Logi Tracker</span>\r\n                     </h2> -->\r\n                     <p class=\"c-blue\">Track your shipment &amp; see the current status</p>\r\n                     <p  *ngIf=\"note\"><small>Note : {{note}}</small></p>\r\n\r\n                  </div>\r\n               </div>\r\n\r\n            </div>\r\n            <div class=\"row track-inner\">\r\n               <div class=\"col-md-8 col-md-offset-2  wow fadeInUp\">\r\n                \r\n\r\n                  <div>\r\n                     <form class=\"row\">\r\n                        <div class=\"col-md-12 col-sm-12\">\r\n                           <div class=\"form-group\">\r\n                              <div class=\"track-input\">\r\n                              <input type=\"text\"  name=\"AWB_no\"\r\n                                 class=\"form-control\" [(ngModel)]='recordsCount' required=\"\"\r\n                                 placeholder=\"Enter AWB No. (or) PO No. (or) Vendor/Client \">\r\n                                 <button class=\"btn-1\" (click)=\"getAwbDetails(recordsCount)\">TRACK</button>\r\n                              </div>   \r\n                           </div>\r\n                           <div ng-model=\"message\"\r\n                              style=\"color: red; font-size: 14px; text-align: center;\">\r\n                              <div ng-hide=\"message\">{{message}}</div>\r\n                           </div>\r\n                        </div>\r\n                        <div class=\"col-md-8 col-sm-8\">\r\n                           <p class=\"c-blue no-margin\"><small>Note: Please expect delay of status update during the public holidays.</small></p>\r\n\r\n                           \r\n                        </div>\r\n                        <div class=\"col-md-4 text-right\">\r\n                           <div *ngIf=\"back; then multishipments else single\"></div>\r\n                           <ng-template #multishipments>\r\n                              <a (click)=\"getAwbDetailssubmit()\"> <i class=\"fa fa-undo c-red\" aria-hidden=\"true\" style=\"cursor:pointer\"></i></a>\r\n                           </ng-template>\r\n                           <ng-template #single>\r\n                              <a (click)=\"getAwbDetailssubmit()\"> <i class=\"fa fa-undo c-red\" aria-hidden=\"true\" style=\"cursor: pointer; \"></i></a>\r\n                           </ng-template>\r\n\r\n\r\n                        </div>\r\n                     </form>\r\n\r\n                  </div>\r\n               </div>\r\n            </div>\r\n            <div *ngIf=\"showActions\">\r\n               <div class=\"row\">\r\n                  <div class=\"col-md-2\"></div>\r\n                  <div class=\"col-md-8  wow fadeInRight\" data-wow-offset=\"50\" data-wow-delay=\".30s\"\r\n                     style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;\">\r\n                     <div class=\"prod-info block-clr\">\r\n                        <div *ngIf=\"multiple; then multishipments else single\"></div>\r\n                        <ng-template #single>\r\n                           <ul *ngFor=\"let import of data\" class=\"multi-ul\">\r\n                              <li (click)=\"getAwbDetails(import.AWB_no)\" class=\"single-li\">\r\n                                 <span class=\"title-2\">{{import.AWB_no}} </span>\r\n                                 <span class=\"colon\">- </span>\r\n                                 <div *ngIf=\"import.Pick_up_date;then no_pkdate else pkdate\"></div>\r\n                                 <ng-template #no_pkdate><span class=\"fs-16\">{{import.Pick_up_date | date}}</span>\r\n                                 </ng-template>\r\n                                 <ng-template #pkdate><span class=\"fs-16\">Shipment not yet picked-up</span>\r\n                                 </ng-template>\r\n\r\n                              </li>\r\n\r\n\r\n                           </ul>\r\n\r\n                        </ng-template>\r\n\r\n                        <ng-template #multishipments>\r\n                           <ul *ngFor=\"let import of data\">\r\n                              <li>\r\n                                 <span class=\"title-2\">AWB No. </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.AWB_no}}</span>\r\n                              </li>\r\n                              <li>\r\n                                 <span class=\"title-2\">Carrier </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.Carrier}}</span>\r\n                              </li>\r\n                              <li>\r\n                                 <span class=\"title-2\">Location </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.SBU_location}}</span>\r\n                              </li>\r\n                              <li>\r\n                                 <span class=\"title-2\">PO No. </span>\r\n                                 <span class=\"colon\">: </span>\r\n                                 <span class=\"fs-16\">{{import.NRM}}{{import.MPR}}{{import.BLR}}{{import.VPO}}</span>\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Vendor Name </span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\">{{import.Vendor_name}}</span> </li>\r\n                              <li> <span class=\"title-2\">Pick up Date </span><span class=\"colon\">: </span>\r\n\r\n                                 <div *ngIf=\"import.Pick_up_date;then no_pkdate else pkdate\"></div>\r\n                                 <ng-template #no_pkdate><span class=\"fs-16\">{{import.Pick_up_date | date }}\r\n                                    </span> </ng-template>\r\n                                 <ng-template #pkdate><span class=\"fs-16\">Shipment not yet picked-up</span>\r\n                                 </ng-template>\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Landed Date</span><span class=\"colon\">: </span>\r\n                                 <div *ngIf=\"import.shpt_land_dt;then no_shdate else shdate\"></div>\r\n                                 <ng-template #no_shdate><span class=\"fs-16\">{{import.shpt_land_dt | date }}</span>\r\n                                 </ng-template>\r\n                                 <ng-template #shdate><span class=\"fs-16\">{{import.shpt_land_dt}}</span> </ng-template>\r\n\r\n                              </li>\r\n                              <li> <span class=\"title-2\">Port of clearance</span><span class=\"colon\">: </span> <span\r\n                                    class=\"fs-16\">{{import.Port_of_clearance}}</span> </li>\r\n                              <li> <span class=\"title-2\">Clearance Status</span> <span class=\"colon\">: </span><span\r\n                                    class=\"fs-16\">{{import.Status}}</span> </li>\r\n                              <li> <span class=\"title-2\">Expected Delivery Date</span><span class=\"colon\">: </span>\r\n                                 <div *ngIf=\"import.Expected_Date_Delivery;then no_expdate else expdate\"></div>\r\n                                 <ng-template #no_expdate><span class=\"fs-16\">{{import.Expected_Date_Delivery | date\r\n                                       }}</span> </ng-template>\r\n                                 <ng-template #expdate><span class=\"fs-16\">{{import.Expected_Date_Delivery}}</span>\r\n                                 </ng-template>\r\n                              </li>\r\n                              <li> <span class=\"title-2\"> Actual Delivery Date</span><span class=\"colon\">: </span>\r\n                                 <div *ngIf=\"import.Delivery_Date;then no_dlvdate else dddate\"></div>\r\n                                 <ng-template #no_dlvdate><span class=\"fs-16\">{{import.Delivery_Date | date}}</span>\r\n                                 </ng-template>\r\n                                 <ng-template #dddate><span class=\"fs-16\">{{import.Delivery_Date}}</span> </ng-template>\r\n\r\n                              </li>\r\n                              <div *ngIf=\"import.Delivery_Date;then content else other_content\"></div>\r\n                              <ng-template #other_content>\r\n                                 <li> <span class=\"title-2\"> Remarks</span> <span class=\"colon\">: </span><span\r\n                                       class=\"fs-16\">{{import.Remarks}}</span> </li>\r\n                              </ng-template>\r\n                              <ng-template #content>\r\n                                 <li> <span class=\"title-2\"> Final Status</span><span class=\"colon\">: </span> <span\r\n                                       class=\"fs-16\">Shipment Delivered</span> </li>\r\n                              </ng-template>\r\n\r\n                           </ul>\r\n\r\n                        </ng-template>\r\n\r\n\r\n                     </div>\r\n                  </div>\r\n                  <div class=\"col-md-2\"></div>\r\n               </div>\r\n            </div>\r\n         </div>\r\n      </section>\r\n      <!-- /.Tracking -->\r\n   </article>\r\n   <!-- /.Content Wrapper -->\r\n   <!-- Footer -->\r\n   <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/import-shipment-details/import-shipment-details.component.ts":
/*!******************************************************************************!*\
  !*** ./src/app/import-shipment-details/import-shipment-details.component.ts ***!
  \******************************************************************************/
/*! exports provided: ImportShipmentDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImportShipmentDetailsComponent", function() { return ImportShipmentDetailsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../core/api-services.service */ "./src/app/core/api-services.service.ts");
/* harmony import */ var _core_social_http_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../core/social-http.service */ "./src/app/core/social-http.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};






var ImportShipmentDetailsComponent = /** @class */ (function () {
    function ImportShipmentDetailsComponent(router, httpClient, route, location, apiService, http) {
        var _this = this;
        this.router = router;
        this.httpClient = httpClient;
        this.route = route;
        this.location = location;
        this.apiService = apiService;
        this.http = http;
        this.showActions = false;
        this.previousUrl = undefined;
        this.currentUrl = undefined;
        this.href = "";
        this.prvurl = "";
        this.currentUrl = this.router.url;
        router.events.subscribe(function (event) {
            if (event instanceof _angular_router__WEBPACK_IMPORTED_MODULE_2__["NavigationEnd"]) {
                _this.previousUrl = _this.currentUrl;
                var px = _this.previousUrl.split("/");
                _this.prvurl = px[2];
                _this.currentUrl = event.url;
            }
            ;
        });
    }
    ImportShipmentDetailsComponent.prototype.ngOnInit = function () {
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        var userdetails = JSON.parse(currentTrackUser);
        this.user = userdetails;
        this.href = this.router.url;
        var stringToSplit = this.href;
        var x = stringToSplit.split("/");
        if (x[2]) {
            this.trackingsids = x[2];
            this.getAwbDetails(x[2]);
        }
        this.getnoteDetails(1);
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        this.back = false;
        this.edited = true;
        setTimeout(function () {
            this.edited = false;
        }.bind(this), 500);
    };
    ImportShipmentDetailsComponent.prototype.getAwbDetailssubmit = function (AwbNo) {
        this.router.navigate(['/']);
    };
    ImportShipmentDetailsComponent.prototype.getAwbDetails = function (AwbNo) {
        if (AwbNo.split(',').length > 1) {
            this.trackingsids = AwbNo;
        }
        var AwbNoss1 = AwbNo.replace('%20', ' ');
        var AwbNosss2 = AwbNoss1.replace('%20', ' ');
        var AwbNosss3 = AwbNosss2.replace('%20', ' ');
        var AwbNosss4 = AwbNosss3.replace('%20', ' ');
        var AwbNosss5 = AwbNosss4.replace('%20', ' ');
        var AwbNosss6 = AwbNosss5.replace('%20', ' ');
        var AwbNosss7 = AwbNosss6.replace('%20', ' ');
        var AwbNosss8 = AwbNosss7.replace('%20', ' ');
        var AwbNosss9 = AwbNosss8.replace('%20', ' ');
        var AwbNosss10 = AwbNosss9.replace('%20', ' ');
        var AwbNosss11 = AwbNosss10.replace('%20', ' ');
        var AwbNosss12 = AwbNosss11.replace('%20', ' ');
        this.recordsCount = AwbNosss12;
        if (AwbNo) {
            this.save({ key: AwbNosss12 ? AwbNosss12 : '' });
        }
        else {
            this.edited = false;
            this.showActions = false;
            this.message = "Please Enter AWB .No / PO.No / Vendor Name";
        }
    };
    ImportShipmentDetailsComponent.prototype.getnoteDetails = function (cNo) {
        var _this = this;
        this.httpClient.get('https://ets.aragen.com/settings/pagedetails/' + cNo)
            .subscribe(function (dataaa) {
            _this.note = dataaa[0].page_description;
        });
    };
    ImportShipmentDetailsComponent.prototype.save = function (dataform) {
        var _this = this;
        dataform['userId'] = this.user.id;
        this.edited = true;
        this.http.post(this.apiService.SEARCH_IMPORTS, dataform)
            .then(function (dataaa) {
            if (dataaa.record.length > 0) {
                _this.data = dataaa.record;
                if (dataaa.record.length == 1) {
                    _this.edited = false;
                    _this.multiple = true;
                    _this.back = true;
                    _this.vendor = _this.prvurl;
                    var rurl = 'import-records/' + dataform['key'];
                    _this.router.navigate([rurl], { queryParams: { "tracking_numbers": _this.trackingsids } });
                }
                else {
                    _this.edited = false;
                    _this.vendor = _this.prvurl;
                    _this.multiple = false;
                    _this.back = false;
                }
                _this.message = '';
                _this.tableName = dataaa.table;
                _this.showActions = true;
            }
            else {
                _this.edited = false;
                _this.showActions = false;
                _this.message = "The shipment details not found, Hence  please check with respective SCM Team";
            }
            _this.response = dataaa.status;
        });
    };
    ImportShipmentDetailsComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    ImportShipmentDetailsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-import-shipment-details',
            template: __webpack_require__(/*! ./import-shipment-details.component.html */ "./src/app/import-shipment-details/import-shipment-details.component.html"),
            styles: [__webpack_require__(/*! ./import-shipment-details.component.css */ "./src/app/import-shipment-details/import-shipment-details.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["Location"],
            _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"],
            _core_social_http_service__WEBPACK_IMPORTED_MODULE_5__["SocialHttpClient"]])
    ], ImportShipmentDetailsComponent);
    return ImportShipmentDetailsComponent;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".login-sec .modal-dialog{\r\n\t\t     margin: 30px auto;\r\n\t\t }\r\n\t\t .login-sec .login-wrap .title-3 ,  .login-sec  .login-wrap p {\r\n\t\t color:#262e7f;\r\n\t\t margin-bottom: 0px;\r\n\t\t text-transform: none;\r\n\t\t }\r\n\t\t .login-sec .login-form .gray-clr{\r\n\t\t color:#666;\r\n\t\t }\r\n\t\t .login-sec .login-form .form-control{\r\n\t\t text-transform:none;\r\n\t\t }\r\n\t\t .login-sec{\r\n\t\t\twidth: 100%;\r\n\t\t  }\r\n\t\t .login-sec img{\r\n\t\t\t  height: 70px;\r\n\t\t  }\r\n\t\t .login-wrap{\r\n\t\t\t  margin: auto;\r\n\t\t\t \r\n\t\t  }\r\n\t\t .row-center{\r\n\t\t\tdisplay: -webkit-box;\r\n\t\t\tdisplay: flex;\r\n\t\t\t-webkit-box-align: stretch;\r\n\t\t\t        align-items: stretch;\r\n\t\t\tflex-wrap: nowrap;\r\n\t\t\t-webkit-box-pack: stretch;\r\n\t\t\t        justify-content: stretch;\r\n\t\t  }\r\n\t\t .align-items-center {\r\n\t\t\t-webkit-box-align: center !important;\r\n\t\t\t        align-items: center !important;\r\n\t\t\tdisplay: -webkit-box;\r\n\t\t\tdisplay: flex;\r\n\t\t}"

/***/ }),

/***/ "./src/app/login/login.component.html":
/*!********************************************!*\
  !*** ./src/app/login/login.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<article>\r\n    <!-- Banner -->\r\n    <section class=\"\">\r\n\r\n        <div>\r\n            <!-- Popup: Login -->\r\n            <div>\r\n                <div class=\"row row-center\">\r\n                    <div class=\"col-md-8 align-items-center banner banner-style2  white-clr\" style=\"background-size: cover;\r\n                                background-repeat: no-repeat;background-position: right center;\">\r\n\r\n                        <div class=\"m-auto\">\r\n\r\n                            <img src=\"../assets/images/eCuleLogiTracker_White.png\" height=\"100px\">\r\n                        </div>\r\n                    </div>\r\n\r\n\r\n                    <div class=\"col-md-4 align-items-center\">\r\n                        <div class=\"login-sec\">\r\n                            <div class=\"login-wrap text-center\">\r\n                                <div> <img src=\"../assets/images/Aragen_Logo.png\" height=\"60px\"><br></div>\r\n                                <div><img src=\"../assets/images/gvk2.png\"></div>\r\n                                <p>Sign in<br>Sign in to GO for getting all details </p>\r\n\r\n                                <div class=\"login-form\">\r\n                                    <form [formGroup]=\"service\">\r\n                                        <div class=\"form-group\">\r\n\r\n                                            <input type=\"text\" name=\"email\" formControlName=\"email\"\r\n                                                Placeholder=\"Enter Email\" class=\"form-control\" [(ngModel)]='email'\r\n                                                (keypress)=\"checkkey($event)\" autocomplete=\"off\">\r\n                                            <div class=\"form-control-feedback\"\r\n                                                *ngIf=\"service.controls['email'].invalid && (service.controls['email'].dirty || service.controls['email'].touched)\"\r\n                                                class=\"text-danger\">\r\n                                                <div *ngIf=\"service.controls['email'].errors.required\">Email is required\r\n                                                </div>\r\n                                                <div *ngIf=\"service.controls['email'].errors.email\">The email address is\r\n                                                    invalid</div>\r\n                                            </div>\r\n                                        </div>\r\n                                        <div class=\"form-group\">\r\n                                            <input type=\"password\" formControlName='Password' name='Password'\r\n                                                Placeholder=\"Enter Password\" class=\"form-control\" [(ngModel)]='Password'\r\n                                                (keypress)=\"checkkey($event)\" autocomplete=\"off\">\r\n                                            <div class=\"form-control-feedback\"\r\n                                                *ngIf=\"service.controls['Password'].invalid && (service.controls['Password'].dirty || service.controls['Password'].touched)\"\r\n                                                class=\"text-danger\">\r\n                                                <div *ngIf=\"service.controls['Password'].errors.required\">Password is\r\n                                                    required</div>\r\n                                                <div *ngIf=\"service.controls['Password'].errors.minLength\">Password is\r\n                                                    too short</div>\r\n                                            </div>\r\n                                            <p *ngIf=\"Message\" class=\"alert-danger\">{{Message}}</p>\r\n                                        </div>\r\n\r\n                                        <div class=\"form-group\">\r\n                                            <button class=\"btn-1 \" type=\"submit\" (click)=\"submit()\"> Sign in now\r\n                                            </button>\r\n                                        </div>\r\n                                    </form>\r\n\r\n\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n\r\n                    </div>\r\n\r\n                </div>\r\n            </div>\r\n            <!-- /Popup: Login -->\r\n        </div>\r\n    </section>\r\n    <!-- /.Banner -->\r\n</article>"

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoginComponent = /** @class */ (function () {
    function LoginComponent(http, router) {
        this.http = http;
        this.router = router;
        this.service = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"]({
            email: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].email]),
            Password: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].minLength(6), _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].maxLength(15)]),
        });
    }
    LoginComponent.prototype.userDetails = function (Details) {
        var _this = this;
        this.http.post('https://ets.aragen.com/api/signIn', Details).subscribe(function (resp) {
            if (resp.data.length == 0) {
                _this.Message = "Enter valid credentials";
            }
            else if (resp.data.length == 1) {
                var now = new Date();
                resp.data[0]['expiry_time'] = now.getTime() + 3600000;
                localStorage.setItem('currentTrackUser', JSON.stringify(resp.data[0]));
                _this.router.navigate(['/']);
            }
        });
    };
    LoginComponent.prototype.ngOnInit = function () {
        this.Message = "";
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser != null) {
            this.router.navigate(['/']);
        }
    };
    LoginComponent.prototype.submit = function () {
        if (!this.email && !this.Password) {
            this.Message = "Enter Email and Password";
        }
        else if (!this.email) {
            this.Message = "Enter Email";
        }
        else {
            this.userDetails({ email: this.email, password: this.Password });
        }
        setTimeout(function () {
            this.Message = "";
        }.bind(this), 2000);
    };
    LoginComponent.prototype.checkkey = function ($event) {
        this.Message = "";
    };
    LoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/my-pipe.ts":
/*!****************************!*\
  !*** ./src/app/my-pipe.ts ***!
  \****************************/
/*! exports provided: Mypipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Mypipe", function() { return Mypipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var Mypipe = /** @class */ (function () {
    function Mypipe() {
    }
    Mypipe.prototype.transform = function (datea, format) {
        if (format === void 0) { format = 'yyyy-MM-dd'; }
        var newdate = new Date(datea).toISOString().slice(0, 10);
        var datePipe = new _angular_common__WEBPACK_IMPORTED_MODULE_1__["DatePipe"]("en-US");
        var value = datePipe.transform(newdate, 'MMM dd, yyyy');
        return value;
    };
    Mypipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({ name: 'custumdate' })
    ], Mypipe);
    return Mypipe;
}());



/***/ }),

/***/ "./src/app/privacy-policy/privacy-policy.component.css":
/*!*************************************************************!*\
  !*** ./src/app/privacy-policy/privacy-policy.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".theme-container.container {\r\n    color: black;\r\n}\r\nul, ol {\r\n    padding-left: 0;\r\n    list-style: aliceblue;\r\n    margin-bottom: 20px;\r\n    margin-left: 17px;\r\n    font-size: 16px;\r\n}\r\nul.s-dec{ \r\n    list-style-type:decimal;\r\n    }\r\nul.s-dec li{\r\n        margin-bottom: 5px;\r\n    }\r\nh2.section-title.section-title_exim {\r\n        text-transform: none;\r\n}    "

/***/ }),

/***/ "./src/app/privacy-policy/privacy-policy.component.html":
/*!**************************************************************!*\
  !*** ./src/app/privacy-policy/privacy-policy.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n    <div class=\"small1\">\r\n       <div class=\"small ball smallball1\"></div>\r\n       <div class=\"small ball smallball2\"></div>\r\n       <div class=\"small ball smallball3\"></div>\r\n       <div class=\"small ball smallball4\"></div>\r\n    </div>\r\n    <div class=\"small2\">\r\n       <div class=\"small ball smallball5\"></div>\r\n       <div class=\"small ball smallball6\"></div>\r\n       <div class=\"small ball smallball7\"></div>\r\n       <div class=\"small ball smallball8\"></div>\r\n    </div>\r\n    <div class=\"bigcon\">\r\n       <div class=\"big ball\"></div>\r\n    </div>\r\n </div>\r\n <main class=\"wrapper\">\r\n    <!-- Header -->\r\n    <!-- /.Header -->\r\n    <div class=\"logout\">\r\n      <a routerLink=\"/\">Home</a>\r\n      <a *ngIf=\"logincheck\" routerLink=\"/change-password\">Change Password</a>\r\n      <a *ngIf=\"logincheck\"  (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n       </div>\r\n\r\n    <!-- Content Wrapper -->\r\n    <article>\r\n       <!-- Breadcrumb -->\r\n       <section class=\"theme-breadcrumb pad-30\">\r\n          <div class=\"theme-container container \">\r\n             <div class=\"row\">\r\n                <div class=\"col-sm-12 text-center\">\r\n                   <a routerLink=\"/\"><img src=\"../assets/images/gvk2.png\"></a>\r\n                </div>\r\n                <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                   <div class=\"title-wrap\">\r\n                     <h2 class=\"section-title section-title_exim\"> eCule <span class=\"theme-clr\"> Logi Tracker</span> </h2>\r\n                                     </div>\r\n                </div>\r\n             </div>\r\n          </div>\r\n       </section>\r\n       <section class=\" pad-30\">\r\n          <div class=\"theme-container container \">\r\n             <div class=\"row \">\r\n                <p>Aragen Life Sciences Private Limited (\"ARAGEN\", “We”, ‘Our’) registered Plot No. 28 A, IDA Nacharam, Hyderabad – 500076, India; operates www.aragen.com (the “Website”). We are committed to protect the privacy and security of your personal data. We advise you to carefully read this Privacy Notice(“Notice”) so that you are aware of how, where, and why we are using your personal data.\r\n                </p>\r\n                <p>                <strong>Privacy Policy</strong></p>\r\n                <p>PURPOSE</p>\r\n                <p>                  We are committed to protecting the privacy of our users while they interact with eCule Logi Tracker APP (the “APP”). This Privacy Policy applies to the APP only. It does not apply to other websites to which we may link. Because we gather certain types of information about our users, we want you to understand what information we collect about you, how we collect it, how that information is used, and how you can control our disclosure of it. YOU AGREE THAT YOUR USE OF THE APP SIGNIFIES YOUR ASSENT TO THIS PRIVACY POLICY. IF YOU DO NOT AGREE WITH THIS PRIVACY POLICY, PLEASE DO NOT USE THE APP. PLEASE ALSO READ OUR TERMS OF USE PAGE, WHICH ESTABLISHES THE USE, DISCLAIMERS, AND LIMITATIONS OF LIABILITY GOVERNING THE USE OF THE APP.\r\n                </p>\r\n                <br>\r\n                <p>                  How We Use Your Information</p>\r\n                <br>\r\n                <p>INFORMATION WE MAY PROCESS (“Personal Data”)</p>\r\n                <p>We may collect personal data on the eCule Logi Tracker application, including information we collect while performing business transactions and information we collect from other sources, as permitted by law. We may collect your personal data including but not limited to</p>\r\n                <ul class=\"s-dec\">\r\n                   <li>Various usage and user metrics when you visit and use our Website including but not limited to cookies, IP addresses, device and software identifiers, referring and exiting URLs, onsite behaviour and usage information, feature use metrics and statistics, usage history, and location data. While some of this data is captured directly from you, for example, by way of web forms and web log servers, others can be captured indirectly from third parties, for example, tracing organization details, preferences, and interests on the basis of IP address and browsing history respectively.</li>\r\n                   <li>Information that you provide to us for the purpose of registering to use the Website, subscribing to the Company’s service, posting material, requesting further services and/or applying for a position of employment with us, including but not limited to your job title, name, address, telephone number, e-mail address, social media profile, curriculum vitae / resume, skillset, preferences, and interests.</li>\r\n                   <li>Information that you provide to us by completing any other forms on the Website or if you contact us with comments or specific requests (including but not limited to your name, address, telephone number, and e-mail address). We may also ask you for information when you report a problem with the Website.</li>\r\n                   <li>If you contact us, we may keep a record of that correspondence.</li>\r\n                   <li>We may also ask you to complete surveys that we use for research purposes, although you do not have to respond to them.</li>\r\n                </ul>\r\n                <p>  We only use your personal information for the original purposes it was given, including the purposes specified in this Privacy Policy and the purposes you otherwise agreed (if any). Your personal information will not be used for other purposes, nor will it be disclosed, sold or otherwise transferred to unaffiliated third parties without your prior approval, unless otherwise required at law. We reserve the right to contact you regarding matters relevant to the underlying service provided or the information collected.\r\n                </p>\r\n                <p>Please note that personally identifiable information is used only to provide you with a more convenient online experience and to help us identify and provide information that may be of interest to you. We use your personally identifiable information to support and enhance your use of the APP and its features, including providing customer service and project tracking and other client support services.\r\n                </p>\r\n                <p><strong>COOKIES</strong></p>\r\n                <p> Cookies are alphanumeric identifiers with small amount of data that is commonly used as an anonymous unique identifier. These are sent to your browser from the website that you visit and are stored on your computer’s hard drive. Please note, a cookie in no way gives us access to your computer, that is to say, cookies cannot access any other information on your computer. Our application uses these cookies to collect information and to improve our Service by making your interaction with us faster and more secure. They may be used for the purposes of managing your preferences, maintaining and optimizing security, marketing, communication, analytics, and research.</p>\r\n                <br>\r\n                <p>We majorly use below types of cookies:</p>\r\n                <br>             \r\n                <ul class=\"s-dec\">\r\n                   <li>\r\n                      <p>Essential Cookies or Strictly Necessary Cookies<br>\r\n                         These cookies are essential to the functioning of our Website and for you to move around the Website. Without these cookies, certain features could not function. No information about your browsing habits is gathered by these cookies.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>Functional Cookies<br>\r\n                         These cookies remember how you prefer to use our Website and improve the way our Website works. These are persistent cookies that help us recognize you as an existing user, so it’s easier for you to return to our Website without signing in again. After signing in, the persistent cookies stay on your browser and will be read when you return on to our sites. These remain on your computer/device for a pre-defined period of time.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>Performance Cookies<br>\r\n                         Some cookies help us with the performance and design of our Website. For example, these cookies show us statistics, which are the most frequently visited pages on the Website, help us record any difficulties you have with the Website, and whether our advertising is effective or not.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>Targeting or Tracking Cookies<br>\r\n                         On certain pages of our Website, we use cookies to help us understand your interests as you browse the Website, so we can tailor and deliver to you a more personalized service in the future. This assists us in delivering relevant, interest-based ads to you.\r\n                      </p>\r\n                      <p>\r\n                         If you do not want to receive cookies, most browsers allow you to control cookies through their setting preferences. However, if you do turn off cookies in your browser, you will not be able to fully experience some of the features our Website.\r\n                      </p>\r\n                      <p>\r\n                         GROUNDS FOR LAWFUL PROCESSING OF PERSONAL DATA<br>\r\n                         When we process your Personal data, we do so primarily in connection with marketing, sale, and promotion of services which we provide or which are procured using our services and to improve and enhance the range of those services and offerings. We may process your personal data for recruitment, communication, sales and marketing, registration and subscriptions purposes, where processing is necessary for the purpose of pursuing our legitimate interests.\r\n                      </p>\r\n                   </li>\r\n                </ul>\r\n                <p>USE OF PERSONAL DATA</p>\r\n                <p>\r\n                   We generally use the information to establish and enhance our relationship with our users for the following purposes:\r\n                </p>\r\n                <ul class=\"s-dec\">\r\n                   <li>\r\n                      <p>Communication <br> \r\n                         We may use your information to administer and provide services you request or have expressed an interest in, to communicate with you in case of any inquiry or support, for sending newsletters, updates and promotional materials, for seeking your opinion and feedback and personalize, to notify you about changes to our service, and/or tailor any communications that we may send you.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>Career Offering <br>  \r\n                         We provide career options on our Website for the users. They can apply to them using our online forms/links by registering with us. Once you are registered with us, we may use your personal data for various job openings that we have in our company and for sending you communication in case of job vacancies.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>Advertising <br>\r\n                         We may use your information to carry out advertising and market research based on behavioural metrics, geo-location data, demographic data and marketing preferences we capture. We may permit certain third party companies to help us tailor advertising based on use.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>Activity Tracking <br>\r\n                         We may use your information to track your activity on our digital platforms and personalize and improve your experience. This can be used to create an individual profile for you so that we can understand and respect your preferences or for profiling purposes to enable us to personalize and/or tailor any marketing communications that you may consent to receive from us.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>\r\n                         Optimization<br>\r\n                         We may use your information to operate, improve and maintain our site, to prevent fraud and abuse.\r\n                      </p>\r\n                   </li>\r\n                   <li>\r\n                      <p>\r\n                         Information Sharing<br>\r\n                         We may use and share your information with third parties with whom we have contractual relationship.<br>\r\n                         We keep your personal data only for the duration of legitimate business requirements or as required by law.\r\n                      </p>\r\n                   </li>\r\n                </ul>\r\n                <p>TRANSFERRING YOUR PERSONAL DATA\r\n                   <br>As a global business, we may transfer your personal data to servers, entities and partners. Your data may also be shared with other trusted third parties based in other countries so that they may process personal data on our behalf to meet your business requirements, if any. The personal data that belongs to you will not be transferred to any third party for storage purposes. It will only be transferred to trusted third parties in accordance to your business needs. By using the eCule Logi Tracker application or otherwise providing us with your personal data, you agree to us doing so in accordance with the terms of this Privacy Notice and applicable data protection laws and regulations. We will take all steps reasonably necessary to ensure that your data is treated securely and in accordance our data protection policy, which is in line with applicable data protection legislation. ARAGEN may permit certain third-party companies to help ARAGEN tailor the advertising that it thinks may be of interest to you, based on your use of our Website. If you do not want to receive any advertisements directed towards you, you can let us know at data.protection@gvkbio.com\r\n                </p>\r\n                <p>\r\n                   CHILDREN’S PRIVACY<br>\r\n                   We understand the importance of taking extra precautions to protect the privacy and safety of children using eCule Logi Tracker. The Services are not intended for users under the age of 16. We do not knowingly collect any Personal data from children under 16 or market to or solicit information from anyone under the age of 16. If we become aware that a person submitting Personal data is under 16, we will delete all the information as soon as possible unless it is with the consent and involvement of a parent or guardian. If you believe we might have any information from or about a child under 16, please contact us at data.protection@gvkbio.com.\r\n                </p>\r\n                <p>\r\n                   SECURITY: HOW SECURE IS YOUR INFORMATION WITH US?<br>\r\n                   We have implemented appropriate physical, electronic, procedural and managerial procedures to safeguard your information against loss, unauthorized access, misuse or modification. We require any third parties processing your information to do the implement the same levels of protection with respect to your data. We strive to use commercially acceptable means for protecting your information.\r\n                </p>\r\n                <p>\r\n                   CHANGES TO THE NOTICE<br>\r\n                   This Notice is effective as of April 10, 2019. We reserve the right to update or change this Notice at any time, and we will provide you with the updated Notice when we make any substantial updates at the earliest either through email or by providing a prominent notice of change on the Website. You should check the Notice periodically. Your continued use of the Website after we post any modifications to the Notice on this page will constitute your acknowledgment of the modifications and your consent to abide and be bound by the modified Notice.\r\n                </p>\r\n                <p>\r\n                   THIRD PARTY WEBSITES<br>\r\n                   From time to time we may provide links to the websites of other organisations, these links are provided for your information only. We have no control over the contents of those sites or resources, and accept no responsibility for them or for any loss or damage that may arise from your use of them.\r\n                </p>\r\n                <p>\r\n                   YOUR PRIVACY RIGHTS AND WHO TO CONTACT<br>\r\n                   We will respect your legal rights in relation to your data. Below are the rights granted to individuals located in the EU as per the General Data Protection Regulation, and ARAGEN is committed towards protection of the same.\r\n                </p>\r\n                <ul class=\"s-dec\">\r\n                   <li>Right to be informed</li>\r\n                   <li>Right to access</li>\r\n                   <li>Right to rectification</li>\r\n                   <li>Right to erasure</li>\r\n                   <li>Right to restrict processing</li>\r\n                   <li>Right to data portability</li>\r\n                   <li>Right to object</li>\r\n                   <li>Right to withdraw consent</li>\r\n                </ul>\r\n                <p>  In case you have any questions, comments or concerns about this Notice / Policy or wish to exercise any of the above mentioned rights, you can contact us at data.protection@gvkbio.com.</p>\r\n             </div>\r\n          </div>\r\n       </section>\r\n       <!-- /.Breadcrumb -->\r\n    </article>\r\n    <!-- /.Content Wrapper -->\r\n    <!-- Footer -->\r\n    <!-- /.Footer -->\r\n </main>\r\n <!-- / Main Wrapper -->\r\n <!-- Top -->\r\n <div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>"

/***/ }),

/***/ "./src/app/privacy-policy/privacy-policy.component.ts":
/*!************************************************************!*\
  !*** ./src/app/privacy-policy/privacy-policy.component.ts ***!
  \************************************************************/
/*! exports provided: PrivacyPolicyComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrivacyPolicyComponent", function() { return PrivacyPolicyComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var PrivacyPolicyComponent = /** @class */ (function () {
    function PrivacyPolicyComponent(http, router) {
        this.http = http;
        this.router = router;
    }
    PrivacyPolicyComponent.prototype.ngOnInit = function () {
        this.logincheck = true;
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.logincheck = false;
        }
        this.edited = true;
        //wait 3 Seconds and hide
        setTimeout(function () {
            this.edited = false;
        }.bind(this), 1000);
    };
    PrivacyPolicyComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    PrivacyPolicyComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-privacy-policy',
            template: __webpack_require__(/*! ./privacy-policy.component.html */ "./src/app/privacy-policy/privacy-policy.component.html"),
            styles: [__webpack_require__(/*! ./privacy-policy.component.css */ "./src/app/privacy-policy/privacy-policy.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], PrivacyPolicyComponent);
    return PrivacyPolicyComponent;
}());



/***/ }),

/***/ "./src/app/product-result/product-result.component.css":
/*!*************************************************************!*\
  !*** ./src/app/product-result/product-result.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/product-result/product-result.component.html":
/*!**************************************************************!*\
  !*** ./src/app/product-result/product-result.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "      <main class=\"wrapper\">\r\n         <!-- Header -->\r\n         <!-- /.Header -->\r\n         <!-- Content Wrapper -->\r\n         <article>\r\n            <!-- Breadcrumb -->\r\n            <section class=\"theme-breadcrumb pad-30\">\r\n               <div class=\"theme-container container \">\r\n                  <div class=\"row\">\r\n                     <div class=\"col-sm-12 text-center\">\r\n                        <div class=\"title-wrap\">\r\n                           <h2 class=\"section-title no-margin\"> PRODUCT TRACKING </h2>\r\n                           <p class=\"fs-16 no-margin\"> Track your product &amp; see the current condition </p>\r\n                        </div>\r\n                     </div>\r\n                     <div class=\"col-sm-12\">\r\n                        <ol class=\"breadcrumb-menubar list-inline\">\r\n                           <li><a href=\"#\" class=\"gray-clr\">Home</a></li>\r\n                           <li class=\"gray-clr disabled\">Search Result</li>\r\n                        </ol>\r\n                     </div>\r\n                  </div>\r\n               </div>\r\n            </section>\r\n            <!-- /.Breadcrumb -->\r\n            <!-- Tracking -->\r\n            <section class=\"pb-120 tracking-wrap\">\r\n               <div class=\"theme-container container \">\r\n                  <div class=\"row pad-10\">\r\n                     <div class=\"col-md-8 col-md-offset-2 tracking-form wow fadeInUp\" data-wow-offset=\"50\" data-wow-delay=\".30s\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInUp;\">\r\n                        <h2 class=\"title-1\"> TRACK YOUR PRODUCT </h2>\r\n                        <span class=\"font2-light fs-12\">Now you can track your product easily</span>\r\n                        <div class=\"row\">\r\n                           <form class=\"\">\r\n                              <div class=\"col-md-8 col-sm-8\">\r\n                                 <div class=\"form-group\">\r\n                                    <input type=\"text\" style=\"background: none; border-color: #ee1c25;\" name=\"AWB_no\" class=\"form-control box-shadow\" [(ngModel)]='recordsCount' required=\"\" placeholder=\"Enter your AWB No. (or) Ref No.\">\r\n                                 </div>\r\n                                 <div ng-model=\"message\" style=\"color: red; font-size: 18px; text-align: center; font-weight: bold\">\r\n                                       <div ng-hide=\"message\">{{message}}</div>\r\n                                       </div> \r\n                              </div>\r\n                              <div class=\"col-md-4 col-sm-4\">\r\n                                 <div class=\"form-group\">\r\n                                    <button class=\"btn-1\" (click)=\"getAwbDetails(recordsCount)\">TRACK YOUR PRODUCT</button>\r\n                                 </div>\r\n                              </div>\r\n                           </form>\r\n                        </div>\r\n                     </div>\r\n                  </div>\r\n\t\t\t\t  <div *ngIf=\"showActions\">\r\n                  <div class=\"row\"  *ngIf=\"checkTableName()\">\r\n                     <div class=\"col-md-2\"></div>\r\n                     <div class=\"col-md-8 pad-30 wow fadeInRight\" data-wow-offset=\"50\" data-wow-delay=\".30s\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;\">\r\n                        <div class=\"prod-info white-clr\">\r\n                         <ul *ngFor=\"let import of data\">\r\n                                 <li> <span class=\"title-2\">AWB no :</span> <span class=\"fs-16\">{{import.AWB_no}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Vendor name :</span> <span class=\"fs-16\">{{import.Vendor_name}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Pick up date :</span> <span class=\"fs-16\">{{import.Pick_up_date}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Landed date:</span> <span class=\"fs-16\">{{import.shpt_land_dt}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Expected Delivery Date:</span> <span class=\"fs-16\">{{import.Expected_Date_Delivery}}</span> </li>\r\n                                 <li> <span class=\"title-2\"> Delivery Date:</span> <span class=\"fs-16\">{{import.Delivery_Date}}</span> </li>\r\n                                 <li> <span class=\"title-2\"> Reasons:</span> <span class=\"fs-16\">{{import.Docs_shared_date}}</span> </li>\r\n\t\t\t\t\t\t</ul>\r\n                        </div>\r\n                     </div>\r\n                     <div class=\"col-md-2\"></div>\r\n                  </div>\r\n                  <div class=\"row\" *ngIf=\"!checkTableName()\">\r\n                        <div class=\"col-md-2\"></div>\r\n                        <div class=\"col-md-8 pad-30 wow fadeInRight\" data-wow-offset=\"50\" data-wow-delay=\".30s\" style=\"visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;\">\r\n                           <div class=\"prod-info white-clr\">\r\n                               <ul *ngFor=\"let export of data\">\r\n                                 <li> <span class=\"title-2\">SHIP TO:</span> <span class=\"fs-16\">{{export.SHIP_TO}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Carrier:</span> <span class=\"fs-16\">{{export.Carrier}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Tracking No:</span> <span class=\"fs-16\">{{export.Tracking_No}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Date:</span> <span class=\"fs-16\">{{export.Date}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Departure from India:</span> <span class=\"fs-16\">{{export.Departure_from_India}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Destination:</span> <span class=\"fs-16\">{{export.Destination}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Destination_Customs_release_date:</span> <span class=\"fs-16\">{{export.Destination_Customs_release_date}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Date_of_Delivery_to_client:</span> <span class=\"fs-16\">{{export.Date_of_Delivery_to_client}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Remarks:</span> <span class=\"fs-16\">{{export.Remarks}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Shipment Delivery:</span> <span class=\"fs-16\">{{export.Shipment_Day_of_pick_up}}</span> </li>\r\n                                 <li> <span class=\"title-2\">Remarks:</span> <span class=\"fs-16\">{{export.Remarks}}</span> </li>\r\n\t\t\t\t\t\t\t\t</ul> \r\n\t\t\t\t\t\t\t</div>\r\n                        </div>\r\n                        <div class=\"col-md-2\"></div>\r\n                     </div>\r\n               </div>\r\n               </div>\r\n            </section>\r\n            <!-- /.Tracking -->\r\n         </article>\r\n         <!-- /.Content Wrapper -->\r\n         <!-- Footer -->\r\n         <!-- /.Footer -->\r\n      </main>\r\n      <!-- / Main Wrapper -->\r\n      <!-- Top -->\r\n      <div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n      <!-- Search Popup -->\r\n      <div class=\"search-popup\">\r\n         <div>\r\n            <div class=\"popup-box-inner\">\r\n               <form>\r\n                  <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n               </form>\r\n            </div>\r\n         </div>\r\n         <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n      </div>\r\n "

/***/ }),

/***/ "./src/app/product-result/product-result.component.ts":
/*!************************************************************!*\
  !*** ./src/app/product-result/product-result.component.ts ***!
  \************************************************************/
/*! exports provided: ProductResultComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductResultComponent", function() { return ProductResultComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ProductResultComponent = /** @class */ (function () {
    function ProductResultComponent(http, route) {
        this.http = http;
        this.route = route;
        this.showActions = false;
    }
    ProductResultComponent.prototype.ngOnInit = function () {
        this.getAwbDetails(this.route.snapshot.params['id']);
    };
    ProductResultComponent.prototype.getAwbDetails = function (AwbNo) {
        var _this = this;
        var formData = new FormData();
        formData.append('key', AwbNo);
        this.http.post('http://gvknew.clientdemos.in/api/getRecords', formData)
            .subscribe(function (dataaa) {
            if (dataaa.status) {
                _this.data = dataaa.data.record;
                _this.message = '';
                _this.tableName = dataaa.data.table;
                _this.showActions = true;
            }
            else {
                _this.showActions = false;
                _this.message = "No Records available";
            }
            _this.response = dataaa.status;
        });
    };
    ProductResultComponent.prototype.checkTableName = function () {
        if (this.tableName == "gvk_import_records") {
            return true;
        }
        if (this.tableName == "gvk_export_records") {
            return false;
        }
        if (this.tableName == "gvk_export_records") {
            return false;
        }
    };
    ProductResultComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-product-result',
            template: __webpack_require__(/*! ./product-result.component.html */ "./src/app/product-result/product-result.component.html"),
            styles: [__webpack_require__(/*! ./product-result.component.css */ "./src/app/product-result/product-result.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
    ], ProductResultComponent);
    return ProductResultComponent;
}());



/***/ }),

/***/ "./src/app/product/product.component.css":
/*!***********************************************!*\
  !*** ./src/app/product/product.component.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".bg-img{\r\n    background-image: url('banner-2.jpg');\r\n    height:100%;\r\n    width:100%;\r\n    background-repeat:no-repeat;\r\n    background-size:cover;\r\n    position: absolute;\r\n      top: 0;\r\n      right: 0;\r\n      bottom: 0;\r\n      left: 0;\r\n      display: block;\r\n    }"

/***/ }),

/***/ "./src/app/product/product.component.html":
/*!************************************************!*\
  !*** ./src/app/product/product.component.html ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\">\r\n    <div class=\"small1\">\r\n       <div class=\"small ball smallball1\"></div>\r\n       <div class=\"small ball smallball2\"></div>\r\n       <div class=\"small ball smallball3\"></div>\r\n       <div class=\"small ball smallball4\"></div>\r\n    </div>\r\n    <div class=\"small2\">\r\n       <div class=\"small ball smallball5\"></div>\r\n       <div class=\"small ball smallball6\"></div>\r\n       <div class=\"small ball smallball7\"></div>\r\n       <div class=\"small ball smallball8\"></div>\r\n    </div>\r\n    <div class=\"bigcon\">\r\n       <div class=\"big ball\"></div>\r\n    </div>\r\n </div>\r\n <!-- /.Preloader -->\t\r\n <!-- Main Wrapper -->        \r\n <main class=\"wrapper\">\r\n    <!-- Content Wrapper -->\r\n    <article>\r\n       <!-- Banner -->\r\n       <section class=\"banner banner-style2 mask-overlay white-clr\">\r\n          <div class=\"pad-50 hidden-xs\"></div> \r\n          <div class=\"container theme-container rel-div\">\r\n             <div><img src=\"../assets/images/gvk2.png\" style=\"width: 300px;\"></div>\r\n             <!-- <img class=\"pt-10 effect animated fadeInLeft\" alt=\"\" src=\"../assets/images/gvk.png\" /> -->\r\n             <ul class=\"list-items fw-600 effect animated wow fadeInUp\" data-wow-offset=\"50\" data-wow-delay=\".20s\">\r\n                <li><a href=\"#\" style=\"font-size:16px\">FAST</a></li>\r\n                <li><a href=\"#\" style=\"font-size:16px\">SECURED</a></li>\r\n                <li><a href=\"#\" style=\"font-size:16px\">WORLDWIDE</a></li>\r\n             </ul>\r\n             <h2 class=\"section-title fs-48 effect animated wow fadeInUp\" data-wow-offset=\"50\" data-wow-delay=\".20s\"> Track your <br> <span class=\"theme-clr\"> Product </span>  </h2>\r\n             <div class=\"pad-30\"></div>\r\n             <div class=\"col-md-8 col-md-offset-2 tracking-form text-left effect animated fadeInUp\">\r\n                <h2 class=\"title-1\"> TRACK YOUR PRODUCT WITH AWB NO. (OR) REF NO.</h2>\r\n                <span class=\"font2-light fs-12\">Now you can track your product easily</span>\r\n                <div class=\"row\">\r\n                     <form class =\"my-5\" [formGroup]=\"service\">\r\n                                    <div class=\"col-md-8 col-sm-8\">\r\n                         <div class=\"form-group\">\r\n                            <input type=\"text\" style=\"background: none; border-color: #ee1c25;\" name=\"AWB_no\" class=\"form-control box-shadow\" formControlName=\"AWB_no\" [(ngModel)]='AWB_no' required=\"\" placeholder=\"Enter your AWB No. (or) Ref No.\">\r\n                         </div>\r\n\r\n                      </div>\r\n                      <div class=\"col-md-4 col-sm-4\">\r\n                         <div class=\"form-group\">\r\n                            <button class=\"btn-1\" (click)=\"submit()\" >TRACK YOUR PRODUCT</button>\r\n                            <div *ngIf=\"message\" style=\"color: red; font-size: 18px; text-align: center; font-weight: bold\">{{message}}</div>\r\n                         </div>\r\n                      </div>\r\n                  </form>\r\n                </div>\r\n                <div class=\"pad-10\"></div>\r\n             </div>\r\n             </div>\r\n       </section>\r\n       <!-- /.Banner -->\r\n    </article>\r\n    <!-- /.Content Wrapper -->\r\n </main>\r\n <!-- / Main Wrapper -->\r\n <!-- Top -->\r\n <div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n <!-- Search Popup -->\r\n <div class=\"search-popup\">\r\n    <div>\r\n       <div class=\"popup-box-inner\">\r\n          <form>\r\n             <input class=\"search-query\" type=\"text\" placeholder=\"Search and hit enter\" />\r\n          </form>\r\n       </div>\r\n    </div>\r\n    <a href=\"javascript:void(0)\" class=\"close-search\"><i class=\"fa fa-close\"></i></a>\r\n </div>"

/***/ }),

/***/ "./src/app/product/product.component.ts":
/*!**********************************************!*\
  !*** ./src/app/product/product.component.ts ***!
  \**********************************************/
/*! exports provided: ProductComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductComponent", function() { return ProductComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var ProductComponent = /** @class */ (function () {
    function ProductComponent(http, router) {
        this.http = http;
        this.router = router;
        this.service = new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroup"]({
            AWB_no: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required)
        });
    }
    ProductComponent.prototype.productDetails = function (Details) {
        var _this = this;
        var formData = new FormData();
        formData.append('key', Details);
        this.http.post('http://gvknew.clientdemos.in/api/getRecords', formData)
            .subscribe(function (data) {
            if (!data.status) {
                _this.message = "No records available with this number";
                // alert("No records available with this number")              
            }
            else {
                _this.router.navigateByUrl("/productDetails/" + _this.AWB_no);
            }
        });
    };
    ProductComponent.prototype.ngOnInit = function () {
    };
    ProductComponent.prototype.submit = function () {
        this.productDetails(this.AWB_no);
    };
    ProductComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-product',
            template: __webpack_require__(/*! ./product.component.html */ "./src/app/product/product.component.html"),
            styles: [__webpack_require__(/*! ./product.component.css */ "./src/app/product/product.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], ProductComponent);
    return ProductComponent;
}());



/***/ }),

/***/ "./src/app/saved-search/saved-search.component.css":
/*!*********************************************************!*\
  !*** ./src/app/saved-search/saved-search.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".white-sap {\r\n    margin-top: 10px;\r\n    color: #fff;\r\n    background: white;\r\n    padding: 10px;\r\n}\r\n#preloader {\r\n    height: 100%;\r\n    width: 100%;\r\n    position: fixed;\r\n    z-index: 9999;\r\n    top: 0px;\r\n    background-color: transparent;\r\n}\r\n::-webkit-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-moz-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::-ms-input-placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n::placeholder {\r\n  color: #000000;\r\n  opacity: 1; /* Firefox */\r\n}\r\n:-ms-input-placeholder { /* Internet Explorer 10-11 */\r\n color: #000000;\r\n}\r\n::-ms-input-placeholder { /* Microsoft Edge */\r\n color: #000000;\r\n}\r\n.fs-16.no-margin {\r\n    color: #f74747;\r\n}\r\n.form-control.box-shadow.ng-dirty.ng-valid.ng-touched {\r\n    color: red;\r\n}\r\n.prod-info ul {\r\n    text-align: left !important;\r\n    border: 1px solid #e62f2d;\r\n    margin-bottom: 15px;\r\n}\r\n.prod-info li {\r\n    border-bottom: 1px solid #f00d0d;\r\n    padding: 7px 30px;\r\n}\r\n.title-2{\r\n    text-transform: initial;\r\n}\r\n.prod-info .fs-16{\r\nwhite-space: pre-wrap;\r\nwhite-space: -moz-pre-wrap;\r\nwhite-space: -pre-wrap;\r\nwhite-space: -o-pre-wrap;\r\nword-wrap: break-word;\r\n}\r\n.prod-info ul li:last-child{\r\nborder:0;\r\n}\r\nli.single-li {\r\n    box-shadow: 0 0 15px rgba(204, 204, 204, 0.28);\r\n}\r\nli.single-li:hover {\r\n    cursor: pointer;\r\n}\r\nh2.section-title.section-title_exim {\r\n    text-transform: none;\r\n}\r\n.btn-tab-sec{\r\n    padding: 2px;\r\n    border: 1px solid #dc402a;\r\n    border-radius: 5px;\r\n    background: #fff;\r\n    margin-bottom: 15px;\r\n}\r\n.btn-tab-sec button{\r\n    background: #e9ecf1;\r\n    padding: 5px 10px;\r\n    width:49.5%;\r\n    border-radius: 5px;\r\n    border:0;\r\n    font-size: 14px;\r\n    color: #0d3f7c;\r\n\r\n}\r\n.btn-tab-sec button:nth-child(1){\r\n   margin-right: 5px;\r\n   background: #fbedea;\r\n   color: #dc402a;\r\n}\r\n.btn-tab-sec button.active{\r\n    background: #dc402a;\r\n    color: #fff;\r\n}\r\n.list-group-flush li a{\r\n    margin-left: 10px;\r\n}\r\na , .fa{\r\n    cursor: pointer;\r\n}\r\n"

/***/ }),

/***/ "./src/app/saved-search/saved-search.component.html":
/*!**********************************************************!*\
  !*** ./src/app/saved-search/saved-search.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"loader\">\r\n  <div class=\"small1\">\r\n     <div class=\"small ball smallball1\"></div>\r\n     <div class=\"small ball smallball2\"></div>\r\n     <div class=\"small ball smallball3\"></div>\r\n     <div class=\"small ball smallball4\"></div>\r\n  </div>\r\n  <div class=\"small2\">\r\n     <div class=\"small ball smallball5\"></div>\r\n     <div class=\"small ball smallball6\"></div>\r\n     <div class=\"small ball smallball7\"></div>\r\n     <div class=\"small ball smallball8\"></div>\r\n  </div>\r\n  <div class=\"bigcon\">\r\n     <div class=\"big ball\"></div>\r\n  </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n  <!-- Header -->\r\n  <!-- /.Header -->\r\n  <!-- Content Wrapper -->\r\n  <article>\r\n   <div class=\"logo-home\">\r\n      <div class=\"m-auto login-logo\"><img src=\"../assets/images/Aragen_Logo.png\" height=\"50px\"></div>\r\n      <div class=\"logout\">\r\n         <a routerLink=\"/\"><i class=\"fa fa-home\" aria-hidden=\"true\"></i> Home</a>\r\n         <a routerLink=\"/change-password\"><i class=\"fa fa-refresh\" aria-hidden=\"true\"></i> Change Password</a>\r\n         <a (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n      </div>\r\n    \r\n         <div class=\"text-center\">\r\n         <div>\r\n            <img src=\"../assets/images/gvk2.png\" >\r\n         </div>\r\n      </div>\r\n      \r\n        \r\n      </div>\r\n     <section class=\"theme-breadcrumb\">\r\n        <div class=\"theme-container container \">\r\n           <div class=\"row\">\r\n              \r\n              <div class=\"col-md-6 col-md-offset-3 text-center\">\r\n                 <div class=\"title-wrap\">\r\n                    <!-- <h2 class=\"section-title section-title_exim\">eCule <span class=\"theme-clr\"> Logi Tracker</span>\r\n                    </h2> -->\r\n                 </div>\r\n                 <div class=\"btn-tab-sec\" [ngSwitch]=\"user.usertype\">\r\n                    <div *ngIf=\"user.usertype == 1 || user.usertype == 2 || user.usertype == 3 || user.usertype == 6\">\r\n                     <button  [ngClass]=\"{'active' : importshow}\"  (click)=\"getImportData()\">IMPORT RECORDS</button>\r\n                     <button  [ngClass]=\"{'active' : shouldShow}\" (click)=\"getExportData()\">EXPORT RECORDS</button>\r\n                    </div>\r\n                 <button *ngSwitchCase=\"4\" [ngClass]=\"{'active' : importshow}\"  (click)=\"getImportData()\">IMPORT RECORDS</button>\r\n                 <button *ngSwitchCase=\"5\" [ngClass]=\"{'active' : shouldShow}\" (click)=\"getExportData()\">EXPORT RECORDS</button>\r\n                </div>\r\n              </div>\r\n\r\n           </div>\r\n        </div>\r\n     </section>\r\n     <!-- /.Breadcrumb -->\r\n     <!-- Tracking -->\r\n     <section class=\"pb-120 tracking-wrap\">\r\n      <div class=\"theme-container container \">\r\n           <div class=\"row pad-10\">\r\n            <div class=\"col-md-3\"></div>\r\n            <div class=\"col-md-6\">   \r\n               <div *ngIf='searchData?.length === 0'>\r\n                  <li class=\"list-group-item\">No Records to display!</li>\r\n                 </div>            \r\n              <ul class=\"list-group list-group-flush s-s\" >\r\n                <li class=\"list-group-item\" *ngFor=\"let data of searchData\" >\r\n                   <div *ngIf=\"data.type == 'import'; else export\">\r\n                   <a class=\"s-name\" routerLink=\"/import-records/{{data.SearchName}}\" >{{data.SearchName}}</a>\r\n                     <a (click)=\"deleteSearch(data.Id, data.type)\" class=\"text-danger pull-right\">\r\n                        <i class=\"fa fa-trash-o\" aria-hidden=\"true\"></i>\r\n                     </a> \r\n                     <a (click)=\"toTop(data)\" class=\"text-primary pull-right\"><i class=\"fa fa-arrow-circle-o-up\" aria-hidden=\"true\"></i>\r\n                     </a>\r\n                  </div>\r\n                  <ng-template #export>\r\n                        <a class=\"s-name\" routerLink=\"/export-records/{{data.SearchName}}\" >{{data.SearchName}}</a>\r\n                           <a (click)=\"deleteSearch(data.Id, data.type)\" class=\"text-danger pull-right\">\r\n                              <i class=\"fa fa-trash-o\" aria-hidden=\"true\"></i>\r\n                        </a> \r\n                        <a (click)=\"toTop(data)\" class=\"text-primary pull-right\">\r\n                           <i class=\"fa fa-arrow-circle-o-up\" aria-hidden=\"true\"></i>\r\n                        </a>\r\n                   </ng-template>\r\n                </li>\r\n               \r\n              </ul>\r\n            </div>\r\n             <div class=\"col-md-3\"></div>\r\n            \r\n           </div>\r\n        </div>\r\n     </section>\r\n     <!-- /.Tracking -->\r\n  </article>\r\n  <!-- /.Content Wrapper -->\r\n  <!-- Footer -->\r\n  <!-- /.Footer -->\r\n</main>\r\n<!-- / Main Wrapper -->\r\n<!-- Top -->\r\n<div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n<!-- Search Popup -->\r\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/saved-search/saved-search.component.ts":
/*!********************************************************!*\
  !*** ./src/app/saved-search/saved-search.component.ts ***!
  \********************************************************/
/*! exports provided: SavedSearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavedSearchComponent", function() { return SavedSearchComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _core_social_http_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../core/social-http.service */ "./src/app/core/social-http.service.ts");
/* harmony import */ var _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../core/api-services.service */ "./src/app/core/api-services.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var SavedSearchComponent = /** @class */ (function () {
    function SavedSearchComponent(httpClient, router, http, apiService) {
        this.httpClient = httpClient;
        this.router = router;
        this.http = http;
        this.apiService = apiService;
        this.loader = false;
        this.shouldShow = false;
        this.importshow = false;
    }
    SavedSearchComponent.prototype.ngOnInit = function () {
        this.loader = true;
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
        var userdetails = JSON.parse(currentTrackUser);
        this.user = userdetails;
        if (this.user.usertype == 4) {
            this.getImportData();
        }
        else if (this.user.usertype == 5) {
            this.getExportData();
        }
        else {
            this.getImportData();
        }
    };
    SavedSearchComponent.prototype.getImportData = function () {
        var _this = this;
        this.loader = true;
        this.importshow = true;
        this.shouldShow = false;
        var params = {};
        params['userId'] = this.user.id;
        this.http.post(this.apiService.SAVED_SEARCH_IMPORTS, params)
            .then(function (data) {
            _this.loader = false;
            _this.searchData = data['data'];
        });
    };
    SavedSearchComponent.prototype.getExportData = function () {
        var _this = this;
        this.loader = true;
        this.importshow = false;
        this.shouldShow = true;
        var params = {};
        params['userId'] = this.user.id;
        this.http.post(this.apiService.SAVED_SEARCH_EXPORTS, params)
            .then(function (data) {
            _this.loader = false;
            _this.searchData = data['data'];
        });
    };
    SavedSearchComponent.prototype.deleteSearch = function (id, type) {
        var _this = this;
        this.loader = true;
        var params = {};
        params['id'] = id;
        params['userId'] = this.user.id;
        this.http.post(this.apiService.DELETE_SAVED_SEARCH, params)
            .then(function (data) {
            if (type == 'export') {
                _this.getExportData();
                _this.loader = false;
            }
            else if (type == 'import') {
                _this.getImportData();
                _this.loader = false;
            }
        });
    };
    SavedSearchComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    SavedSearchComponent.prototype.toTop = function (data) {
        var _this = this;
        this.loader = true;
        var params = {};
        params['userId'] = this.user.id;
        params['Id'] = data.Id;
        params['type'] = data.type;
        this.http.post(this.apiService.TO_TOP_SEARCH, params)
            .then(function (data) {
            if (params['type'] == 'import') {
                _this.getImportData();
            }
            else if (params['type'] == 'export') {
                _this.getExportData();
            }
        });
    };
    SavedSearchComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-saved-search',
            template: __webpack_require__(/*! ./saved-search.component.html */ "./src/app/saved-search/saved-search.component.html"),
            styles: [__webpack_require__(/*! ./saved-search.component.css */ "./src/app/saved-search/saved-search.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _core_social_http_service__WEBPACK_IMPORTED_MODULE_3__["SocialHttpClient"],
            _core_api_services_service__WEBPACK_IMPORTED_MODULE_4__["ApiServicesService"]])
    ], SavedSearchComponent);
    return SavedSearchComponent;
}());



/***/ }),

/***/ "./src/app/terms-conditions/terms-conditions.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/terms-conditions/terms-conditions.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".theme-container.container {\r\n    color: black;\r\n}\r\nul, ol {\r\n    padding-left: 0;\r\n    list-style: aliceblue;\r\n    margin-bottom: 20px;\r\n    margin-left: 17px;\r\n    font-size: 16px;\r\n}\r\nul.s-dec{ \r\n    list-style-type:decimal;\r\n    }\r\nul.s-dec li{\r\n        margin-bottom: 5px;\r\n    }\r\nh2.section-title.section-title_exim {\r\n        text-transform: none;\r\n}    "

/***/ }),

/***/ "./src/app/terms-conditions/terms-conditions.component.html":
/*!******************************************************************!*\
  !*** ./src/app/terms-conditions/terms-conditions.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"preloader\" *ngIf=\"edited\">\r\n  <div class=\"small1\">\r\n     <div class=\"small ball smallball1\"></div>\r\n     <div class=\"small ball smallball2\"></div>\r\n     <div class=\"small ball smallball3\"></div>\r\n     <div class=\"small ball smallball4\"></div>\r\n  </div>\r\n  <div class=\"small2\">\r\n     <div class=\"small ball smallball5\"></div>\r\n     <div class=\"small ball smallball6\"></div>\r\n     <div class=\"small ball smallball7\"></div>\r\n     <div class=\"small ball smallball8\"></div>\r\n  </div>\r\n  <div class=\"bigcon\">\r\n     <div class=\"big ball\"></div>\r\n  </div>\r\n</div>\r\n<main class=\"wrapper\">\r\n       <!-- Header -->\r\n       <!-- /.Header -->\r\n   <div class=\"logout\">\r\n      <a routerLink=\"/\">Home</a>\r\n      <a *ngIf=\"logincheck\" routerLink=\"/change-password\">Change Password</a>\r\n      <a *ngIf=\"logincheck\"  (click)=\"logout()\"><i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> Logout</a>\r\n       </div>\r\n          <!-- Content Wrapper -->\r\n       <article>\r\n          <!-- Breadcrumb -->\r\n          <section class=\"theme-breadcrumb pad-30\">\r\n             <div class=\"theme-container container \">\r\n                <div class=\"row\">\r\n        <div class=\"col-sm-12 text-center\">\r\n        <a routerLink=\"/\"><img src=\"../assets/images/gvk2.png\" style=\"width: 300px;\"></a></div>\r\n                   <div class=\"col-md-8 col-md-offset-2 text-center\">\r\n                      <div class=\"title-wrap\">\r\n                        <!-- <h2 class=\"section-title section-title_exim\"> eCule <span class=\"theme-clr\"> Logi Tracker</span> </h2> -->                      \r\n                        </div>\r\n                   </div>\r\n                  \r\n                </div>\r\n             </div>\r\n          </section>\r\n          <section class=\" pad-30\">\r\n              <div class=\"theme-container container \">\r\n\r\n            <div class=\"row \">\r\n\r\n             <h4>LEGAL DISCLAIMER</h4>\r\n            <p> 1.No eCule Logi Tracker app user is allowed to use the APP to submit inquiries about any chemical the use of which by such user is prohibited or unauthorised under the applicable laws. A user must be solely responsible for all his/her own conducts/acts under the registered account, including without limitation any contents such user submits as well as any subsequent consequences. UNLESS OTHERWISE REQUIRED AT LAW, ARAGEN WILL NOT BE LIABLE FOR ANY LOSS OR DAMAGE CAUSED BY ANY USER’S CONDUCTS/ACTS UNDER HIS/HER REGISTERED ACCOUNT.\r\n            </p>\r\n            <p>2.All tracking information that ARAGEN provides to users are for information purposes only. All users acknowledge that their use of any and all information provided by ARAGEN is merely based on their own independent judgement, and they shall bear all the associated risks on their own in this connection. UNLESS OTHERWISE REQUIRED AT LAW, ARAGEN WILL NOT BE LIABLE FOR ANY LOSS OR DAMAGE CAUSED BY ANY USER’S USE OF ANY COMPOUNDS PROVIDED BY ARAGEN.</p>\r\n          </div>\r\n          </div>\r\n        </section>\r\n          <!-- /.Breadcrumb -->\r\n         </article>\r\n       <!-- /.Content Wrapper -->\r\n       <!-- Footer -->\r\n       <!-- /.Footer -->\r\n    </main>\r\n    <!-- / Main Wrapper -->\r\n    <!-- Top -->\r\n    <div class=\"to-top theme-clr-bg transition\"> <i class=\"fa fa-angle-up\"></i> </div>\r\n   \r\n"

/***/ }),

/***/ "./src/app/terms-conditions/terms-conditions.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/terms-conditions/terms-conditions.component.ts ***!
  \****************************************************************/
/*! exports provided: TermsConditionsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TermsConditionsComponent", function() { return TermsConditionsComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var TermsConditionsComponent = /** @class */ (function () {
    function TermsConditionsComponent(http, router) {
        this.http = http;
        this.router = router;
    }
    TermsConditionsComponent.prototype.ngOnInit = function () {
        this.logincheck = true;
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.logincheck = false;
        }
        this.edited = true;
        //wait 3 Seconds and hide
        setTimeout(function () {
            this.edited = false;
        }.bind(this), 1000);
    };
    TermsConditionsComponent.prototype.logout = function () {
        localStorage.removeItem('currentTrackUser');
        var currentTrackUser = localStorage.getItem('currentTrackUser');
        if (currentTrackUser == null) {
            this.router.navigate(['/login']);
        }
    };
    TermsConditionsComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-terms-conditions',
            template: __webpack_require__(/*! ./terms-conditions.component.html */ "./src/app/terms-conditions/terms-conditions.component.html"),
            styles: [__webpack_require__(/*! ./terms-conditions.component.css */ "./src/app/terms-conditions/terms-conditions.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], TermsConditionsComponent);
    return TermsConditionsComponent;
}());



/***/ }),

/***/ "./src/app/user-screen/user-screen.component.css":
/*!*******************************************************!*\
  !*** ./src/app/user-screen/user-screen.component.css ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/user-screen/user-screen.component.html":
/*!********************************************************!*\
  !*** ./src/app/user-screen/user-screen.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class =\"container\">\r\n  <div class=\"row bg-success\" style=\"justify-content: center; align-items:center\">\r\n    <!-- <h4 class=\"display2 font-weight-bold text-dark\">\r\n      Welcome to user details page\r\n    </h4> -->\r\n<input type=\"file\" style=\"display: inline-block;\" (change)=\"incomingfile($event)\" placeholder=\"Upload file\" accept=\".xlsx\">\r\n<button type=\"button\" class=\"btn btn-info\" (click)=\"Upload()\" >Upload</button>\r\n    \r\n  </div>\r\n  </div>\r\n"

/***/ }),

/***/ "./src/app/user-screen/user-screen.component.ts":
/*!******************************************************!*\
  !*** ./src/app/user-screen/user-screen.component.ts ***!
  \******************************************************/
/*! exports provided: UserScreenComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserScreenComponent", function() { return UserScreenComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! xlsx */ "./node_modules/xlsx/xlsx.js");
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_2__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var UserScreenComponent = /** @class */ (function () {
    function UserScreenComponent(http) {
        this.http = http;
    }
    UserScreenComponent.prototype.incomingfile = function (event) {
        this.file = event.target.files[0];
    };
    UserScreenComponent.prototype.Upload = function () {
        var _this = this;
        var fileReader = new FileReader();
        fileReader.onload = function (e) {
            _this.arrayBuffer = fileReader.result;
            var data = new Uint8Array(_this.arrayBuffer);
            var arr = new Array();
            for (var i = 0; i != data.length; ++i)
                arr[i] = String.fromCharCode(data[i]);
            var bstr = arr.join("");
            var workbook = xlsx__WEBPACK_IMPORTED_MODULE_2__["read"](bstr, { type: "binary" });
            var first_sheet_name = workbook.SheetNames[0];
            var worksheet = workbook.Sheets[first_sheet_name];
        };
        fileReader.readAsArrayBuffer(this.file);
    };
    //  workbook = XLSX.readFile('D:\GVKProject\gvkcsv.xlsx');
    //  sheet_name_list = workbook.SheetNames;
    // xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);
    // console.log(xlData);
    UserScreenComponent.prototype.ngOnInit = function () {
        // let obs = this.http.get('index/user');
        // obs.subscribe((response:any) => console.log(response.recordset[0].email))    
        // }
    };
    UserScreenComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-user-screen',
            template: __webpack_require__(/*! ./user-screen.component.html */ "./src/app/user-screen/user-screen.component.html"),
            styles: [__webpack_require__(/*! ./user-screen.component.css */ "./src/app/user-screen/user-screen.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], UserScreenComponent);
    return UserScreenComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    apiUrl_base: 'https://ets.aragen.com'
    //  apiUrl_base: 'http://175.101.7.162:8090'
};
/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ "./src/services/auth.guard.ts":
/*!************************************!*\
  !*** ./src/services/auth.guard.ts ***!
  \************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AuthGuard = /** @class */ (function () {
    function AuthGuard(router) {
        this.router = router;
    }
    AuthGuard.prototype.canActivate = function (route, state) {
        var res = localStorage.getItem('currentTrackUser');
        var item = JSON.parse(res);
        if (item) {
            return true;
        }
        ;
        localStorage.removeItem('currentTrackUser');
        this.router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
        return false;
    };
    AuthGuard = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({ providedIn: 'root' }),
        __metadata("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]])
    ], AuthGuard);
    return AuthGuard;
}());



/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Projects\eCuleLogitrackerWeb\src\main.ts */"./src/main.ts");


/***/ }),

/***/ 1:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 2:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ 3:
/*!************************!*\
  !*** stream (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map