'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.post('/testProductDetails', function(req, res){
    console.log('********connection established***********');
    var data = req.body;
    console.log(data);
    // data.id =  Math.floor((Math.random() * 10000) + 10000);
    // data.Updated_date =  new Date();
    var sql = "INSERT INTO dbo.product(Start_Date, Country, No_of_chem, AWB_no, Create_Date, Updated_date) VALUES";
    sql += util.format("('%s','%s','%d','%d','%s','%s')",data.Start_Date, data.Country, data.No_of_chem, data.AWB_no, data.Create_Date, data.Updated_date);
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("Error in the program", err);
        else{
            console.log("record inserted")
            res.send(JSON.stringify(recordset));
        }

    })   
});
app.get('/getDetails/:AWB_no', function(req, res){
    console.log('connection established')
    const awb_no = req.params.awb_no;
    var sql = "select * from product where AWB_no=" +awb_no+";";
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else 
         //console.log('response',recordset);
         res.send(recordset);
});
});
module.exports = app;