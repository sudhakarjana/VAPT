const nodemailer = require('nodemailer');
const nodemailerMailgun = require('nodemailer-mailgun-transport');

 var transporter = nodemailer.createTransport({
 host: 'mail.aragen.com',
 port: 465,
 auth: {
        user: 'it.dev',
        pass: 'it#123'
    },
secureConnection: true,
tls:{
        secureProtocol: "TLSv1_method"
    }
});


exports.email=(toArr, ccArr, bccArr, from, subject, msg, callback)=>{
 let message={
     from: from,
     to:toArr,
     cc:ccArr,
     bcc:bccArr,
     subject:subject,
     html:msg
    }
    transporter.sendMail(message, function(err, info) {
        if (err) {
            console.log(err)
			return err
        } else {
			console.log(info);
			return info
        }
    });
}



