'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.get('/countries', function(req, res){
    var sql = "select * from gvk_country ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});
app.get('/countries/:ID', function(req, res){
    const id = req.params.ID;
    var sql = "select * from gvk_country where ID="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});

app.post('/countryadd', function(req, res){
    console.log('connection established')
   var data = req.body;
   var sql = "INSERT INTO gvk_country (country, create_By) VALUES";
    sql += util.format("('%s','%s')", data.country, 1)    
     db.executeSql(sql, function(err, recordset){
            if(err){
            console.log("Error in the query")
          } else{
            //console.log('record inserted')
            res.send(JSON.stringify(recordset))
          }
    });
});

app.put('/countryUpdate/:ID', function(req, res){
    console.log("SQL Conncection established");
    const id = req.params.ID;
    var data= req.body;
    var sql = "UPDATE gvk_country SET country='"+data.country+"' where id="+id+";";
    console.log("query", sql);
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is here", err);
        else
        res.send(recordset)
    })
})

app.delete('/DeleteCountry/:ID', function(req, res){
    console.log('connection established')
    const id = req.params.ID;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_country WHERE ID="+id+";";
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})
module.exports = app;