// 'use strict';
// const mongodb = require('../mongodb');
// const users = require('../mongodb').users;
// var express = require('express')
// var app = express.Router();

//   app.post('/userDetails', function (req, res) {
// 		if (!req.body.phone ) {
// 			res.json({
// 				status: 'error', "error": "input validation error",
// 				"message": "User doesn't exist, please register with your number."
// 			});
// 			return;
// 		}

// 		if (!req.body.name) {
// 			res.json({
// 				status: 'error', "error": "input validation error",
// 			  "message": "Please provide a name"
// 			});
// 			return;
//     }
//     if (!req.body.email) {
// 			res.json({
// 				status: 'error', "error": "input validation error",
// 			  "message": "Please provide a valid emaail "
// 			});
// 			return;
//     }   
//     mongodb.userDetails.saveUserDetails(req.body,(err,response)=>{
//       if(err){
//         console.log(err);
//        res.send({status:"error"})
//       }else{
//         res.send({status:"sucess",email:req.body.email});
//       }
//     })

//   });

//   // app.get('/userDetails/:userId', function (req, res) {
// 	// 	if (!req.params.userId) {
// 	// 		res.json({
// 	// 			status: 'error', "error": "input validation error",
// 	// 			"message": "Please provide valid userId."
//   //     });
//   //   }
//   //     const userId = req.params.userId;
//   //     mongodb.userDetails.findUserDetailsById(userId,(error, result) => {
//   //       if (error) throw error; 
//   //       res.send(result);
//   //   });
//   // })

//   app.get('/userDetails/:email', function (req, res) {
// 		if (!req.params.email) {
// 			res.json({
// 				status: 'error', "error": "input validation error",
// 				"message": "Please provide valid email."
//       });
//     }
//       const email = req.params.email;
//       mongodb.userDetails.findUserDetailsById1(email,(error, result) => {
//         if (error) 
//         res.send(error); 
//         else{
//         console.log(result)
//         res.send(result);
//         }
//     });
//   })

//   module.exports = app;
	