'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.get('/carrierlist', function(req, res){
    var sql = "select * from gvk_carrier ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});
app.get('/carriers/:ID', function(req, res){
    const id = req.params.ID;
    var sql = "select * from gvk_carrier where ID="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});

app.post('/carrierAdd', function(req, res){
    console.log('connection established')
   var data = req.body;
   var sql = "INSERT INTO gvk_carrier (carrier, create_By) VALUES";
    sql += util.format("('%s','%s')", data.carrier, 1)    
     db.executeSql(sql, function(err, recordset){
            if(err){
            console.log("Error in the query")
          } else{
            //console.log('record inserted')
            res.send(JSON.stringify(recordset))
          }
    });
});

app.put('/carrierUpdate/:ID', function(req, res){
    const id = req.params.ID;
    var data= req.body;
    var sql = "UPDATE gvk_carrier SET carrier='"+data.carrier+"' where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is here", err);
        else
        res.send(recordset)
    })
})

app.delete('/DeleteCarrier/:ID', function(req, res){
    const id = req.params.ID;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_carrier WHERE ID="+id+";";
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})
module.exports = app;