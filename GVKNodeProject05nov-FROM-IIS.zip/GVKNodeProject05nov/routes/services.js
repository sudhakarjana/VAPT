'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');
const middleware    = require("../middleware");
var dateFormat = require('dateformat');
const emails = require("../email/index");
const request = require('request');


function FedExOnTime(ress,regW,carrir,SBU_location,Clearance_BSO_NON_BSO,No_of_days_Door_to_Door){
		if(Clearance_BSO_NON_BSO === 'Non-BSO'){
			return ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === SBU_location && item.No_of_days_Door_to_Door <=No_of_days_Door_to_Door )).length
		}else if(Clearance_BSO_NON_BSO === 'BSO'){
			return ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === SBU_location && item.No_of_days_Door_to_Port <=No_of_days_Door_to_Door ) ).length
		}else{
			return 0
		}
}

function FedExOnTimeOther(ress,regW,carrir,SBU_location,Clearance_BSO_NON_BSO,No_of_days_Door_to_Door){
		if(Clearance_BSO_NON_BSO === 'Non-BSO'){
			return ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC' && item.SBU_location === SBU_location &&  item.No_of_days_Door_to_Door <=No_of_days_Door_to_Door )).length
		}else if(Clearance_BSO_NON_BSO === 'BSO'){
			return ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC' && item.SBU_location === SBU_location &&  item.No_of_days_Door_to_Port <=No_of_days_Door_to_Door ) ).length
		}else{
			return 0
		}
}

app.post('/email', async function(req, res){

		var ccArr = [];
		var email = 'ravikumar.p@kairostech.com';
		var ccArr = ['ravikumar.p@kairostech.com'];
		var subject = "AWB No: 12345"
		var message = 'The subjected shipment/ PO has been delivered at our site, please contact concerned stores team.'
		var messageObject = { ccArr: ccArr, email: email, name:"Ravi Pulusu",message:message,subject:subject}
		var resp = await emails.shipmentStatusMail(messageObject)
		res.json({"status": 200, "error": null, "bodypost": req.body,resp:resp});          
		  
   
})
app.post('/changepassword', function(req, res){
    var data = req.body;
    var table = 'gvk_users';
	var id =data.uid;	
	var pass =data.new_password;	
	var sql ="UPDATE gvk_users SET Password='"+pass+"' WHERE id="+id;
	db.executeSql(sql, function(err, recordset){
        if(err){
			res.json({"status": false, "data": err});	
        }else{
			res.json({"status": true, "data": data});	
        }
    });
});

app.post('/signIn', function(req, res){
    var data = req.body;
    if(data.email && data.password){
        var table = 'gvk_users';
        var email =data.email;	
        var pass =data.password;	
        var sql = "select * from gvk_users WHERE email LIKE '"+email+"' AND Password LIKE '"+pass+"'";
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({"message": err});	
            }else{
                if(recordset.recordset.length>0){
                    var sqlSaveSes = "INSERT INTO gvk_userSessions(userId) VALUES";
                    sqlSaveSes += util.format("('%s')",
                    recordset.recordset[0].id); 
                    db.executeSql(sqlSaveSes, function(err, dataSave){
                        //console.log(dataSave)
                    })
                }
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({"status": true, "message": "Send all required fields"});
    }
});

app.post('/signUp', function (req, res) {
    var data = req.body;
    var user_type = 3;
    var user_status = 1;
    var sql = "INSERT INTO gvk_users (email, password,usertype,status,fullname,username,designation,department) VALUES";
    sql += util.format("('%s','%s','%s','%s','%s','%s','%s','%s')", data.email, data.password, user_type, user_status, data.fullname, data.username, data.designation, data.department)
    db.executeSql(sql, function (err, recordset) {
        if (err) {
            res.status(500).json({"message":err})
        } else {
            res.status(200).json({"status":true,"data":recordset})
        }
    });
});


app.post('/getExportRecords', function(req, res){
    var data = req.body;
    if(data.userId && data.key){
    var table = 'gvk_export_records';
			if(data.key){
				var str = data.key;
					var str_array = str.split(',');
					var whereTracking_No = ""
						for(var i = 0; i < str_array.length; i++) {
						// Trim the excess whitespace.
							var key = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
							if(i==0){
							   whereTracking_No += "Tracking_No LIKE '"+key+"'"
							}else if(i < 10){
							   whereTracking_No += "OR Tracking_No LIKE '"+key+"'"                       
							}
						}
			var sql = "select * from gvk_export_shipments WHERE Invoice_No LIKE '"+key+"' OR "+whereTracking_No+" order by Date DESC;select * from gvk_users where id='"+data.userId+"';select * from gvk_saveSearchs WHERE userId='"+data.userId+"' AND type='export' AND SearchName='"+data.key+"'";
			 }else{
				res.status(400).json({"message": 'Please send Tracking_No or Invoice_No'});
			 }
            db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({"message": err});
            }else{
                var userDetails = recordset.recordsets[1][0]
				
                if((recordset.recordset.length > 0) && (data.save == 1) && (recordset.recordsets[2].length ===0)){
                    var sqlSaveSearch = "INSERT INTO gvk_saveSearchs(SearchName, userId,type) VALUES";
                    sqlSaveSearch += util.format("('%s','%s','%s')",
                    data.key?data.key:'',data.userId?data.userId:'','export'); 
                    db.executeSql(sqlSaveSearch, function(err, dataSave){
                       // console.log('dataSave',dataSave)
                    })
                }
                var result = recordset.recordset
                if(result.length == 1){
					if(result[0].customerID ==userDetails.customerID || userDetails.usertype < 3){
						for(let i=0; i < 1; i++){
							var sqlSub = "select Subscribe from gvk_shipmentUpdateSubscriptions where shipmentType='gvk_export_shipments' AND shipmentId="+result[i].id
							db.executeSql(sqlSub, function(err, recordsSub){
								if(recordsSub.recordset.length > 0){
									result[i]['subscribe'] = recordsSub.recordset[0].Subscribe
								}else{
									result[i]['subscribe'] = 0
								}
								console.log(result[i]['Destination_Customs_release_date'],150)
								if(result[i].Invoice_Date){
									result[i]['Invoice_Date']= dateFormat(result[i].Invoice_Date, "yyyy-mm-dd")
								}
								if(result[i].Date){
									result[i]['Date']= dateFormat(result[i].Date, "yyyy-mm-dd")
								}
								if(result[i].Departure_from_India){
									result[i]['Departure_from_India']= dateFormat(result[i].Departure_from_India, "yyyy-mm-dd")								
								}
								if(result[i].Landing_Destination_Port){
									result[i]['Landing_Destination_Port']= dateFormat(result[i].Landing_Destination_Port, "yyyy-mm-dd")
								}
								if(result[i].Destination_Customs_release_date){									
									result[i]['Destination_Customs_release_date']= dateFormat(result[i].Destination_Customs_release_date, "yyyy-mm-dd")
								}
								if(result[i].Date_of_Delivery_to_client){
									result[i]['Date_of_Delivery_to_client']= dateFormat(result[i].Date_of_Delivery_to_client, "yyyy-mm-dd")
								}

								console.log(result[i]['Destination_Customs_release_date'],157)

								res.status(200).json({"status": true,count:recordset.recordset.length, "table":table,permission:1, "record": result,message:"success"});	
							})  
						}
					}else{
						res.status(200).json({"status": true,count:recordset.recordset.length, "table":table, permission:0,"record": result, message:"You don't have permission to view"});	
					}
					
                }else{
							res.status(200).json({"status": true,count:recordset.recordset.length, "table":table,permission:1, "record": recordset.recordset,message:"success"});
                }	
            }
        });
    }else{
        res.status(400).json({"status": true, "message":"Send required fields"});	
    }
});
app.get('/getImportRecordsAll', function(req, res){
	
	 var sql = "select AWB_no from gvk_import_shipments";
        
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({"message":err});
            }else{
                
                var result = recordset.recordset
                res.status(200).json({"status": true, "record": recordset.recordset});	
                        
                
            }
               
            
        });
	
	
});
app.get('/getExportRecordsAll', function(req, res){
	
	 var sql = "select * from gvk_export_shipments";
        
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({"message":err});
            }else{
                
                var result = recordset.recordset
                res.status(200).json({"status": true, "record": recordset.recordset});	
                        
                
            }
               
            
        });
	
	
});
app.post('/getImportRecords', function(req, res){
    var data = req.body;
    if(data.userId && data.key){
        var table = 'gvk_import_records';
        if(data.key){
            var str = data.key;
            var str_array = str.split(',');
            var whereawb = ""
			var whereNRM = ""
			var whereMPR = ""
			var whereBLR = ""
			var whereVPO = ""
            for(var i = 0; i < str_array.length; i++) {
                    var key = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
				if(i == 0){
					whereawb += "AWB_no LIKE '"+key+"'"
                    whereNRM += "NRM LIKE '%"+key+"%'"
                    whereMPR += "MPR LIKE '%"+key+"%'"
                    whereBLR += "BLR LIKE '%"+key+"%'"
                    whereVPO += "VPO LIKE '%"+key+"%'"
				}else if(i < 10){
					whereawb += "OR AWB_no LIKE '"+key+"'"
                    whereNRM += "OR NRM LIKE '%"+key+"%'"
                    whereMPR += "OR MPR LIKE '%"+key+"%'"
                    whereBLR += "OR BLR LIKE '%"+key+"%'"
                    whereVPO += "OR VPO LIKE '%"+key+"%'"
				}
           
            }

            var sql= "select * from (select * from gvk_import_shipments WHERE (Vendor_name LIKE '%"+key+"%' OR "+whereNRM+" OR "+whereMPR+" OR "+whereBLR+" OR "+whereVPO+" OR "+whereawb+") AND Pick_up_date>DATEADD(day,-30000,GETDATE()) union select * from gvk_import_shipments WHERE (Vendor_name LIKE '%"+key+"%' OR "+whereNRM+" OR "+whereMPR+" OR "+whereBLR+" OR "+whereVPO+" OR "+whereawb+") AND( Pick_up_date is null or Pick_up_date=''))tbl order by (case when ( Pick_up_date is null or Pick_up_date='')  then 1 else 0  end)desc,Pick_up_date desc;select * from gvk_saveSearchs WHERE userId='"+data.userId+"' AND type='import' AND SearchName='"+data.key+"'";
       }else{
            var sql = "select * from gvk_import_shipments";
        }
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({"message":err});
            }else{
				if((recordset.recordset.length > 0) && (data.save == 1) && (recordset.recordsets[1].length ===0)){
                    var sqlSaveSearch = "INSERT INTO gvk_saveSearchs(SearchName, userId,type) VALUES";
                    sqlSaveSearch += util.format("('%s','%s','%s')",
                    data.key?data.key:'',data.userId?data.userId:'','import'); 
                    db.executeSql(sqlSaveSearch, function(err, dataSave){
                      //  console.log(dataSave)
                    })
                }
                var result = recordset.recordset
                if(result.length == 1){ 
                    for(let i=0; i < 1; i++){
                        var sqlSub = "select Subscribe from gvk_shipmentUpdateSubscriptions where shipmentType='gvk_import_shipments' AND  shipmentId="+result[i].id+" AND userId="+data.userId
                        db.executeSql(sqlSub, function(err, recordsSub){
                            if(recordsSub.recordset.length > 0){
                                result[i]['subscribe'] = recordsSub.recordset[0].Subscribe
                            }else{
                                result[i]['subscribe'] = 0
                            }
                            res.status(200).json({"status": true, "table":table, "record": result});	
                        })  
                    }
                }else{
                    res.status(200).json({"status": true, "table":table, "record": recordset.recordset});
                }
               
            }
        });
    }else{
        res.status(400).json({"message":"Send all required params"});
    }
    
});

app.post('/import-saved-searchs-list', function(req, res){
    if(req.body.userId){
        var data = req.body;
        var id =data.userId;
        var sql ="select * from gvk_saveSearchs WHERE userId='"+id+"' AND type='import' ORDER BY DateCreated DESC";
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err});	
            }else{
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});
app.post('/export-saved-searchs-list', function(req, res){
    if(req.body.userId){
        var data = req.body;
        var id =data.userId;	
        var sql ="select * from gvk_saveSearchs WHERE userId='"+id+"' AND type='export' ORDER BY DateCreated DESC";
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err});	
            }else{
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});
app.post('/delete-search', function(req, res){
	if(req.body.userId && req.body.id){
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
        var sql ="select * from gvk_saveSearchs WHERE userId='"+userId+"' AND Id="+id;
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err});	
            }else{
                if((recordset.recordset.length>0)){
                    var deleteSql ="DELETE from gvk_saveSearchs WHERE userId='"+userId+"' AND Id="+id;
                    db.executeSql(deleteSql, function(errr, deleteData){
                        if(errr){
                            res.status(500).json({ "message": err});
                        }else{
                            res.status(200).json({"status": true, "data": deleteData});	
                        }

                    })
                }else{
                    res.status(400).json({ "message": 'Records not availale'});
                }
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});

app.post('/user-logs', function(req, res){
    if(req.body.userId){
		
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
        if(data.fromDate){
		   var fromDate =data.fromDate;	
		   var toDate =data.toDate+' 23:59:59.999';	
				 var sql = "SELECT gvk_users.fullname, gvk_users.username, gvk_users.designation,  gvk_users.department, gvk_users.email,gvk_users.usertype,gvk_userSessions.DateCreated,gvk_userSessions.userId FROM gvk_userSessions LEFT JOIN gvk_users ON gvk_userSessions.userId = gvk_users.id WHERE DateCreated BETWEEN '"+data.fromDate+"' AND '"+toDate+"' ORDER BY DateCreated DESC";
	     }else{
	        var sql = "SELECT gvk_users.fullname, gvk_users.username, gvk_users.designation,  gvk_users.department, gvk_users.email,gvk_users.usertype,gvk_userSessions.DateCreated,gvk_userSessions.userId FROM gvk_userSessions LEFT JOIN gvk_users ON gvk_userSessions.userId = gvk_users.id ORDER BY DateCreated DESC";
         }
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err,sql:sql});	
            }else{
                res.status(200).json({"status": true, "data": recordset.recordset});	
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});

app.post('/subscribe-shipment', function(req, res){
    if(req.body.userId && req.body.shipmentId && req.body.shipmentType){
            var data = req.body;
            var shipmentId = data.shipmentId
            var shipmentType = data.shipmentType
            var subscribe = data.subscribe
        if(shipmentType =='gvk_import_shipments' || (shipmentType =='gvk_export_shipments')){
            sql = "select "+shipmentType+".* from "+shipmentType+" LEFT JOIN gvk_shipmentUpdateSubscriptions ON "+shipmentType+".id=gvk_shipmentUpdateSubscriptions.shipmentId  where gvk_shipmentUpdateSubscriptions.shipmentType = '"+shipmentType+"' AND gvk_shipmentUpdateSubscriptions.userId = '"+data.userId+"' AND gvk_shipmentUpdateSubscriptions.shipmentId="+shipmentId 
            db.executeSql(sql, function(err, recordset){
                if(err){
                    res.status(500).json({ "message": err,sql:sql});	
                }else{
					if(recordset.recordset.length == 0){
						var sqlSelect = "select * from  "+shipmentType+" Where id="+shipmentId
                        db.executeSql(sqlSelect, function(err, sqlSelect){
						 if(sqlSelect.recordset.length > 0){
                            if(shipmentType =='gvk_import_shipments'){
                                var shipmentStatus = sqlSelect.recordset[0].Status
                             }else if(shipmentType =='gvk_export_shipments')
                             {
                                 var shipmentStatus = sqlSelect.recordset[0].Status
                             }else{
                                 var shipmentStatus = ''
                             }
                            var sqlSaveSearch = "INSERT INTO gvk_shipmentUpdateSubscriptions(shipmentId,userId,shipmentType,Status,Subscribe) VALUES";
                                sqlSaveSearch += util.format("('%s','%s','%s','%s','%s')",
                                data.shipmentId?data.shipmentId:'',data.userId?data.userId:'',data.shipmentType?data.shipmentType:'',shipmentStatus?shipmentStatus:'',data.subscribe?data.subscribe:1); 
                                db.executeSql(sqlSaveSearch, function(err, insertData){
                                    if(err){
										res.status(500).json({"status": false, "data": insertData});	
									}else{
										res.status(200).json({"status": data.subscribe, "data": insertData});	
									}
                                })
                          }else{
                            res.status(400).json({"status": true, message:"No data available with shipmentId "+shipmentId});
                          }
                        })
                       
                    }else{
                        if(shipmentType =='gvk_import_shipments'){
                            var shipmentStatus = recordset.recordset[0].Status
                         }else if(shipmentType =='gvk_export_shipments')
                         {
                             var shipmentStatus = recordset.recordset[0].Remarks
                         }else{
                             var shipmentStatus = ''
                         }
     
                        var deleteSql = "UPDATE gvk_shipmentUpdateSubscriptions SET Subscribe = '"+subscribe+"' ,Status ='"+shipmentStatus+"' WHERE shipmentId ='"+data.shipmentId+"'  AND userId ='"+data.userId+"' AND shipmentType = '"+data.shipmentType+"'"
                        db.executeSql(deleteSql, function(err, delData){
							if(err){
								res.status(500).json({"status": false, "err": err});
							}else{
								res.status(200).json({"status": data.subscribe, "data": delData});	
							}
                        })
                    }
                    
                }
            });
        }else{
            res.status(400).json({ "message": 'Send valid shipmentType'});
        }
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});
app.post('/sort-saved-searchs-list', function(req, res){
    if(req.body.userId && req.body.Id && req.body.type){
        var data = req.body;
        var userId =data.userId;	
        var type =data.type;	
        var id =data.Id;	
        var sql ="select * from gvk_saveSearchs WHERE userId='"+userId+"' AND Id='"+id+"'";
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err});	
            }else{
				if(recordset.recordset.length >0){
				  var dt = new Date().toISOString('en-US', {  timeZone: 'Asia/Calcutta'})
				  var DateCreated=dateFormat(dt, "yyyy-mm-dd hh:mm:ss fff");
				  var ts_hms = new Date();
					var dtf =ts_hms.getFullYear() + '-' + 
					("0" + (ts_hms.getMonth() + 1)).slice(-2) + '-' + 
					("0" + (ts_hms.getDate())).slice(-2) + ' ' +
					("0" + ts_hms.getHours()).slice(-2) + ':' +
					("0" + ts_hms.getMinutes()).slice(-2) + ':' +
					("0" + ts_hms.getSeconds()).slice(-2)
				  var sortSql= "UPDATE gvk_saveSearchs SET DateCreated ='"+dtf+"' WHERE userId='"+userId+"' AND Id='"+id+"'"
				  db.executeSql(sortSql, function(errs, updateSort){
					  if(errs){
							res.status(500).json({ "message": errs});	
						}else{
							var orderSQL ="select * from gvk_saveSearchs WHERE userId='"+userId+"' AND type='"+type+"' ORDER BY DateCreated DESC";
							db.executeSql(orderSQL, function(errs, orderSQLSort){
							  if(errs){
									res.status(500).json({ "message": errs});	
								}else{
								  res.status(200).json({"status": true, "data": orderSQLSort.recordset}); 
								}
							})
						}
				  })
                 	
				}else{
					res.status(200).json({"status": true, "data": recordset.recordset}); 
				}
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});
app.get('/subscribes', function(req, res){
            sql = "select gvk_shipmentUpdateSubscriptions.*,gvk_users.email, gvk_users.fullname from gvk_shipmentUpdateSubscriptions LEFT JOIN gvk_users ON gvk_shipmentUpdateSubscriptions.userId = gvk_users.id where gvk_shipmentUpdateSubscriptions.subscribe='1'"
            db.executeSql(sql, function(err, recordset){
                if(err){
                    res.status(500).json({ "message": err,sql:sql});	
                }else{
                    let result = recordset.recordset
                    result.forEach(element => {
                        var shipmentsql = "select * from "+element.shipmentType+" where id=" +element.shipmentId
                        db.executeSql(shipmentsql, function(err, shipmentDetails){
                            if(element.shipmentType =='gvk_import_shipments'){
								if(shipmentDetails.rowsAffected > 0){
								    if(shipmentDetails.recordset[0].Status == element.Status){
										console.log(479,element)
									}else{
										var updateSQl = "UPDATE gvk_shipmentUpdateSubscriptions SET Status ='"+shipmentDetails.recordset[0].Status+"' WHERE subscrionId ="+element.subscrionId
										db.executeSql(updateSQl, function(err, updateSQlData){	
											if(shipmentDetails.recordset[0].Status=='Under-Clearance'){
												var message = 'The subjected shipment/ PO has been picked-up from origin. Will update once shipment lands in Indian port.'
											}else if(shipmentDetails.recordset[0].Status=='In-Transit'){
												var message = 'The subjected shipment/ PO has arrived in Indian port, please check with logistics team for documents query/ customs requirement.'
											}else if(shipmentDetails.recordset[0].Status=='Cleared'){
												var message = 'The subjected shipment/ PO has been delivered at our site, please contact concerned stores team.'
											}
										    var ccArr = [];
											var email = element.email
											var subject = "Import shipment -- AWB No: "+shipmentDetails.recordset[0].AWB_no+" , PO No:"+shipmentDetails.recordset[0].NRM+shipmentDetails.recordset[0].MPR+shipmentDetails.recordset[0].BLR+shipmentDetails.recordset[0].VPO
											var messageObject = { ccArr: ccArr, email: email, name:element.fullname,message:message,subject:subject}
											emails.shipmentStatusMail(messageObject)
											
										})
									}
									
								}else{
								    console.log('mail0')	
								}
                            }else if(element.shipmentType =='gvk_export_shipments'){
                          	if(shipmentDetails.rowsAffected > 0){
								    if(shipmentDetails.recordset[0].Status == element.Status){
										console.log(479,element)
									}else{
										var updateSQl = "UPDATE gvk_shipmentUpdateSubscriptions SET Status ='"+shipmentDetails.recordset[0].Status+"' WHERE subscrionId ="+element.subscrionId
										db.executeSql(updateSQl, function(err, updateSQlData){	
											if(shipmentDetails.recordset[0].Status=='Pickup'){
												var message = 'The subjected shipment has been picked-up from origin.'
											}else if(shipmentDetails.recordset[0].Status=='Departure'){
												var message = 'The subjected shipment has been departed from India, its presently in Transit.'
											}else if(shipmentDetails.recordset[0].Status=='Arrival'){
												var message = 'The subjected shipment has arrived destination port, currently its under customs clearance process.'
											}else if(shipmentDetails.recordset[0].Status=='Delivery'){
												var message = 'The subjected shipment has been delivered to consignee.'
											}else{
												var message = ''
											}
											if(message){
												var ccArr = [];
												var email = element.email
												var subject = "Export shipment -- Tracking No: "+shipmentDetails.recordset[0].Tracking_No+" , Invoice_No:"+shipmentDetails.recordset[0].Invoice_No
												var messageObject = { ccArr: ccArr, email: email, name:element.fullname,message:message,subject:subject}
												emails.shipmentStatusMail(messageObject)
											}
											console.log('495',message)
											
										})
									}
									
								}else{
								    console.log('mail0')	
								}
                            }else{
								console.log(element.shipmentType,element)
							}
                           
						   if(element.subscrionId == 3){
							   console.log(shipmentsql)
							    res.status(200).json({"status": true, "data": shipmentDetails});	
						   }
						   
                        })

                    });
                                    
                   
                }
            });      
});

app.post('/export-reports', function(req, res){
    if(req.body.userId){
		
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
		var days = data.days?data.days:0;
		var No_of_days_Door_to_Port = data.No_of_days_Door_to_Port?data.No_of_days_Door_to_Port:100;
		var Clearance_BSO_NON_BSO = data.Clearance_BSO_NON_BSO?data.Clearance_BSO_NON_BSO:'';
        if(data.fromDate){
		 
		var Datess = new Date(data.fromDate);
		var  d2 = new Date ( Datess )

		d2.setMinutes ( d2.getMinutes() - 1 );
		var fromDate =dateFormat(d2, "dd-mmm-yy")+' 00:00:00';
		var DateToDate = new Date(data.toDate);

		DateToDate.setMinutes ( DateToDate.getMinutes() - 1 );
		var toDate =dateFormat(DateToDate, "dd-mmm-yy");
		
		var regions = ['APAC','US','EU','Middle East']
		if(data.regions && Array.isArray(data.regions) &&  data.regions.length > 0){
			var regions = data.regions
		}  
		var Zonewhere=''
		var Destinationwhere=''
		var where_No_of_days_Door_to_Door=''
		if(regions.length > 0){
			let key =''
			for(let a=0; a < regions.length; a++){
				key += "'"+regions[a]+"'"
				let lastone = (regions.length) -1
                if( a < lastone){
					key +=','	
				}
			}
			
			Zonewhere = "AND Zone_Sales_District in ("+key+")"
		}
		if(data.Destination && Array.isArray(data.Destination) &&  data.Destination.length > 0){
			let key =''
			for(let a=0; a < data.Destination.length; a++){
				key += "'"+data.Destination[a]+"'"
				let lastone = (data.Destination.length) -1
                if( a < lastone){
					key +=','	
				}
			}
			
			Destinationwhere = " AND Destination in ("+key+")"
		}
		
		  var sql = "SELECT CONVERT(date,Invoice_Date),Clearance_BSO_NON_BSO,SBU_location,Carrier,Zone_Sales_District,No_of_days_Door_to_Door,No_of_days_Door_to_Port from gvk_export_shipments WHERE CONVERT(date,Invoice_Date) BETWEEN CONVERT(date,'"+fromDate+"') AND CONVERT(date,'"+toDate+"') "+Zonewhere + Destinationwhere  +"; SELECT Carrier from gvk_export_shipments WHERE CONVERT(date,Invoice_Date) BETWEEN CONVERT(date,'"+fromDate+"') AND CONVERT(date,'"+toDate+"') "+Zonewhere + Destinationwhere +"GROUP BY Carrier; SELECT Zone_Sales_District from gvk_export_shipments WHERE CONVERT(date,Invoice_Date) BETWEEN CONVERT(date,'"+fromDate+"') AND CONVERT(date,'"+toDate+"') "+Zonewhere + Destinationwhere +"GROUP BY Zone_Sales_District" ;
	     }else{
	         //var sql = "SELECT * from gvk_export_shipments";
			 res.status(400).json({ "message": 'Send required fields'});
			 return
         }
		 
		db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err,sql:sql});	
            }else{
				var ress = recordset.recordset;
				var carriersObj = recordset.recordsets[1];
				var Zone_Sales_DistrictObj = recordset.recordsets[2];
				
				let region = {}
				let EUR_reg = {}
				let US_reg = {}
				let FedEx = {}
	   var carriers = []
		carriersObj.forEach(({Carrier}) => carriers.push(Carrier));

		if(data.carriers && Array.isArray(data.carriers) && data.carriers.length > 0){
			var carriers = data.carriers
		}
			
		
			
		
		let TotalsByCarrier = {}
	regions.forEach(regW =>{
	    let APAC_rej = {}
	    let TotalCarrier = []
	    
		for(let c = 0; c < carriers.length; c++){
			
		let FedEx_WA = {}
		let carrir = carriers[c]
		let FedEx_BLR = {}
		let FedEx_NRM = {}
		let FedEx_MPR = {}
		let FedEx_MLR = {}
		let FedEx_NRM_MFG = {}
		let FedEx_Vizaq = {}
		let FedEx_OTHER = {}
		let FedEx_Tot = {}
		
		
		var FedEx_nos = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir))

		if(carrir === 'WC' || carrir === 'Marken' || carrir === 'UPS' || carrir === 'DHL' || carrir === 'FedEx'){
		
		
			
		var FedEx_wa_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir)).length
		var FedEx_BLR_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === 'BLR') ).length
		var FedEx_NRM_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === 'NRM') ).length
		var FedEx_MPR_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === 'MPR') ).length
		var FedEx_MLR_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === 'MLR') ).length
		
		var FedEx_NRM_MFG_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === 'NRM-MFG') ).length
		var FedEx_Vizaq_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && item.SBU_location === 'Vizaq') ).length
		
		
		var FedEx_OTHER_no = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir && (item.SBU_location !== 'BLR' && item.SBU_location !== 'NRM' && item.SBU_location !== 'MLR' && item.SBU_location !== 'MPR' && item.SBU_location !== 'NRM-MFG' && item.SBU_location !== 'Vizaq') ) ).length
		
		
		var FedEx_wa_onTime = ress.filter(item => (item.Zone_Sales_District === regW && item.Carrier === carrir)).length
	
		var FedEx_BLR_onTime = FedExOnTime(ress,regW,carrir,'BLR',Clearance_BSO_NON_BSO,days)
		var FedEx_NRM_onTime = FedExOnTime(ress,regW,carrir,'NRM',Clearance_BSO_NON_BSO,days)
		var FedEx_MPR_onTime = FedExOnTime(ress,regW,carrir,'MPR',Clearance_BSO_NON_BSO,days)
		var FedEx_NRM_MFG_onTime = FedExOnTime(ress,regW,carrir,'Vizaq',Clearance_BSO_NON_BSO,days)
		var FedEx_Vizaq_onTime = FedExOnTime(ress,regW,carrir,'NRM-MFG',Clearance_BSO_NON_BSO,days)
		var FedEx_OTHER_onTime = 0	
		
		
				FedEx_BLR['no'] =FedEx_BLR_no
				FedEx_NRM['no'] = FedEx_NRM_no
				FedEx_MPR['no'] =FedEx_MPR_no
				FedEx_MLR['no'] =FedEx_MLR_no
				FedEx_NRM_MFG['no'] =FedEx_NRM_MFG_no
				FedEx_Vizaq['no'] =FedEx_Vizaq_no
				FedEx_OTHER['no'] =FedEx_OTHER_no
				FedEx_Tot['no'] =FedEx_BLR_no+FedEx_NRM_no+FedEx_MPR_no+FedEx_MLR_no+FedEx_Vizaq_no+FedEx_NRM_MFG_no+FedEx_OTHER_no
					
				FedEx_BLR['onTime'] =FedEx_BLR_onTime
				FedEx_NRM['onTime'] = FedEx_NRM_onTime
				FedEx_MPR['onTime'] =FedEx_MPR_onTime
				FedEx_MLR['onTime'] =FedEx_MLR_onTime
				FedEx_NRM_MFG['onTime'] =FedEx_NRM_MFG_onTime
				FedEx_Vizaq['onTime'] =FedEx_Vizaq_onTime
				FedEx_OTHER['onTime'] =FedEx_OTHER_onTime
				FedEx_Tot['onTime'] =FedEx_BLR_onTime+FedEx_NRM_onTime+FedEx_MPR_onTime+FedEx_MLR_onTime+FedEx_Vizaq_onTime+FedEx_NRM_MFG_onTime+FedEx_OTHER_onTime
				
				FedEx_BLR['delay'] =Math.abs(FedEx_BLR_no - FedEx_BLR_onTime);
				FedEx_NRM['delay'] = Math.abs(FedEx_NRM_no - FedEx_NRM_onTime)
				FedEx_MPR['delay'] = Math.abs(FedEx_MPR_no - FedEx_MPR_onTime)
				FedEx_MLR['delay'] =Math.abs(FedEx_MLR_no - FedEx_MLR_onTime)
				FedEx_NRM_MFG['delay'] =Math.abs(FedEx_NRM_MFG_no - FedEx_NRM_MFG_onTime)
				FedEx_Vizaq['delay'] =Math.abs(FedEx_Vizaq_no - FedEx_Vizaq_onTime)
				FedEx_OTHER['delay'] =Math.abs(FedEx_OTHER_no - FedEx_OTHER_onTime)
				FedEx_Tot['delay'] =Math.abs(FedEx_Tot['no'] - FedEx_Tot['onTime'])
				
				
				
				FedEx_WA['BLR'] = FedEx_BLR
				FedEx_WA['NRM'] = FedEx_NRM
				FedEx_WA['MPR'] = FedEx_MPR
			//	FedEx_WA['MLR'] = FedEx_MLR
				FedEx_WA['NRM-MFG'] = FedEx_NRM_MFG
				FedEx_WA['Vizaq'] = FedEx_Vizaq
				//FedEx_WA['OTHER'] = FedEx_OTHER
				FedEx_WA['WA/Total'] = FedEx_Tot
				
				APAC_rej[carrir] =FedEx_WA	
				TotalCarrier[carrir] =FedEx_Tot	
			
		}else{			
		var FedEx_wa_no = ress.filter(item => (item.Zone_Sales_District === regW )).length
		var FedEx_BLR_no = ress.filter(item => (item.Zone_Sales_District === regW  && item.SBU_location === 'BLR') && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC')).length
		var FedEx_NRM_no = ress.filter(item => (item.Zone_Sales_District === regW  && item.SBU_location === 'NRM') && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC')).length
		var FedEx_MPR_no = ress.filter(item => (item.Zone_Sales_District === regW  && item.SBU_location === 'MPR') && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC')).length
		var FedEx_MLR_no = ress.filter(item => (item.Zone_Sales_District === regW  && item.SBU_location === 'MLR') && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC')).length
		
		var FedEx_NRM_MFG_no = ress.filter(item => (item.Zone_Sales_District === regW && item.SBU_location === 'NRM-MFG') && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC')).length
		var FedEx_Vizaq_no = ress.filter(item => (item.Zone_Sales_District === regW  && item.SBU_location === 'Vizaq') && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC') ).length
				
		var FedEx_OTHER_no = ress.filter(item => (item.Zone_Sales_District === regW  && (item.SBU_location !== 'BLR' && item.SBU_location !== 'NRM' && item.SBU_location !== 'MLR' && item.SBU_location !== 'MPR' && item.SBU_location !== 'NRM-MFG' && item.SBU_location !== 'Vizaq') && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC') ) ).length
		
		
		var FedEx_wa_onTime = ress.filter(item => (item.Zone_Sales_District === regW && (item.Carrier !== 'DHL' && item.Carrier !== 'UPS' && item.Carrier !== 'Marken' && item.Carrier !== 'FedEx' && item.Carrier !== 'WC'))).length
	

		
		
		var FedEx_BLR_onTime = FedExOnTimeOther(ress,regW,'Other','BLR',Clearance_BSO_NON_BSO,days)
		var FedEx_NRM_onTime = FedExOnTimeOther(ress,regW,'Other','NRM',Clearance_BSO_NON_BSO,days)
		var FedEx_MPR_onTime = FedExOnTimeOther(ress,regW,'Other','MPR',Clearance_BSO_NON_BSO,days)
		var FedEx_NRM_MFG_onTime = FedExOnTimeOther(ress,regW,'Other','Vizaq',Clearance_BSO_NON_BSO,days)
		var FedEx_Vizaq_onTime = FedExOnTimeOther(ress,regW,'Other','NRM-MFG',Clearance_BSO_NON_BSO,days)
		var FedEx_OTHER_onTime = 0	
		var FedEx_MLR_onTime = 0		
				
				FedEx_BLR['no'] =FedEx_BLR_no
				FedEx_NRM['no'] = FedEx_NRM_no
				FedEx_MPR['no'] =FedEx_MPR_no
				FedEx_MLR['no'] =FedEx_MLR_no
				FedEx_NRM_MFG['no'] =FedEx_NRM_MFG_no
				FedEx_Vizaq['no'] =FedEx_Vizaq_no
				FedEx_OTHER['no'] =FedEx_OTHER_no
				FedEx_Tot['no'] =FedEx_BLR_no+FedEx_NRM_no+FedEx_MPR_no+FedEx_MLR_no+FedEx_Vizaq_no+FedEx_NRM_MFG_no+FedEx_OTHER_no
					
				FedEx_BLR['onTime'] =FedEx_BLR_onTime
				FedEx_NRM['onTime'] = FedEx_NRM_onTime
				FedEx_MPR['onTime'] =FedEx_MPR_onTime
				FedEx_MLR['onTime'] =FedEx_MLR_onTime
				FedEx_NRM_MFG['onTime'] =FedEx_NRM_MFG_onTime
				FedEx_Vizaq['onTime'] =FedEx_Vizaq_onTime
				FedEx_OTHER['onTime'] =FedEx_OTHER_onTime
				FedEx_Tot['onTime'] =FedEx_BLR_onTime+FedEx_NRM_onTime+FedEx_MPR_onTime+FedEx_MLR_onTime+FedEx_Vizaq_onTime+FedEx_NRM_MFG_onTime+FedEx_OTHER_onTime
				
				FedEx_BLR['delay'] =Math.abs(FedEx_BLR_no - FedEx_BLR_onTime);
				FedEx_NRM['delay'] = Math.abs(FedEx_NRM_no - FedEx_NRM_onTime)
				FedEx_MPR['delay'] = Math.abs(FedEx_MPR_no - FedEx_MPR_onTime)
				FedEx_MLR['delay'] =Math.abs(FedEx_MLR_no - FedEx_MLR_onTime)
				FedEx_NRM_MFG['delay'] =Math.abs(FedEx_NRM_MFG_no - FedEx_NRM_MFG_onTime)
				FedEx_Vizaq['delay'] =Math.abs(FedEx_Vizaq_no - FedEx_Vizaq_onTime)
				FedEx_OTHER['delay'] =Math.abs(FedEx_OTHER_no - FedEx_OTHER_onTime)
				FedEx_Tot['delay'] =Math.abs(FedEx_Tot['no'] - FedEx_Tot['onTime'])
				
				
				
				FedEx_WA['BLR'] = FedEx_BLR
				FedEx_WA['NRM'] = FedEx_NRM
				FedEx_WA['MPR'] = FedEx_MPR
			//	FedEx_WA['MLR'] = FedEx_MLR
				FedEx_WA['NRM-MFG'] = FedEx_NRM_MFG
				FedEx_WA['Vizaq'] = FedEx_Vizaq
			//	FedEx_WA['OTHER'] = FedEx_OTHER
				FedEx_WA['WA/Total'] = FedEx_Tot
								
				APAC_rej['Others'] =FedEx_WA	
				TotalCarrier['Others'] =FedEx_Tot	
								
				
			}
								
				
			}

				
				TotalsByCarrier[regW]=TotalCarrier
				region[regW] = APAC_rej
		
			})
			
		
var loopArraySum = {};
var loopCheck = 0;
var loopArray =  Object.entries(TotalsByCarrier);

loopArray.forEach(([index, val]) => {

var value =  Object.entries(val);

value.forEach(([index1, value1]) => {
if (loopCheck > 0) {
loopArraySum[index1]['totalNo'] = loopArraySum[index1]['totalNo'] + value1.no;
loopArraySum[index1]['onTime'] = loopArraySum[index1]['onTime'] + value1.onTime;
loopArraySum[index1]['delay'] = loopArraySum[index1]['delay'] + value1.delay;
}
else{
var InnerArray = {}
InnerArray['totalNo'] = value1.no;
InnerArray['onTime'] = value1.onTime;
InnerArray['delay'] = value1.delay;
loopArraySum[index1] = InnerArray;
}

});
loopCheck++
});
//loopArraySum['WA / Total'] = {totalNo:totalNo,onTime:onTime,delay:delay}
		
                res.status(200).json({"status": true,count:recordset.recordset.length,region:region,carriers:carriers,TotalsByCarrier:loopArraySum,loopArraySum:TotalsByCarrier});
			
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});
app.post('/export-reports-weekly', function(req, res){
    if(req.body.userId){
		
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
        if(data.fromDate){
		var d1 = new Date ();

		var Datess = new Date(data.fromDate);
		var  d2 = new Date ( Datess )
		d2.setMinutes ( d2.getMinutes() - 1 );
		var fromDate =dateFormat(d2, "dd-mmm-yy")+' 00:00:00';
		var DateToDate = new Date(data.toDate);
		DateToDate.setMinutes ( DateToDate.getMinutes() - 1 );
		var toDate =dateFormat(DateToDate, "dd-mmm-yy");
		
		
		
		
		var fDate = new Date('2021-04-01');
		var fmDate =dateFormat(fDate, "dd-mmm-yy");
		var now = new Date();
		var TDate =dateFormat(now, "dd-mmm-yy");
		   
		  var sql = "SELECT CONVERT(date,Invoice_Date),Clearance_BSO_NON_BSO,Gr_Wt,Net_Wt,UOM,SBU_location,Carrier,Zone_Sales_District,Region,No_of_days_Door_to_Door,No_of_days_Door_to_Port from gvk_export_shipments WHERE CONVERT(date,Landing_Destination_Port) BETWEEN CONVERT(date,'"+fromDate+"') AND CONVERT(date,'"+toDate+"');select Region from gvk_export_shipments Group by Region;SELECT CONVERT(date,Invoice_Date),Clearance_BSO_NON_BSO,Gr_Wt,Net_Wt,UOM,SBU_location,Carrier,Zone_Sales_District,Region,No_of_days_Door_to_Door,No_of_days_Door_to_Port from gvk_export_shipments WHERE CONVERT(date,Landing_Destination_Port) BETWEEN CONVERT(date,'"+fmDate+"') AND CONVERT(date,'"+TDate+"');";
	     }else{
	        var sql = "SELECT * from gvk_export_shipments;select Region from gvk_export_shipments Group by Region";
         }
		db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err,sql:sql});	
            }else{
			var sets ={}
			var regions = ['Chemistry-Japan','Chemistry-US','Chemistry-UK','Chemistry-EU','Chemistry-RoW','Biology','CDS-Japan','CDS-US','CDS-UK','CDS-EU','CDS-RoW','CMS-Japan','CMS-US','CMS-UK','CMS-EU','CMS-RoW','CMS-Domestic','CDS-Domestic','Chemistry-Domestic']
			var regionss = recordset.recordsets[1]
			for(let a=0; a < 2; a++){
				if(a==0){
					var response = recordset.recordsets[0];
				}else{
					var response = recordset.recordsets[2];	
				}
				var allDate ={}
			
				for(let c = 0; c < regions.length; c++){
				 var zone = regions[c]
					var regionWise ={}
					var noItems = response.filter(item => (((item.Region).replace(/\s+/g, ' ').trim()).toLowerCase() === zone.toLowerCase()))
					
					var belowFiveDays = response.filter(item => (((item.Region).replace(/\s+/g, ' ').trim()).toLowerCase() === zone.toLowerCase() && (item.No_of_days_Door_to_Port ==0 || item.No_of_days_Door_to_Port ==1|| item.No_of_days_Door_to_Port ==2|| item.No_of_days_Door_to_Port ==3|| item.No_of_days_Door_to_Port ==4|| item.No_of_days_Door_to_Port ==5))).length
					var SixSeven = response.filter(item => (((item.Region).replace(/\s+/g, ' ').trim()).toLowerCase() === zone.toLowerCase() && (item.No_of_days_Door_to_Port ==6 || item.No_of_days_Door_to_Port ==7))).length
					var EightNine = response.filter(item => (((item.Region).replace(/\s+/g, ' ').trim()).toLowerCase() === zone.toLowerCase() && (item.No_of_days_Door_to_Port ==8 || item.No_of_days_Door_to_Port ==9))).length
					var TenEleven = response.filter(item => (((item.Region).replace(/\s+/g, ' ').trim()).toLowerCase() === zone.toLowerCase() && (item.No_of_days_Door_to_Port ==10 || item.No_of_days_Door_to_Port ==11))).length
					var AboveEleven = response.filter(item => (((item.Region).replace(/\s+/g, ' ').trim()).toLowerCase() === zone.toLowerCase() && item.No_of_days_Door_to_Port >11)).length
					
					let Gr_WtSum = 0;
					let Net_WtSum = 0;
					let No_of_days_Door_to_PortSum = 0;
					let itemsFound = 0;


						for(let g=0; g<noItems.length; g++){
							//console.log(g,noItems[g].Gr_Wt)
							if(noItems[g].Gr_Wt){
								Gr_WtSum = parseFloat(Gr_WtSum) + parseFloat(noItems[g].Gr_Wt)
							}
							if(noItems[g].Net_Wt){
								var Net_WtKgs = 0
								if((noItems[g].UOM).toLowerCase() === 'mg'){
									Net_WtKgs = parseFloat(noItems[g].Net_Wt) / 1000000
								}else if((noItems[g].UOM).toLowerCase() === 'g'){
									Net_WtKgs = parseFloat(noItems[g].Net_Wt) / 1000
								}else if((noItems[g].UOM).toLowerCase() === 'kg'){
									Net_WtKgs = parseFloat(noItems[g].Net_Wt)
								}else{
									Net_WtKgs = 0
								}
								Net_WtSum = parseFloat(Net_WtSum) + Net_WtKgs
							}
							if(noItems[g].No_of_days_Door_to_Port){
								if(parseInt(noItems[g].No_of_days_Door_to_Port) >=0){
									No_of_days_Door_to_PortSum = parseInt(No_of_days_Door_to_PortSum) + parseInt(noItems[g].No_of_days_Door_to_Port)
								}
							}
							
							itemsFound = itemsFound + 1;

						}
						
						if(itemsFound > 0){
							var avg_DTP = No_of_days_Door_to_PortSum / itemsFound;
						}else{
							var avg_DTP = 0
						}
				
					let belowFive = (belowFiveDays/noItems.length)*100
					let SixSevenDays = (SixSeven/noItems.length)*100
					let EightNineDays = (EightNine/noItems.length)*100
					let TenElevenDays = (TenEleven/noItems.length)*100
					let AboveElevenDays = (AboveEleven/noItems.length)*100
					
					regionWise['region'] = zone
					regionWise['noItems'] = noItems.length
					regionWise['Gr_Wt']=Gr_WtSum
					regionWise['Net_Wt']=Net_WtSum
					regionWise['avg_DTP']=avg_DTP
					regionWise['belowFiveDays']=belowFive
					regionWise['SixSeven']=SixSevenDays
					regionWise['EightNine']=EightNineDays
					regionWise['TenEleven']=TenElevenDays
					regionWise['AboveEleven']=AboveElevenDays
					allDate[c]=regionWise
				}
				
				sets[a]=allDate
			
			}
				
				
		
			  res.status(200).json({"status": true,count:sets});
			
            }
        });
    }else{
        res.status(400).json({ "message": 'Send required fields'});
    }
});

app.get('/export-reports-dropdowns', function(req, res){
	
	var regions = ['APAC','US','EU']
	var carriers = ['DHL','FedEx','UPS','Marken','WC']
 res.status(200).json({"status": true,regions:regions,carriers:carriers});
	
	
});
app.get('/export-reports-dropdown-list', function(req, res){
	   var sql = "SELECT Zone_Sales_District FROM gvk_export_shipments Group By Zone_Sales_District;SELECT Zone_Sales_District, Destination FROM gvk_export_shipments";
    db.executeSql(sql, function (err, recordset) {
        if (err) {
            res.status(500).json({"message":err})
        } else {
			var Destination ={}
			var zones = recordset.recordsets[0]
			var counties = recordset.recordsets[1]
			for(let c = 0; c < zones.length; c++){
				var listOfTags = counties.filter(item => (item.Zone_Sales_District === zones[c].Zone_Sales_District));
				const unique = [];

				listOfTags.map(x => unique.filter(a => a.Zone_Sales_District == x.Zone_Sales_District && a.Destination == x.Destination).length > 0 ? null : unique.push(x));

				Destination[zones[c].Zone_Sales_District] = unique
			}
            res.status(200).json({"status":true,zones:zones,counties:Destination})
        }
    });
	
		
	
});
app.post('/export-reports-dropdown-by-zone', function(req, res){
		
		var data = req.body
		var Zonewhere = ''
		if(data.region && Array.isArray(data.region) &&  data.region.length > 0){
			let key =''
			for(let a=0; a < data.region.length; a++){
				key += "'"+data.region[a]+"'"
				let lastone = (data.region.length) -1
                if( a < lastone){
					key +=','	
				}
			}			
			Zonewhere = "Where Zone_Sales_District in ("+key+")"
		}
	   var sql = "SELECT Destination FROM gvk_export_shipments "+Zonewhere+" Group by Destination";
    db.executeSql(sql, function (err, recordset) {
		
        if (err) {
            res.status(500).json({"message":err})
        } else {
			var Destination ={}
			var counties = recordset.recordsets[0]
            res.status(200).json({"status":true,counties:counties})
        }
    });
	
		
	
});
	
	
app.get('/import-reports-zones-list', function(req, res){
	   var sql = "SELECT Zone FROM gvk_import_shipments Group By Zone";
    db.executeSql(sql, function (err, recordset) {
        if (err) {
            res.status(500).json({"message":err})
        } else {
			var Destination ={}
			var zones = recordset.recordsets[0]
			
            res.status(200).json({"status":true,zones:zones})
        }
    });
	
		
	
});

app.get('/import-reports-zones', function(req, res){
	   var sql = "SELECT id,AWB_no,Zone FROM gvk_import_shipments";
    db.executeSql(sql, function (err, recordset) {
        if (err) {
            res.status(500).json({"message":err})
        } else {
			var Destination ={}
			var zones = recordset.recordsets[0]
			
            res.status(200).json({"status":true,zones:zones})
        }
    });
	
		
	
});
app.post('/import-reports', function(req, res){
    //if(req.body.userId){
		
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
		var Date_date_d_f = new Date(data.fromDate);
		var fromDate =dateFormat(Date_date_d_f, "yyyy-mm-dd");
		var Date_date_d_t = new Date(data.toDate);
		var toDate =dateFormat(Date_date_d_t, "yyyy-mm-dd");
		var days = data.days
        var Zonewhere=''
		if(data.zone.length > 0){
			let key =''
			for(let a=0; a < data.zone.length; a++){
				key += "'"+data.zone[a]+"'"
				let lastone = (data.zone.length) -1
                if( a < lastone){
					key +=','	
				}
			}
			Zonewhere = "AND Zone in ("+key+")"
		}
		if(fromDate){
		    var sql = "SELECT * from gvk_import_shipments WHERE Delivery_Date BETWEEN '"+fromDate+"' AND '"+toDate+"' "+Zonewhere;
	    }else{
	        var sql = "SELECT * from gvk_import_shipments";
        }
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err,sql:sql});	
            }else{
				var response = recordset.recordset;
				
				var ClearanceTAT ={}
				var TransitTAT ={}
				var tats = {}
				var tot ={}
				var totalShipments = {}
				var totalShipmentsTat = {}
				
			if(data.category && Array.isArray(data.category) && data.category.length >0){
				var cats = data.category
			}else{
				var cats = ['Clearance TAT','Transit TAT']
			}
				
			cats.forEach(cat=>{
				
				var overAll = {}
				
			if(cat ==='Clearance TAT'){
				
			   
				if(data.cha && Array.isArray(data.cha) && data.cha.length >0){
					var chas = data.cha
				}else{
					var chas = ['DHL','OSBL','CSR','OTHERS']
				}
				var onTime =0
				var totalNo =0
				var delay =0
				
				var onTimes = 0
				var totalNoItems = 0
				  var dataCarier ={}
				 chas.forEach(cha=>{
					
					var dataCar ={}
					if(cha ==='OTHERS'){
						totalNo = response.filter(item => (item.CHA != 'DHL' && item.CHA != 'OSBL' && item.CHA != 'CSR')).length	
					    onTime = response.filter(item => (item.Clearance_TAT <=days && item.CHA != 'DHL' && item.CHA != 'OSBL' && item.CHA != 'CSR')).length	
						delay = Math.abs(totalNo-onTime)
					}else{
						totalNo = response.filter(item => (item.CHA === cha)).length	
					    onTime = response.filter(item => (item.Clearance_TAT <=days && item.CHA === cha)).length
					    delay = Math.abs(totalNo-onTime)
					}
					onTimes = onTimes + onTime
					totalNoItems = totalNoItems + totalNo
					dataCar['totalNo'] = totalNo
					dataCar['onTime'] = onTime
					dataCar['delay'] = delay
					dataCarier[cha] =dataCar
					
				 })
				 
				 totalShipments['totalNo'] = totalNoItems
				 totalShipments['onTime'] = onTimes
				 totalShipments['delay'] = Math.abs(totalNoItems - onTimes)

				 tats[cat] = dataCarier			  
				 tot[cat] = totalShipments			  
				   
			  
			}else if(cat === 'Transit TAT'){
				
				var totalNo_car =0
				var onTime_car =0
				var delay_car =0
				var carriersData = {}
				
				var onTimes = 0
				
				
				if(data.carriers && Array.isArray(data.carriers) && data.carriers.length >0){
					var carriers = data.carriers
				}else{
					var carriers = ['FedEx DG','FedEx-Non DG','FedEx All','DHL DG','DHL-Non DG','OTHERS','DHL All']
				}
			  carriers.forEach(car=>{
					var insideCar = {}
					if(car ==='OTHERS'){
						totalNo_car = response.filter(item => (item.Carrier != 'DHL' && item.Carrier != 'FedEx' && item.Carrier != 'Fedex')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=days && item.Carrier != 'DHL' && item.Carrier != 'FedEx' && item.Carrier != 'Fedex')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
				    }else if(car === 'FedEx DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'Fedex' && item.DG === 'X')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'Fedex' && item.DG === 'X')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'FedEx-Non DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'Fedex' && item.DG === '')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'Fedex' && item.DG === '')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'FedEx All'){
						totalNo_car = response.filter(item => (item.Carrier === 'Fedex')).length	
					    onTime_car = parseInt(response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'Fedex' && item.DG === '')).length)+parseInt(response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'Fedex' && item.DG === 'X')).length)
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'DHL DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'DHL' && item.DG === 'X')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'DHL' && item.DG === 'X')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'DHL-Non DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'DHL' && item.DG === '')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'DHL' && item.DG === '')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'DHL All'){
						totalNo_car = response.filter(item => (item.Carrier === 'DHL')).length	
					    onTime_car = parseInt(response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'DHL' && item.DG === '')).length)+parseInt(response.filter(item => (item.Transit_TAT <=days && item.Carrier === 'DHL' && item.DG === 'X')).length)
						delay_car = Math.abs(totalNo_car - onTime_car)
					}
					insideCar['totalNo']=totalNo_car
					insideCar['onTime']=onTime_car
					insideCar['delay']=delay_car
					TransitTAT[car]=insideCar
					onTimes = onTimes + onTime_car
				
				 totalShipmentsTat['totalNo'] = response.length
				 totalShipmentsTat['onTime'] = onTimes
				 totalShipmentsTat['delay'] = Math.abs(totalShipmentsTat['totalNo'] - totalShipmentsTat['onTime'])
				 
					
				 })
				
							  
				 			 
				  tats[cat] = TransitTAT
				  tot[cat] = totalShipmentsTat
				  
			}
			
			
				  
			})
				  
                res.status(200).json({"status": true,count:recordset.recordset.length,response:tats,totalShipments:tot});	
            }
        });
		
		
		
		
		
   // }else{
     //   res.status(400).json({ "message": 'Send required fields'});
   // }
});
app.post('/import-reports-overAll', function(req, res){
    if(req.body.fromDate && req.body.toDate){
        var data = req.body;
        var userId =data.userId;
        var id =data.id;	
		var Date_date_d_f = new Date(data.fromDate);
		var fromDate =dateFormat(Date_date_d_f, "yyyy-mm-dd");
		var Date_date_d_t = new Date(data.toDate);
		var toDate =dateFormat(Date_date_d_t, "yyyy-mm-dd");
		var Zonewhere=''
		if(data.zone.length > 0){
			let key =''
			for(let a=0; a < data.zone.length; a++){
				key += "'"+data.zone[a]+"'"
				let lastone = (data.zone.length) -1
                if( a < lastone){
					key +=','	
				}
			}
			Zonewhere = "AND Zone in ("+key+")"
		}
		var ClearanceDays = { 'DHL':2,'OSBL':2,'CSR':2,'OTHERS':2 }
		var TransitDays = { 'FedEx DG':5,'FedEx-Non DG':4,'FedEx All':4,'DHL DG':5,'DHL-Non DG':4,'OTHERS':3,'DHL All':4 }
        if(fromDate){
		    var sql = "SELECT * from gvk_import_shipments WHERE Delivery_Date BETWEEN '"+fromDate+"' AND '"+toDate+"' "+Zonewhere;
	     }else{
	        var sql = "SELECT * from gvk_import_shipments";
         }
        db.executeSql(sql, function(err, recordset){
            if(err){
                res.status(500).json({ "message": err,sql:sql});	
            }else{
				var response = recordset.recordset;
				var ClearanceTAT ={}
				var TransitTAT ={}
				var tats = {}
				var tot ={}
				var totalShipments = {}
				var totalShipmentsTat = {}
				
			if(data.category && Array.isArray(data.category) && data.category.length >0){
				var cats = data.category
			}else{
				var cats = ['Clearance TAT','Transit TAT']
			}
				
			cats.forEach(cat=>{
				
				var overAll = {}
				
			if(cat ==='Clearance TAT'){
				
			   
				if(data.cha && Array.isArray(data.cha) && data.cha.length >0){
					var chas = data.cha
				}else{
					var chas = ['DHL','OSBL','CSR','OTHERS']
				}
				
				var onTime =0
				var totalNo =0
				var delay =0
				
				var onTimes = 0
				var totalNoItems = 0
				  var dataCarier ={}
				 chas.forEach(cha=>{
					
					var dataCar ={}
					if(cha ==='OTHERS'){
						totalNo = response.filter(item => (item.CHA != 'DHL' && item.CHA != 'OSBL' && item.CHA != 'CSR')).length	
					    onTime = response.filter(item => (item.Clearance_TAT <=ClearanceDays[cha] && item.CHA != 'DHL' && item.CHA != 'OSBL' && item.CHA != 'CSR')).length	
						delay = Math.abs(totalNo-onTime)
					}else{
						totalNo = response.filter(item => (item.CHA === cha)).length	
					    onTime = response.filter(item => (item.Clearance_TAT <=ClearanceDays[cha] && item.CHA === cha)).length
					    delay = Math.abs(totalNo-onTime)
						//console.log(totalNo,ClearanceDays[cha])
					}
					onTimes = onTimes + onTime
					totalNoItems = totalNoItems + totalNo
					dataCar['totalNo'] = totalNo
					dataCar['onTime'] = onTime
					dataCar['delay'] = delay
					dataCarier[cha] =dataCar
					
				 })
				 totalShipments['totalNo'] = totalNoItems
				 totalShipments['onTime'] = onTimes
				 totalShipments['delay'] = Math.abs(totalNoItems - onTimes)
				 tats[cat] = dataCarier			  
				 tot[cat] = totalShipments			  
				   
				  
			  
			}else if(cat === 'Transit TAT'){
				
				var totalNo_car =0
				var onTime_car =0
				var delay_car =0
				var carriersData = {}
				
				var onTimes = 0
				var totlaItems = 0
				
				
				if(data.carriers && Array.isArray(data.carriers) && data.carriers.length >0){
					var carriers = data.carriers
				}else{
					var carriers = ['FedEx DG','FedEx-Non DG','FedEx All','DHL DG','DHL-Non DG','OTHERS','DHL All']
				}
			  carriers.forEach(car=>{
					var insideCar = {}
					if(car ==='OTHERS'){
						totalNo_car = response.filter(item => (item.Carrier != 'DHL' && item.Carrier != 'FedEx' && item.Carrier != 'Fedex')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=TransitDays[car] && item.Carrier != 'DHL' && item.Carrier != 'FedEx' && item.Carrier != 'Fedex')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
				    }else if(car === 'FedEx DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'Fedex' && item.DG === 'X')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=TransitDays[car] && item.Carrier === 'Fedex' && item.DG === 'X')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'FedEx-Non DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'Fedex' && item.DG === '')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=TransitDays[car] && item.Carrier === 'Fedex' && item.DG === '')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'FedEx All'){
						totalNo_car = response.filter(item => (item.Carrier === 'Fedex' || item.Carrier === 'FedEx')).length	
					    onTime_car = parseInt(response.filter(item => (item.Transit_TAT <=TransitDays[car] && (item.Carrier === 'Fedex' || item.Carrier === 'FedEx') && item.DG === '')).length)+parseInt(response.filter(item => (item.Transit_TAT <=TransitDays[car] && (item.Carrier === 'Fedex' || item.Carrier === 'FedEx') && item.DG === 'X')).length)
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'DHL DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'DHL' && item.DG === 'X')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=TransitDays[car] && item.Carrier === 'DHL' && item.DG === 'X')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'DHL-Non DG'){
						totalNo_car = response.filter(item => (item.Carrier === 'DHL' && item.DG === '')).length	
					    onTime_car = response.filter(item => (item.Transit_TAT <=TransitDays[car] && item.Carrier === 'DHL' && item.DG === '')).length
						delay_car = Math.abs(totalNo_car - onTime_car)
					}else if(car === 'DHL All'){
						totalNo_car = response.filter(item => (item.Carrier === 'DHL')).length	
					    onTime_car = parseInt(response.filter(item => (item.Transit_TAT <=3 && item.Carrier === 'DHL' && item.DG === '')).length)+parseInt(response.filter(item => (item.Transit_TAT <=4 && item.Carrier === 'DHL' && item.DG === 'X')).length)
						delay_car = Math.abs(totalNo_car - onTime_car)
					}
					insideCar['totalNo']=totalNo_car
					insideCar['onTime']=onTime_car
					insideCar['delay']=delay_car
					TransitTAT[car]=insideCar
					
					
					onTimes = onTimes + onTime_car
					totlaItems = totlaItems + totalNo_car
				
				 totalShipmentsTat['totalNo'] = totlaItems
				 totalShipmentsTat['onTime'] = onTimes
				 totalShipmentsTat['delay'] = Math.abs(totlaItems - onTimes)
				 
					
				 })
				 tats[cat] = TransitTAT
				 tot[cat] = totalShipmentsTat
				  
			}
			
			
				  
			})
				  
                res.status(200).json({"status": true,count:recordset.recordset.length,response:tats,totalShipments:tot,params:data});	
            }
        });
		
		
		
		
		
    }else{
      res.status(400).json({ "message": 'Send required fields'});
    }
});
app.post('/fedex-live-track', function(req, res){
    if(req.body.id){
		var url = 'https://apis.fedex.com/oauth/token';
		var url2 = 'https://apis.fedex.com/track/v1/trackingnumbers';
		var form = { 
			'grant_type':'client_credentials',
			'client_id':'l758a94235460a403a8a21e459f0b42c91',
			'client_secret':'c3c54648f5db40b8bfeb64dfea2c6d11'
		};

	var headers = {};
		
	  request.post({ url: url, form: form, headers: headers ,json: true }, function(error, response, body) {
			if (!error && response.statusCode == 200) {
				var access_token = body.access_token
				var options = {
					  'method': 'POST',
					  'url': 'https://apis.fedex.com/track/v1/trackingnumbers',
					  'headers': {
						'x-customer-transaction-id': ' 624deea6-b709-470c-8c39-4b5511281492',
						'content-type': ' application/json',
						'authorization': 'Bearer '+access_token
					  },
				body: '{"includeDetailedScans": true,"trackingInfo": [{"trackingNumberInfo": {"trackingNumber": "'+req.body.id+'"}}]}',
				json:false
				};
				request(options, function (error, response) {
				  if (error) throw new Error(error);
					res.status(200).json({error:error, response:JSON.parse(response.body), message: 'Not found'});
				});
				
			}else{
				      res.status(response.statusCode).json({error:error, response:response,headers:headers, message: 'failed1'});
			}
		
			})	
     
	}else{
      res.status(400).json({ "message": 'Send required fields'});
    }
});

module.exports = app;