const fs = require('fs');
const path = require('path');
var template = require('es6-template-strings');
const emailer_kairos = require('../emailhost-kairos');
const config = require('../config/index')


exports.shipmentStatusMail = (messageObj, callback) => {
  var blindSchoolEmailTemplate = path.join(__dirname, '/shipmentStatusMail.html')
  fs.readFile(blindSchoolEmailTemplate, "utf8", function (error, temp) {
    var message = template(temp, {
      name: messageObj.name,
      message: messageObj.message
    });
	
    var ccArr=messageObj.ccArr;
    var subject = messageObj.subject;
    var toArr = messageObj.email
    var from=config.fromKairosAdd;
    var bccArr= '';
    emailer_kairos.email(toArr, ccArr, bccArr, from, subject, message, function (err, result) {
      callback(err, result);
    })
  })
}
