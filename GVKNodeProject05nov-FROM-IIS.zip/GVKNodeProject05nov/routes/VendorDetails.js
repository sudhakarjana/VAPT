'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.get('/vendorName', function(req, res){
    console.log('connection established')
    db.executeSql("select * from Vendor", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/SBU', function(req, res){
    db.executeSql("select * from SBU", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/Category', function(req, res){
    db.executeSql("select * from Category", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/Country', function(req, res){
    db.executeSql("select * from Country", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/Status', function(req, res){
    db.executeSql("select * from Status", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/Carrier', function(req, res){
    db.executeSql("select * from Carrier", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/Port_of_clearance', function(req, res){
    db.executeSql("select * from Port_of_clearance", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/CHA', function(req, res){
    db.executeSql("select * from CHA", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

app.get('/RFR', function(req, res){
    db.executeSql("select * from RFR", function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         //console.log('response',recordset);
         res.send(recordset)
    });
});

module.exports = app;
