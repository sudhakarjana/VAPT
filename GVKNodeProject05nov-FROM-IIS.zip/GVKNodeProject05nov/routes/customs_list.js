'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');
var dateFormat = require('dateformat');

app.get('/chalist', function(req, res){
	var datess=dateFormat(43685, "d-mmm-yyyy");
	console.log(datess);
	var sql = "select * from gvk_customs_handling_agent ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});
app.get('/getcha/:ID', function(req, res){
    const id = req.params.ID;
    var sql = "select * from gvk_customs_handling_agent where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});

app.post('/chaAdd', function(req, res){
    var data = req.body;
    var sql = "INSERT INTO gvk_customs_handling_agent (cha_name, create_By) VALUES";
    sql += util.format("('%s','%s')", data.cha_name, 1)    
     db.executeSql(sql, function(err, recordset){
            if(err){
            console.log("Error in the query")
          } else{
            res.send(JSON.stringify(recordset))
          }
    });
});

app.put('/chaUpdate/:ID', function(req, res){
    const id = req.params.ID;
    var data= req.body;
    var sql = "UPDATE gvk_customs_handling_agent SET cha_name='"+data.cha_name+"' where ID="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is here", err);
        else
        res.send(recordset)
    })
})

app.delete('/deleteCha/:ID', function(req, res){
    console.log('connection established')
    const id = req.params.ID;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_customs_handling_agent WHERE ID="+id+";";
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})
module.exports = app;