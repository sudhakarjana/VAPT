// const sql = require('mssql');
// var config = {
//     user:'KAIROS013\Veni',
//     password:'Admin@1234',
//     server:'KAIROS013\\SQLEXPRESS', 
//     database:'gvkdatabase' 
// };
// const connection = new sql.ConnectionPool(config); // sql.Connection is not a constructor

var sql = require('mssql');
var Connection = require('tedious').Connection
var Request = require('tedious').Request
var express = require('express');
var app = express();
var config = {
    server: 'KAIROS013\\SQLEXPRESS',
    database: 'gvkdatabase',
    username :'sa',
    password : 'Admin@1234',
    
};
var connection = new Connection(config)
connection.on('connect', function (err) {
    if (err) {
      console.log(err)
    } else {
      executeStatement()
    }
  })
  function executeStatement () {
    request = new Request("select * from dbo.user_details", function (err, rowCount) {
      if (err) {
        console.log(err)
      } else {
        console.log(rowCount + ' rows')
      }
      connection.close()
    })
  
    request.on('row', function (columns) {
      columns.forEach(function (column) {
        if (column.value === null) {
          console.log('NULL')
        } else {
          console.log(column.value)
        }
      })
    })
  
    connection.execSql(request)
}