
// Flatpickr
$(function () {
  // Date
  $('input[name="Date"], input[name="shpt_land_dt"], input[name="Rev_info"], input[name="Delivery_Date"], input[name="Expected_Date_Delivery"], input[name="Expected_Date_Delivery"], input[name="Pick_up_date"], input[name="Docs_shared_date"], input[name="Shipping_Documents_Shared_Date"], input[name="BE_Date"], input[name="CR_DM_Date"], input[name="Invoice_Date"], input[name="Shipment_Day_of_pick_up"], input[name="Departure_from_India"], input[name="Landing_Destination_Port"], input[name="Destination_Customs_release_date"], input[name="Date_of_Delivery_to_client"], input[name="LEO_Date"], input[name="SB_origina_Date_of_receipt"], input[name="Shipping_Bill_Date"], input[name="SB_original_Date_of_receipt"]').flatpickr({
	dateFormat: "Y-m-d",
  });

  // Time
  $('input[name="Compound_DM_Time"]').flatpickr({
    dateFormat:"H:i", 
    enableTime: true,
    noCalendar: true,
	time_24hr: true    
  });

  // Datetime
  $('#flatpickr-datetime').flatpickr({
    enableTime: true,
    altInput: true
  });

  // Full
  $('#flatpickr-full').flatpickr({
    weekNumbers: true,
    enableTime: true,
    mode: 'multiple',
    minDate: 'today',
    altInput: true
  });

  // Range
  $('#flatpickr-range').flatpickr({
    mode: 'range',
    altInput: true
  });

  // Inline
  $('#flatpickr-inline').flatpickr({
    inline: true,
    altInput: true,
    allowInput: false
  });
});


$('input[name="NRM"], input[name="MPR"], input[name="BLR"], input[name="VPO"], input[name="No_of_chem"], input[name="Clearance_Charges"], input[name="Freight"], input[name="Penalty_Charges"], input[name="QTY"], input[name="SAP_Ref_No"], input[name="HS_Code_No"], input[name="No_of_Boxes"], input[name="Gr_Wt"], input[name="Net_Wt"], input[name="Invoice_Value"], input[name="Shipping_Bill_Number"], input[name="MAWB"]').keypress(validateNumber);

function validateNumber(event) {
	var key = window.event ? event.keyCode : event.which;
    if (event.keyCode === 8 ) {
        return true;
    } else if ( key < 48 || key > 57 ) {
        return false;
    } else {
        return true;
    }
};	
$('input[name="LEO_No"]').keypress(validateNumberSlash);
function validateNumberSlash(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode !== 47) 
    {
        return false;
    }
    return true;
};
function calc()
{
var start = moment("2013-11-03");
var end = moment("2013-11-05");
var car = end.diff(start, "days");
alert(car);
}

$('input[name="Date"],input[name="Landing_Destination_Port"]').change(function() {
 var t1=$('.LDP').val();	
 var t2=$('.Datep').val();	
 if(t1 && t2){
	var start = moment(t2);
	var end = moment(t1);
	var cal = end.diff(start, "days");	
	$('#No_of_days_Door_to_Port_val').val(cal);
 }	
});

$('input[name="Date"],input[name="Date_of_Delivery_to_client"]').change(function() {
 var t1=$('.DDC').val();	
 var t2=$('.Datep').val();	
 if(t1 && t2){
	var start = moment(t2);
	var end = moment(t1);
	var cal = end.diff(start, "days");	
	$('#nddd').val(cal);
 }	
});