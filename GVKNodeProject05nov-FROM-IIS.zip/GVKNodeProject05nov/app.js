var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser');
var usersDetails = require('./routes/userDetails');
var imporRecords = require('./routes/imporRecords');
var VendorDetails=require('./routes/VendorDetails');
var vendors = require('./routes/vendor_list');
var carriers = require('./routes/carrier_list');
var users = require('./routes/users_list');
var countries = require('./routes/country_list');
var cha = require('./routes/customs_list');
var currencies = require('./routes/currencies_list');
var settings = require('./routes/setting.js');
var services = require('./routes/services');
var testProductDetails = require('./routes/test_sql');
var exportRecords = require('./routes/exportRecords');
var mongodb = require('./mongodb/index');
var mssql = require('./mssql/index')
var cors = require('cors')
var dateFormat = require('dateformat');
const dotenv                = require('dotenv').config();
var app = express();

app.use(cors());
app.use(function (req, res, next) {
	let headers = req.headers
	//console.log(36,headers)
	
    next();
});

process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;
//process.env["NODE_TLS_REJECT_UNAUTHORIZED"] = 1;

// view engine setup
//mongodb.mongoPool.start();
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, './client/dist/client')));

// app.use('/index', indexRouter);
app.use('/users', usersDetails);
app.use('/import', imporRecords);
app.use('/dropDown', VendorDetails);
app.use('/Details', testProductDetails);
app.use('/export', exportRecords);
app.use('/vendor', vendors);
app.use('/carrier', carriers);
app.use('/users', users);
app.use('/country', countries);
app.use('/cha', cha);
app.use('/currency', currencies);
app.use('/settings', settings);
app.use('/api', services);


app.get('*', function (req, res) {
    console.log("headers for index -->", JSON.stringify(req.headers));
    res.sendFile(path.join(__dirname, './client/dist/client/index.html'));
});


module.exports = app;
