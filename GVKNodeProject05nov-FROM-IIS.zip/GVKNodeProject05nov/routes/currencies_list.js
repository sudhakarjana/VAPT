'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.get('/currencies', function(req, res){
    var sql = "select * from gvk_foreign_currency ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});
app.get('/getcurrency/:ID', function(req, res){
    const id = req.params.ID;
    var sql = "select * from gvk_foreign_currency where ID="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});

app.post('/currenciesadd', function(req, res){
    console.log('connection established')
   var data = req.body;
    var sql = "INSERT INTO gvk_foreign_currency (currency_name, export_value, import_value, create_by) VALUES";
    sql += util.format("('%s','%s','%s','%s')", data.currency_name, data.export_value, data.import_value, 1 )    
     db.executeSql(sql, function(err, recordset){
            if(err){
            console.log("Error in the query", err)
          } else{
            //console.log('record inserted')
            res.send(JSON.stringify(recordset))
          }
    });
});

app.put('/currenciesUpdate/:ID', function(req, res){
    console.log("SQL Conncection established");
    const id = req.params.ID;
    var data= req.body;
    data.Update_Date = new Date();
    var sql = "UPDATE gvk_foreign_currency SET currency_name='"+data.currency_name+"', export_value='"+data.export_value+"', import_value='"+data.import_value+"' where ID="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is here", err);
        else
        res.send(recordset)
    })
})

app.delete('/removeDetails/:ID', function(req, res){
    console.log('connection established')
    const id = req.params.ID;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_foreign_currency WHERE ID="+id+";";
    console.log("query",sql)
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})
module.exports = app;