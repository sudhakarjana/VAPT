'use strict';
var express = require('express');
var sql = require('mssql');
var app = express.Router();
var db = require('../mssql/index');
var util = require('util');

app.get('/pageslist', function(req, res){
    var sql = "select * from gvk_settings ORDER BY id DESC";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
        res.send(JSON.stringify(recordset.recordset));
        }
    });
});
app.get('/pagedetails/:ID', function(req, res){
    const id = req.params.ID;
    var sql = "select * from gvk_settings where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log('error is:', err)
        else{
         res.send(JSON.stringify(recordset.recordset));
        }
    });
});

app.post('/pageAdd', function(req, res){
    console.log('connection established')
   var data = req.body;
   var sql = "INSERT INTO gvk_settings (page_name, page_description) VALUES";
    sql += util.format("('%s','%s')", data.page_name, data.page_description)    
     db.executeSql(sql, function(err, recordset){
            if(err){
            console.log("Error in the query")
          } else{
            res.send(JSON.stringify(recordset))
          }
    });
});

app.put('/pageUpdate/:ID', function(req, res){
    const id = req.params.ID;
    var data= req.body;
	var datades =data.page_description;
	var description = datades.replace("'", "");
    var sql = "UPDATE gvk_settings SET page_description='"+description+"' where id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if(err)
        console.log("error is here", err);
        else
        res.send(recordset)
    })
})

app.delete('/Deletepage/:ID', function(req, res){
    const id = req.params.ID;
    console.log("ID ID", id)
    var sql = "DELETE FROM gvk_settings WHERE id="+id+";";
    db.executeSql(sql, function(err, recordset){
        if (err)        
        console.log('error is here', err);
         else  
         res.send(recordset)
    });
})
module.exports = app;