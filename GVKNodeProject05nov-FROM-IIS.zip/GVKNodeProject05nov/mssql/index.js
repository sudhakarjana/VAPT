'use strict';
var express = require('express');
var app = express();
var sqlDb = require("mssql");

var config ={
  user:'sa',
  password:'M0b1le@ppdb',
  server:'GVKMOBAPP', 
  database:'EximTracker',
  port:1433,
  requestTimeout: 300000000,
  ConnectionPool:50
}

exports.executeSql = function(sql, callback){
  var conn = new sqlDb.ConnectionPool(config)
  conn.connect()
  .then(function( ){
      var req= new sqlDb.Request(conn);
      req.query(sql,function(err,recordset){
        if (err){
        console.log('error is here', err);
        callback(err,null)
        }else{
         // console.log('response',recordset);
          callback(null,recordset)
        }
         
      })
  })
  .catch(function(err){
    console.log(err);
    callback(null, err);

})
};
// function GetData(){
  
//     console.log('connection established')
//     console.log("FGHJK", req)
//     req.query("select * from veni", function(err, recordset){
//         if (err)        
//         console.log('error is here', err);
//          else  
//          console.log('response',recordset);
//     });
//   });
// }

// GetData();
